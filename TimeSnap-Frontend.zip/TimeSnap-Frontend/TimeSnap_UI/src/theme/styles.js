import { mode } from "@chakra-ui/theme-tools";

export const globalStyles = {
  colors: {
    brand: {
      100: "#E6F4FF",
      200: "#B8E0FF",
      300: "#7FC5FF",
      400: "#4AA7FF",
      500: "#1E88FF",
      600: "#0D6EDE",
      700: "#0A57B0",
      800: "#0B447F",
      900: "#0D315B",
    },
    brandScheme: {
      100: "#E6F4FF",
      200: "#B8E0FF",
      300: "#7FC5FF",
      400: "#4AA7FF",
      500: "#1E88FF",
      600: "#0D6EDE",
      700: "#0A57B0",
      800: "#0B447F",
      900: "#0D315B",
    },
    brandTabs: {
      100: "#E6F4FF",
      200: "#B8E0FF",
      300: "#7FC5FF",
      400: "#4AA7FF",
      500: "#1E88FF",
      600: "#0D6EDE",
      700: "#0A57B0",
      800: "#0B447F",
      900: "#0D315B",
    },
    secondaryGray: {
      100: "#EEF2F8",
      200: "#E6ECF5",
      300: "#DDE6F2",
      400: "#C9D6E8",
      500: "#8A9BB2",
      600: "#6B7C95",
      700: "#4C5D76",
      800: "#36445B",
      900: "#1E2A3D",
    },
    red: {
      100: "#FEECEE",
      500: "#E65B66",
      600: "#C73D4B",
    },
    blue: {
      50: "#EFF6FF",
      500: "#1E88FF",
    },
    orange: {
      100: "#FFF4E5",
      500: "#F59E0B",
    },
    green: {
      100: "#E9F8F1",
      500: "#20A36A",
    },
    navy: {
      50: "#D7E4F8",
      100: "#B8CBEE",
      200: "#9CB2DF",
      300: "#7E97CD",
      400: "#607CB8",
      500: "#47629B",
      600: "#354C7C",
      700: "#25395D",
      800: "#1A2A45",
      900: "#111D33",
    },
    gray: {
      100: "#F7FAFC",
    },
  },
  semanticTokens: {
    colors: {
      "bg.canvas": {
        default: "#F4F7FB",
        _dark: "#0F172A",
      },
      "bg.surface": {
        default: "#FFFFFF",
        _dark: "#111827",
      },
      "border.subtle": {
        default: "#E2E8F0",
        _dark: "#334155",
      },
      "text.primary": {
        default: "#0F172A",
        _dark: "#E2E8F0",
      },
      "text.muted": {
        default: "#64748B",
        _dark: "#94A3B8",
      },
      "accent.primary": {
        default: "#1E88FF",
        _dark: "#60A5FA",
      },
      "accent.soft": {
        default: "#E6F4FF",
        _dark: "#1E3A8A",
      },
    },
  },
  styles: {
    global: (props) => ({
      body: {
        overflowX: "hidden",
        bg: mode("bg.canvas", "#0F172A")(props),
        color: mode("text.primary", "#E2E8F0")(props),
        fontFamily: "'Plus Jakarta Sans', 'DM Sans', system-ui, -apple-system, sans-serif",
        letterSpacing: "-0.01em",
      },
      input: {
        color: "gray.700",
      },
      html: {
        fontFamily: "'Plus Jakarta Sans', 'DM Sans', system-ui, -apple-system, sans-serif",
      },
      "*::placeholder": {
        color: mode("#94A3B8", "#64748B")(props),
      },
    }),
  },
};
