import React, { useEffect, useMemo, useRef, useState } from "react";
import { logoutUser } from "utils/authUtils";
import { useAuth } from "contexts/AuthContext";
import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogOverlay,
  Box,
  Button,
  Drawer,
  DrawerBody,
  DrawerCloseButton,
  DrawerContent,
  DrawerOverlay,
  Flex,
  HStack,
  IconButton,
  Spacer,
  Text,
  Tooltip,
  VStack,
  Popover,
  PopoverTrigger,
  PopoverContent,
  PopoverBody,
  useDisclosure,
  Image,
} from "@chakra-ui/react";
import { HamburgerIcon } from "@chakra-ui/icons";
import {
  Bell,
  Building2,
  CalendarDays,
  CheckSquare,
  ChevronLeft,
  ChevronDown,
  ChevronRight,
  Clock3,
  FileBarChart2,
  FolderKanban,
  LineChart,
  LogOut,
  Settings,
  ShieldAlert,
  UserCog,
  Users,
} from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import { fetchProfileInfo } from "utils/api";

const SIDEBAR_COLLAPSE_STORAGE_KEY = "ts_sidebar_collapsed";
const SIDEBAR_OPEN_WIDTH = 240;
const SIDEBAR_COLLAPSED_WIDTH = 64;
const HEADER_HEIGHT = 58;
const PREMIUM_SIDEBAR_BG = "var(--sidebar-bg)";
const PREMIUM_HEADER_BG = "var(--header-bg)";
const PREMIUM_BLUE_DEEP = "#213a5f";
const PREMIUM_HEADER_BASE = "#315C8C";
const LIGHT_BORDER = "var(--sidebar-divider)";
const LIGHT_TEXT_PRIMARY = "var(--sidebar-text-primary)";
const LIGHT_TEXT_SECONDARY = "var(--sidebar-text-secondary)";
const LIGHT_TEXT_MUTED = "var(--sidebar-text-muted)";
const MODERN_FONT_STACK = "'Plus Jakarta Sans', 'Inter', system-ui, -apple-system, 'Segoe UI', sans-serif";

const NAV_GROUPS = [
  { label: "WORKSPACE", items: ["Timesheet", "Project"] },
  { label: "MANAGE", items: ["Team", "Task", "Employee", "Client"] },
  { label: "SYSTEM", items: ["Settings", "Reports", "Audit Log"] },
];

const SUBMENU_CONFIG = {
  Project: {
    label: "Projects",
    children: [
      { sourceLabel: "Project", label: "Details" },
      { sourceLabel: "Insights", label: "Insights" },
    ],
  },
};

const ROUTE_ICON_MAP = {
  Timesheet: CalendarDays,
  Project: FolderKanban,
  Projects: FolderKanban,
  Details: FolderKanban,
  Insights: LineChart,
  Team: Users,
  Task: CheckSquare,
  Employee: UserCog,
  Client: Building2,
  Settings,
  Reports: FileBarChart2,
  "Audit Log": ShieldAlert,
};

const getLabelFromRouteName = (name) => {
  if (typeof name === "string") {
    return name;
  }

  if (React.isValidElement(name)) {
    const children = name.props?.children;
    if (typeof children === "string") {
      return children;
    }
    if (Array.isArray(children)) {
      return children.join("").trim();
    }
  }

  return "Untitled";
};

const flattenRoutes = (routesList = []) => {
  const result = [];

  routesList.forEach((route) => {
    if (!route) {
      return;
    }

    if (route.category && Array.isArray(route.items)) {
      result.push(...flattenRoutes(route.items));
      return;
    }

    if (route.layout && route.path) {
      const label = getLabelFromRouteName(route.name);
      if (label !== "Sign Out" && label !== "My Profile") {
        result.push({
          ...route,
          label,
          fullPath: `/${route.layout.replace(/^\/+|\/+$/g, "")}/${route.path
            .toString()
            .replace(/^\/+|\/+$/g, "")}`,
        });
      }
    }
  });

  return result;
};

const getInitials = (value, fallback = "MM") => {
  if (!value || typeof value !== "string") {
    return fallback;
  }

  const parts = value
    .split(" ")
    .map((part) => part.trim())
    .filter(Boolean);

  if (parts.length === 0) {
    return fallback;
  }

  return parts
    .slice(0, 2)
    .map((part) => part[0].toUpperCase())
    .join("");
};

const getPersistedCollapse = () => {
  if (typeof window === "undefined") {
    return false;
  }

  return window.localStorage.getItem(SIDEBAR_COLLAPSE_STORAGE_KEY) === "true";
};

const formatSessionDate = (date) =>
  date.toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    year: "numeric",
  });

const getGroupedRouteItems = (routes = []) => {
  const routeMap = new Map(routes.map((route) => [route.label, route]));
  const assigned = new Set();

  const grouped = NAV_GROUPS.map((group) => {
    const groupItems = group.items
      .map((label) => {
        const route = routeMap.get(label);
        if (!route) {
          return null;
        }

        assigned.add(label);
        const submenuConfig = SUBMENU_CONFIG[label];
        const children = submenuConfig?.children
          ?.map(({ sourceLabel, label: childLabel }) => {
            const childRoute = routeMap.get(sourceLabel);
            if (!childRoute) {
              return null;
            }

            assigned.add(sourceLabel);
            return {
              ...childRoute,
              label: childLabel,
            };
          })
          .filter(Boolean) || [];

        return {
          ...route,
          label: submenuConfig?.label || route.label,
          children,
        };
      })
      .filter(Boolean);

    return { label: group.label, routes: groupItems };
  }).filter((group) => group.routes.length > 0);

  const remainingRoutes = routes.filter((route) => !assigned.has(route.label));
  if (remainingRoutes.length > 0) {
    grouped.push({ label: "SYSTEM", routes: remainingRoutes });
  }

  return grouped;
};

function SidebarLink({ route, isActive, isCollapsed, onNavigate }) {
  const IconComponent = ROUTE_ICON_MAP[route.label];

  return (
    <Tooltip
      label={isCollapsed ? route.label : ""}
      placement="right"
      hasArrow
      isDisabled={!isCollapsed}
      openDelay={200}
    >
      <Box position="relative" mx="8px" my="2px">
        {isActive && (
          <Box
            position="absolute"
            left="0"
            top="50%"
            transform="translateY(-50%)"
            w="3px"
            h="20px"
            bg="var(--sidebar-active-pill)"
            borderRadius="0 3px 3px 0"
          />
        )}

        <Flex
          align="center"
          h="42px"
          px="10px"
          gap="10px"
          borderRadius="9px"
          cursor="pointer"
          bg={isActive ? "rgba(255,255,255,0.18)" : "transparent"}
          color={isActive ? "#FFFFFF" : LIGHT_TEXT_SECONDARY}
          transition="all 150ms ease"
          _hover={{
            bg: isActive ? "rgba(255,255,255,0.18)" : "rgba(255,255,255,0.1)",
            color: LIGHT_TEXT_PRIMARY,
          }}
          onClick={() => onNavigate(route.fullPath)}
        >
          <Flex w="18px" h="18px" align="center" justify="center" flexShrink={0}>
            {IconComponent ? (
              <IconComponent
                size={18}
                strokeWidth={1.8}
                color={isActive ? "#FFFFFF" : LIGHT_TEXT_MUTED}
              />
            ) : (
              route.icon
            )}
          </Flex>

          <Text
            noOfLines={1}
            fontSize="14px"
            lineHeight="18px"
            letterSpacing="-0.1px"
            fontWeight={isActive ? 700 : 600}
            opacity={isCollapsed ? 0 : 1}
            maxW={isCollapsed ? "0px" : "140px"}
            pointerEvents={isCollapsed ? "none" : "auto"}
            transition="all 150ms ease"
          >
            {route.label}
          </Text>
        </Flex>
      </Box>
    </Tooltip>
  );
}

SidebarLink.propTypes = {
  route: PropTypes.shape({
    label: PropTypes.string,
    icon: PropTypes.node,
    fullPath: PropTypes.string,
  }).isRequired,
  isActive: PropTypes.bool.isRequired,
  isCollapsed: PropTypes.bool.isRequired,
  onNavigate: PropTypes.func.isRequired,
};

function SidebarSubmenu({
  route,
  isCollapsed,
  locationPath,
  onNavigate,
  isOpen,
  onToggle,
}) {
  const IconComponent = ROUTE_ICON_MAP[route.label];
  const hasChildren = Array.isArray(route.children) && route.children.length > 0;
  const isParentActive = route.fullPath
    ? locationPath === route.fullPath || locationPath.startsWith(`${route.fullPath}/`)
    : false;
  const isChildActive = hasChildren
    && route.children.some(
      (child) => locationPath === child.fullPath || locationPath.startsWith(`${child.fullPath}/`)
    );
  const isActive = isParentActive || isChildActive;

  const handleChildNavigate = (childPath) => {
    onNavigate(childPath);
    if (isOpen) {
      onToggle(route.label);
    }
  };

  const renderChildItems = (variant = "inline") => (
    route.children.map((childRoute) => {
      const isChildRouteActive =
        locationPath === childRoute.fullPath || locationPath.startsWith(`${childRoute.fullPath}/`);
      const ChildIconComponent = ROUTE_ICON_MAP[childRoute.label];
      const isIconOnly = variant === "icons-only";

      if (isIconOnly) {
        return (
          <Tooltip
            key={`${childRoute.fullPath}-${childRoute.label}`}
            label={childRoute.label}
            placement="right"
            hasArrow
            openDelay={200}
          >
            <Flex
              as="button"
              type="button"
              align="center"
              justify="center"
              w="36px"
              h="36px"
              borderRadius="8px"
              cursor="pointer"
              bg={isChildRouteActive ? "rgba(255,255,255,0.16)" : "transparent"}
              color={isChildRouteActive ? "#FFFFFF" : LIGHT_TEXT_SECONDARY}
              transition="all 150ms ease"
              _hover={{
                bg: isChildRouteActive ? "rgba(255,255,255,0.16)" : "rgba(255,255,255,0.08)",
                color: LIGHT_TEXT_PRIMARY,
              }}
              onClick={() => handleChildNavigate(childRoute.fullPath)}
            >
              {ChildIconComponent ? (
                <ChildIconComponent
                  size={18}
                  strokeWidth={1.8}
                  color={isChildRouteActive ? "#FFFFFF" : LIGHT_TEXT_MUTED}
                />
              ) : (
                childRoute.icon
              )}
            </Flex>
          </Tooltip>
        );
      }

      return (
        <Box key={`${childRoute.fullPath}-${childRoute.label}`}>
          <Flex
            align="center"
            h="36px"
            px="10px"
            gap="10px"
            borderRadius="8px"
            cursor="pointer"
            bg={isChildRouteActive ? "rgba(255,255,255,0.16)" : "transparent"}
            color={isChildRouteActive ? "#FFFFFF" : LIGHT_TEXT_SECONDARY}
            transition="all 150ms ease"
            _hover={{
              bg: isChildRouteActive ? "rgba(255,255,255,0.16)" : "rgba(255,255,255,0.08)",
              color: LIGHT_TEXT_PRIMARY,
            }}
            onClick={() => handleChildNavigate(childRoute.fullPath)}
          >
            <Flex w="16px" h="16px" align="center" justify="center" flexShrink={0}>
              {ChildIconComponent ? (
                <ChildIconComponent
                  size={16}
                  strokeWidth={1.8}
                  color={isChildRouteActive ? "#FFFFFF" : LIGHT_TEXT_MUTED}
                />
              ) : (
                childRoute.icon
              )}
            </Flex>
            <Text
              noOfLines={1}
              fontSize="13px"
              lineHeight="18px"
              fontWeight={isChildRouteActive ? 700 : 600}
            >
              {childRoute.label}
            </Text>
          </Flex>
        </Box>
      );
    })
  );

  const parentRowProps = {
    align: "center",
    h: "42px",
    px: "10px",
    gap: "10px",
    borderRadius: "9px",
    cursor: "pointer",
    bg: isActive ? "rgba(255,255,255,0.18)" : "transparent",
    color: isActive ? "#FFFFFF" : LIGHT_TEXT_SECONDARY,
    transition: "all 150ms ease",
    _hover: {
      bg: isActive ? "rgba(255,255,255,0.18)" : "rgba(255,255,255,0.1)",
      color: LIGHT_TEXT_PRIMARY,
    },
  };

  const collapsedParentIcon = (
    <Flex
      {...parentRowProps}
      justify="center"
      px="0"
      w="42px"
      mx="auto"
    >
      <Flex w="18px" h="18px" align="center" justify="center" flexShrink={0}>
        {IconComponent ? (
          <IconComponent
            size={18}
            strokeWidth={1.8}
            color={isActive ? "#FFFFFF" : LIGHT_TEXT_MUTED}
          />
        ) : (
          route.icon
        )}
      </Flex>
    </Flex>
  );

  const parentRowContent = (
    <>
      <Flex w="18px" h="18px" align="center" justify="center" flexShrink={0}>
        {IconComponent ? (
          <IconComponent
            size={18}
            strokeWidth={1.8}
            color={isActive ? "#FFFFFF" : LIGHT_TEXT_MUTED}
          />
        ) : (
          route.icon
        )}
      </Flex>

      <Text
        noOfLines={1}
        fontSize="14px"
        lineHeight="18px"
        letterSpacing="-0.1px"
        fontWeight={isActive ? 700 : 600}
        opacity={isCollapsed ? 0 : 1}
        maxW={isCollapsed ? "0px" : "140px"}
        pointerEvents={isCollapsed ? "none" : "auto"}
        transition="all 150ms ease"
        flex="1"
      >
        {route.label}
      </Text>

      {!isCollapsed && hasChildren && (
        <Flex
          as="button"
          type="button"
          align="center"
          justify="center"
          w="22px"
          h="22px"
          borderRadius="6px"
          color={isActive ? "#FFFFFF" : LIGHT_TEXT_MUTED}
          _hover={{ bg: "rgba(255,255,255,0.1)" }}
          onClick={(event) => {
            event.stopPropagation();
            onToggle(route.label);
          }}
        >
          {isOpen ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
        </Flex>
      )}
    </>
  );

  const parentRow = (
    <Flex
      {...parentRowProps}
      onClick={() => {
        if (hasChildren) {
          onToggle(route.label);
          return;
        }
        onNavigate(route.fullPath);
      }}
    >
      {parentRowContent}
    </Flex>
  );

  if (isCollapsed && hasChildren) {
    return (
      <Box position="relative" mx="8px" my="2px">
        {isActive && (
          <Box
            position="absolute"
            left="0"
            top="50%"
            transform="translateY(-50%)"
            w="3px"
            h="20px"
            bg="var(--sidebar-active-pill)"
            borderRadius="0 3px 3px 0"
            zIndex={1}
          />
        )}

        <Popover
          isOpen={isOpen}
          onClose={() => {
            if (isOpen) {
              onToggle(route.label);
            }
          }}
          placement="right-start"
          gutter={12}
          isLazy
          closeOnBlur
          strategy="fixed"
        >
          <PopoverTrigger>
            <Box
              as="button"
              type="button"
              w="full"
              border="none"
              bg="transparent"
              p="0"
              onClick={() => onToggle(route.label)}
            >
              <Tooltip
                label={route.label}
                placement="right"
                hasArrow
                isDisabled={isOpen}
                openDelay={200}
              >
                {collapsedParentIcon}
              </Tooltip>
            </Box>
          </PopoverTrigger>
          <PopoverContent
            w="auto"
            minW="unset"
            bg={PREMIUM_BLUE_DEEP}
            border={`1px solid ${LIGHT_BORDER}`}
            borderRadius="12px"
            boxShadow="0 12px 28px rgba(15,23,42,0.24)"
            _focus={{ boxShadow: "0 12px 28px rgba(15,23,42,0.24)" }}
            zIndex={1400}
          >
            <PopoverBody p="6px">
              <VStack align="center" spacing="4px">
                {renderChildItems("icons-only")}
              </VStack>
            </PopoverBody>
          </PopoverContent>
        </Popover>
      </Box>
    );
  }

  return (
    <Box mx="8px" my="2px">
      {parentRow}

      {!isCollapsed && hasChildren && isOpen && (
        <VStack align="stretch" spacing="2px" mt="4px" pl="28px">
          {renderChildItems("inline")}
        </VStack>
      )}
    </Box>
  );
}

SidebarSubmenu.propTypes = {
  route: PropTypes.shape({
    label: PropTypes.string,
    icon: PropTypes.node,
    fullPath: PropTypes.string,
    children: PropTypes.arrayOf(PropTypes.object),
  }).isRequired,
  isCollapsed: PropTypes.bool.isRequired,
  locationPath: PropTypes.string.isRequired,
  onNavigate: PropTypes.func.isRequired,
  isOpen: PropTypes.bool.isRequired,
  onToggle: PropTypes.func.isRequired,
};

function SidebarSections({ groupedRoutes, isCollapsed, locationPath, onNavigate }) {
  const initialOpenState = useMemo(() => {
    const state = {};

        groupedRoutes.forEach((group) => {
      group.routes.forEach((route) => {
        const isParentActive = route.fullPath
          ? locationPath === route.fullPath || locationPath.startsWith(`${route.fullPath}/`)
          : false;
        const isChildActive = route.children?.some(
          (child) => locationPath === child.fullPath || locationPath.startsWith(`${child.fullPath}/`)
        );

        if (isParentActive || isChildActive) {
          state[route.label] = true;
        }
      });
    });

    return state;
  }, [groupedRoutes, locationPath]);

  const [openSubmenus, setOpenSubmenus] = useState(initialOpenState);
  const wasCollapsedRef = useRef(isCollapsed);

  useEffect(() => {
    setOpenSubmenus(initialOpenState);
  }, [initialOpenState]);

  useEffect(() => {
    if (!wasCollapsedRef.current && isCollapsed) {
      setOpenSubmenus({});
    }
    wasCollapsedRef.current = isCollapsed;
  }, [isCollapsed]);

  const handleToggleSubmenu = (label) => {
    setOpenSubmenus((prev) => ({
      ...prev,
      [label]: !prev[label],
    }));
  };

  return (
    <VStack align="stretch" spacing="10px" mt="8px">
      {groupedRoutes.map((group) => (
        <Box key={group.label}>
          <VStack align="stretch" spacing="0">
            {group.routes.map((route) => {
              if (route.children?.length) {
                return (
                  <SidebarSubmenu
                    key={`${route.fullPath}-${route.label}`}
                    route={route}
                    isCollapsed={isCollapsed}
                    locationPath={locationPath}
                    onNavigate={onNavigate}
                    isOpen={Boolean(openSubmenus[route.label])}
                    onToggle={handleToggleSubmenu}
                  />
                );
              }

              const isActive =
                locationPath === route.fullPath || locationPath.startsWith(`${route.fullPath}/`);

              return (
                <SidebarLink
                  key={`${route.fullPath}-${route.label}`}
                  route={route}
                  isActive={isActive}
                  isCollapsed={isCollapsed}
                  onNavigate={onNavigate}
                />
              );
            })}
          </VStack>
        </Box>
      ))}
    </VStack>
  );
}

SidebarSections.propTypes = {
  groupedRoutes: PropTypes.arrayOf(PropTypes.object).isRequired,
  isCollapsed: PropTypes.bool.isRequired,
  locationPath: PropTypes.string.isRequired,
  onNavigate: PropTypes.func.isRequired,
};

function DesktopSidebar({
  groupedRoutes,
  locationPath,
  isCollapsed,
  onToggle,
  onNavigate,
}) {
  return (
    <Box
      display={{ base: "none", md: "block" }}
      position="fixed"
      left="0"
      top="0"
      h="100vh"
      w="var(--sidebar-width)"
      bg={PREMIUM_SIDEBAR_BG}
      boxShadow="4px 0 24px rgba(15,23,42,0.08)"
      transition="width 280ms cubic-bezier(0.4, 0, 0.2, 1)"
      zIndex="1200"
      overflow="hidden"
      fontFamily={MODERN_FONT_STACK}
    >
      <Flex direction="column" h="full">
        <HStack
          h="64px"
          px="16px"
          spacing="10px"
          borderBottom={`1px solid ${LIGHT_BORDER}`}
          overflow="hidden"
        >
          <Flex
            w="28px"
            h="28px"
            align="center"
            justify="center"
            flexShrink={0}
          >
            <Image
              src="/CI_Icon.ico"
              alt="TimeSnap Icon"
              boxSize="28px"
              objectFit="contain"
            />
          </Flex>

          <Text
            color={LIGHT_TEXT_PRIMARY}
            fontSize="17px"
            lineHeight="22px"
            fontWeight={700}
            letterSpacing="-0.3px"
            opacity={isCollapsed ? 0 : 1}
            maxW={isCollapsed ? "0px" : "140px"}
            pointerEvents={isCollapsed ? "none" : "auto"}
            transition="all 280ms cubic-bezier(0.4, 0, 0.2, 1)"
            noOfLines={1}
          >
            TimeSnap
          </Text>
        </HStack>

        <Box
          flex="1"
          overflowY="auto"
          pb="8px"
          sx={{
            scrollbarWidth: "none",
            msOverflowStyle: "none",
            "&::-webkit-scrollbar": {
              display: "none",
            },
          }}
        >
          <SidebarSections
            groupedRoutes={groupedRoutes}
            isCollapsed={isCollapsed}
            locationPath={locationPath}
            onNavigate={onNavigate}
          />
        </Box>

        <Flex justify="center" pb="16px" pt="8px">
          <IconButton
            aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
            icon={<ChevronLeft size={16} style={{ transform: isCollapsed ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 280ms cubic-bezier(0.4, 0, 0.2, 1)" }} />}
            size="sm"
            w="32px"
            h="32px"
            minW="32px"
            bg="#FFFFFF"
            color="#334155"
            border="1px solid rgba(51,65,85,0.28)"
            borderRadius="8px"
            transition="all 150ms ease"
            _hover={{ bg: "#F8FAFC", color: "#0F172A" }}
            onClick={onToggle}
          />
        </Flex>
      </Flex>
    </Box>
  );
}

DesktopSidebar.propTypes = {
  groupedRoutes: PropTypes.arrayOf(PropTypes.object).isRequired,
  locationPath: PropTypes.string.isRequired,
  isCollapsed: PropTypes.bool.isRequired,
  onToggle: PropTypes.func.isRequired,
  onNavigate: PropTypes.func.isRequired,
};

function MobileMenu({
  isOpen,
  onClose,
  groupedRoutes,
  locationPath,
  onNavigate,
  onLogoutOpen,
}) {
  return (
    <Drawer isOpen={isOpen} placement="left" onClose={onClose}>
      <DrawerOverlay />
      <DrawerContent
        maxW="240px"
        bg={PREMIUM_SIDEBAR_BG}
        boxShadow="4px 0 24px rgba(15,23,42,0.08)"
        fontFamily={MODERN_FONT_STACK}
      >
        <DrawerCloseButton />
        <DrawerBody
          px="0"
          py="0"
          sx={{
            scrollbarWidth: "none",
            msOverflowStyle: "none",
            "&::-webkit-scrollbar": {
              display: "none",
            },
          }}
        >
          <VStack align="stretch" spacing="10px">
            <HStack h="64px" px="16px" spacing="10px" borderBottom={`1px solid ${LIGHT_BORDER}`}>
              <Flex
                w="28px"
                h="28px"
                align="center"
                justify="center"
              >
                <Image
                  src="/CI_Icon.ico"
                  alt="TimeSnap Icon"
                  boxSize="28px"
                  objectFit="contain"
                />
              </Flex>
              <Text color={LIGHT_TEXT_PRIMARY} fontSize="17px" lineHeight="22px" fontWeight={700} letterSpacing="-0.3px">
                TimeSnap
              </Text>
            </HStack>

            <SidebarSections
              groupedRoutes={groupedRoutes}
              isCollapsed={false}
              locationPath={locationPath}
              onNavigate={(path) => {
                onNavigate(path);
                onClose();
              }}
            />

            <Button
              mx="12px"
              mt="8px"
              color={LIGHT_TEXT_SECONDARY}
              bg="#FFFFFF"
              border={`1px solid ${LIGHT_BORDER}`}
              fontSize="14px"
              fontWeight={600}
              _hover={{ bg: "#F8FAFC" }}
              onClick={onLogoutOpen}
            >
              Sign Out
            </Button>
          </VStack>
        </DrawerBody>
      </DrawerContent>
    </Drawer>
  );
}

MobileMenu.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  groupedRoutes: PropTypes.arrayOf(PropTypes.object).isRequired,
  locationPath: PropTypes.string.isRequired,
  onNavigate: PropTypes.func.isRequired,
  onLogoutOpen: PropTypes.func.isRequired,
};

function MainLayout({ routes = [], children }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { setAuth } = useAuth();
  const [isCollapsed, setIsCollapsed] = useState(getPersistedCollapse);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [profile, setProfile] = useState(null);
  const [sessionDate, setSessionDate] = useState(() => new Date());
  const empCode = localStorage.getItem("emp_code");
  const userMenuRef = React.useRef(null);

  const mobileMenu = useDisclosure();
  const logoutDialog = useDisclosure();
  const cancelRef = React.useRef();

  const navigableRoutes = useMemo(() => flattenRoutes(routes), [routes]);
  const groupedRoutes = useMemo(() => getGroupedRouteItems(navigableRoutes), [navigableRoutes]);

  const activeRouteLabel = useMemo(() => {
    const activeRoute = navigableRoutes.find((route) => {
      return location.pathname === route.fullPath || location.pathname.startsWith(`${route.fullPath}/`);
    });

    return activeRoute?.label || "Dashboard";
  }, [location.pathname, navigableRoutes]);

  useEffect(() => {
    if (!isUserMenuOpen) {
      return undefined;
    }

    const handleOutsideClick = (event) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target)) {
        setIsUserMenuOpen(false);
      }
    };

    document.addEventListener("mousedown", handleOutsideClick);
    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
    };
  }, [isUserMenuOpen]);

  useEffect(() => {
    const loadProfile = async () => {
      if (!empCode) {
        return;
      }

      try {
        const profileData = await fetchProfileInfo(empCode);
        setProfile(profileData || null);
      } catch (error) {
        console.error("Error loading profile:", error);
      }
    };

    loadProfile();
  }, [empCode]);

  useEffect(() => {
    const applyResponsiveCollapse = () => {
      if (window.innerWidth < 768) {
        setIsCollapsed(true);
      } else {
        setIsCollapsed(getPersistedCollapse());
      }
    };

    applyResponsiveCollapse();
    window.addEventListener("resize", applyResponsiveCollapse);

    return () => {
      window.removeEventListener("resize", applyResponsiveCollapse);
    };
  }, []);

  useEffect(() => {
    const updateSessionDate = () => {
      setSessionDate(new Date());
    };

    updateSessionDate();
    const intervalId = window.setInterval(updateSessionDate, 60 * 1000);

    return () => {
      window.clearInterval(intervalId);
    };
  }, []);

  const handleToggleSidebar = () => {
    const nextValue = !isCollapsed;
    setIsCollapsed(nextValue);
    window.localStorage.setItem(SIDEBAR_COLLAPSE_STORAGE_KEY, String(nextValue));
  };

  const handleNavigation = (path) => {
    navigate(path);
  };

  const handleUserMenuAction = (action) => {
    setIsUserMenuOpen(false);

    if (action === "profile") {
      navigate("/admin/profile");
      return;
    }

    if (action === "settings") {
      navigate("/admin/settings");
      return;
    }

    if (action === "signout") {
      logoutDialog.onOpen();
    }
  };

  const handleLogout = () => {
    logoutDialog.onClose();
    logoutUser({ navigate, setAuth });
  };

  const headerDisplayName = profile?.user_name || "User";
  const sidebarWidth = `${isCollapsed ? SIDEBAR_COLLAPSED_WIDTH : SIDEBAR_OPEN_WIDTH}px`;

  return (
    <>
      <Flex
        className={isCollapsed ? "sidebar-collapsed" : ""}
        minH="100vh"
        bg="#FFFFFF"
        style={{
          "--sidebar-width": sidebarWidth,
          "--header-height": `${HEADER_HEIGHT}px`,
        }}
      >
        <DesktopSidebar
          groupedRoutes={groupedRoutes}
          locationPath={location.pathname}
          isCollapsed={isCollapsed}
          onToggle={handleToggleSidebar}
          onNavigate={handleNavigation}
        />

        <MobileMenu
          isOpen={mobileMenu.isOpen}
          onClose={mobileMenu.onClose}
          groupedRoutes={groupedRoutes}
          locationPath={location.pathname}
          onNavigate={handleNavigation}
          onLogoutOpen={logoutDialog.onOpen}
        />

        <Box className="main-content" flex="1" minH="100vh">
          <Flex
            position="fixed"
            top="0"
            left={{ base: 0, md: "var(--sidebar-width)" }}
            right="0"
            h="var(--header-height)"
            px={{ base: "16px", md: "28px" }}
            align="center"
            bg={PREMIUM_HEADER_BG}
            borderBottom={`1px solid ${LIGHT_BORDER}`}
            zIndex="1100"
            transition="left 280ms cubic-bezier(0.4, 0, 0.2, 1)"
            fontFamily={MODERN_FONT_STACK}
          >
            <HStack spacing="10px" minW="0">
              <IconButton
                aria-label="Open menu"
                icon={<HamburgerIcon />}
                variant="ghost"
                display={{ base: "inline-flex", md: "none" }}
                onClick={mobileMenu.onOpen}
              />
              <HStack spacing="8px" minW="0">
                <Text
                  color={LIGHT_TEXT_PRIMARY}
                  fontSize="18px"
                  lineHeight="20px"
                  fontWeight={700}
                  letterSpacing="-0.3px"
                  noOfLines={1}
                >
                  {activeRouteLabel}
                </Text>
                <Text color="rgba(255,255,255,0.5)" fontSize="15px" lineHeight="18px" fontWeight={500} mx="8px">
                  /
                </Text>
                <Text color={LIGHT_TEXT_MUTED} fontSize="14px" lineHeight="18px" fontWeight={500} noOfLines={1}>
                  Team workspace insights
                </Text>
              </HStack>
            </HStack>

            <Spacer />

            <HStack spacing="8px" align="center">
              <HStack
                spacing="5px"
                px="12px"
                py="5px"
                borderRadius="20px"
                bg="rgba(58,105,154,0.22)"
                color="#EAF2FF"
                border="1px solid rgba(167,199,236,0.42)"
                display={{ base: "none", lg: "inline-flex" }}
              >
                <Clock3 size={14} strokeWidth={1.8} color="#A7C7EC" />
                <Text fontSize="13px" lineHeight="16px" fontWeight={600}>
                  {formatSessionDate(sessionDate)}
                </Text>
              </HStack>

              {/* <Box position="relative">
                <IconButton
                  aria-label="Notifications"
                  icon={<Bell size={17} strokeWidth={1.8} />}
                  w="36px"
                  h="36px"
                  minW="36px"
                  borderRadius="9px"
                  bg="rgba(255,255,255,0.06)"
                  border="1px solid rgba(255,255,255,0.28)"
                  color="#FFFFFF"
                  transition="all 150ms ease"
                  _hover={{
                    bg: "rgba(255,255,255,0.12)",
                    borderColor: "rgba(255,255,255,0.42)",
                    color: "#FFFFFF",
                  }}
                />
                <Box
                  position="absolute"
                  top="5px"
                  right="5px"
                  w="6px"
                  h="6px"
                  borderRadius="full"
                  bg="#EF4444"
                  border={`2px solid ${PREMIUM_HEADER_BASE}`}
                />
              </Box> */}

              <Box position="relative" ref={userMenuRef}>
                <Tooltip label="My Profile" placement="bottom" hasArrow openDelay={200}>
                  <Box
                    as="button"
                    type="button"
                    h="36px"
                    px="12px"
                    minW="110px"
                    maxW="180px"
                    borderRadius="999px"
                    bg="rgba(255,255,255,0.06)"
                    border="1px solid rgba(255,255,255,0.28)"
                    color="#FFFFFF"
                    fontSize="13px"
                    fontWeight={700}
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                    transition="all 150ms ease"
                    _hover={{
                      bg: "rgba(255,255,255,0.12)",
                      borderColor: "rgba(255,255,255,0.42)",
                    }}
                    cursor="pointer"
                    onClick={() => setIsUserMenuOpen((prev) => !prev)}
                  >
                    <Text noOfLines={1}>{headerDisplayName}</Text>
                  </Box>
                </Tooltip>

                {isUserMenuOpen && (
                  <Box
                    position="absolute"
                    top="calc(100% + 8px)"
                    right="0"
                    w="200px"
                    bg={PREMIUM_BLUE_DEEP}
                    border={`1px solid ${LIGHT_BORDER}`}
                    borderRadius="12px"
                    boxShadow="0 12px 28px rgba(15,23,42,0.14)"
                    p="6px"
                    zIndex="1200"
                  >
                    <Box
                      as="button"
                      type="button"
                      h="36px"
                      w="100%"
                      px="10px"
                      borderRadius="7px"
                      fontSize="14px"
                      fontWeight={600}
                      color={LIGHT_TEXT_SECONDARY}
                      textAlign="left"
                      _hover={{ bg: "rgba(255,255,255,0.12)", color: "#FFFFFF" }}
                      onClick={() => handleUserMenuAction("profile")}
                    >
                      My Profile
                    </Box>
                  </Box>
                )}
              </Box>

              <Box position="relative">
                <Tooltip label="Sign Out" placement="bottom" hasArrow openDelay={200}>
                  <IconButton
                    aria-label="Sign out"
                    icon={<LogOut size={16} strokeWidth={2} />}
                    w="36px"
                    h="36px"
                    minW="36px"
                    borderRadius="9px"
                    bg="rgba(255,255,255,0.06)"
                    border="1px solid rgba(255,255,255,0.28)"
                    color="#FFFFFF"
                    transition="all 150ms ease"
                    _hover={{
                      bg: "rgba(239,68,68,0.12)",
                      borderColor: "rgba(239,68,68,0.38)",
                      color: "#FFFFFF",
                    }}
                    onClick={logoutDialog.onOpen}
                  />
                </Tooltip>
              </Box>
            </HStack>
          </Flex>

          <Box pt="var(--header-height)" transition="all 200ms ease">
            <Box className="page-content-wrapper">
              {children}
            </Box>
          </Box>
        </Box>
      </Flex>

      <AlertDialog
        isOpen={logoutDialog.isOpen}
        leastDestructiveRef={cancelRef}
        onClose={logoutDialog.onClose}
      >
        <AlertDialogOverlay>
          <AlertDialogContent className="signout-confirm-modal">
            <AlertDialogHeader fontSize="lg" fontWeight="bold">
              Confirm Sign Out
            </AlertDialogHeader>
            <AlertDialogBody>
              Are you sure you want to sign out from this workspace?
            </AlertDialogBody>
            <AlertDialogFooter>
              <Button ref={cancelRef} onClick={logoutDialog.onClose}>
                Cancel
              </Button>
              <Button colorScheme="red" ml={3} onClick={handleLogout}>
                Sign Out
              </Button>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialogOverlay>
      </AlertDialog>
    </>
  );
}

MainLayout.propTypes = {
  routes: PropTypes.arrayOf(PropTypes.object),
  children: PropTypes.node,
};

export default MainLayout;
