import React from "react";
import { useState,useEffect} from "react";
import { Flex, Text, useColorModeValue,Avatar, Box } from "@chakra-ui/react";
import { fetchProfileInfo,fetchUserProfilePicture } from 'utils/api';

export function SidebarBrand() {
  const textColor = useColorModeValue("navy.700", "white");
  const [profile, setProfile] = useState(null);
  const [profilePhoto, setProfilePhoto] = useState(null);
const empCode = localStorage.getItem("emp_code");

  useEffect(() => {
    const fetchProfileInfoDetails = async () => {
      try {
        if (empCode) {
          const data = await fetchProfileInfo(empCode);
          setProfile(data);
        }
      } catch (error) {
        console.error("Error fetching profile info:", error);
      }
    };

    fetchProfileInfoDetails();
  }, [empCode]);

  useEffect(() => {
      const loadProfilePicture = async () => {
        const imageUrl = await fetchUserProfilePicture(empCode);
        if (imageUrl) setProfilePhoto(imageUrl);
      };
      loadProfilePicture();
  }, [empCode]);

  return (
    <Flex align="center" direction="column">
      {/* Avatar with border effect */}
      <Box
        marginTop='15px'
        position="relative"
        borderRadius="full"
        border="3px solid"
        borderColor="green.200" 
        cursor='pointer'
        p="3px"
      >
        <Avatar size="xl" color= "black" bg="green.100" 
        src={profilePhoto || undefined}
        name={profile ? profile.user_name : "Loading..."} />
      </Box>
      <Text fontSize="lg" fontWeight="bold" color={textColor} mt={3}>
        {profile ? profile.user_name : "Loading..."}
      </Text>

      <Text fontSize="sm" color="gray.500">
        {profile ? profile.email_Id : "Loading..."}
      </Text>
    </Flex>
  );
}

export default SidebarBrand;
