import React from 'react';
import { Button, Tooltip } from '@chakra-ui/react';

/**
 * CustomButton Component
 *
 * @param {string} label - The button text
 * @param {function} onClick - Function to trigger on click
 * @param {string} variant - Button variant (e.g., 'solid', 'outline')
 * @param {string} colorScheme - Chakra UI color scheme (e.g., 'blue', 'black')
 * @param {string} size - Button size ('sm', 'md', 'lg')
 * @param {ReactNode} icon - Icon for the button (optional)
 * @param {string} tooltip - Tooltip text (optional)
 * @param {string} className - Additional CSS classes
 * @param {boolean} isDisabled - Disable button if true
 * @param {string|number} width - Fixed width for the button (optional)
 */
const CustomButton = ({
  label,
  onClick,
  variant = 'solid',
  colorScheme = 'blue',
  size = 'md',
  icon,
  tooltip,
  className = '',
  isDisabled = false,
  width = '80px', // fixed width
  isLoading = false,
}) => {
  const normalizedLabel =
    typeof label === 'string' ? label.trim().toLowerCase() : '';
  const isSaveAction = normalizedLabel.includes('save');
  const effectiveColorScheme =
    isSaveAction && variant !== 'outline' && colorScheme !== 'red'
      ? 'blue'
      : colorScheme;

  const tone =
    variant === 'outline'
      ? 'secondary'
      : effectiveColorScheme === 'red'
        ? 'danger'
        : effectiveColorScheme === 'green'
          ? 'success'
          : 'primary';

  const button = (
    <Button
      className={className}
      data-btn-tone={tone}
      data-btn-color-scheme={effectiveColorScheme}
      variant={variant}
      colorScheme={effectiveColorScheme}
      onClick={onClick}
      size={size}
      leftIcon={icon}
      isDisabled={isDisabled}
      width={width}
      isLoading={isLoading}
    >
      {label}
    </Button>
  );

  return tooltip ? <Tooltip label={tooltip}>{button}</Tooltip> : button;
};

export default CustomButton;
