import React from 'react';
import { Tooltip, IconButton } from '@chakra-ui/react';
// import './globalStyles.css';
import 'assets/styles/globalStyles.css';
/**
 * CustomIconButton Component
 *
 * @param {function} onClick - Function to trigger on click
 * @param {string} iconClass - FontAwesome icon class (e.g., 'fas fa-trash')
 * @param {string} tooltip - Tooltip text
 */
const CustomIconButton = ({
  iconClass,
  tooltip,
  onClick,
  isDisabled = false,
}) => {
  return (
    <Tooltip
    label={tooltip}
    placement="top"
    openDelay={500} // Delay to prevent immediate display
    closeOnClick={false}
    closeOnMouseDown={true} // Close when clicked
    hasArrow
  >
      <IconButton
        icon={<i className={iconClass} />}
        onClick={onClick}
        isDisabled={isDisabled}
        variant="ghost"
        size="sm"
        aria-label={tooltip}
        tabIndex={-1} // Prevents auto-focus
      />
    </Tooltip>
  );
};

export default CustomIconButton;
