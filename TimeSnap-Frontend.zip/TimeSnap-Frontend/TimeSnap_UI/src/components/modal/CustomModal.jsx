import React, { useEffect, useRef } from 'react';
import {
    Modal as ChakraModal,
    ModalOverlay,
    ModalContent,
    ModalHeader,
    ModalBody,
    ModalFooter,
    ModalCloseButton,
} from '@chakra-ui/react';

/**
 * CustomModal Wrapper
 * Automatically focuses the first interactive input field when opened.
 * This is useful for "Add/Edit" modals relative to where they are used.
 */
const CustomModal = ({
    isOpen,
    onClose,
    initialFocusRef, // Allow overriding if specifically provided
    children,
    ...props
}) => {
    const modalContentRef = useRef(null);

    useEffect(() => {
        if (isOpen && !initialFocusRef) {
            // Small timeout to allow the modal to render its content
            const timer = setTimeout(() => {
                if (modalContentRef.current) {
                    // Find the first input, textarea, or select element
                    // Exclude hidden inputs, disabled, and readonly elements
                    const firstInput = modalContentRef.current.querySelector(
                        'input:not([type="hidden"]):not([disabled]):not([readonly]), textarea:not([disabled]):not([readonly]), select:not([disabled]):not([readonly]), [role="combobox"]:not([aria-disabled="true"])'
                    );

                    if (firstInput) {
                        firstInput.focus();
                    }
                }
            }, 50); // 50ms delay is usually sufficient

            return () => clearTimeout(timer);
        }
    }, [isOpen, initialFocusRef]);

    return (
        <ChakraModal
            isOpen={isOpen}
            onClose={onClose}
            initialFocusRef={initialFocusRef}
            {...props}
        >
            {/* We don't render ModalOverlay/Content here to allow flexibility in usage, 
          BUT users must use this CustomModal as a direct replacement for Chakra's <Modal>.
          
          However, to querySelector *inside* the content easily without invasive cloning,
          we can attach a ref to a div wrapper or pass the ref if we controlled the Content.
          
          Since Chakra Modal children are usually Overlay, Content, etc., we can't wrap them easily 
          without breaking Chakra's structure requiring ModalContent to be direct child sometimes.
          
          Better approach: We assume the user uses the standard structure. 
          We can try to use `initialFocusRef={undefined}` to let our effect handle it, 
          and we need a ref to search within. 
          
          Actually, querying `document.activeElement` or `document.querySelector` within the portal 
          might be safer if we don't own the ref. 
          
          Let's try to query the document body for the modal content class or ID 
          if we can't attach a ref directly to the content.
          
          Wait, Chakra's Modal passes `ref` to the ModalContent? No.
          
          Alternative: We leverage the `id` or a wrapper. 
          Or, simply document query locally.
       */}
            {/* 
         Since we can't easily ref the "Content" from outside (it's a child),
         we will use a slightly broader query restricted to the active modal portal.
         Chakra modals render in a Portal.
       */}
            {children}
            <AutoFocuser isOpen={isOpen} initialFocusRef={initialFocusRef} />
        </ChakraModal>
    );
};

// Helper component that simply runs the side-effect.
// It is rendered INSIDE the Modal, so it mounts when Modal opens (if unmountOnClose)
// or we rely on the `isOpen` prop.
const AutoFocuser = ({ isOpen, initialFocusRef }) => {
    useEffect(() => {
        if (isOpen && !initialFocusRef) {
            const timer = setTimeout(() => {
                // Find the modal content. Chakra usually adds `id` or generic class.
                // But the safest way is to find the closest focusable container or just query the document
                // for the top-most modal.

                // Strategy: Query for the standard ModalBody or general inputs.
                // Since modals stack, we want the last one (top-most).

                const activeModals = document.querySelectorAll('.chakra-modal__content');

                if (activeModals.length > 0) {
                    // Get the last one (top-most in stacking context)
                    const activeModal = activeModals[activeModals.length - 1];

                    if (activeModal) {
                        const input = activeModal.querySelector(
                            'input:not([type="hidden"]):not([disabled]):not([readonly]), textarea:not([disabled]):not([readonly]), select:not([disabled]):not([readonly]), [role="combobox"]:not([aria-disabled="true"])'
                        );
                        if (input) input.focus();
                    }
                }
            }, 100);
            return () => clearTimeout(timer);
        }
    }, [isOpen, initialFocusRef]);
    return null;
}

export default CustomModal;
