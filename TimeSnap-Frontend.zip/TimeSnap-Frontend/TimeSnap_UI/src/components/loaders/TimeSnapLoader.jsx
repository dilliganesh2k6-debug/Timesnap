import { useEffect, useRef, useState } from "react";

const TEXT = "#1a2e4a";
const TRACK = "#e2e8f0";
const FILL = "#3b6fd4";

const CSS = `
@keyframes ts-spin-cw { to { transform: rotate(360deg); } }
@keyframes ts-spin-ccw { to { transform: rotate(-360deg); } }
@keyframes ts-hour { to { transform: translateX(-50%) rotate(360deg); } }
@keyframes ts-minute { to { transform: translateX(-50%) rotate(360deg); } }
@keyframes ts-second { to { transform: translateX(-50%) rotate(360deg); } }
@keyframes ts-fadein {
  from { opacity: 0; transform: translateY(10px) scale(0.98); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}
@keyframes ts-progress-fill {
  0% { width: 0%; }
  50% { width: 72%; }
  100% { width: 100%; }
}
`;

function injectStyles() {
  if (document.getElementById("ts-loader-styles")) return;
  const tag = document.createElement("style");
  tag.id = "ts-loader-styles";
  tag.textContent = CSS;
  document.head.appendChild(tag);
}

function ClockTicks() {
  const major = [0, 90, 180, 270];
  const minor = [30, 60, 120, 150, 210, 240, 300, 330];
  const toXY = (deg, r) => ({
    x: 36 + r * Math.sin((deg * Math.PI) / 180),
    y: 36 - r * Math.cos((deg * Math.PI) / 180),
  });

  return (
    <svg
      viewBox="0 0 72 72"
      style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
    >
      {major.map((d) => {
        const a = toXY(d, 28);
        const b = toXY(d, 32);
        return (
          <line
            key={d}
            x1={a.x}
            y1={a.y}
            x2={b.x}
            y2={b.y}
            stroke="#214f93"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
        );
      })}
      {minor.map((d) => {
        const a = toXY(d, 29.5);
        const b = toXY(d, 31.5);
        return (
          <line
            key={d}
            x1={a.x}
            y1={a.y}
            x2={b.x}
            y2={b.y}
            stroke="rgba(59, 111, 212, 0.22)"
            strokeWidth="1.2"
            strokeLinecap="round"
          />
        );
      })}
    </svg>
  );
}

export default function TimeSnapLoader({
  message = "Syncing your schedule...",
  text,
  onDone = null,
  duration = 3000,
}) {
  const [visible, setVisible] = useState(true);
  const timerRef = useRef(null);
  const displayMessage = text || message;

  useEffect(() => {
    injectStyles();
    if (duration > 0 && onDone) {
      timerRef.current = setTimeout(() => {
        setVisible(false);
        onDone();
      }, duration);
    }
    return () => clearTimeout(timerRef.current);
  }, [duration, onDone]);

  if (!visible) return null;

  const S = {
    root: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      width: "min(340px, calc(100vw - 32px))",
      padding: "12px 16px",
      animation: "ts-fadein .35s ease both",
    },
    shell: {
      position: "relative",
      width: "92px",
      height: "92px",
      marginBottom: "18px",
      filter: "drop-shadow(0 10px 22px rgba(0, 0, 0, 0.22))",
    },
    halo: {
      position: "absolute",
      inset: "-14px",
      borderRadius: "50%",
      background:
        "radial-gradient(circle, rgba(255,255,255,0.92) 0%, rgba(226,232,240,0.72) 45%, rgba(255,255,255,0) 78%)",
      opacity: 0.95,
      pointerEvents: "none",
    },
    arcOuter: {
      position: "absolute",
      inset: 0,
      animation: "ts-spin-cw 3.4s linear infinite",
    },
    arcInner: {
      position: "absolute",
      inset: "11px",
      animation: "ts-spin-ccw 2.2s linear infinite",
    },
    face: {
      position: "absolute",
      inset: "17px",
      borderRadius: "50%",
      background: "#ffffff",
      border: "2px solid rgba(26, 46, 74, 0.2)",
      boxShadow: "0 8px 24px rgba(26, 46, 74, 0.22)",
      overflow: "hidden",
    },
    faceGlow: {
      position: "absolute",
      inset: 0,
      borderRadius: "50%",
      background:
        "radial-gradient(circle at 36% 28%, rgba(59, 111, 212, 0.28), transparent 62%)",
    },
    handHour: {
      position: "absolute",
      bottom: "50%",
      left: "50%",
      width: "3px",
      height: "24%",
      background: "#10233d",
      transformOrigin: "bottom center",
      transform: "translateX(-50%) rotate(300deg)",
      borderRadius: "999px",
      boxShadow: "0 0 6px rgba(16, 35, 61, 0.28)",
      animation: "ts-hour 6s steps(12,end) infinite",
    },
    handMinute: {
      position: "absolute",
      bottom: "50%",
      left: "50%",
      width: "2px",
      height: "33%",
      background: "#244f8e",
      transformOrigin: "bottom center",
      transform: "translateX(-50%) rotate(60deg)",
      borderRadius: "999px",
      boxShadow: "0 0 6px rgba(36, 79, 142, 0.2)",
      animation: "ts-minute 2s linear infinite",
    },
    handSecond: {
      position: "absolute",
      bottom: "50%",
      left: "50%",
      width: "1.4px",
      height: "37%",
      background: FILL,
      transformOrigin: "bottom center",
      transform: "translateX(-50%) rotate(0deg)",
      borderRadius: "999px",
      boxShadow: "0 0 8px rgba(59, 111, 212, 0.4)",
      animation: "ts-second 1s steps(60,end) infinite",
    },
    centerDot: {
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%,-50%)",
      width: "8px",
      height: "8px",
      borderRadius: "50%",
      background: FILL,
      boxShadow: "0 0 0 3px #ffffff, 0 0 10px rgba(59, 111, 212, 0.35)",
      zIndex: 2,
    },
    label: {
      marginBottom: "14px",
      fontFamily: "'Plus Jakarta Sans', 'DM Sans', system-ui, -apple-system, sans-serif",
      fontSize: "14px",
      fontWeight: 600,
      lineHeight: 1.4,
      color: "#ffffff",
      textAlign: "center",
      textShadow: "0 2px 10px rgba(0, 0, 0, 0.35)",
    },
    track: {
      width: "220px",
      maxWidth: "100%",
      height: "6px",
      background: "rgba(255, 255, 255, 0.3)",
      borderRadius: "999px",
      overflow: "hidden",
      boxShadow: "0 4px 16px rgba(0, 0, 0, 0.18)",
    },
    fill: {
      height: "100%",
      width: "0%",
      background: FILL,
      borderRadius: "999px",
      animation: "ts-progress-fill 1.8s ease-in-out infinite",
    },
  };

  return (
    <div style={S.root}>
      <div style={S.shell}>
        <div style={S.halo} />
        <svg style={S.arcOuter} viewBox="0 0 120 120" fill="none">
          <circle
            cx="60"
            cy="60"
            r="56"
            stroke="#153e73"
            strokeWidth="2.8"
            strokeLinecap="round"
            strokeDasharray="42 12 16 12 78 14"
            opacity="0.92"
          />
        </svg>

        <svg style={S.arcInner} viewBox="0 0 92 92" fill="none">
          <circle
            cx="46"
            cy="46"
            r="43"
            stroke={FILL}
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeDasharray="20 9 56 9"
            opacity="1"
          />
        </svg>

        <div style={S.face}>
          <div style={S.faceGlow} />
          <ClockTicks />
          <div style={S.handHour} />
          <div style={S.handMinute} />
          <div style={S.handSecond} />
          <div style={S.centerDot} />
        </div>
      </div>

      <div style={S.label}>{displayMessage}</div>

      <div style={S.track}>
        <div style={S.fill} />
      </div>
    </div>
  );
}
