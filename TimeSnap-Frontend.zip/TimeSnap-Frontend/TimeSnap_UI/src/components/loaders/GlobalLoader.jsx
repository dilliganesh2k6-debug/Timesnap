import React from 'react';
import { Box } from '@chakra-ui/react';
import { useLoader } from '../../contexts/LoaderContext';
import TimeSnapLoader from './TimeSnapLoader';

const GlobalLoader = () => {
  const { isGlobalLoading } = useLoader();

  if (!isGlobalLoading) return null;

  return (
    <Box
      position="fixed"
      inset="0"
      bg="rgba(31, 58, 95, 0.34)"
      display="flex"
      alignItems="center"
      justifyContent="center"
      zIndex="9999"
      px={4}
    >
      <TimeSnapLoader />
    </Box>
  );
};

export default GlobalLoader;
