import { useState, useEffect } from "react";
import { Select as ChakraSelect } from "@chakra-ui/react";
import ReactSelect from "react-select";
import PropTypes from "prop-types";
import { fetchDropdownData } from "utils/api";
import Select, { components } from "react-select";

function Dropdown({
  type,
  placeholder,
  selectedValue,
  setSelectedValue,
  extraParams = {},
  isMulti = false,
  itemsProp = null,
}) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Helper to get consistent labels for sorting
  const getItemLabel = (item) => {
    return (
      item.taskName ??
      item.subCategoryName ??
      item.categoryName ??
      item.name ??
      ""
    );
  };

  const CheckboxOption = (props) => {
    return (
      <components.Option {...props}>
        <div style={{ display: "flex", alignItems: "center" }}>
          {/* Label */}
          <span>{props.label}</span>

          {/* Tickmark when selected */}
          {props.isSelected && (
            <span style={{ marginLeft: "auto", color: "green", fontWeight: "bold" }}>
              ✔
            </span>
          )}
        </div>
      </components.Option>
    );
  };

  useEffect(() => {
    const sortItems = (data) => {
      return [...(data || [])].sort((a, b) =>
        getItemLabel(a).localeCompare(getItemLabel(b), undefined, {
          sensitivity: "base",
          numeric: true,
        })
      );
    };

    // ✅ If items are passed from parent (subTasks case)
    if (Array.isArray(itemsProp)) {
      setItems(sortItems(itemsProp));
      setLoading(false);
      setError(null);
      return;
    }
    setLoading(true);
    setError(null);

    fetchDropdownData(type, extraParams)
      .then((data) => setItems(sortItems(data)))
      .catch(setError)
      .finally(() => setLoading(false));
  }, [type, JSON.stringify(extraParams), itemsProp]);


  // If Multi select -> react-select component
  if (isMulti) {
    const options = items.map((item) => ({
      value: item.id,
      label: item.name,
    }));
    // Ensure selectedValue is an array, and compare as strings to avoid type issues
    const selectedIds = Array.isArray(selectedValue)
      ? selectedValue.map((v) => String(v))
      : [];

    const selectedObjects = options.filter((opt) =>
      selectedIds.includes(String(opt.value))
    );

    return (
      <Select
        isMulti
        placeholder={placeholder} hideSelectedOptions={false}
        options={options}
        value={selectedObjects}
        onChange={(selected) => {
          const ids = selected?.map((o) => o.value) || [];
          setSelectedValue(ids);
        }}
        isLoading={loading}
        closeMenuOnSelect={false}
        components={{ Option: CheckboxOption }}
        styles={{
          control: (base) => ({
            ...base,
            minHeight: "40px",
            overflow: "hidden",

          }),

          valueContainer: (base) => ({
            ...base,
            display: "flex",
            flexWrap: "nowrap",
            overflowX: "auto",
            scrollbarWidth: "thin",
          }),

          multiValue: (base) => ({
            ...base,
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            whiteSpace: "nowrap",
            flexShrink: 0,
          }),

          multiValueLabel: (base) => ({
            ...base,
            whiteSpace: "nowrap",
          }),

          option: (base, state) => ({
            ...base,
            backgroundColor: state.isSelected ? "#d6eafb" : "white",
            color: "black",

            ":hover": {
              backgroundColor: "blue.500",
            },

            ":active": {
              backgroundColor: "white",
            },
          }),
        }}

      />
    );
  }



  /* ----------------------------------
     DETECT FILTER DROPDOWN (All ...)
  -----------------------------------*/
  const isFilterDropdown = placeholder?.startsWith("All ");

  /* ----------------------------------
     METHOD 1: Chakra Select (Filters)
  -----------------------------------*/
  if (isFilterDropdown) {
    return (
      <ChakraSelect
        focusBorderColor="blue.500"
        value={selectedValue ?? ""}
        onChange={(e) => setSelectedValue(e.target.value)}
      >
        {/* Disabled placeholder */}
        <option value="">
          {placeholder}
        </option>

        {loading ? (
          <option disabled>Loading...</option>
        ) : error ? (
          <option disabled>
            {error?.message || "Failed to load data"}
          </option>
        ) : (
          items.map((item) => (
            <option key={item.id} value={item.id}>
              {item.name}
            </option>
          ))
        )}
      </ChakraSelect>
    );
  }

  /* ----------------------------------
     METHOD 2: react-select (Forms)
  -----------------------------------*/
  // const options = items.map((item) => ({
  //   value: item.id,
  //   label:
  //     type === "clients" && item.location
  //       ? `${item.name} (${item.location})`
  //       : item.name,
  // }));
  const options = items
    .map((item) => {
      const value =
        item.sub_category_Id ??
        item.subCategoryId ??
        item.taskId ??
        item.id ??
        item.categoryId;

      if (value === undefined || value === null) return null;

      return {
        value: String(value),   // ✅ force string consistency
        label:
          item.taskName ??
          item.subCategoryName ??
          item.categoryName ??
          item.name ??
          "",
      };
    })
    .filter(Boolean); // ✅ remove invalid options


  const selectedOption = selectedValue
    ? options.find(
      (o) => String(o.value) === String(selectedValue)
    )
    : null;

  return (
    <Select
      placeholder={placeholder}
      options={options}
      // isLoading={loading}
      value={selectedOption}
      onChange={(option) => setSelectedValue(option?.value || "")}
      isClearable={false}
      menuPortalTarget={document.body}
      menuPosition="fixed"
      components={{
        IndicatorSeparator: () => null,
      }}
      styles={{
        menuPortal: (base) => ({
          ...base,
          zIndex: 1500,
        }),

        container: (base) => ({
          ...base,
          width: "100%",
        }),

        control: (base, state) => ({
          ...base,
          width: "100%",
          minHeight: "40px",
          borderColor: state.isFocused ? "#3182ce" : "#CBD5E0",
          boxShadow: state.isFocused ? "0 0 0 1px #3182ce" : "none",
        }),

        /* ✅ THIS FIXES SELECTED VALUE COLOR */
        singleValue: (base) => ({
          ...base,
          color: "#1A202C",          // text color (dark)
          fontWeight: 500,
        }),

        /* optional – keeps padding consistent */
        valueContainer: (base) => ({
          ...base,
          paddingLeft: "12px",
        }),

        option: (base, state) => ({
          ...base,
          backgroundColor: state.isSelected
            ? "#3182ce"      // selected option bg
            : state.isFocused
              ? "#ebf8ff"      // hover bg
              : "white",
          color: state.isSelected ? "white" : "#1A202C",
          cursor: "pointer",
        }),
      }}

    />

  );
}




Dropdown.propTypes = {
  type: PropTypes.string.isRequired,
  placeholder: PropTypes.string,
  selectedValue: PropTypes.oneOfType([PropTypes.string, PropTypes.number, PropTypes.array]),
  setSelectedValue: PropTypes.func.isRequired,
  extraParams: PropTypes.object,
  isMulti: PropTypes.bool,
};

export default Dropdown;
