// utils/gridUtils.js
export const clearGridFocus = (gridRef) => {
    if (gridRef?.current?.api) {
      gridRef.current.api.clearFocusedCell();
    }
  
    if (typeof document !== 'undefined') {
      document.activeElement.blur();
    }
  };
  