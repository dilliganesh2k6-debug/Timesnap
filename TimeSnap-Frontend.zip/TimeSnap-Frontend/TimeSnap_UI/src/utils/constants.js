
// Timesheet Screen constants
export const PROGRESS_COLOR_MAP = { UNDER: '#c93434', EXACT: '#85e085', OVERTIME: '#ffa500' };

export const LOCAL_STORAGE_KEYS = {
  TASKS_BY_WEEK: 'tasksByWeek',
  EMP_CODE: 'emp_code',
  ROLE_ID: 'roleId'
};
// employee screen  
export const MAX_EMPLOYEE_NAME_LENGTH = 30;
export const MAX_NAME_LENGTH = 30;
// task screen ,reports screen (search)
export const MAX_INPUT_LENGTH = 50;
export const MAX_DESCRIPTION_LENGTH = 100;

export const validateStringInput = (value) => {
  return /^[A-Za-z\s]+$/.test(value) && value.length <= MAX_INPUT_LENGTH;
};

export const MAX_DAILY_HOURS = 24;
export const MAX_MINUTES = 59;
export const REGULAR_WORK_HOURS = 8;
export const MAX_WEEKLY_HOURS = 7 * 8;
export const PERCENTAGE_MAX = 100;

// Time-related constants
export const MINUTES_IN_HOUR = 60;
export const MINUTES_PADDING_THRESHOLD = 10;
export const MINUTES_DOUBLE_DIGIT_MULTIPLIER = 10;

// fetchTimesheetDetails
export const MILLISECONDS_IN_DAY = 1000 * 60 * 60 * 24;
export const DAYS_IN_WEEK = 7;
export const UNKNOWN_PROJECT_LABEL = 'Unknown Project';
export const DEFAULT_PROJECT_COLOR = '#ccc';
export const DATE_LOCALE = 'en-US';
export const DATE_FORMAT_OPTIONS = { weekday: 'short', month: 'short', day: 'numeric' };
export const DEFAULT_HOUR_VALUE = 0;
export const DATE_FORMAT_SLICE_INDEX = 10;

// getWeekStartEndDates
export const WEEK_START_OFFSET = 1; // Monday
export const WEEK_END_OFFSET = 6; // Sunday

export const WEEK_START_INDEX = 0;
export const WEEK_END_INDEX = 6;
export const WEEK_RANGE_DATE_FORMAT = {
  day: '2-digit',
  month: 'short',
  year: 'numeric',
};
export const TIMESHEET_STATUSES = {
  Approved: 'Approved',
  Posted: 'Posted',
  Pending: 'Pending',
  Declined: 'Declined',
  PartiallyPosted: 'Partially Posted',
  PartiallyApproved: 'Partially Approved'
};

export const STATUS_COLOR_MAP = {
  [TIMESHEET_STATUSES.Approved]: 'green',
  [TIMESHEET_STATUSES.Posted]: 'yellow',
  [TIMESHEET_STATUSES.Pending]: 'red',
  [TIMESHEET_STATUSES.Declined]: 'orange',
  [TIMESHEET_STATUSES.PartiallyPosted]: 'blue',
  [TIMESHEET_STATUSES.PartiallyApproved]: 'blue',
};

export const STATUS_COLORS = {
  Approved: '#c93434', // Red
  Posted: '#85e085', // Green
  Pending: '#ffa500' // Orange
};

// Default Values for Timesheet Payload
export const DEFAULT_TIMESHEET_ID = 0;
export const DEFAULT_HOURS = 0;

// Toast Configuration
export const TOAST_CONFIG = {
  success: {
    title: 'Success',
    status: 'success',
    duration: 3000,
    isClosable: true,
    position: 'top-end'
  },
  error: {
    title: 'Error',
    status: 'error',
    duration: 3000,
    isClosable: true,
    position: 'top-end'
  },
  warning: {
    title: 'Warning',
    status: 'warning',
    duration: 3000,
    isClosable: true,
    position: 'top-end'
  }
};

// Profile Image Constants
export const PROFILE_IMAGE = {
  ALLOWED_TYPES: ['image/jpeg', 'image/png', 'image/gif'],
  MAX_SIZE: 5 * 1024 * 1024, // 5MB in bytes
  ERROR_MESSAGES: {
    SIZE: 'Please upload an image smaller than 5MB.',
    TYPE: 'Please upload a JPEG, PNG, or GIF image.',
    EMPTY: 'Please choose an image to upload.'
  }
};
// Date Format Constants
export const DATE_FORMAT_SPLIT_CHAR = 'T';

// Modal/Task-related constants
export const EMPTY_SEARCH_TERM = '';
export const EMPTY_FILTERED_ROW_DATA = undefined;
export const EMPTY_SELECTED_TASKS = [];

//Change Password Screen
export const ROLE_ID = 7000;

export const statusColorScheme = {
  Todo: 'yellow',
  Active: 'green',
  Inactive: 'red',
  'In-Progress': 'blue',
  Completed: 'green',
  Pending: 'orange',
  Hold: 'red',
  Break: 'orange',
};

// settings screen
export const validateAlphanumericInput = (value) => {
  return /^[A-Za-z0-9\s]*$/.test(value) && value.length <= MAX_NAME_LENGTH;
};

export const validateDescriptionInput = (value) => {
  return /^[A-Za-z0-9\s]*$/.test(value) && value.length <= MAX_DESCRIPTION_LENGTH;
};

//Project screen
export const projectValidateAlphanumeric = (value) => {
  return /^[A-Za-z0-9\s]*$/.test(value) && value.length <= MAX_NAME_LENGTH; // Allows spaces
};

//Project, Team, Task screen
export const ValidateNameField = (name) => {
  const containsAlphanumeric = /[a-zA-Z0-9]/.test(name);
  return name.trim() !== '' && containsAlphanumeric;
};

//Project screen
export const ValidateProjectNameField = (name) => {
  const MAX_NAME_LENGTH = 30; // You can reuse your global constant if already defined
  const pattern = /^[a-zA-Z0-9 _-]+$/; // Allows letters, numbers, space, - and _
  const containsAlphanumeric = /[a-zA-Z0-9]/.test(name);

  return (
    name.trim() !== '' &&
    containsAlphanumeric &&
    pattern.test(name) &&
    name.length <= MAX_NAME_LENGTH
  );
};

export const formatDate = (dateStr) => {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-');
  return `${day}-${month}-${year}`;
};


