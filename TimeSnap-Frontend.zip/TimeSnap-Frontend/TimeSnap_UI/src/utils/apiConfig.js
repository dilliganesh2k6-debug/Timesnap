import axios from 'axios';
import { isTokenExpired } from './authUtils';
 
// Base URL for API requests
export const API_BASE_URL =
  process.env.REACT_APP_API_BASE_URL;
// console.log("API URL:", process.env.REACT_APP_API_BASE_URL);


const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor 
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

 
// Response interceptor to extract meaningful error messages
// apiClient.interceptors.response.use(
//   (response) => response, // Pass successful responses

//   (error) => {
//     let errorMessage = 'An unexpected error occurred.';

//     if (error.response) {
//       errorMessage =
//         error.response.data?.message || error.response.statusText;

//       // 🔐 Token expired or invalid
//       if (error.response.status === 401) {
//         localStorage.clear();
//         sessionStorage.clear();
//         window.location.href = '/auth/signin';
//       }
//     }

//     return Promise.reject(new Error(errorMessage));
//   }
  // (error) => {
  //   let errorMessage = "An unexpected error occurred.";
 
  //   if (error.response) {
  //     errorMessage = error.response.data?.message || error.response.statusText;
  //   } else if (error.request) {
      
  //     errorMessage = "No response from server. Please try again.";
  //   } else {
  //     errorMessage = error.message;
  //   }
 
  //   return Promise.reject(new Error(errorMessage));
  // }
// );
apiClient.interceptors.response.use(
  (response) => response,

  (error) => {
    let errorMessage = "An unexpected error occurred.";

    if (error.response) {
      errorMessage =
        error.response.data?.message || error.response.statusText;

      const status = error.response.status;
      const requestUrl = error.config?.url || "";

      // 🔐 JWT expired / invalid — but NOT login API
      if (
        status === 401 &&
        !requestUrl.includes("/login") &&
        !requestUrl.includes("/signin")
      ) {
        localStorage.clear();
        sessionStorage.clear();

        // Optional: show message before redirect
        localStorage.setItem(
          "authError",
          "Session expired. Please login again."
        );

        window.location.href = "/auth/signin";
      }
    } 
    else if (error.request) {
      errorMessage = "No response from server. Please try again.";
    } 
    else {
      errorMessage = error.message;
    }

    return Promise.reject(new Error(errorMessage));
  }
);

 
export default apiClient;
 
 