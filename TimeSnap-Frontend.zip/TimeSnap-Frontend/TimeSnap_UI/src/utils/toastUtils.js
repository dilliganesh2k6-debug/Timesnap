import {
  useToast,
  Box,
  Text,
  Flex,
  CloseButton,
  Icon,
} from '@chakra-ui/react';
import {
  CheckCircleIcon,
  WarningIcon,
  InfoIcon,
  WarningTwoIcon,
  SmallCloseIcon,
} from '@chakra-ui/icons';
import { useCallback } from 'react';
import { keyframes } from '@emotion/react';

export const useCustomToast = () => {
  const toast = useToast();

  return useCallback((type, message) => {
    toast({
      position: 'top-right',
      duration: 3000,
      isClosable: true,
      render: ({ onClose }) => (
        <CustomToast message={message} type={type} onClose={onClose} />
      ),
    });
  }, [toast]);
};

const progressAnimation = keyframes`
  from { width: 100%; }
  to { width: 0%; }
`;

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(-10px); }
  to { opacity: 1; transform: translateY(0); }
`;

const CustomToast = ({ message, type, onClose }) => {
  return (
    <Box
      animation={`${fadeIn} 0.3s ease`}
      p={6}
      borderRadius="lg"
      bg={getBg(type)}
      color="white"
      boxShadow="lg"
      minW="280px"
      position="relative"
      overflow="hidden"
    >
      <Flex justify="space-between" align="center">
        <Flex align="center" gap={2}>
          <Icon as={getIcon(type)} w={6} h={6} />
          <Text fontWeight="medium">{message}</Text>
        </Flex>
        <CloseButton size="sm" color="whiteAlpha.800" onClick={onClose} />
      </Flex>

      <Box
        position="absolute"
        bottom="0"
        left="0"
        height="4px"
        width="100%"
        bg="whiteAlpha.400"
      >
        <Box
          height="70%"
          bg="white"
          animation={`${progressAnimation} 3s linear forwards`}
        />
      </Box>
    </Box>
  );
};

const getIcon = (type) => {
  switch (type) {
    case 'success':
      return CheckCircleIcon;
    case 'error':
      return WarningIcon;
    case 'info':
      return InfoIcon;
    case 'warning':
      return WarningTwoIcon;
    default:
      return InfoIcon;
  }
};

const getBg = (type) => {
  switch (type) {
    case 'success':
      return 'green.500';
    case 'error':
      return 'red.600';
    case 'info':
      return 'orange.400';
    case 'info-blue':
      return 'blue.400';
    case 'warning':
      return 'orange.400';
    default:
      return 'gray.600';
  }
};
