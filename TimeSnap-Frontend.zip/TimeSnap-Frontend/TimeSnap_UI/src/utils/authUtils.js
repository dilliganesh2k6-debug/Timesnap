import { logoutFromServer } from 'utils/api';

export const logoutUser = async ({
  navigate,
  setAuth,
  toast = null,
  redirectPath = '/auth/signin',
} = {}) => {

  const empCode = localStorage.getItem('emp_code');

  // 1️⃣ Notify server (best effort)
  try {
    if (empCode) {
      await logoutFromServer(parseInt(empCode));
    }
  } catch (error) {
    console.error('Logout API failed:', error);
    if (toast) {
      toast({
        title: 'Logout Warning',
        description: 'Server logout failed, but you were logged out locally.',
        status: 'warning',
        duration: 4000,
        isClosable: true,
        position: 'top-right',
      });
    }
  }

  // 2️⃣ IMPORTANT: notify other tabs FIRST
  localStorage.setItem('logout', Date.now());

  // 3️⃣ Clear ALL auth + role related keys (explicit, not clear())
  localStorage.removeItem('token');
  localStorage.removeItem('roleId');
  localStorage.removeItem('accessDetails');
  localStorage.removeItem('IS_ADMIN');
  localStorage.removeItem('sessionID');
  localStorage.removeItem('activeUser');
  localStorage.removeItem('emp_code');

  // 4️⃣ Clear session storage
  
 
  // Local logout steps
  
 
  localStorage.clear();
  sessionStorage.clear();
  if (setAuth) {
    setAuth({
      isAuthenticated: false,
      roleId: null,
      isAdmin: false,
      accessDetails: null,
      user: null,
    });
  }

  // 5️⃣ Navigate safely (SPA)
  if (navigate) {
    navigate(redirectPath, { replace: true });
  }
};

export const getTokenExpiry = (token) => {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    return payload.exp * 1000; // convert to ms
  } catch {
    return null;
  }
};

export const isTokenExpired = (token) => {
  if (!token) return true;

  try {
    const payload = JSON.parse(atob(token.split('.')[1]));

   console.log("JWT payload:", payload);
  console.log("Token expiry time:", new Date(payload.exp * 1000));
  console.log("Current time:", new Date());

    const expiry = payload.exp * 1000; // JWT exp is in seconds
    return Date.now() > expiry;
  } catch (err) {
    return true;
  }
};

 
 
