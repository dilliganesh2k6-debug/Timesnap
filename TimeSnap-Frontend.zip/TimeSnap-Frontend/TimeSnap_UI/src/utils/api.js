import apiClient from 'utils/apiConfig';


export const updateUserActivity = async (empCode) => {
  try {
    await apiClient.post('/Users/updateactivity', empCode);
  } catch (error) {
    console.error("Failed to update user activity:", error);
  }
};

export const logoutFromServer = async (empCode) => {
  try {
    await apiClient.post('/Users/logout', empCode);
  } catch (error) {
    throw error;
  }
};

// Add this function to your api.js file after the changePassword function

// Change user password (for logged-in users)
export const changeUserPassword = async (empCode, currentPassword, newPassword) => {
  try {
    const response = await apiClient.post('/Users/ChangePassword', {
      empCode: parseInt(empCode),
      currentPassword: currentPassword,
      newPassword: newPassword,
    });
    return response.data;
  } catch (error) {
    // Handle different error scenarios
    if (error.response) {
      // The server responded with an error status
      throw new Error(error.response.data.message || 'Failed to change password');
    } else if (error.request) {
      // The request was made but no response was received
      throw new Error('No response from server. Please check your connection.');
    } else {
      // Something else happened
      throw new Error(error.message || 'An unexpected error occurred');
    }
  }
};

// Reset user password to default (Admin action)
export const resetUserPassword = async (empCode) => {
  try {
    // Send empCode as part of the URL, not in the body
    const response = await apiClient.post(`/Users/ResetToDefaultPassword/${empCode}`);
    return response.data;
  } catch (error) {
    console.error("Failed to reset user password:", error);
    throw error; // rethrow so the UI can handle it
  }
};


// ** User Profile API Methods ** //

// Fetch user profile information by Employee Code
export const fetchProfileInfo = async (employeeCode) => {
  const response = await apiClient.get(`/Users/profileInfo?EmployeeCode=${employeeCode}`);
  return response.data;
};


export const fetchUserProfilePicture = async (empCode) => {
  try {
    const response = await apiClient.get(`/userprofilepicture/get/${empCode}`, { responseType: 'blob' });
    return URL.createObjectURL(response.data);
  } catch (error) {
    // console.error("Error loading profile picture:", error);
    return null; // Return null to prevent UI crashes
  }
};



export const uploadUserProfilePicture = async (file, empCode) => {
  const formData = new FormData();
  formData.append("file", file);
  formData.append("empCode", empCode);

  try {
    const response = await apiClient.post('/userprofilepicture/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data', // Override for file uploads
      },
    });
    return response.data;
  } catch (error) {
    console.error("Error uploading profile photo:", error);
    throw error;
  }
};

// Delete user profile picture
export const deleteUserProfilePicture = async (empCode) => {
  const response = await apiClient.post(`/userprofilepicture/delete/${empCode}`);
  return response.data;
};


// Update an existing project
export const updateProject = async (projectId, projectData) => {
  const response = await apiClient.post(`/ProjectView/update/${projectId}`, projectData);
  return response.data;
};

// Update employee details
export const updateEmployeeDetails = async (empCode, userDetails) => {
  const response = await apiClient.post(`/Employee/${empCode}`, userDetails);
  return response.data;
};

// Fetch employee details by Employee Code and Role ID
export const fetchEmployeeDetails = async (empCode, roleId) => {
  const response = await apiClient.get(`/Employee/${empCode}/${roleId}`);
  return response.data;
};

// ** User Management API Methods ** //

// Fetch User Management Data with Filters
export const fetchUserManagementDatas = async (filters = {}) => {
  try {
    const response = await apiClient.get('/UserManagement', { params: filters });
    return response.data;
  } catch (error) {
    throw new error.message
  }
};

// Add a new user
export const addUsers = async (userToAdd) => {
  const response = await apiClient.post('/UserManagement', userToAdd);
  return response.data;
};

// Update an existing user
export const updateUsers = async (updateRequest) => {
  const response = await apiClient.post(`/UserManagement/update/${updateRequest.emp_code}`, updateRequest);
  return response.data;
};

// Delete a user by Employee Code
export const deleteUser = async (empCode) => {
  const response = await apiClient.post(`/UserManagement/delete/${empCode}`);
  return response.data;
};


// ** Team management API Methods ** //

// Fetch all teams
export const getTeam = async () => {
  const response = await apiClient.get('/TeamManagement');
  return response.data;
};

// Add a new team
export const createTeam = async (teamData) => {
  const response = await apiClient.post('/TeamManagement', teamData);
  return response.data;
};

// Update an existing team
export const updateTeam = async (teamId, updatedTeamData) => {
  const response = await apiClient.post(`/TeamManagement/update/${teamId}`, updatedTeamData);
  return response.data;
};

// Delete a team
export const removeTeam = async (teamId) => {
  const response = await apiClient.post(`/TeamManagement/delete/${teamId}`);
  return response.data;
};


// ** Team members screen API methods ** //

// Add a new team member
export const createTeamMember = async (teamMember) => {
  try {
    const response = await apiClient.post('/ProjectMembers', {
      projectid: teamMember.projectId,
      emp_code: teamMember.emp_code,
      user_name: teamMember.user_name,
    });
    return response.data;
  } catch (error) {
    throw Error(error.message);
  }
};


// Fetch user details
export const getUserDetails = async () => {
  const response = await apiClient.get('/ProjectMembers/role');
  return response.data;
};

// Fetch Project members by Project ID
export const getProjectMembersByProjectId = async (projectid) => {
  const response = await apiClient.get(`/Projectmembers/${projectid}`);
  return response.data;
};

// Fetch team members by team ID
export const getTeamMembersByTeamId = async (teamId) => {
  const response = await apiClient.get(`/teammembers/${teamId}`);
  return response.data;
};

// Delete a team member
export const removeMemberByProjectIdandEmpcode = async (projectId, empCode) => {
  try {
    const response = await apiClient.post(`/ProjectMembers/${projectId}/${empCode}`);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Failed to remove team member.');
  }
};

export const removeTeamMemberByempCode = async (projectId, empCode) => {
  try {
    const response = await apiClient.post(`/ProjectMembers/${projectId}/${empCode}`);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Failed to remove team member.');
  }
};



// ** Project management API Methods ** //

// Fetch all project management data
export const fetchProjectManagementDatas = async () => {
  const response = await apiClient.get('/ProjectView');
  return response.data;
};

// Fetch teams by manager ID
export const fetchTeamsByManager = async (managerId) => {
  const response = await apiClient.get(`/ProjectView/GetTeamsByManager/${managerId}`);
  return response.data;
};

// Fetch project task status by project ID
export const fetchProjectTaskStatusById = async (projectId) => {
  const response = await apiClient.get(`/ProjectTaskStatus/${projectId}`);
  return response.data;
};


// Add a new project
export const addProject = async (newProject) => {
  const response = await apiClient.post('/ProjectView', newProject);
  return response.data;
};

// Delete a project by Project ID
export const deleteProject = async (projectId) => {
  try {
    const response = await apiClient.post(`/ProjectView/delete/${projectId}`);
    return response.data;
  } catch (error) {
    throw new Error(error.message);
  }
};

// ** view Project management API Methods **/


// Get all main categories
export const getTaskCategories = async () => {
  const response = await apiClient.get('/Tasks/GetCategories');
  return response.data;
};

// Get sub tasks
export const getTasksByCategory = async (categoryId) => {
  const response = await apiClient.get(`/Tasks/GetTasksByCategory/${categoryId}`);
  return response.data;
};

// Fetch edit project data by Project ID
export const fetchEditProjectDatas = async (projectId) => {
  try {
    const response = await apiClient.get(`/EditProject/${projectId}`);
    return response.data;
  } catch (error) {
    throw new Error(error.message);
  }
};


// Assign new tasks to a project
export const addAssignTasks = async (newTask) => {
  try {
    const response = await apiClient.post('/EditProject', newTask);
    return response.data;
  }
  catch (error) {
    throw new Error(error.message);
  }
};

// Bulk assign tasks to a project
export const addBulkAssignTasks = async (bulkPayload) => {
  try {
    const response = await apiClient.post('/EditProject/bulk', bulkPayload);
    return response.data;
  }
  catch (error) {
    throw new Error(error.message);
  }
};


// Fetch team names by project ID
export const fetchTeamNamesByProject = async (projectId) => {
  const response = await apiClient.get(`/EditProject/GetTeamNamesByProject/${projectId}`);
  return response.data;
};

// Update a project task by index ID
export const updateProjectTask = async (task_id, updatedTask) => {
  const response = await apiClient.post(`/EditProject/update/${task_id}`, updatedTask);
  return response.data;
};

// Delete a task by index ID
export const deleteTaskByIndexId = async (task_id) => {
  try {
    const response = await apiClient.post(`/EditProject/delete/${task_id}`);
    return response.data;
  } catch (error) {
    throw new Error(error.message);
  }
};


// ** Task management API Methods ** //

// Fetch all tasks
export const fetchTasks = async () => {
  const response = await apiClient.get('/Tasks');
  return response.data;
};

export const addTasks = async (newTask) => {
  try {
    const response = await apiClient.post('/Tasks', newTask);
    return response.data;
  }
  catch (error) {
    throw new Error(error.message);
  }
};

// Edit a task by ID
// export const EditTasks = async (id, updatedTask) => {
//   try{
//   const response = await apiClient.post(`/Tasks/update/${id}`, updatedTask);
//   return response.data;
// }catch (error) {
//   throw new Error(error.message);
// }
// };

// Edit a task (POST)
export const EditTasks = async (id, updatedTask) => {
  try {
    const payload = {
      taskName: updatedTask.taskName.trim(),
      description: updatedTask.description.trim(),
      categoryId: Number(updatedTask.categoryId),
    };

    const response = await apiClient.post(
      `/Tasks/update/${id}`,
      payload
    );

    return response.data;
  } catch (error) {
    throw new Error(
      error.response?.data?.message || 'Failed to update task'
    );
  }
};


// Delete a task by ID
// export const deleteTask = async (id) => {
//   try {
//   const response = await apiClient.delete(`/Tasks/id/${id}`);
//   return response.data;
//   } catch (error) {
//     throw new Error(error.message);
//   }
// };

export const deleteTask = async (id) => {
  try {
    const response = await apiClient.post(`/Tasks/delete/${id}`);
    return response.data;
  } catch (error) {
    throw new Error(
      error.response?.data?.message || 'Failed to delete task'
    );
  }
};

// ** Clients API Methods ** //

// Fetch all clients
export const fetchClients = async () => {
  const response = await apiClient.get('/Settings/clients');
  return response.data;
};

// Add a new client
export const addClient = async (clientData) => {
  try {
    const response = await apiClient.post('/Settings/clients/create', clientData);
    return response.data;
  } catch (error) {
    throw new Error(error.message);
  }
};

// Update an existing Department
export const updateClient = async (clientId, updatedClientData) => {
  const response = await apiClient.post(`/Settings/clients/update/${clientId}`, updatedClientData);
  return response.data;
};
// Delete a client by ID
export const deleteClient = async (clientId) => {
  try {
    const response = await apiClient.post(`/Settings/clients/delete/${clientId}`);
    return response.data;
  } catch (error) {
    throw new Error(error.message);
  }
};


// ** Departments API Methods ** //

// Fetch all departments
export const fetchDepartments = async () => {
  const response = await apiClient.get('/Settings/departments');
  return response.data;
};

// Add a new department
export const addDepartment = async (departmentData) => {
  try {
    const response = await apiClient.post('/settings/departments/create', departmentData);
    return response.data;
  } catch (error) {
    throw new Error(error.message); // Ensure error message is correctly propagated
  }
};

// Update an existing Department
export const updateDepartment = async (departmentId, updatedDepartmentData) => {
  const response = await apiClient.post(`/Settings/departments/update/${departmentId}`, updatedDepartmentData);
  return response.data;
};

// Delete a department by ID
export const deleteDepartment = async (departmentId) => {
  try {
    const response = await apiClient.post(`/Settings/departments/delete/${departmentId}`);
    return response.data;
  } catch (error) {
    throw new Error(error.message); // Ensure error message is correctly propagated
  }
};


// ** categories API Methods ** //

// Fetch all categories
export const fetchCategories = async () => {
  try {
    const response = await apiClient.get('/Settings/GetAllCategories');
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Add a new category
export const addCategories = async (categoryData) => {
  try {
    console.log("Sending request to API with data:", categoryData); // Debugging

    const response = await apiClient.post('/Settings/AddCategory', categoryData);

    console.log("API response:", response.data);
    return response.data;
  } catch (error) {
    console.error("API Error:", error.message);
    throw new Error(error.message);
  }
};
// Update an existing Department
export const updateCategory = async (id, updatedCategoryData) => {
  if (!id) {
    throw new Error('Category ID is required for updating.');
  }

  console.log(`Sending PUT request to: /Settings/UpdateCategory/${id}`); // Debugging log

  const response = await apiClient.post(`/Settings/UpdateCategory/${id}`, updatedCategoryData);
  return response.data;
};


// Delete a category by ID
export const deleteCategory = async (id) => {
  if (!id) {
    throw new Error('Category ID is required for deletion.');
  }

  try {
    const response = await apiClient.post(`/Settings/DeleteCategory/${id}`);
    return response.data; // Axios automatically parses JSON
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Failed to delete category');
  }
};



// ** Roles API Methods ** //

// Fetch all roles
export const fetchRoles = async () => {
  const response = await apiClient.get('/Settings/roles');
  return response.data;
};

// Add a new role
export const addRole = async (roleData) => {
  try {
    const response = await apiClient.post('/Settings/roles/create', roleData);
    return response.data;
  } catch (error) {
    throw new Error(error.message);
  }
};

// Update an existing Department
export const updateRole = async (roleId, updatedRoleData) => {
  const response = await apiClient.post(`/Settings/roles/update/${roleId}`, updatedRoleData);
  return response.data;
};
// Delete a role by ID
export const deleteRole = async (roleId) => {
  try {
    const response = await apiClient.post(`/Settings/roles/delete/${roleId}`);
    return response.data;
  } catch (error) {
    throw new Error(error.message);
  }
};

// ** Access Rights API Methods ** //
// Fetch access rights for a role
export const fetchAccessRights = async (role) => {
  try {
    const response = await apiClient.get(`/Users/getaccessbyrole/${role}`);
    return response.data;
  }
  catch (error) {
    throw new Error(error.message);
  }
};

// Save access rights for a role
export const saveAccessRights = async (payload) => {
  const response = await apiClient.post('/Users/saveaccessbyrole', payload);
  return response.data;
};

// ** Project Dropdown for Timesheet ** //
export const projectDropdown = async () => {
  const response = await apiClient.get('/Timesheets/projectDataforTimesheet');
  return response.data;
};

export const fetchProjectsByEmpCode = async () => {
  const empCode = localStorage.getItem("emp_code"); // Get employee code from local storage
  if (!empCode) {
    throw new Error("Employee code not found in local storage.");
  }
  const response = await apiClient.get(`/Timesheets/GetProjectsByEmpCode?empCode=${empCode}`);
  return response.data;
};


// ** Login API Methods ** //
export const loginUser = async (email_Id, password) => {
  const response = await apiClient.post('/Users/login', { email_Id, password });
  return response.data;
};

export const changePassword = async (email, newPassword) => {
  try {
    const response = await apiClient.post('/Users/change-password', {
      email_Id: email,
      newPassword: newPassword,
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};


// Fetch Dropdown Data
export const fetchDropdownData = async (type, extraParams = {}) => {
  const query = new URLSearchParams({ type, ...extraParams }).toString();
  const res = await apiClient.get(`/DropDown/dropdown?${query}`);
  return res.data;
};




// ** Timesheet API Methods ** //

export const getFilteredTasks = async (projectId, categoryId, subCategoryId) => {
  return apiClient.get("/EditProject/filter", {
    params: {
      projectId,
      categoryId,
      subCategoryId
    }
  });
};


// Fetch timesheet data
export const fetchTimesheetData = async (empCode, startDate, endDate) => {
  const response = await apiClient.get(
    `/Timesheets/timesheetdetails?empCode=${empCode}&startDate=${startDate}&endDate=${endDate}`
  );
  return response.data;
};

// ✅ Get all notes for a timesheet
export const fetchTimesheetNotes = async (timesheetId, empCode) => {
  const response = await apiClient.get(
    `/TimesheetNotes/GetNotes?timesheetId=${timesheetId}&empCode=${empCode}`
  );
  return response.data;
};

// Save timesheet as draft
export const TimesheetSaveDraft = async (timesheetPayload) => {
  // ensure header contains IsDraftSubmission flag
  if (!timesheetPayload.header) timesheetPayload.header = {};
  timesheetPayload.header.IsDraftSubmission = true;
  const response = await apiClient.post('/Timesheets/save', timesheetPayload);
  return response.data;
};



// Delete a timesheet task
export const deleteTimesheetTask = async (empCode, taskId, projectId, categoryId, subCategoryId, startDate, endDate) => {
  const response = await apiClient.post(
    `/timesheets/deletetask?empCode=${empCode}&taskId=${taskId}&projectId=${projectId}&categoryId=${categoryId}&subCategoryId=${subCategoryId}&startDate=${startDate}&endDate=${endDate}`
  );
  return response.data;
};

export const submitWeek = async (empCode, startDate, endDate) => {
  const payload = {
    EmpCode: empCode,
    StartDate: startDate,
    EndDate: endDate
  };
  const response = await apiClient.post('/Timesheets/SubmitWeek', payload);
  return response.data;
};


// Fetch approval timesheet data for a manager
export const fetchApprovalTimesheetData = async (managerId) => {
  const response = await apiClient.get(`/Timesheets/GetTimesheetApprovals?managerId=${managerId}`);
  return response.data;
};

export const fetchApproveTimesheetDetails = async (timesheetId, projectId) => {
  const response = await apiClient.get(`/Timesheets/GetTimesheetDetails/${timesheetId}/${projectId}`);
  console.log('fetchApproveTimesheetDetails', response.data);
  return response.data;
};



// Update timesheet status
export const updateTimesheetStatus = async (timesheetId, status, notes = '', taskId, date,) => {
  const payload = { timesheetId, taskId, date, status, notes };
  const response = await apiClient.post(`/Timesheets/UpdateTimesheetStatus/${timesheetId}`, payload);
  return response.data;
};

export const declineTimesheetTasks = async (tasksPayload) => {
  const response = await apiClient.post('/Timesheets/DeclineTasks', tasksPayload);
  return response.data;
};

export const approveTimesheetTasks = async (tasksPayload) => {
  const response = await apiClient.post('/Timesheets/ApproveTasks', tasksPayload);
  return response.data;
};


// Fetch timesheet status counts
export const FetchTimesheetStatusCounts = async (empCode) => {
  const response = await apiClient.get(`/Timesheets/GetApprovalStatusCountsByEmployee?empCode=${empCode}`);
  return response.data;
};

export const FetchApprovalStatusCounts = async (empCode) => {
  const response = await apiClient.get(
    `/Timesheets/GetApprovalStatusCounts?empCode=${empCode}`
  );
  return response.data;
};



// Fetch My Timesheets
export const fetchMyTimesheets = async (empCode, roleId) => {
  const response = await apiClient.get(`/Timesheets/MyTimesheet?empCode=${empCode}&roleId=${roleId}`);
  return response.data;
};

// Fetch Timesheet Approvals
export const fetchTimesheetApprovals = async (empCode, roleId) => {
  const response = await apiClient.get(`/Timesheets/GetTimesheetApprovals?empCode=${empCode}&roleId=${roleId}`);
  return response.data;
};

export const usersbyReporting = async () => {
  const empCode = localStorage.getItem("emp_code");
  if (!empCode) {
    throw new Error("Employee code not found in local storage.");
  }
  const response = await apiClient.get(`/Timesheets/usersbyreportingid?empCode=${empCode}`);
  return response.data;
};


// ** Report API Methods ** //

// Fetch Timesheet Report Data
export const fetchTimesheetReportData = async (params, config = {}) => {
  const response = await apiClient.get('/TimesheetReport/summary/filter', {
    params,
    ...config,
  });
  return response.data;
};

// Fetch Project Data
export const fetchProjectsData = async (filters = {}) => {
  const response = await apiClient.get('/ProjectOverview', { params: filters });
  return response.data;
};

export const fetchProjects = async () => {
  try {
    const response = await apiClient.get('/TimesheetReport/report/projects');
    return response.data;
  } catch (error) {
    throw error;
  }
};
// Fetch Project Analytics (Flowchart data)
export const fetchProjectAnalytics = async (projectId) => {
  const response = await apiClient.get(
    `/TimesheetReport/${projectId}`
  );
  return response.data;
};

// ================= AUDIT LOG API =================
export const fetchAuditLogs = async () => {
  const response = await apiClient.get('/AuditLogs');
  return response.data;
};


