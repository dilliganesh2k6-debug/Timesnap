import React, { createContext, useContext, useState } from "react";

// 1️⃣ Create Context
const LoaderContext = createContext(null);

// 2️⃣ Provider Component
export const LoaderProvider = ({ children }) => {
  const [isGlobalLoading, setIsGlobalLoading] = useState(false);

  // 3️⃣ Helper functions
  const showGlobalLoader = () => {
    setIsGlobalLoading(true);
  };

  const hideGlobalLoader = () => {
    setIsGlobalLoading(false);
  };

  return (
    <LoaderContext.Provider
      value={{
        isGlobalLoading,
        showGlobalLoader,
        hideGlobalLoader,
      }}
    >
      {children}
    </LoaderContext.Provider>
  );
};

// 4️⃣ Custom Hook (Best Practice)
export const useLoader = () => {
  const context = useContext(LoaderContext);
  if (!context) {
    throw new Error("useLoader must be used inside LoaderProvider");
  }
  return context;
};
