
import React, {
  createContext,
  useContext,
  useEffect,
  useState,
} from 'react';
import { useNavigate } from 'react-router-dom';
import { isTokenExpired } from 'utils/authUtils';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const navigate = useNavigate();

  // 🔹 Initialize auth state from localStorage
  const getInitialAuthState = () => {
    const token = localStorage.getItem('token');
    const roleId = localStorage.getItem('roleId');
    const accessDetails = localStorage.getItem('accessDetails');
    const user = localStorage.getItem('activeUser');
    const isAdmin = localStorage.getItem('IS_ADMIN') === 'true';

    return {
      isAuthenticated: !!token,
      token,
      roleId: roleId || null,
      isAdmin: isAdmin,
      accessDetails: accessDetails ? JSON.parse(accessDetails) : null,
      user: user ? JSON.parse(user) : null,
    };
  };

  const [auth, setAuth] = useState(getInitialAuthState);

  // 🔹 JWT auto-expiry watcher
  useEffect(() => {
    const interval = setInterval(() => {
      const token = localStorage.getItem('token');

      if (!token) return;

      if (isTokenExpired(token)) {
        console.warn('JWT expired → auto logout');

        localStorage.clear();
        sessionStorage.clear();

        setAuth({
          isAuthenticated: false,
          token: null,
          roleId: null,
          accessDetails: null,
          user: null,
        });

        navigate('/auth/signin');
      }
    }, 60 * 1000); // every 1 minute

    return () => clearInterval(interval);
  }, [navigate]);

  return (
    <AuthContext.Provider value={{ auth, setAuth }}>
      {children}
    </AuthContext.Provider>
  );
};

// 🔹 Custom hook
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return context;
};
