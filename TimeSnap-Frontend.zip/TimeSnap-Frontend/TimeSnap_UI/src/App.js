import { Routes, Route, Navigate, useNavigate } from "react-router-dom";
import { ChakraProvider } from "@chakra-ui/react";
import { useEffect, useState } from "react";

import AuthLayout from "./layouts/auth";
import AdminLayout from "./layouts/admin";
import SignIn from "./views/auth/signIn";

import initialTheme from "./theme/theme";
import { updateUserActivity } from "utils/api";

import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { LoaderProvider, useLoader } from "./contexts/LoaderContext";
import GlobalLoader from "./components/loaders/GlobalLoader";

function AppRoutes({ currentTheme, setCurrentTheme }) {
  const navigate = useNavigate();
  const { auth } = useAuth();

  useEffect(() => {
    const interval = setInterval(() => {
      const empCode = sessionStorage.getItem("emp_code");
      const token = localStorage.getItem("token");

      if (empCode && token) {
        updateUserActivity(Number(empCode));
      }
    }, 60000);

    return () => clearInterval(interval);
  }, []);

  return (
    <Routes>
      <Route path="/" element={<Navigate to="/auth/signin" replace />} />

      <Route path="auth/*" element={<AuthLayout />} />
      <Route path="auth/signin" element={<SignIn />} />

      <Route
        path="admin/*"
        element={
          auth.isAuthenticated ? (
            <AdminLayout
              theme={currentTheme}
              setTheme={setCurrentTheme}
            />
          ) : (
            <Navigate to="/auth/signin" replace />
          )
        }
      />
    </Routes>
  );
}

function AppContent({ currentTheme, setCurrentTheme }) {
  const { isGlobalLoading } = useLoader();

  return (
    <ChakraProvider theme={currentTheme}>
      <div
        style={{
          pointerEvents: isGlobalLoading ? "none" : "auto",
        }}
      >
        <AppRoutes
          currentTheme={currentTheme}
          setCurrentTheme={setCurrentTheme}
        />
      </div>
      <GlobalLoader />
    </ChakraProvider>
  );
}

export default function App() {
  const [currentTheme, setCurrentTheme] = useState(initialTheme);

  return (
    <AuthProvider>
      <LoaderProvider>
        <AppContent
          currentTheme={currentTheme}
          setCurrentTheme={setCurrentTheme}
        />
      </LoaderProvider>
    </AuthProvider>
  );
}
