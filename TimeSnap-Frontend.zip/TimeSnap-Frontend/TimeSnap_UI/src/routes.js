import React from 'react';
import { Icon, Text } from '@chakra-ui/react';
import * as MdIcons from 'react-icons/md';
import menuConfig from './menuConfig.json';

import MainDashboard from 'views/admin/default';
import Timesheet from 'views/admin/TimesheetManagement';
import Usermanagement from 'views/admin/UserManagement';
import ProjectManagement from 'views/admin/ProjectManagement';
import TeamManagement from 'views/admin/TeamManagement';
import Task from 'views/admin/Task';
import ClientInfo from 'views/admin/ClientManagement/components/Clientinfo';
import Settings from 'views/admin/Settings/components/Settings';
import Reports from 'views/admin/Reports/components/Reports';
import AuditLog from 'views/admin/AuditLog/components/AuditLog';
import Profile from 'views/admin/ProfileManagement/components/Profile';
import Insights from 'views/admin/Insights';

const components = {
  MainDashboard,
  Timesheet,
  Usermanagement,
  ProjectManagement,
  TeamManagement,
  Task,
  Settings,
  ClientInfo,
  Reports,
  Profile,
  AuditLog,
  Insights,
};

// ✅ FUNCTION — NOT static
export const getRoutes = (accessDetails = [], isAdmin = false) => {
  const visibleMenus = isAdmin
    ? menuConfig
    : menuConfig.filter((menu) =>
      accessDetails.some((detail) => detail.screenId === menu.screenId)
    );

  return visibleMenus.map((menu) => {
    const Component = components[menu.component];
    return {
      name: (
        <Text fontWeight="bold">
          {menu.name}
        </Text>
      ),
      layout: menu.layout,
      // path: menu.path,
      icon: (
        <Icon
          as={MdIcons[menu.icon]}
          width="20px"
          height="20px"
        />
      ),
      path: menu.path.replace('/', ''),
      component: <Component />,
    };
  });
};
