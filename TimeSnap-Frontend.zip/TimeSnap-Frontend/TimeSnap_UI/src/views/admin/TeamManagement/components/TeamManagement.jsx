import React, { useState, useEffect, useRef } from 'react';
import { getTeam, createTeam, updateTeam, removeTeam } from 'utils/api';
import Dropdown from 'components/Dropdown/Dropdown';
import { statusColorScheme } from 'utils/constants';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useCustomToast } from 'utils/toastUtils';
import CustomButton from 'components/button/CustomButton';
import CustomIconButton from 'components/button/CustomIconButton';
import CustomModal from 'components/modal/CustomModal';
import { clearGridFocus } from 'utils/gridUtils';

import {
  Text,
  Box,
  Heading,
  Button,
  Tag,
  Select,
  Input,
  InputGroup,
  Flex,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  IconButton,
  ModalBody,
  ModalFooter,
  ModalCloseButton,
  FormControl,
  FormLabel,
} from '@chakra-ui/react';
import {
  validateAlphanumericInput,
  projectValidateAlphanumeric,
  ValidateNameField,
} from 'utils/constants';
import '@fortawesome/fontawesome-free/css/all.min.css';
import './TeamManagement.css';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { useToast, Tooltip } from '@chakra-ui/react';
import { useLoader } from "contexts/LoaderContext";

const TeamManagement = () => {
  // State to control which view is active: TeamManagement or TeamMembers
  const [activeView, setActiveView] = useState('TeamManagement');
  // State to store the currently selected team for viewing team members
  const [selectedTeam, setSelectedTeam] = useState();
  const { showGlobalLoader, hideGlobalLoader, isGlobalLoading } = useLoader();
  // Team management states
  const [teamNameToDelete, setTeamNameToDelete] = useState(''); // Store team name for delete confirmation
  const [teams, setTeams] = useState([]); // Store list of all teams

  // Filter states to control ag-grid filtering
  const [filters, setFilters] = useState({
    status: '',
    search: '',
  });

  // Toast notifications setup
  const toast = useToast();
  const showToast = useCustomToast();

  // Modal control states
  const [isAddModalOpen, setIsAddModalOpen] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // States for team operations
  const [teamToDelete, setTeamToDelete] = useState(null);
  const [teamToEdit, setTeamToEdit] = useState(null);
  const [isReadOnly, setIsReadOnly] = useState(false);

  useEffect(() => {
    const accessDetailsString = localStorage.getItem('accessDetails');
    if (accessDetailsString) {
      try {
        const accessDetails = JSON.parse(accessDetailsString);
        const screenAccess = accessDetails.find(
          (screen) => screen.screenId === 105,
        );
        if (screenAccess) {
          setIsReadOnly(screenAccess.readOnly === 1);
        }
      } catch (error) {
        console.error('Invalid accessDetails format in localStorage');
      }
    }
  }, []);
  const gridRef = useRef(null);

  // Initial state for new team form with validation structure
  const initialTeamState = {
    team_name: '',
    manager_id: '',
    status_Id: '',
    validationErrors: {},
  };
  const [newTeam, setNewTeam] = useState(initialTeamState);

  /**
   * Filter logic for teams based on user-selected filters
   * Applies  status, and search text filters
   */
  const filteredTeams = teams.filter((team) => {
    const matchesStatus =
      !filters.status ||
      team.status_Id.toString() === filters.status.toString();
    const matchesSearch =
      !filters.search ||
      team.managerName.toLowerCase().includes(filters.search.toLowerCase()) ||
      team.teamName.toLowerCase().includes(filters.search.toLowerCase());

    return matchesStatus && matchesSearch;
  });

  /**
   * Fetch teams data
   */
  useEffect(() => {
    const fetchTeam = async () => {
      showGlobalLoader();
      try {
        const data = await getTeam();
        setTeams(data);
      } catch (error) {
        showToast(toast, 'Error', error.message, 'error');
      } finally {
        hideGlobalLoader();
      }
    };

    fetchTeam();
  }, [toast]);
  useEffect(() => {
    // Disable scroll on the body
    document.body.style.overflow = 'hidden';

    // Clean up: Restore the scroll when the component unmounts
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, []);

  /**
   * Reset filters when switching back to TeamManagement view
   */
  useEffect(() => {
    if (activeView === 'TeamManagement' && (filters.status || filters.search)) {
      setFilters({
        status: '',
        search: '',
      });
    }
  }, [activeView]);

  /**
   * Handle adding a new team
   * Validates form data and makes API call to create new team
   */

  const handleCreateTeam = async () => {
    let validationErrors = {};

    if (!newTeam.team_name) {
      validationErrors.team_name = 'Team name is required.';
    } else if (!ValidateNameField(newTeam.team_name)) {
      validationErrors.team_name =
        'Team name must contain at least one character or number.';
    }

    if (!newTeam.manager_id) {
      validationErrors.manager_id = 'Manager is required.';
    }

    if (!newTeam.status_Id) {
      validationErrors.status_Id = 'Status is required.';
    }

    // Stop submission if validation errors exist
    if (Object.keys(validationErrors).length > 0) {
      setNewTeam((prevState) => ({
        ...prevState,
        validationErrors: validationErrors,
      }));

      return;
    }

    try {
      setIsSubmitting(true);
      await createTeam(newTeam);

      // Refresh team list
      const updatedTeams = await getTeam();
      setTeams(updatedTeams);

      showToast('success', `${newTeam.team_name} has been added successfully.`);

      // Reset form and close modal
      setNewTeam(initialTeamState);
      setIsAddModalOpen(false);
    } catch (error) {
      showToast(
        'error',
        error.message || 'Unable to add the team. Please try again.',
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  /**
   * Opens the edit modal and populates team details for editing
   */
  const handleEditTeam = (team) => {
    setTeamToEdit({
      teamId: team.teamId,
      teamName: team.teamName,
      manager_id: team.manager_id,
      status_Id: team.status_Id,
      teamStatus: team.teamStatus,
    });
    setIsEditModalOpen(true);
  };

  /**
   * Save edited team data
   * Submits updated team information to API
   */
  const handleUpdateTeam = async () => {
    // Validate team name for the edit form
    if (!ValidateNameField(teamToEdit.teamName)) {
      showToast(
        'error',
        'Team name must contain at least one letter or number.',
      );
      return;
    }

    try {
      setIsSubmitting(true);
      const updatedTeamData = {
        team_Id: teamToEdit.teamId,
        team_name: teamToEdit.teamName,
        manager_id: teamToEdit.manager_id,
        status_Id: teamToEdit.status_Id,
        isDelete: false,
      };

      await updateTeam(updatedTeamData.team_Id, updatedTeamData);

      setTimeout(async () => {
        const updatedTeams = await getTeam();
        setTeams(updatedTeams);
        clearGridFocus(gridRef);
      }, 100);

      showToast(
        'success',
        `Team "${teamToEdit.teamName}" has been updated successfully.`,
      );
      setIsEditModalOpen(false);
      setFilters({
        status: '',
        search: '',
      });
    } catch (error) {
      showToast('warning', error.message || 'Unable to update the team.');
    } finally {
      setIsSubmitting(false);
    }
  };

  /**
   * Prepares the team deletion confirmation modal.
   */
  const confirmTeamDeletion = (team) => {
    setIsDeleteModalOpen(true);
    setTeamToDelete(team.teamId);
    setTeamNameToDelete(team.teamName);
  };

  /**
   * Confirm  for team deletion
   * Calls delete API and refresh team list
   */
  const handleDeleteTeam = async () => {
    try {
      setIsSubmitting(true);
      await removeTeam(teamToDelete);

      setTimeout(async () => {
        const updatedTeams = await getTeam();
        setTeams(updatedTeams);
        clearGridFocus(gridRef); //  Fix auto-tooltip/focus
      }, 100);
      showToast(
        'success',
        `Team "${teamNameToDelete}" has been successfully deleted.`,
      );
      setIsDeleteModalOpen(false);
      setFilters({
        status: '',
        search: '',
      });
    } catch (error) {
      showToast('warning', error.message || 'Failed to delete team.');
    } finally {
      setIsSubmitting(false);
      setIsDeleteModalOpen(false);
      setFilters({
        status: '',
        search: '',
      });
    }
  };

  /**
   * Reset form state and close add modal
   */
  const onAddModalClose = () => {
    setNewTeam(initialTeamState);
    setIsAddModalOpen(false);
  };

  /**
   * Navigate back to team management view from team members view
   */
  const handleBackToManagement = () => {
    setActiveView('TeamManagement');
  };
  //Handle team selection to view team members
  const handleTeamClick = (team) => {
    setSelectedTeam(team);
    setActiveView('TeamMembers');
  };

  /**
   * Close delete confirmation modal
   */
  const onDeleteModalClose = () => {
    setIsDeleteModalOpen(false);
  };

  /**
   * Close edit modal and reset edit state
   */
  const onEditModalClose = () => {
    setIsEditModalOpen(false);
    setTeamToEdit(null);
  };

  const getStatusBadgeClass = (value = '') => {
    const normalized = value.toString().toLowerCase();
    if (normalized.includes('active')) return 'status-active';
    if (normalized.includes('inactive')) return 'status-inactive';
    if (normalized.includes('progress') || normalized.includes('pending') || normalized.includes('break')) return 'status-progress';
    if (normalized.includes('complete')) return 'status-completed';
    return '';
  };

  return (
    <div>
      {/* Team Management View */}
      {activeView === 'TeamManagement' && (
        <Box className="list-table-page">
          <ToastContainer />
          <Flex className="page-header-zone">
            <Heading className="page-title">Team</Heading>
            <Button
              className="page-primary-cta"
              onClick={() => setIsAddModalOpen(true)}
              isDisabled={isReadOnly}
            >
              Add
            </Button>
          </Flex>

          {/* Filters and Add Team Button Section */}
          <Box className="list-filter-bar">
            <Box className="list-filter-select">
              <Dropdown
                type="teamactiveinactivestatus"
                placeholder="All Status"
                selectedValue={filters.status}
                setSelectedValue={(value) =>
                  setFilters({ ...filters, status: value })
                }
              />
            </Box>

            <Box className="list-search-wrap">
              <Input
                className="list-search-input"
                placeholder="Search..."
                value={filters.search}
                onChange={(e) => {
                  const value = e.target.value;
                  if (validateAlphanumericInput(value)) {
                    setFilters({ ...filters, search: e.target.value });
                  }
                }}
                variant="outline"
              />
            </Box>
          </Box>

          {/* Teams Data Grid */}
          <div
            className="ag-theme-alpine list-table-grid content-surface"
            style={{ width: '100%' }}
          >
            <AgGridReact
              ref={gridRef}
              rowData={filteredTeams}
              suppressNoRowsOverlay={isGlobalLoading}
              suppressMovableColumns={true}
              suppressRowDrag={true}
              suppressMoveWhenRowDragging={true}
              columnDefs={[
                {
                  headerName: 'Team Name',
                  field: 'teamName',
                  sortable: true,
                },

                {
                  headerName: 'Manager Name',
                  field: 'managerName',
                  sortable: true,
                },

                {
                  headerName: 'Status',
                  field: 'teamStatus',
                  cellRenderer: (params) => {
                    const value = params.value?.toLowerCase();
                    const isBreak = value === 'break';
                    return (
                      <Tag
                        className={`Badge-lables status-pill ${getStatusBadgeClass(params.value)}`}
                        colorScheme={
                          !isBreak ? statusColorScheme[params.value] : undefined
                        }
                        backgroundColor={isBreak ? '#FFE4B3' : undefined}
                        color={isBreak ? '#4A4A4A' : undefined}
                      >
                        {params.value}
                      </Tag>
                    );
                  },
                },

                {
                  headerName: 'Actions',
                  cellRenderer: (params) => (
                    <Box display="flex" justifyContent="left">
                      {/* Edit team button */}
                      <CustomIconButton
                        iconClass="fas fa-edit"
                        tooltip="Edit Team"
                        onClick={() => handleEditTeam(params.data)}
                        isDisabled={isReadOnly}
                      />
                      {/* Delete team button */}
                      <CustomIconButton
                        iconClass="fas fa-trash"
                        tooltip="Delete Team"
                        onClick={() => confirmTeamDeletion(params.data)}
                        isDisabled={isReadOnly}
                      />
                    </Box>
                  ),
                },
              ]}
              defaultColDef={{
                flex: 1,
                minWidth: 100,
                resizable: false,
              }}
              pagination={true}
              paginationPageSize={10}
              paginationPageSizeSelector={[10, 25, 50, 100]}
            />
          </div>

          {/* Delete Modal */}
          <CustomModal
            isOpen={isDeleteModalOpen}
            closeOnOverlayClick={false}
            onClose={onDeleteModalClose}
            isCentered
          >
            <ModalOverlay />
            <ModalContent className="team-delete-warning-modal">
              <ModalHeader>Delete Team</ModalHeader>
              <ModalCloseButton />
              <ModalBody>
                <p>
                  Are you sure you want to delete the team{' '}
                  <Text as="span" fontWeight="bold">
                    {teamNameToDelete}
                  </Text>
                  ?
                </p>
              </ModalBody>
              <ModalFooter>
                <Flex gap={4} justify="flex-end" mt={3}>
                  <CustomButton
                    label="Cancel"
                    onClick={onDeleteModalClose}
                    variant="outline"
                    colorScheme="black"
                    className="common-button"
                  />
                  <CustomButton
                    label="Delete"
                    onClick={() => handleDeleteTeam(teamToDelete)}
                    colorScheme="red"
                    className="common-button"
                    isLoading={isSubmitting}
                  />
                </Flex>
              </ModalFooter>
            </ModalContent>
          </CustomModal>

          {/* Add Team Modal   */}
          <CustomModal
            isOpen={isAddModalOpen}
            closeOnOverlayClick={false}
            onClose={onAddModalClose}
            size="lg"
          >
            <ModalOverlay />
            <ModalContent className="settings-add-modal-content">
              <ModalHeader>Create Team</ModalHeader>
              <ModalCloseButton onClick={onAddModalClose} />
              <ModalBody>
                {/* Team Name Field with validation */}
                <FormControl
                  position="relative"
                  mb={4}
                  isRequired
                  isInvalid={!!newTeam.validationErrors?.team_name}
                >
                  <FormLabel>Team Name</FormLabel>
                  <InputGroup>
                    <Input
                      value={newTeam.team_name}
                      onChange={(e) => {
                        const value = e.target.value;
                        // Allow letters, numbers, spaces, underscores, and hyphens, max 30 chars
                        if (
                          /^[a-zA-Z0-9 _-]*$/.test(value) &&
                          value.length <= 30
                        ) {
                          setNewTeam({
                            ...newTeam,
                            team_name: value,
                            validationErrors: {
                              ...newTeam.validationErrors,
                              team_name: '',
                            },
                          });
                        }
                      }}
                      placeholder="Enter Team Name"
                      size="sm"
                      focusBorderColor="blue.500"
                      borderRadius="5px"
                      zIndex={2}
                    />
                  </InputGroup>
                  {newTeam.validationErrors?.team_name && (
                    <Text color="red.500" fontSize="sm">
                      {newTeam.validationErrors.team_name}
                    </Text>
                  )}
                </FormControl>

                {/* Manager Selection Dropdown */}
                <FormControl
                  position="relative"
                  isRequired
                  isInvalid={!!newTeam.validationErrors?.manager_id}
                  mb={4}
                >
                  <FormLabel>Manager Name</FormLabel>
                  <InputGroup>
                    <Dropdown
                      type="reportingto"
                      placeholder="Select Manager"
                      selectedValue={newTeam.manager_id}
                      setSelectedValue={(value) =>
                        setNewTeam({
                          ...newTeam,
                          manager_id: value,
                          validationErrors: {
                            ...newTeam.validationErrors,
                            manager_id: '',
                          },
                        })
                      }
                    />
                  </InputGroup>
                  {newTeam.validationErrors?.manager_id && (
                    <Text color="red.500" fontSize="sm">
                      {newTeam.validationErrors.manager_id}
                    </Text>
                  )}
                </FormControl>

                {/* Status Selection Dropdown */}
                <FormControl
                  isRequired
                  isInvalid={!!newTeam.validationErrors?.status_Id}
                  mb={4}
                >
                  <FormLabel>Status</FormLabel>
                  <Dropdown
                    type="teamactiveinactivestatus"
                    placeholder="Select status"
                    selectedValue={newTeam.status_Id}
                    setSelectedValue={(value) =>
                      setNewTeam({
                        ...newTeam,
                        status_Id: value,
                        validationErrors: {
                          ...newTeam.validationErrors,
                          status_Id: '',
                        },
                      })
                    }
                  />
                  {newTeam.validationErrors?.status_Id && (
                    <Text color="red.500" fontSize="sm">
                      {newTeam.validationErrors.status_Id}
                    </Text>
                  )}
                </FormControl>
              </ModalBody>
              <ModalFooter>
                <Flex gap={4} justify="flex-end" mt={3}>
                  <CustomButton
                    label="Cancel"
                    onClick={onAddModalClose}
                    variant="outline"
                    colorScheme="black"
                    className="common-button"
                  />
                  <CustomButton
                    label="Save"
                    onClick={() => handleCreateTeam(newTeam)}
                    colorScheme="green"
                    className="common-button"
                    isLoading={isSubmitting}
                  />
                </Flex>
              </ModalFooter>
            </ModalContent>
          </CustomModal>

          {/* Edit Team Modal   */}
          <CustomModal
            isOpen={isEditModalOpen}
            closeOnOverlayClick={false}
            onClose={onEditModalClose}
            size="lg"
          >
            <ModalOverlay />
            <ModalContent className="settings-add-modal-content">
              <ModalHeader>Edit Team</ModalHeader>
              <ModalCloseButton />
              <ModalBody>
                {/* Team Name Field */}
                <FormControl mb={4}>
                  <FormLabel>Team Name</FormLabel>
                  <Input
                    value={teamToEdit?.teamName || ''}
                    onChange={(e) => {
                      const value = e.target.value;
                      // Allow only valid characters
                      if (
                        /^[a-zA-Z0-9 _-]*$/.test(value) &&
                        value.length <= 30
                      ) {
                        setTeamToEdit({ ...teamToEdit, teamName: value });
                      }
                    }}
                    placeholder="Enter Team Name"
                    size="sm"
                    focusBorderColor="blue.500"
                    borderRadius="5px"
                    zIndex={2}
                  />
                </FormControl>

                {/* Manager Selection */}
                <FormControl mb={4}>
                  <FormLabel>Manager Name</FormLabel>
                  <Dropdown
                    type="reportingto"
                    selectedValue={teamToEdit?.manager_id || ''}
                    setSelectedValue={(value) =>
                      setTeamToEdit({ ...teamToEdit, manager_id: value })
                    }
                  />
                </FormControl>

                {/* Status Selection */}
                <FormControl mb={4}>
                  <FormLabel>Status</FormLabel>
                  <Dropdown
                    type="teamactiveinactivestatus"
                    selectedValue={teamToEdit?.status_Id || ''}
                    setSelectedValue={(value) =>
                      setTeamToEdit({ ...teamToEdit, status_Id: value })
                    }
                  />
                </FormControl>
              </ModalBody>
              <ModalFooter>
                <Flex gap={4} justify="flex-end" mt={3}>
                  <CustomButton
                    label="Cancel"
                    onClick={onEditModalClose}
                    variant="outline"
                    colorScheme="black"
                    className="common-button"
                  />
                  <CustomButton
                    label="Save"
                    onClick={handleUpdateTeam}
                    colorScheme="green"
                    className="common-button"
                    isLoading={isSubmitting}
                  />
                </Flex>
              </ModalFooter>
            </ModalContent>
          </CustomModal>
        </Box>
      )}
    </div>
  );
};

export default TeamManagement;
