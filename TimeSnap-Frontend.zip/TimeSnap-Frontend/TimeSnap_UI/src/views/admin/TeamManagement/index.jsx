import React from 'react';
import TeamManagement from './components/TeamManagement';

function App() {
  return (
    <div>
      <TeamManagement />
    </div>
  );
}
export default App;
