import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
} from 'react';
import './Timesheet.css';
import { FaCalendarAlt } from 'react-icons/fa';
import ReactSelect from 'react-select';
import { useCustomToast } from 'utils/toastUtils';
import Dropdown from 'components/Dropdown/Dropdown';
import { Select } from '@chakra-ui/react';
import { clearGridFocus } from 'utils/gridUtils';
import { BsCalendarWeekFill } from 'react-icons/bs';
import {
  TimesheetSaveDraft,
  fetchTasks,
  fetchProjectsByEmpCode,
  fetchTimesheetData,
  deleteTimesheetTask,
  submitWeek,
  FetchTimesheetStatusCounts,
  FetchApprovalStatusCounts,
  fetchApproveTimesheetDetails,
  updateTimesheetStatus,
  fetchMyTimesheets,
  fetchTimesheetApprovals,
  fetchDropdownData,
  declineTimesheetTasks,
  approveTimesheetTasks,
  usersbyReporting,
  getTaskCategories,
  getTasksByCategory,
  getFilteredTasks,
} from 'utils/api';
import {
  MAX_DAILY_HOURS,
  MAX_MINUTES,
  REGULAR_WORK_HOURS,
  PROGRESS_COLOR_MAP,
  MINUTES_IN_HOUR,
  MINUTES_PADDING_THRESHOLD,
  MINUTES_DOUBLE_DIGIT_MULTIPLIER,
  MILLISECONDS_IN_DAY,
  DAYS_IN_WEEK,
  UNKNOWN_PROJECT_LABEL,
  DEFAULT_PROJECT_COLOR,
  DATE_LOCALE,
  DATE_FORMAT_OPTIONS,
  WEEK_START_OFFSET,
  WEEK_END_OFFSET,
  PERCENTAGE_MAX,
  WEEK_START_INDEX,
  WEEK_END_INDEX,
  WEEK_RANGE_DATE_FORMAT,
  TIMESHEET_STATUSES,
  LOCAL_STORAGE_KEYS,
  DEFAULT_HOUR_VALUE,
  DEFAULT_TIMESHEET_ID,
  DEFAULT_HOURS,
  DATE_FORMAT_SPLIT_CHAR,
  DATE_FORMAT_SLICE_INDEX,
  EMPTY_SEARCH_TERM,
  EMPTY_FILTERED_ROW_DATA,
  EMPTY_SELECTED_TASKS,
  STATUS_COLOR_MAP,
  formatDate,
} from 'utils/constants';
import {
  Box,
  Text,
  Text as ChakraText,
  Tooltip,
  Button,
  ModalFooter,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  Input,
  useDisclosure,
  Heading,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  Spacer,
  VStack,
  TabPanel,
  Flex,
  FormControl,
  FormLabel,
  Tag,
  Textarea,
  HStack,
  Badge,
  FormErrorMessage,
  Center,
  InputGroup,
  InputRightElement,
  useColorModeValue,
} from '@chakra-ui/react';
import { validateStringInput } from 'utils/constants';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useLoader } from 'contexts/LoaderContext';
import CustomModal from 'components/modal/CustomModal';
import TimeSnapLoader from '../../../../components/loaders/TimeSnapLoader';
const customStyles = {
  option: (provided, state) => ({
    ...provided,
    backgroundColor: state.isSelected ? 'lightgray' : 'white',
  }),
  singleValue: (provided, state) => ({
    ...provided,
  }),
};

const Timesheet = () => {
  const gridRef = useRef(null);
  const approvalDateRef = useRef(null);
  const showToast = useCustomToast();
  const { showGlobalLoader, hideGlobalLoader } = useLoader();
  const empCode = localStorage.getItem(LOCAL_STORAGE_KEYS.EMP_CODE);
  const roleId = localStorage.getItem(LOCAL_STORAGE_KEYS.ROLE_ID);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isResubmitting, setIsResubmitting] = useState(false);
  const [selectedTaskIds, setSelectedTaskIds] = useState(new Set());
  const [isDirty, setIsDirty] = useState(false);
  const [filteredTasks, setFilteredTasks] = useState([]);
  const [projectTasks, setProjectTasks] = useState([]);
  const [allCategories, setAllCategories] = useState([]);
  const [categories, setCategories] = useState([]);
  const [subTasks, setSubTasks] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedSubTask, setSelectedSubTask] = useState('');

  useEffect(() => {
    const fetchCategories = async () => {
      const data = await getTaskCategories();

      // normalize, filter out invalid entries, and sort categories
      const mapped = data
        .map((c) => {
          return {
            categoryId: c.categoryId,
            categoryName: c.categoryName,
          };
        })
        .filter((c) => c.categoryId != null && c.categoryName != null)
        .sort((a, b) =>
          (a.categoryName || '').localeCompare(
            b.categoryName || '',
            undefined,
            {
              sensitivity: 'base',
              numeric: true,
            },
          ),
        );

      setAllCategories(mapped);
      setCategories(mapped);
    };

    fetchCategories();
  }, []);

  const [apiError, setApiError] = useState(null);
  const [toastMessage, setToastMessage] = useState('');
  const [toastType, setToastType] = useState('');
  const [timesheetNotes, setTimesheetNotes] = useState([]);
  const [isApiSuccess, setIsApiSuccess] = useState(false);
  const [timesheetStatus, setTimesheetStatus] = useState('');
  const [rowData, setRowData] = useState([]);
  const [approvels, setApprovels] = useState([]);
  const [touchedNotes, setTouchedNotes] = useState({});
  const [statusList, setStatusList] = useState([]);
  const [dropdownData, setDropdownData] = useState([]);
  const [myTimesheetFilters, setMyTimesheetFilters] = useState({
    status: '',
    search: '',
  });
  const [timesheetApprovalFilters, setTimesheetApprovalFilters] = useState({
    status: '',
    search: '',
    fromDate: '',
    toDate: '',
  });
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedWeekStartDate, setSelectedWeekStartDate] = useState(
    new Date(),
  );
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedWeekRange, setSelectedWeekRange] = useState('');
  const [notesError, setNotesError] = useState({});
  const dateInputRef = useRef(null);
  const [underHoursConfirmation, setUnderHoursConfirmation] = useState(false);
  const [underHoursError, setUnderHoursError] = useState(false);
  const [zeroHoursTaskError, setZeroHoursTaskError] = useState(false);
  const [incompleteDayError, setIncompleteDayError] = useState({
    isOpen: false,
    dayName: '',
  });

  const [newTask, setNewTask] = useState({
    project_Id: '',
    category_Id: '',
    sub_category_Id: '',
    task_id: '',
    task_Name: '',
    task_Desc: '',
  });

  const [roleFlags, setRoleFlags] = useState({
    isAdmin: false,
    isReportingManager: false,
    isProjectManager: false,
  });
  const [loggedInUser, setLoggedInUser] = useState(null);
  const pageBg = useColorModeValue('white', '#0f172a');
  const pageText = useColorModeValue('gray.800', 'gray.100');
  const selectedTabText = useColorModeValue('gray.800', 'gray.100');
  const selectedTabBorder = useColorModeValue('gray.600', 'gray.200');
  const statusCardStyles = {
    Approved: {
      bg: useColorModeValue('#E6F4EA', 'rgba(30, 76, 56, 0.45)'),
      label: useColorModeValue('#1E334F', '#E6FFF4'),
      count: useColorModeValue('#0F6A46', '#86EFAC'),
    },
    Posted: {
      bg: useColorModeValue('#E9EDF5', 'rgba(36, 59, 97, 0.45)'),
      label: useColorModeValue('#1E334F', '#EAF1FF'),
      count: useColorModeValue('#284E8F', '#93C5FD'),
    },
    Pending: {
      bg: useColorModeValue('#F7ECEE', 'rgba(99, 33, 41, 0.45)'),
      label: useColorModeValue('#1E334F', '#FFECEE'),
      count: useColorModeValue('#8E2B2B', '#FCA5A5'),
    },
  };
  const controlBg = useColorModeValue('white', '#1f2937');
  const controlText = useColorModeValue('black', '#e5e7eb');
  const controlIcon = useColorModeValue('black', '#e5e7eb');
  const mutedMeta = useColorModeValue('#666', '#94a3b8');
  const modalPanelBg = useColorModeValue('white', '#16213f');
  const modalPanelText = useColorModeValue('gray.800', 'gray.100');
  const modalPanelMutedText = useColorModeValue('gray.700', 'gray.300');
  const modalInputBg = useColorModeValue('gray.50', '#0f1b3d');
  const modalPlaceholderText = useColorModeValue('gray.500', 'gray.400');
  const modalTableHeaderBg = useColorModeValue('#f9fafb', '#1e293b');
  const modalTableBodyBg = useColorModeValue('#ffffff', '#0f1b3d');
  const modalTableBorder = useColorModeValue('#e5e7eb', '#334155');
  const modalTaskMetaText = useColorModeValue('#666', '#cbd5e1');
  const selectMenuBg = useColorModeValue('#ffffff', '#1f2937');
  const selectTextColor = useColorModeValue('#1f2937', '#e5e7eb');
  const selectPlaceholderColor = useColorModeValue('#9ca3af', '#94a3b8');
  const selectBorderColor = useColorModeValue('#cbd5e1', '#475569');
  const selectHoverBg = useColorModeValue('#f8fafc', '#334155');
  const selectActiveBg = useColorModeValue('#e2e8f0', '#1e3a8a');

  const projectSelectStyles = useMemo(
    () => ({
      control: (provided, state) => ({
        ...provided,
        minHeight: '38px',
        backgroundColor: selectMenuBg,
        borderColor: state.isFocused ? '#3b82f6' : selectBorderColor,
        boxShadow: 'none',
        ':hover': { borderColor: '#3b82f6' },
      }),
      menu: (provided) => ({
        ...provided,
        backgroundColor: selectMenuBg,
        zIndex: 2500,
      }),
      menuPortal: (provided) => ({ ...provided, zIndex: 2500 }),
      option: (provided, state) => ({
        ...provided,
        backgroundColor: state.isSelected
          ? selectActiveBg
          : state.isFocused
            ? selectHoverBg
            : selectMenuBg,
        color: selectTextColor,
      }),
      singleValue: (provided) => ({ ...provided, color: selectTextColor }),
      input: (provided) => ({ ...provided, color: selectTextColor }),
      placeholder: (provided) => ({
        ...provided,
        color: selectPlaceholderColor,
      }),
      indicatorSeparator: (provided) => ({
        ...provided,
        backgroundColor: selectBorderColor,
      }),
      dropdownIndicator: (provided) => ({
        ...provided,
        color: selectPlaceholderColor,
      }),
    }),
    [
      selectMenuBg,
      selectTextColor,
      selectPlaceholderColor,
      selectBorderColor,
      selectHoverBg,
      selectActiveBg,
    ],
  );

  const getWeekKey = (date) => {
    const startOfWeek = new Date(date);
    startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay() + 1);
    const yyyy = startOfWeek.getFullYear();
    const mm = String(startOfWeek.getMonth() + 1).padStart(2, '0');
    const dd = String(startOfWeek.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };

  const handleCategoryChange = async (categoryId) => {
    setSelectedCategory(categoryId);
    setSelectedSubTask('');

    if (!categoryId) {
      setSubTasks([]);
      return;
    }

    try {
      setIsAddTaskLoading(true);
      const data = await getTasksByCategory(categoryId);
      const mapped = data
        .map((t) => ({
          subCategoryId: t.sub_category_Id || t['sub category Id'] || t.id,
          subCategoryName: t.taskName || t.subCategoryName || t.name,
        }))
        .filter((t) => t.subCategoryId != null && t.subCategoryName != null) // Filter out undefined/null entries
        .sort((a, b) =>
          (a.subCategoryName || '').localeCompare(
            b.subCategoryName || '',
            undefined,
            {
              sensitivity: 'base',
              numeric: true,
            },
          ),
        );
      setSubTasks(mapped);
    } catch (error) {
      console.error('Error fetching subcategories:', error);
      setSubTasks([]);
    } finally {
      setIsAddTaskLoading(false);
    }
  };
  useEffect(() => {
    if (subTasks.length === 1) {
      const onlySub = subTasks[0];
      setSelectedSubTask(onlySub.subCategoryId);
      handleSubcategoryChange(onlySub.subCategoryId);
    }
  }, [subTasks]);

  const getCategoriesForProject = async (projectId) => {
    try {
      const response = await getFilteredTasks(projectId, 0, 0);

      // Extract unique categories
      const uniqueCategories = {};
      response.data.forEach((item) => {
        uniqueCategories[item.category_Id] = item.categoryName;
      });

      return Object.entries(uniqueCategories).map(([id, name]) => ({
        categoryId: id,
        categoryName: name,
      }));
    } catch (error) {
      console.error('Error fetching categories for project:', error);
      return [];
    }
  };

  const handleSubcategoryChange = (subCategoryId) => {
    setSelectedSubTask(subCategoryId);
  };

  // Local date formatter: returns YYYY-MM-DD using the date's local fields
  const formatDateLocal = (input) => {
    const d = new Date(input);
    d.setHours(0, 0, 0, 0);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };

  const pickFirst = (...values) =>
    values.find((value) => value !== undefined && value !== null && value !== '');

  const normalizeTimesheetDetails = (payload) => {
    const list = Array.isArray(payload)
      ? payload
      : (payload?.data && Array.isArray(payload.data) ? payload.data : null) ||
        (payload?.timesheetDetails && Array.isArray(payload.timesheetDetails)
          ? payload.timesheetDetails
          : null) ||
        (payload?.items && Array.isArray(payload.items) ? payload.items : null) ||
        [];
    return list.map((row) => ({
      ...row,
      employeeName: pickFirst(row.employeeName, row.EmployeeName),
      projectName: pickFirst(row.projectName, row.ProjectName),
      categoryName: pickFirst(row.categoryName, row.CategoryName),
      subCategoryName: pickFirst(row.subCategoryName, row.SubCategoryName),
      taskName: pickFirst(row.taskName, row.TaskName),
      date: pickFirst(row.date, row.Date),
      hours: pickFirst(row.hours, row.Hours, row.totalHours, row.TotalHours),
      status: pickFirst(row.status, row.Status, row.taskStatus, row.TaskStatus),
      categoryId: pickFirst(row.categoryId, row.category_Id, row.Category_Id),
      subCategoryId: pickFirst(
        row.subCategoryId,
        row.sub_category_Id,
        row.Sub_Category_Id,
      ),
    }));
  };

  const isSameDay = (a, b) => {
    if (!a || !b) return false;
    const d1 = new Date(a);
    const d2 = new Date(b);
    d1.setHours(0, 0, 0, 0);
    d2.setHours(0, 0, 0, 0);
    return d1.getTime() === d2.getTime();
  };
  //Initializing from localStorage
  const [tasks, setTasks] = useState(() => {
    const savedTasks = JSON.parse(localStorage.getItem('tasksByWeek')) || {};
    const currentWeekKey = `${empCode}-${getWeekKey(selectedWeekStartDate)}`;
    return savedTasks[currentWeekKey] || [];
  });

  const getStartOfWeek = (date) => {
    const start = new Date(date);
    start.setDate(start.getDate() - start.getDay() + 1); // Monday as start of the week
    start.setHours(0, 0, 0, 0);
    return start;
  };

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const isCurrentWeek =
    getStartOfWeek(currentDate).getTime() === getStartOfWeek(today).getTime();

  const [hasApprovalAccess, setHasApprovalAccess] = useState(false);
  const [selectedTasks, setSelectedTasks] = useState([]);
  const [selectedDayCells, setSelectedDayCells] = useState([]);
  const [selectedDayRows, setSelectedDayRows] = useState([]);
  const [showWeekends, setShowWeekends] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [filteredRowData, setFilteredRowData] = useState();
  const [originalRowData, setOriginalRowData] = useState([]);
  const [projectOptions, setProjectOptions] = useState([]);
  const [selectedProjectValue, setSelectedProjectValue] = useState(null);
  const [notesByEmployee, setNotesByEmployee] = useState({});
  const [errors, setErrors] = useState({});
  const [earlySubmissionWarning, setEarlySubmissionWarning] = useState(false);
  const [submitConfirmation, setSubmitConfirmation] = useState({
    isOpen: false,
    timesheetId: null,
  });
  const [selectedTimesheetId, setSelectedTimesheetId] = useState(null);
  const [selectedProjectId, setSelectedProjectId] = useState(null);
  const [selectedTimesheet, setSelectedTimesheet] = useState(null);
  const [timesheetTasks, setTimesheetTasks] = useState([]);
  const [navConfirmation, setNavConfirmation] = useState({
    isOpen: false,
    nextAction: null,
  });

  const handleNavigate = (direction) => {
    const nextAction = () => {
      setTasks([]);
      const newDate = new Date(currentDate);
      if (direction === 'prev') {
        newDate.setDate(newDate.getDate() - 7);
      } else if (direction === 'next') {
        newDate.setDate(newDate.getDate() + 7);
      }
      setCurrentDate(newDate);
    };

    if (isDirty && tasks.length > 0) {
      setNavConfirmation({
        isOpen: true,
        nextAction,
      });
    } else {
      setIsDirty(false);
      nextAction();
    }
  };
  const [selectedTabIndex, setSelectedTabIndex] = useState(0);
  const WEEKDAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  const getDayIndexFromDate = (date) => {
    const jsDay = date.getDay();
    return jsDay === 0 ? 6 : jsDay - 1;
  };
  const {
    isOpen: isSaveDraftOpen,
    onOpen: onSaveDraftOpen,
    onClose: onSaveDraftClose,
  } = useDisclosure();
  const {
    isOpen: isApproveOpen,
    onOpen: onApproveOpen,
    onClose: onApproveClose,
  } = useDisclosure();

  // Filter function for the Timesheet Approval tabs
  useEffect(() => {
    fetchDropdownData('approvelstatus').then((data) => setStatusList(data));
  }, []);

  const getStatusNameById = (id) => {
    const status = statusList.find((item) => item.id === id);
    return status ? status.name : '';
  };

  const filteredMyTimesheets = rowData.filter((entry) => {
    const selectedStatusName = getStatusNameById(myTimesheetFilters.status);

    const matchesStatus =
      !myTimesheetFilters.status ||
      entry.status === selectedStatusName ||
      entry.statusId === myTimesheetFilters.status;

    const matchesSearch =
      !myTimesheetFilters.search ||
      (entry.employeeName &&
        entry.employeeName
          .toLowerCase()
          .includes(myTimesheetFilters.search.toLowerCase()));

    return matchesStatus && matchesSearch;
  });

  const filteredApprovals = approvels.filter((entry) => {
    const selectedStatusName = getStatusNameById(
      timesheetApprovalFilters.status,
    );

    const matchesStatus =
      !timesheetApprovalFilters.status ||
      // entry.status === selectedStatusName ||
      // entry.statusId === timesheetApprovalFilters.status;
      entry.projectStatus === selectedStatusName ||
      entry.projectStatus === timesheetApprovalFilters.status;

    const matchesSearch =
      !timesheetApprovalFilters.search ||
      (entry.employeeName &&
        entry.employeeName
          .toLowerCase()
          .includes(timesheetApprovalFilters.search.toLowerCase()));

    let matchesDate = true;
    if (timesheetApprovalFilters.fromDate || timesheetApprovalFilters.toDate) {
      // entry.weekRange format expected: "Jan 19 - Jan 25" or with year
      const [startStr, endStr] = (entry.weekRange || '').split(' - ');
      if (startStr) {
        const currentYear = new Date().getFullYear();
        const parseDateState = (dStr) => {
          const d = new Date(`${dStr}, ${currentYear}`);
          // If the parsed date is much further in the future (e.g. Dec vs Jan), adjust year?
          // For now assume current year is fine or the string has year.
          return d;
        };

        const weekStart = parseDateState(startStr);
        // Reset to 00:00:00
        weekStart.setHours(0, 0, 0, 0);

        if (timesheetApprovalFilters.fromDate) {
          const from = new Date(timesheetApprovalFilters.fromDate);
          from.setHours(0, 0, 0, 0);
          if (weekStart < from) matchesDate = false;
        }

        if (matchesDate && timesheetApprovalFilters.toDate) {
          const to = new Date(timesheetApprovalFilters.toDate);
          to.setHours(23, 59, 59, 999);
          // Check if week starts before the 'to' date, or maybe ends before?
          // Usually strict filter means the week must be within range?
          // Let's go with "Week Start" is the anchor.
          if (weekStart > to) matchesDate = false;
        }
      }
    }

    return matchesStatus && matchesSearch && matchesDate;
  });

  const sumDecimalHoursAsFloat = (decimalHoursArray) => {
    let totalMinutes = 0;
    decimalHoursArray.forEach((decimalHours) => {
      // Allow numbers and ribbons (strings that parse to numbers)
      if (
        (typeof decimalHours !== 'number' && typeof decimalHours !== 'string') ||
        isNaN(parseFloat(decimalHours))
      ) {
        return;
      }
      const [hoursStr, minutesStr = '0'] = decimalHours.toString().split('.');
      let hours = parseInt(hoursStr) || 0;
      let minutes = parseInt(minutesStr) || 0;

      // Handle single digit decimals (e.g. 1.3 -> 1h 30m)
      if (minutesStr.length === 1 && minutes > 0) {
        minutes = minutes * 10;
      }

      // Convert excess minutes (e.g. 1.60 -> 2h)
      if (minutes > 59) {
        hours += Math.floor(minutes / 60);
        minutes = minutes % 60;
      }

      totalMinutes += hours * 60 + minutes;
    });

    return totalMinutes / 60;
  };

  // Decimal formation for the hours
  const formatTotalHoursAndMinutes = (decimalHoursArray) => {
    let totalMinutes = 0;

    decimalHoursArray.forEach((decimalHours) => {
      // Allow numbers and ribbons (strings that parse to numbers)
      if (
        (typeof decimalHours !== 'number' && typeof decimalHours !== 'string') ||
        isNaN(parseFloat(decimalHours))
      ) {
        return;
      }

      const [hoursStr, minutesStr = '0'] = decimalHours.toString().split('.');
      let hours = parseInt(hoursStr) || 0;
      let minutes = parseInt(minutesStr) || 0;

      // Handle single digit decimals
      if (minutesStr.length === 1 && minutes > 0) {
        minutes = minutes * 10;
      }

      // Validate and convert excess minutes to hours
      if (minutes > 59) {
        hours += Math.floor(minutes / 60);
        minutes = minutes % 60;
      }

      totalMinutes += hours * 60 + minutes;
    });

    const finalHours = Math.floor(totalMinutes / 60);
    const finalMinutes = totalMinutes % 60;

    // Format as "Xh Ym"
    if (finalMinutes === 0) {
      return `${finalHours}h`;
    }
    return `${finalHours}h ${finalMinutes}m`;
  };

  // Convert decimal hours (from sumDecimalHoursAsFloat) to "Xh Ym" format
  const formatDecimalHoursToHM = (decimalHours) => {
    if (typeof decimalHours !== 'number' || isNaN(decimalHours)) return '0h';
    const totalMinutes = Math.round(decimalHours * 60);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    if (minutes === 0) return `${hours}h`;
    return `${hours}h ${minutes}m`;
  };

  const handleToggleWeekends = (state) => {
    setShowWeekends(state);
  };

  const handleHourChange = (uniqueId, dayIndex, value) => {
    setIsDirty(true); // Mark dirty change
    let finalValue = value;
    if (value && value.toString().includes('.')) {
      const [hours, minutes] = value.toString().split('.');
      // Ensure minutes are between 0-59
      if (minutes && parseInt(minutes) > 59) {
        showToast('error', 'Minutes cannot exceed 59');
        return;
      }

      // Normalize minutes (e.g. 1.60 -> 2.00, 1.9 -> 2.30)
      if (minutes > 59) {
        hours += Math.floor(minutes / 60);
        minutes = minutes % 60;
      }

      // Format to 2 decimal places (e.g. 1.3 becomes 1.30, 1.9 -> 2.30)
      finalValue = `${hours}.${minutes.toString().padStart(2, '0')}`;
    } else {
      // While typing, allow the raw input (as string or number)
      finalValue = value;
    }

    const updatedTasks = tasks.map((task) => {
      if (task.uniqueId === uniqueId) {
        // Only set dirty if the value actually changed
        if (task.hours[dayIndex] !== finalValue) {
          setIsDirty(true);
        }
        const updatedHours = [...task.hours];
        updatedHours[dayIndex] = parseFloat(finalValue) || DEFAULT_HOUR_VALUE;
        return { ...task, hours: updatedHours };
      }
      return task;
    });
    setTasks(updatedTasks);
  };

  const weekDays = [...Array(DAYS_IN_WEEK)].map((_, i) => {
    const date = new Date(currentDate);
    date.setDate(
      currentDate.getDate() - currentDate.getDay() + i + WEEK_START_OFFSET,
    );
    return new Date(date);
  });

  const filteredWeekDays = showWeekends
    ? weekDays
    : weekDays.filter((day) => day.getDay() !== 0 && day.getDay() !== 6);

  const handleDateChange = (e) => {
    const inputValue = e.target.value;

    const nextAction = (date) => {
      setTasks([]);
      setCurrentDate(date);
      setSelectedWeekStartDate(date);
      setSelectedDate(formatDateLocal(date));
      setTimesheetNotes([]);
    };

    // If the input is cleared, reset to today's date
    if (!inputValue) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      // Always reset to Monday
      today.setDate(today.getDate() - today.getDay() + 1);

      if (isDirty && tasks.length > 0) {
        setNavConfirmation({
          isOpen: true,
          nextAction: () => nextAction(today),
        });
      } else {
        setIsDirty(false);
        nextAction(today);
      }
      return;
    }

    const selected = new Date(inputValue);
    const today = new Date();

    // Set time to 00:00 for accurate comparison
    selected.setHours(0, 0, 0, 0);
    today.setHours(0, 0, 0, 0);

    if (selected > today) {
      alert("You can't select a future date.");
      return;
    }

    // Always reset to Monday
    selected.setDate(selected.getDate() - selected.getDay() + 1);

    if (isDirty && tasks.length > 0) {
      setNavConfirmation({
        isOpen: true,
        nextAction: () => nextAction(selected),
      });
    } else {
      setIsDirty(false);
      nextAction(selected);
    }
  };

  const handleTodayClick = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    // Always reset to Monday
    today.setDate(today.getDate() - today.getDay() + 1);

    const nextAction = (date) => {
      setTasks([]);
      setCurrentDate(date);
      setSelectedWeekStartDate(date);
      setSelectedDate(formatDateLocal(date));
      setTimesheetNotes([]);
    };

    if (isDirty && tasks.length > 0) {
      setNavConfirmation({
        isOpen: true,
        nextAction: () => nextAction(today),
      });
    } else {
      nextAction(today);
    }
  };

  useEffect(() => {
    if (projectOptions.length > 0) {
      const startOfWeek = new Date(currentDate);
      startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay() + 1);
      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(startOfWeek.getDate() + 6);

      fetchTimesheetDetails(
        formatDateLocal(startOfWeek),
        formatDateLocal(endOfWeek),
      );
    }
  }, [currentDate, projectOptions]);
  useEffect(() => {
    // Disable scroll on the body
    document.body.style.overflow = 'hidden';

    // Clean up: Restore the scroll when the component unmounts
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, []);
  useEffect(() => {
    const currentWeekKey = `${empCode}-${getWeekKey(selectedWeekStartDate)}`;
    const savedTasksByWeek =
      JSON.parse(localStorage.getItem('tasksByWeek')) || {};
    const storedTasks = savedTasksByWeek[currentWeekKey] || [];
    const formattedStoredTasks = storedTasks.map(task => ({
      ...task,
      hours: task.hours.map(h =>
        (typeof h === 'number' || (typeof h === 'string' && h !== ''))
          ? (parseFloat(h) || 0).toFixed(2)
          : '0.00'
      )
    }));
    setTasks(formattedStoredTasks);
  }, [empCode, selectedWeekStartDate]);

  useEffect(() => {
    const currentWeekKey = `${empCode}-${getWeekKey(selectedWeekStartDate)}`;
    const savedTasksByWeek =
      JSON.parse(localStorage.getItem('tasksByWeek')) || {};
    savedTasksByWeek[currentWeekKey] = tasks;
    localStorage.setItem('tasksByWeek', JSON.stringify(savedTasksByWeek));
  }, [tasks, empCode, selectedWeekStartDate]);

  const handleSearchChange = (e) => {
    const searchValue = e.target.value.toLowerCase();
    setSearchTerm(e.target.value);

    if (!searchValue) {
      setFilteredRowData(originalRowData);
      return;
    }

    const filtered = originalRowData.filter(
      (task) =>
        (task.taskName && task.taskName.toLowerCase().includes(searchValue)) ||
        (task.description &&
          task.description.toLowerCase().includes(searchValue)),
    );
    setFilteredRowData(filtered);
  };

  const resetSearch = () => {
    setSearchTerm('');
    setFilteredRowData(originalRowData);
  };

  //Fetching project details for the dropdown in add task modal
  useEffect(() => {
    const fetchProjects = async () => {
      try {
        // const response = await projectDropdown();
        const response = await fetchProjectsByEmpCode();
        if (response && Array.isArray(response)) {
          const formattedProjects = response
            .map((project) => ({
              value: project.project_id,
              label: project.project_name,
              color: project.color_Code,
            }))
            .sort((a, b) =>
              (a.label || '').localeCompare(b.label || '', undefined, {
                sensitivity: 'base',
                numeric: true,
              }),
            );
          setProjectOptions(formattedProjects);

          const startOfWeek = new Date(currentDate);
          startOfWeek.setDate(
            startOfWeek.getDate() - startOfWeek.getDay() + WEEK_START_OFFSET,
          );
          const endOfWeek = new Date(startOfWeek);
          endOfWeek.setDate(startOfWeek.getDate() + WEEK_END_OFFSET);

          fetchTimesheetDetails(
            formatDateLocal(startOfWeek),
            formatDateLocal(endOfWeek),
          );
        }
      } catch (error) {
        console.error('Error fetching project data:', error);
      }
    };

    fetchProjects();
  }, []);

  const handleProjectChange = async (selected) => {
    setSelectedProjectValue(selected);

    // Reset states
    setSelectedCategory('');
    setSelectedSubTask('');
    setSubTasks([]);
    setFilteredRowData([]);
    setOriginalRowData([]);

    if (!selected) return;

    try {
      setIsAddTaskLoading(true);
      // Fetch ALL project tasks
      const response = await getFilteredTasks(selected.value);
      const tasksData = response.data.map((t) => ({
        id: t.task_Id,
        taskName: t.task_Name,
        description: t.task_Desc,
        project_Id: t.project_Id,
      }));

      setProjectTasks(tasksData);
      setOriginalRowData(tasksData);
      setFilteredRowData(tasksData);
    } catch (err) {
      console.error(err);
      setProjectTasks([]);
      setOriginalRowData([]);
      setFilteredRowData([]);
    } finally {
      setIsAddTaskLoading(false);
    }
  };

  const handleAddTaskClick = () => {
    onOpen();

    // load modal empty but DO NOT reset category or subcategory
    setOriginalRowData([]);
    setFilteredRowData([]);
    setSearchTerm('');
  };

  const closeAddtaskModal = () => {
    setSearchTerm(EMPTY_SEARCH_TERM);
    setFilteredRowData(EMPTY_FILTERED_ROW_DATA);
    setSelectedTasks(EMPTY_SELECTED_TASKS);
    setSelectedTaskIds(new Set());
    setSelectedProjectValue(null);
    onClose();
  };

  const addTask = () => {
    if (selectedTasks.length === 0) {
      showToast('warning', 'Please select at least one task.');
      return;
    }

    if (!selectedCategory) {
      showToast('warning', 'Please select a Main Category.');
      return;
    }

    if (!selectedSubTask) {
      showToast('warning', 'Please select a Sub Category.');
      return;
    }

    const validTasks = selectedTasks.filter(
      (task) => task && task.taskName && task.description !== undefined,
    );
    if (validTasks.length === 0) {
      showToast('warning', 'Selected tasks are invalid.');
      return;
    }

    const selectedCategoryName =
      allCategories.find(
        (c) => String(c.categoryId) === String(selectedCategory),
      )?.categoryName || ''; // Changed back to categoryName (camelCase)
    const selectedSubTaskName =
      subTasks.find((s) => String(s.subCategoryId) === String(selectedSubTask))
        ?.subCategoryName || '';

    const enhancedTasks = validTasks
      .map((task) => {
        const uniqueId = `${task.id}-${selectedProjectValue.value}-${selectedCategory}-${selectedSubTask}`;
        const exists = tasks.some(
          (existingTask) => existingTask.uniqueId === uniqueId,
        );

        if (exists) {
          showToast(
            'warning',
            `Task "${task.taskName}" with this category/subcategory already exists for the selected project`,
          );
          return null;
        }

        return {
          id: task.id,
          taskName: task.taskName,
          description: task.description || '',
          category_Id: selectedCategory,
          sub_category_Id: selectedSubTask,
          categoryName: selectedCategoryName,
          subCategoryName: selectedSubTaskName,
          uniqueId,
          hours: Array(7).fill('0.00'),
          project: {
            value: selectedProjectValue.value,
            label: selectedProjectValue.label,
            color: selectedProjectValue.color,
          },
        };
      })
      .filter((item) => item !== null); // REMOVE null items

    if (enhancedTasks.length > 0) {
      setTasks((prevTasks) => [...prevTasks, ...enhancedTasks]);
      setIsDirty(true); // Mark dirty change
      setSelectedTasks([]);
      closeAddtaskModal();
      showToast(
        'success',
        `${enhancedTasks.length} task${enhancedTasks.length > 1 ? 's' : ''} added successfully.`,
      );
    }
  };

  const addTaskColumnDefs = [
    {
      headerName: 'Task Name',
      field: 'taskName',
      sortable: true,
    },
    {
      headerName: 'Description',
      field: 'description',
      sortable: true,
    },
  ];

  const totalMinutesThisWeek = tasks
    .flatMap((task) => task.hours)
    .map((num) => {
      const hrs = Math.floor(Math.abs(num));
      const mins = Math.round(Math.abs(num - Math.floor(num)) * 100);
      return hrs * 60 + mins;
    })
    .reduce((sum, mins) => sum + mins, 0);

  const isFullySubmitted =
    timesheetStatus === 'Approved' || timesheetStatus === 'Posted';

  const isAddTaskDisabled = isFullySubmitted;

  const handleSelectionChanged = (e) => {
    const selectedNodes = e.api.getSelectedNodes();
    const selectedData = selectedNodes.map((node) => node.data);
    const currentlySelectedIds = new Set(selectedData.map((task) => task.id));

    // Copy the existing selectedTaskIds set
    const updatedIds = new Set(selectedTaskIds);

    //  Remove any previously selected IDs that are no longer selected
    //  (i.e., user deselected them in the current visible list)
    filteredRowData.forEach((task) => {
      if (!currentlySelectedIds.has(task.id)) {
        updatedIds.delete(task.id);
      }
    });

    //  Add all currently selected IDs
    selectedData.forEach((task) => {
      updatedIds.add(task.id);
    });

    // Final update
    setSelectedTaskIds(updatedIds);
    setSelectedTasks(originalRowData.filter((task) => updatedIds.has(task.id)));

    // Ensure columns fill the available width after selection changes
    // This prevents the grid from leaving a blank gap on the right when
    // checkboxes are toggled or project selection affects the layout.
    try {
      if (
        gridRef.current &&
        gridRef.current.api &&
        gridRef.current.api.sizeColumnsToFit
      ) {
        // use setTimeout to allow ag-grid to finish any internal updates first
        setTimeout(() => gridRef.current.api.sizeColumnsToFit(), 0);
      }
    } catch (err) {
      // swallow any errors silently — sizing is an optimization
      // console.error('Error sizing columns', err);
    }
  };

  useEffect(() => {
    if (gridRef.current && filteredRowData) {
      gridRef.current.api.forEachNode((node) => {
        if (selectedTaskIds.has(node.data.id)) {
          node.setSelected(true);
        }
      });

      // After updating selection, make sure columns are sized to fit the grid
      // This addresses the issue where the row content appears to shrink and
      // a blank space appears on the right side of the grid.
      try {
        if (gridRef.current.api && gridRef.current.api.sizeColumnsToFit) {
          setTimeout(() => gridRef.current.api.sizeColumnsToFit(), 0);
        }
      } catch (err) {
        // ignore sizing errors
      }
    }
  }, [filteredRowData]);

  // Fetching timesheet details
  const fetchTimesheetDetails = async (startDate, endDate) => {
    showGlobalLoader();
    try {
      setApiError(null);
      const data = await fetchTimesheetData(empCode, startDate, endDate);
      setIsApiSuccess(true);

      const { notes, status, timesheetDetails } = data;

      const startOfWeek = new Date(startDate);
      const endOfWeek = new Date(endDate);
      startOfWeek.setHours(0, 0, 0, 0);
      endOfWeek.setHours(23, 59, 59, 999);

      const currentWeekData = timesheetDetails.filter((item) => {
        const itemDate = new Date(item.date);
        itemDate.setHours(0, 0, 0, 0);
        return itemDate >= startOfWeek && itemDate <= endOfWeek;
      });

      const taskGroups = {};
      currentWeekData.forEach((item) => {
        // --- ROBUST CASE-INSENSITIVE MAPPING ---
        // We check for various naming conventions (snake_case, camelCase, PascalCase)
        // to ensure ID mapping works regardless of backend serializer settings.
        const tId = item.task_Id || item.taskId || item.Task_Id;
        const pId = item.project_Id || item.projectId || item.Project_Id;
        const cId = item.category_Id || item.categoryId || item.Category_Id;
        const scId =
          item.sub_category_Id ||
          item.subCategoryId ||
          item.Sub_Category_Id ||
          item.sub_Category_Id;

        const uniqueId = `${tId}-${pId}-${cId}-${scId}`;
        const itemDate = new Date(item.date);
        const dayIndex = Math.floor(
          (itemDate - startOfWeek) / MILLISECONDS_IN_DAY,
        );

        const matchingProject = projectOptions.find(
          (p) => String(p.value) === String(pId),
        );

        if (!taskGroups[uniqueId]) {
          taskGroups[uniqueId] = {
            id: tId,
            uniqueId: uniqueId,
            taskName:
              item.taskName ||
              item.task_Name ||
              item.TaskName ||
              item.Task_Name,
            category_Id: cId,
            sub_category_Id: scId,
            categoryName: item.categoryName || item.CategoryName,
            subCategoryName: item.subCategoryName || item.SubCategoryName,
            project: matchingProject || {
              value: pId,
              label:
                item.projectName || item.ProjectName || UNKNOWN_PROJECT_LABEL,
              color:
                item.projectColor || item.ProjectColor || DEFAULT_PROJECT_COLOR,
            },
            timesheet_Id:
              item.timesheet_Id || item.timesheetId || item.Timesheet_Id,
            emp_Code: item.emp_Code || item.empCode || item.Emp_Code,
            hours: Array(DAYS_IN_WEEK).fill('0.00'),
            dayStatuses: Array(DAYS_IN_WEEK).fill('Draft'),
            status: status,
          };
        }

        if (dayIndex >= 0 && dayIndex < DAYS_IN_WEEK) {
          taskGroups[uniqueId].hours[dayIndex] = (parseFloat(item.hours) || 0).toFixed(2);
          taskGroups[uniqueId].dayStatuses[dayIndex] = item.status;
        }
      });

      if (notes && notes.trim() !== '') {
        setTimesheetNotes([
          {
            date: new Date().toLocaleDateString(
              DATE_LOCALE,
              DATE_FORMAT_OPTIONS,
            ),
            notes: notes,
          },
        ]);
      } else {
        setTimesheetNotes([]);
      }
      setTimesheetStatus(status);
      const transformedTasks = Object.values(taskGroups);
      setTasks(transformedTasks);
      setIsDirty(false); // Reset dirty state on successful fetch
    } catch (error) {
      console.error('Failed to fetch timesheet data:', error);
      setIsApiSuccess(false);
      setTimesheetStatus('');
      setIsResubmitting(false);
    } finally {
      hideGlobalLoader();
    }
  };

  //Save draft Functions
  const isSaveDraftDisabled =
    isFullySubmitted ||
    tasks.length === 0 ||
    tasks.every((task) => task.hours.every((hour) => hour === 0));

  const saveDraft = async () => {
    if (tasks.length === 0) {
      showToast(
        'error',
        'Please add at least one task before saving the draft.',
      );
      return;
    }
    try {
      setIsSubmitting(true);
      const startOfWeek = weekDays[0];
      const endOfWeek = weekDays[6];

      const payload = {
        header: {
          empCode: empCode,
          startDate: formatDateLocal(startOfWeek),
          endDate: formatDateLocal(endOfWeek),
          IsDraftSubmission: true,
        },
        details: tasks.flatMap((task) =>
          weekDays.map((day, dayIndex) => ({
            timesheetId: DEFAULT_TIMESHEET_ID,
            empCode: empCode,
            taskId: task.id,
            projectId: task.project?.value || null,
            categoryId: task.category_Id,
            subCategoryId: task.sub_category_Id,
            date: formatDateLocal(day),
            hours: filteredWeekDays.includes(day)
              ? task.hours[filteredWeekDays.indexOf(day)] || DEFAULT_HOURS
              : DEFAULT_HOURS,
          })),
        ),
      };
      await TimesheetSaveDraft(payload);
      setIsDirty(false); // Now everything saved
      showToast('success', 'The Timesheet has been Saved successfully.');

      //  Fetch updated timesheet data
      await fetchTimesheetDetails(
        formatDateLocal(startOfWeek),
        formatDateLocal(endOfWeek),
      );
    } catch (error) {
      console.error('Error saving timesheet:', error);
      showToast('error', 'Failed to add the Timesheet. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  //Submit Week Functions
  const handleEarlySubmitConfirmation = () => {
    setEarlySubmissionWarning(false);
    setSubmitConfirmation({ isOpen: true, timesheetId: null });
  };

  // Check if any task has any day with 'Declined', 'Pending', or non-empty 'Draft' status (for corrections)
  const hasEditableTasksInPostedSheet = tasks?.some((task) =>
    task?.dayStatuses?.some(
      (status, index) =>
        ['Declined', 'Pending'].includes(status) ||
        (status === 'Draft' && parseFloat(task.hours?.[index] || 0) > 0),
    ),
  );

  // Allow submit if:
  // 1. Normal flow: Status is Draft/Pending/Empty
  // 2. Correction flow: Status is Posted/Approved/Pending BUT we have editable tasks
  const isSubmitWeekDisabled =
    tasks.length === 0 ||
    isResubmitting ||
    (!hasEditableTasksInPostedSheet &&
      (timesheetStatus !== 'Draft' &&
        timesheetStatus !== 'Pending' &&
        timesheetStatus !== ''));

  const handleSubmitCancel = () => {
    setIsResubmitting(false);
    setSubmitConfirmation({
      isOpen: false,
      timesheetId: null,
    });
  };

  const showSubmitConfirmation = () => {
    //  Block Submit Week if unsaved changes exist
    if (isDirty) {
      showToast('warning', 'Please save the timesheet before submitting.');
      return;
    }

    // Block submit if any task has zero total hours
    const hasZeroHourTask = tasks.some((task) => {
      const taskTotal = task.hours.reduce(
        (sum, h) => sum + (parseFloat(h) || 0),
        0,
      );
      return taskTotal === 0;
    });

    if (hasZeroHourTask) {
      setZeroHoursTaskError(true);
      return;
    }

    // Block submit if any day has hours > 0 but < 8
    for (let dayIndex = 0; dayIndex < DAYS_IN_WEEK; dayIndex++) {
      let dayTotalMins = 0;
      tasks.forEach((task) => {
        const num = task.hours[dayIndex] || 0;
        const hrs = Math.floor(Math.abs(num));
        const mins = Math.round(Math.abs(num - Math.floor(num)) * 100);
        dayTotalMins += hrs * 60 + mins;
      });

      if (dayTotalMins > 0 && dayTotalMins < 480) {
        // < 8 hours
        const dayName = weekDays[dayIndex].toLocaleDateString('en-US', {
          weekday: 'long',
        });
        setIncompleteDayError({ isOpen: true, dayName });
        return;
      }
    }

    const { endDate } = getWeekStartEndDates();
    const today = formatDateLocal(new Date());

    // Check if this is a resubmit scenario
    const isResubmitScenario = hasEditableTasksInPostedSheet &&
      (timesheetStatus === 'Posted' ||
        timesheetStatus === 'Approved' ||
        timesheetStatus === 'Pending');

    if (isResubmitScenario) {
      setIsResubmitting(true);
    }

    setSubmitConfirmation({ isOpen: true, timesheetId: null });
  };

  const getWeekStartEndDates = () => {
    const startOfWeek = weekDays[0];
    const endOfWeek = weekDays[6];
    return {
      startDate: formatDateLocal(startOfWeek),
      endDate: formatDateLocal(endOfWeek),
    };
  };

  const handleSubmitWeek = async () => {
    const { startDate, endDate } = getWeekStartEndDates();
    try {
      setIsSubmitting(true);
      await submitWeek(empCode, startDate, endDate);

      let postedMinutes = 0;
      for (let dayIndex = 0; dayIndex < DAYS_IN_WEEK; dayIndex++) {
        let dayTotalMins = 0;
        tasks.forEach((task) => {
          const num = task.hours[dayIndex] || 0;
          const hrs = Math.floor(Math.abs(num));
          const mins = Math.round(Math.abs(num - Math.floor(num)) * 100);
          dayTotalMins += hrs * 60 + mins;
        });
        if (dayTotalMins >= 480) {
          // >= 8 hours considered a posted day
          postedMinutes += dayTotalMins;
        }
      }

      if (postedMinutes < 2400) {
        const hrs = Math.floor(postedMinutes / 60);
        const mins = postedMinutes % 60;
        const timeStr = mins === 0 ? `${hrs} hrs` : `${hrs} hrs ${mins} mins`;
        showToast('info-blue', `Timesheet Partially Submitted ${timeStr}`);
      } else {
        showToast('success', 'The Timesheet has been submitted successfully.');
      }
      setIsModalOpen(false);

      // Fetch updated timesheet details
      await fetchTimesheetDetails(startDate, endDate);

      await handleFetchMyTimesheets();

      // Update status counts in parallel
      handleTabStatusCountFetch(selectedTabIndex);
    } catch (error) {
      showToast('error', 'Failed to submit the Timesheet. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
    setSubmitConfirmation({ isOpen: false, timesheetId: null });
  };

  //Delete API Method
  const [deleteConfirmation, setDeleteConfirmation] = useState({
    isOpen: false,
    taskId: null,
    projectId: null,
    startDate: null,
    endDate: null,
  });

  const showDeleteConfirmation = (
    taskId,
    projectId,
    categoryId,
    subCategoryId,
  ) => {
    const uniqueId = `${taskId}-${projectId}-${categoryId}-${subCategoryId}`;
    const taskToDelete = tasks.find((task) => task.uniqueId === uniqueId);
    const startOfWeek = new Date(currentDate);
    startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay() + 1);
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);

    setDeleteConfirmation({
      isOpen: true,
      taskId: taskId,
      taskName: taskToDelete?.taskName || 'this task',
      projectId: projectId,
      categoryId: categoryId,
      subCategoryId: subCategoryId,
      startDate: formatDateLocal(startOfWeek),
      endDate: formatDateLocal(endOfWeek),
    });
  };

  const handleDeleteConfirm = async () => {
    if (deleteConfirmation.taskId && deleteConfirmation.projectId) {
      try {
        setIsSubmitting(true);
        await deleteTask(
          deleteConfirmation.taskId,
          deleteConfirmation.projectId,
          deleteConfirmation.categoryId,
          deleteConfirmation.subCategoryId,
          deleteConfirmation.startDate,
          deleteConfirmation.endDate,
        );
      } catch (error) {
        console.error('Error deleting task:', error);
        showToast('warning', 'Failed to delete task');
      } finally {
        setIsSubmitting(false);
      }
    }
    setDeleteConfirmation({
      isOpen: false,
      taskId: null,
      projectId: null,
      startDate: null,
      endDate: null,
    });
  };

  const handleDeleteCancel = () => {
    setDeleteConfirmation({
      isOpen: false,
      taskId: null,
      projectId: null,
      startDate: null,
      endDate: null,
    });
  };

  const deleteTask = async (
    taskId,
    projectId,
    categoryId,
    subCategoryId,
    startDate,
    endDate,
  ) => {
    try {
      const response = await deleteTimesheetTask(
        empCode,
        taskId,
        projectId,
        categoryId,
        subCategoryId,
        startDate,
        endDate,
      );

      const result = response; // Axios already returns parsed JSON

      if (result.message === 'True') {
        // Delete only locally (for Declined or unsaved timesheet)
        deleteTaskLocally(taskId, projectId, categoryId, subCategoryId);
        showToast(
          'success',
          `The task "${deleteConfirmation.taskName}" has been deleted successfully.`,
        );
      } else {
        // Task deleted from DB
        const uniqueIdToDelete = `${taskId}-${projectId}-${categoryId}-${subCategoryId}`;
        setTasks((prevTasks) =>
          prevTasks.filter((task) => task.uniqueId !== uniqueIdToDelete),
        );
        showToast(
          'success',
          `The saved task "${deleteConfirmation.taskName}" has been deleted successfully.`,
        );
        setTimeout(() => {
          clearGridFocus(gridRef);
        }, 100);

        // Fetch the updated timesheet details
        await fetchTimesheetDetails(startDate, endDate);
      }
    } catch (error) {
      showToast('warning', `Failed to delete task: ${error.message}`);
    }
  };

  const deleteTaskLocally = (taskId, projectId, categoryId, subCategoryId) => {
    const weekKey = `${empCode}-${getWeekKey(selectedWeekStartDate)}`; // use selected week
    const savedTasksByWeek =
      JSON.parse(localStorage.getItem('tasksByWeek')) || {};

    const uniqueIdToDelete = `${taskId}-${projectId}-${categoryId}-${subCategoryId}`;

    if (savedTasksByWeek[weekKey]) {
      savedTasksByWeek[weekKey] = savedTasksByWeek[weekKey].map(task => ({
        ...task,
        hours: task.hours.map(h =>
          (typeof h === 'number' || (typeof h === 'string' && h !== ''))
            ? (parseFloat(h) || 0).toFixed(2)
            : '0.00'
        )
      })).filter(
        (task) => task.uniqueId !== uniqueIdToDelete,
      );
      localStorage.setItem('tasksByWeek', JSON.stringify(savedTasksByWeek));
      setTasks(savedTasksByWeek[weekKey]);
    }
    setIsDirty(true);
  };

  //Progress Functions on the main screen
  const calculateProgress = (dayIndex) => {
    const hoursList = tasks.map((task) => {
      const hoursForTask = task.hours || Array(DAYS_IN_WEEK).fill(0);
      return hoursForTask[dayIndex] || 0;
    });

    // Use helper to sum properly
    const totalHours = sumDecimalHoursAsFloat(hoursList);
    const regularHours = Math.min(totalHours, REGULAR_WORK_HOURS);

    return { regularHours, totalHours };
  };

  const calculateWeeklyProgress = () => {
    const allHours = tasks.flatMap((task) => task.hours || []);
    const totalWeeklyHours = sumDecimalHoursAsFloat(allHours);

    const maxWeeklyHours = DAYS_IN_WEEK * REGULAR_WORK_HOURS;

    return Math.min(
      (totalWeeklyHours / maxWeeklyHours) * PERCENTAGE_MAX,
      PERCENTAGE_MAX,
    );
  };

  //Week Range on the main screen
  const getFormattedWeekRange = () => {
    const startOfWeek = weekDays[WEEK_START_INDEX];
    const endOfWeek = weekDays[WEEK_END_INDEX];

    const startFormatted = startOfWeek.toLocaleDateString(
      DATE_LOCALE,
      WEEK_RANGE_DATE_FORMAT,
    );
    const endFormatted = endOfWeek.toLocaleDateString(
      DATE_LOCALE,
      WEEK_RANGE_DATE_FORMAT,
    );

    return `${startFormatted} - ${endFormatted}`;
  };

  const getWeekRangeFromRows = (rows) => {
    const dates = (rows || [])
      .map((r) => r?.date)
      .filter(Boolean)
      .map((d) => new Date(d))
      .filter((d) => !Number.isNaN(d.getTime()));
    if (dates.length === 0) return '';
    const minDate = new Date(Math.min(...dates.map((d) => d.getTime())));
    const maxDate = new Date(Math.max(...dates.map((d) => d.getTime())));
    const minFormatted = minDate.toLocaleDateString(
      DATE_LOCALE,
      WEEK_RANGE_DATE_FORMAT,
    );
    const maxFormatted = maxDate.toLocaleDateString(
      DATE_LOCALE,
      WEEK_RANGE_DATE_FORMAT,
    );
    return `${minFormatted} - ${maxFormatted}`;
  };

  //Status counters in the main screen
  const [statusCounters, setStatusCounters] = useState({
    Approved: 0,
    Posted: 0,
    Pending: 0,
  });

  const [isMyTimesheetLoading, setIsMyTimesheetLoading] = useState(false);
  const [isApprovalLoading, setIsApprovalLoading] = useState(false);
  const [isApproving, setIsApproving] = useState(false);
  const [isDeclining, setIsDeclining] = useState(false);
  const [isTimesheetLoading, setIsTimesheetLoading] = useState(false);
  const [isAddTaskLoading, setIsAddTaskLoading] = useState(false);
  const approvalMetaBadgeBg = useColorModeValue('green.100', 'green.700');
  const approvalMetaBadgeColor = useColorModeValue('gray.800', 'white');

  useEffect(() => {
    handleFetchMyTimesheets();
  }, []);

  //My Timesheet tab API Methods
  const handleFetchMyTimesheets = async () => {
    try {
      setIsMyTimesheetLoading(true);
      if (!empCode || !roleId) {
        console.error('empCode or roleId is missing from localStorage.');
        return;
      }
      const response = await fetchMyTimesheets(empCode, roleId);
      if (response) {
        const transformedData = response.map((item) => ({
          id: item.timesheetId,
          computedId: item.computedTimesheetId,
          employeeCode: item.employeeCode,
          employeeName: item.employeeName,
          week: item.weekRange,
          totalHours: item.totalHours,
          status: item.status,
          notes: item.notes || '',
        }));

        setRowData(transformedData);
      }
    } catch (error) {
      console.error('Error fetching My Timesheets:', error);
    } finally {
      setIsMyTimesheetLoading(false);
    }
  };

  //Timesheet approval tab API Methods
  const handleFetchTimesheetApprovals = async () => {
    try {
      setIsApprovalLoading(true);
      if (!empCode || !roleId) {
        console.error('empCode or roleId is missing from localStorage.');
        return;
      }
      const response = await fetchTimesheetApprovals(empCode, roleId);

      if (response) {
        setHasApprovalAccess(response.hasApprovalAccess);
        setRoleFlags({
          isAdmin: response.isAdmin,
          isReportingManager: response.isReportingManager,
          isProjectManager: response.isProjectManager,
        });

        if (response.timesheetApprovals) {
          const transformedData = response.timesheetApprovals.map((item) => ({
            id: item.timesheetId,
            computedId: item.computedTimesheetId,
            employeeCode: item.employeeCode,
            employeeName: item.employeeName,
            weekRange: item.weekRange,
            projectId: item.projectId,
            projectName: item.projectName,
            hours: item.hours,
            totalHours: item.totalHours,
            projectTotalHours: item.projectTotalHours,
            projectStatus: item.projectStatus,
            notes: item.notes || '',
            reportingId: item.reportingId,
            projectManagerId: item.projectManagerId,
          }));
          setApprovels(transformedData);
        }
      }
    } catch (error) {
      console.error('Error fetching Timesheet Approvals:', error);
    } finally {
      setIsApprovalLoading(false);
    }
  };

  useEffect(() => {
    handleFetchMyTimesheets();
    handleFetchTimesheetApprovals();

    // Add this block to fetch status counts on screen load
    if (empCode && roleId) {
      FetchTimesheetStatusCounts(empCode, roleId)
        .then((data) => {
          if (data && data.statusCounts) {
            setStatusCounters({
              Approved:
                (data.statusCounts.find(
                  (s) => s.status === TIMESHEET_STATUSES.Approved,
                )?.count || 0) +
                (data.statusCounts.find(
                  (s) => s.status === TIMESHEET_STATUSES.PartiallyApproved,
                )?.count || 0),
              Posted:
                (data.statusCounts.find(
                  (s) => s.status === TIMESHEET_STATUSES.Posted,
                )?.count || 0) +
                (data.statusCounts.find(
                  (s) => s.status === TIMESHEET_STATUSES.PartiallyPosted,
                )?.count || 0),
              Pending:
                data.statusCounts.find(
                  (s) => s.status === TIMESHEET_STATUSES.Pending,
                )?.count || 0,
            });
          }
        })
        .catch((error) => { });
    }
  }, []);

  const handleApproveAction = async (row, action) => {
    if (action !== 'View') return;

    const id = row.id;
    const projectId = row.projectId;

    setSelectedTasks([]);
    setSelectedDayCells([]);
    setSelectedDayRows([]);
    setErrors((prev) => ({ ...prev, [id]: '' }));

    setSelectedTimesheetId(id);
    setSelectedProjectId(projectId);

    // Save Week Range from grid row
    setSelectedWeekRange(row.week || row.weekRange || '');

    try {
      setIsApprovalLoading(true);
      const raw = await fetchApproveTimesheetDetails(id, projectId || null);
      const data = normalizeTimesheetDetails(raw);
      setTimesheetTasks(data);

      if (data.length > 0) {
        setSelectedTimesheet({
          employeeName: data[0].employeeName,
          projectName: data[0].projectName,
          projectStatus: row.projectStatus,
        });

        setNotesByEmployee((prev) => ({
          ...prev,
          [id]: data[0].notes || '',
        }));
      } else {
        setSelectedTimesheet(null);
      }
    } catch (error) {
      console.error('Error loading dummy timesheet:', error);
      setTimesheetTasks([]);
      setSelectedTimesheet(null);
    } finally {
      setIsApprovalLoading(false);
    }

    onApproveOpen();
  };

  const handleApproveClose = () => {
    setNotesError({}); // 🔥 Clear all errors
    setSelectedTasks([]); // Optional reset
    setSelectedDayCells([]);
    setSelectedDayRows([]);
    setSelectedTimesheetId(null); // Reset selected sheet
    onApproveClose(); // Your existing close function
  };
  const getStatusClass = (task, dayIdx) => {
    const status = task.dayStatuses?.[dayIdx];
    if (!status) return '';
    return status.toLowerCase(); // maps to CSS classes like 'approved', 'declined'
  };

  // NEW: Approve from (combined) modal – task wise for the whole week
  const handleApprove = async () => {
    if (!selectedTimesheetId) {
      showToast('error', 'No timesheet selected.');
      return;
    }

    if (!selectedTasks || selectedTasks.length === 0) {
      showToast('error', 'Please select at least one task to approve.');
      return;
    }

    const safeTasks = Array.isArray(timesheetTasks) ? timesheetTasks : [];
    if (safeTasks.length === 0) {
      showToast('error', 'No timesheet details available to approve.');
      return;
    }

    const daySelections = selectedTasks.filter((t) => t.date);
    const taskSelections = selectedTasks.filter((t) => !t.date);

    const rowsFromTasks = (() => {
      if (taskSelections.length === 0) return [];
      const selectedKeySet = new Set(
        taskSelections.map((t) => {
          const cId = t.categoryId || t.category_Id;
          const scId = t.subCategoryId || t.sub_category_Id;
          return `${t.projectId}-${t.taskId}-${cId}-${scId}`;
        }),
      );
      return safeTasks.filter((row) => {
        const cId = row.categoryId || row.category_Id;
        const scId = row.subCategoryId || row.sub_category_Id;
        return selectedKeySet.has(
          `${row.projectId}-${row.taskId}-${cId}-${scId}`,
        );
      });
    })();

    const rowsToUpdate = (() => {
      const combined = [...daySelections, ...rowsFromTasks];
      const unique = new Map();
      combined.forEach((row) => {
        const cId = row.categoryId || row.category_Id;
        const scId = row.subCategoryId || row.sub_category_Id;
        const dateKey = row.date ? formatDateLocal(row.date) : '';
        const key = `${row.projectId}-${row.taskId}-${cId}-${scId}-${dateKey}`;
        if (!unique.has(key)) unique.set(key, row);
      });
      return Array.from(unique.values());
    })();

    if (rowsToUpdate.length === 0) {
      showToast('error', 'No matching rows found for selected tasks.');
      return;
    }

    // Group by project – same idea as existing handler
    const groupedByProject = rowsToUpdate.reduce((acc, row) => {
      if (!acc[row.projectId]) acc[row.projectId] = [];
      acc[row.projectId].push(row);
      return acc;
    }, {});

    try {
      setIsApproving(true);
      for (const [projectId, tasksForProject] of Object.entries(
        groupedByProject,
      )) {
        const payload = {
          timesheetId: selectedTimesheetId,
          notes: notesByEmployee[selectedTimesheetId] || '',
          headerStatus: 'Approved',
          managerEmpCode: empCode,
          tasks: tasksForProject.map((task) => ({
            projectId: task.projectId,
            taskId: task.taskId,
            categoryId: task.categoryId,
            subCategoryId: task.subCategoryId,
            empCode: task.employeeCode,
            date: task.date, // per-day row – same as existing API
            taskStatus: 'Approved',
          })),
        };

        await approveTimesheetTasks(payload); // existing API call
      }

      await handleFetchTimesheetApprovals();
      await handleFetchMyTimesheets();

      const updatedDetails = await fetchApproveTimesheetDetails(
        selectedTimesheetId,
        selectedProjectId,
      );
      setTimesheetTasks(normalizeTimesheetDetails(updatedDetails));
      setSelectedTasks([]);
      setSelectedDayCells([]);
      setSelectedDayRows([]);

      await handleTabStatusCountFetch(selectedTabIndex);
      showToast(
        'success',
        'Selected tasks have been approved successfully.',
      );
    } catch (error) {
      console.error('Dummy approval error:', error);
      showToast('error', 'Failed to approve selected tasks. Please try again.');
    } finally {
      setIsApproving(false);
    }
  };

  // NEW: Decline from Dummy (combined) modal – task wise for the whole week
  const handleDecline = async () => {
    if (!selectedTimesheetId) {
      showToast('error', 'No timesheet selected.');
      return;
    }

    // Notes required for decline
    const note = notesByEmployee[selectedTimesheetId]?.trim();

    if (!note) {
      setNotesError((prev) => ({
        ...prev,
        [selectedTimesheetId]: 'Notes are required',
      }));
      return;
    }

    if (!selectedTasks || selectedTasks.length === 0) {
      showToast('error', 'Please select at least one task to decline.');
      return;
    }

    const safeTasks = Array.isArray(timesheetTasks) ? timesheetTasks : [];
    if (safeTasks.length === 0) {
      showToast('error', 'No timesheet details available to decline.');
      return;
    }

    const daySelections = selectedTasks.filter((t) => t.date);
    const taskSelections = selectedTasks.filter((t) => !t.date);

    const rowsFromTasks = (() => {
      if (taskSelections.length === 0) return [];
      const selectedKeySet = new Set(
        taskSelections.map((t) => {
          const cId = t.categoryId || t.category_Id;
          const scId = t.subCategoryId || t.sub_category_Id;
          return `${t.projectId}-${t.taskId}-${cId}-${scId}`;
        }),
      );
      return safeTasks.filter((row) => {
        const cId = row.categoryId || row.category_Id;
        const scId = row.subCategoryId || row.sub_category_Id;
        return selectedKeySet.has(
          `${row.projectId}-${row.taskId}-${cId}-${scId}`,
        );
      });
    })();

    const rowsToUpdate = (() => {
      const combined = [...daySelections, ...rowsFromTasks];
      const unique = new Map();
      combined.forEach((row) => {
        const cId = row.categoryId || row.category_Id;
        const scId = row.subCategoryId || row.sub_category_Id;
        const dateKey = row.date ? formatDateLocal(row.date) : '';
        const key = `${row.projectId}-${row.taskId}-${cId}-${scId}-${dateKey}`;
        if (!unique.has(key)) unique.set(key, row);
      });
      return Array.from(unique.values());
    })();

    if (rowsToUpdate.length === 0) {
      showToast('error', 'No matching rows found for selected tasks.');
      return;
    }

    const groupedByProject = rowsToUpdate.reduce((acc, row) => {
      if (!acc[row.projectId]) acc[row.projectId] = [];
      acc[row.projectId].push(row);
      return acc;
    }, {});

    try {
      setIsDeclining(true);
      for (const [projectId, tasksForProject] of Object.entries(
        groupedByProject,
      )) {
        const payload = {
          timesheetId: selectedTimesheetId,
          projectId: parseInt(projectId, 10),
          notes: note,
          managerEmpCode: empCode,
          headerStatus: 'Pending', // keep existing behaviour
          tasks: tasksForProject.map((task) => ({
            projectId: task.projectId,
            taskId: task.taskId,
            categoryId: task.categoryId,
            subCategoryId: task.subCategoryId,
            empCode: task.employeeCode,
            date: task.date,
            taskStatus: 'Declined',
          })),
        };

        await declineTimesheetTasks(payload); // existing API call
      }

      await handleFetchTimesheetApprovals();
      await handleFetchMyTimesheets();

      const updatedDetails = await fetchApproveTimesheetDetails(
        selectedTimesheetId,
        selectedProjectId,
      );
      setTimesheetTasks(normalizeTimesheetDetails(updatedDetails));
      setSelectedTasks([]); // Clear selected tasks to uncheck checkboxes
      setSelectedDayCells([]);
      setSelectedDayRows([]);
      await handleTabStatusCountFetch(selectedTabIndex);

      showToast(
        'success',
        'Selected tasks have been declined successfully.',
      );
    } catch (error) {
      console.error('Dummy decline error:', error);
      showToast('error', 'Failed to decline selected tasks. Please try again.');
    } finally {
      setIsDeclining(false);
    }
  };

  const getHourBoxStyle = (status, isSelected = false, isDisabled = false) => {
    const base = {
      minWidth: '40px',
      padding: '0px 4px',
      borderRadius: '5px',
      height: '26px',
      fontWeight: 500,
      fontSize: '10px',
      display: 'inline-flex',
      justifyContent: 'center',
      alignItems: 'center',
      cursor: isDisabled ? 'not-allowed' : 'pointer',
      backgroundColor: isSelected ? '#DBEAFE' : 'transparent',
      boxShadow: isSelected ? 'inset 0 0 0 1px #2563EB' : 'none',
    };

    switch (status) {
      case 'Approved':
        return { ...base, border: '1px solid #16A34A', color: '#166534' };
      case 'Declined':
        return { ...base, border: '1px solid #DC2626', color: '#991B1B' };
      case 'Pending':
        return { ...base, border: '1px solid #FACC15', color: '#854D0E' };
      default:
        return { ...base, border: '1px solid #D1D5DB', color: '#374151' };
    }
  };

  const columnDefsforapprove = [
    {
      field: 'employeeCode',
      headerName: 'Emp Code',
      sortable: true,
      width: 120,
      valueFormatter: (params) => `E0${params.value}`,
    },

    {
      field: 'employeeName',
      headerName: 'Employee Name',
      sortable: true,
      flex: 1,
    },
    {
      field: 'projectName',
      headerName: 'Project Name',
      sortable: true,
      flex: 1,
    },
    {
      field: 'weekRange',
      headerName: 'Week',
      sortable: true,
      width: 160,
    },
    {
      field: 'hours',
      headerName: 'Hours',
      width: 120,
    },

    {
      field: 'projectStatus',
      headerName: 'Status',
      sortable: true,
      width: 140,
      cellRenderer: (params) => (
        <Tag
          className="Badge-lables"
          colorScheme={STATUS_COLOR_MAP[params.value] || 'gray'}
        >
          {params.value}
        </Tag>
      ),
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 120,
      cellRenderer: (params) => (
        <Flex align="center">
          {/* First Eye */}
          <Tooltip label="Review" placement="top">
            <Button
              className="icon-button"
              p="4px"
              minW="15px"
              h="40px"
              onClick={() => handleApproveAction(params.data, 'View')}
            >
              {/* <i className="fas fa-eye timesheet-icon"></i> */}
              <BsCalendarWeekFill />
            </Button>
          </Tooltip>
        </Flex>
      ),
    },
  ];

  const handleTabStatusCountFetch = async (tabIndex) => {
    try {
      if (!empCode) return;

      let data;
      if (tabIndex === 0 || tabIndex === 1) {
        data = await FetchTimesheetStatusCounts(empCode);
      } else if (tabIndex === 2) {
        data = await FetchApprovalStatusCounts(empCode);
      }

      if (data && data.statusCounts) {
        const counts = {
          [TIMESHEET_STATUSES.Approved]:
            (data.statusCounts.find(
              (s) => s.status === TIMESHEET_STATUSES.Approved,
            )?.count || 0) +
            (data.statusCounts.find(
              (s) => s.status === TIMESHEET_STATUSES.PartiallyApproved,
            )?.count || 0),
          [TIMESHEET_STATUSES.Posted]:
            (data.statusCounts.find(
              (s) => s.status === TIMESHEET_STATUSES.Posted,
            )?.count || 0) +
            (data.statusCounts.find(
              (s) => s.status === TIMESHEET_STATUSES.PartiallyPosted,
            )?.count || 0),
          [TIMESHEET_STATUSES.Pending]:
            data.statusCounts.find(
              (s) => s.status === TIMESHEET_STATUSES.Pending,
            )?.count || 0,
        };
        setStatusCounters(counts);
      } else {
        // Add this to reset the counts if no data is returned
        setStatusCounters({
          [TIMESHEET_STATUSES.Approved]: 0,
          [TIMESHEET_STATUSES.Posted]: 0,
          [TIMESHEET_STATUSES.Pending]: 0,
        });
      }
    } catch (err) {
      console.error('Error fetching status counts:', err);
      // Optional: also reset counts on error
      setStatusCounters({
        [TIMESHEET_STATUSES.Approved]: 0,
        [TIMESHEET_STATUSES.Posted]: 0,
        [TIMESHEET_STATUSES.Pending]: 0,
      });
    }
  };

  const timesheetDetailColumnDefs = [
    {
      field: 'projectName',
      headerName: 'Project',
      sortable: true,
    },
    {
      field: 'categoryName',
      headerName: 'Category',
      sortable: true,
    },
    {
      field: 'subCategoryName',
      headerName: 'Subcategory',
      sortable: true,
    },
    {
      field: 'taskName',
      headerName: 'Task Name',
      sortable: true,
    },

    {
      headerName: 'Date',
      field: 'date',
      valueFormatter: (params) => formatDate(params.value),
    },

    { field: 'hours', headerName: 'Hours', sortable: true },
    {
      field: 'status',
      headerName: 'Status',
      sortable: true,
      cellRenderer: (params) => (
        <Tag
          className="Badge-lables"
          colorScheme={STATUS_COLOR_MAP[params.value] || 'gray'}
        >
          {params.value}
        </Tag>
      ),
    },
  ];

  return (
    <Box className="list-table-page">
      <ToastContainer />
      <Heading className="page-title" mb={4}>Timesheet</Heading>
      <Tabs
        variant="line"
        colorScheme="gray"
        mt={2}
        px={0}
        index={selectedTabIndex}
        onChange={(index) => {
          const nextAction = () => {
            setSelectedTabIndex(index);

            // Refresh Tab Data
            if (index === 0) {
              // Timesheet Main Tab
              const { startDate, endDate } = getWeekStartEndDates();
              fetchTimesheetDetails(startDate, endDate);
            } else if (index === 1) {
              // My Timesheets Tab
              handleFetchMyTimesheets();
            } else if (index === 2) {
              // Timesheet Approval Tab
              handleFetchTimesheetApprovals();
            }

            handleTabStatusCountFetch(index);

            // Reset filters with a small delay to ensure controlled input reset
            setTimeout(() => {
              setMyTimesheetFilters({ status: '', search: '' });
              setTimesheetApprovalFilters({ status: '', search: '' });
            }, 0);
          };

          if (isDirty && tasks.length > 0 && selectedTabIndex === 0) {
            setNavConfirmation({
              isOpen: true,
              nextAction,
            });
          } else {
            nextAction();
          }

          handleTabStatusCountFetch(index);

          // Reset filters with a small delay to ensure controlled input reset
          setTimeout(() => {
            setMyTimesheetFilters({ status: '', search: '' });
            setMyTimesheetFilters({ status: '', search: '' });
            setTimesheetApprovalFilters({ status: '', search: '', date: '' });
          }, 0);
        }}
      >
        <TabList
          display="flex"
          alignItems="center"
          gap={{ base: 2, md: 4 }}
          w="100%"
          px={0}
          borderBottom={'none'}
        >
          <Tab
            fontSize="16px"
            fontWeight="600"
            _selected={{
              borderBottomColor: 'gray.600',
              color: 'gray.800',
              fontWeight: '700',
            }}
          >
            Timesheet
          </Tab>
          <Tab
            fontSize="16px"
            fontWeight="600"
            _selected={{
              borderBottomColor: 'gray.600',
              color: 'gray.800',
              fontWeight: '700',
            }}
          >
            My Timesheets
          </Tab>
          {hasApprovalAccess && (
            <Tab
              fontSize="16px"
              fontWeight="600"
              _selected={{
                borderBottomColor: 'gray.600',
                color: 'gray.800',
                fontWeight: '700',
              }}
            >
              Timesheet Approval
            </Tab>
          )}

          <Flex ml="auto" gap={2} pr={4}>
            {[
              {
                label: 'Approved',
                color: 'green',
                count: statusCounters.Approved,
              },
              { label: 'Posted', color: 'blue', count: statusCounters.Posted },
              {
                label: 'Pending',
                color: 'red',
                count: statusCounters.Pending,
              },
            ].map((status, index) => {
              const cardStyle = statusCardStyles[status.label] || {
                bg: '#E9EDF5',
                label: '#1E334F',
                count: '#284E8F',
              };
              return (
                <Box
                  key={index}
                  bg={cardStyle.bg}
                  px={4}
                  py={2}
                  borderRadius="md"
                  display="flex"
                  flexDirection="column"
                  alignItems="center"
                  justifyContent="center"
                  minW="90px"
                  minH="60px"
                  _hover={{
                    transform: 'scale(1.05)',
                    boxShadow: 'md',
                    borderColor: `${status.color}.400`,
                  }}
                >
                  <ChakraText fontSize="md" fontWeight="bold" color={cardStyle.label}>
                    {status.label}
                  </ChakraText>
                  <ChakraText
                    fontSize="lg"
                    fontWeight="bold"
                    color={cardStyle.count}
                  >
                    {status.count}
                  </ChakraText>
                </Box>
              );
            })}
          </Flex>
        </TabList>

        <TabPanels>
          <TabPanel px={0} pt={4}>
            <VStack spacing={4} align="stretch">
              <div>
                <div
                  className="timesheet-container"
                  style={{ position: 'relative' }}
                >
                  {isTimesheetLoading && (
                    <Center
                      position="absolute"
                      top="0"
                      left="0"
                      right="0"
                      bottom="0"
                      bg="rgba(255, 255, 255, 0.7)"
                      zIndex={10}
                    >
                      <TimeSnapLoader size="lg" text="Loading timesheet..." />
                    </Center>
                  )}
                  {toastMessage && (
                    <div className={`toast ${toastType}`}>{toastMessage}</div>
                  )}
                  {/* navigation button controls   */}
                  <div className="timesheet-header">
                    <h3>{getFormattedWeekRange()}</h3>
                    <div
                      className="week-controls"
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px',
                      }}
                    >
                      <button
                        onClick={() => handleNavigate('prev')}
                        id="head"
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                          padding: '6px 12px',
                          backgroundColor: controlBg,
                          border: 'none',
                          color: controlText,
                          cursor: 'pointer',
                          fontWeight: 'normal',
                        }}
                      >
                        <span
                          style={{
                            display: 'inline-block',
                            width: '16px',
                            height: '16px',
                            backgroundColor: controlIcon,
                            clipPath: 'polygon(70% 0%, 0% 50%, 70% 100%)',
                          }}
                        ></span>
                        Prev
                      </button>

                      <input
                        ref={dateInputRef}
                        type="date"
                        value={selectedDate}
                        max={formatDateLocal(new Date())}
                        onChange={handleDateChange}
                        style={{
                          position: 'absolute',
                          opacity: 0,
                          width: 0,
                          pointerEvents: 'none',
                        }}
                      />

                      {/* Calendar Icon */}
                      <FaCalendarAlt
                        size={20}
                        style={{ cursor: 'pointer', color: mutedMeta }}
                        onClick={() => dateInputRef.current.showPicker()}
                      />

                      <button
                        onClick={() => handleNavigate('next')}
                        id="head"
                        disabled={isCurrentWeek}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                          padding: '6px 12px',
                          backgroundColor: controlBg,
                          color: controlText,
                          opacity: isCurrentWeek ? 0.5 : 1,
                          cursor: isCurrentWeek ? 'not-allowed' : 'pointer',
                          fontWeight: 'normal',
                          border: 'none',
                        }}
                      >
                        Next
                        <span
                          style={{
                            display: 'inline-block',
                            width: '16px',
                            height: '16px',
                            backgroundColor: controlIcon,
                            clipPath: 'polygon(30% 0%, 100% 50%, 30% 100%)',
                          }}
                        ></span>
                      </button>
                    </div>
                  </div>

                  <div className="task-addition">
                    <div
                      style={{
                          marginLeft: '0px',
                        display: 'flex',
                        alignItems: 'center',
                      }}
                    >
                      <button
                        fontWeight="normal"
                        cursor="pointer"
                        disabled={isAddTaskDisabled}
                        onClick={handleAddTaskClick}
                        style={{
                          opacity: isAddTaskDisabled ? 0.5 : 1,
                          cursor: isAddTaskDisabled ? 'not-allowed' : 'pointer',
                        }}
                      >
                        + Add Task
                      </button>

                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '11px',
                        }}
                      >
                        <label className="toggle-switch">
                          <input
                            type="checkbox"
                            checked={showWeekends}
                            onChange={(e) =>
                              handleToggleWeekends(e.target.checked)
                            }
                          />
                          <span className="slider round"></span>
                        </label>
                        <span style={{ fontSize: '14px' }}>Show Weekend</span>
                      </div>
                    </div>

                    <div>
                      <button
                        onClick={showSubmitConfirmation}
                        id="timeoff"
                        disabled={isSubmitWeekDisabled}
                        style={{
                          opacity: isSubmitWeekDisabled ? 0.5 : 1,
                          cursor: isSubmitWeekDisabled
                            ? 'not-allowed'
                            : 'pointer',
                        }}
                      >
                        {(() => {
                          const totalMinutes = tasks
                            .flatMap((task) => task.hours)
                            .map((num) => {
                              const hrs = Math.floor(Math.abs(num));
                              const mins = Math.round(
                                Math.abs(num - Math.floor(num)) * 100,
                              );
                              return hrs * 60 + mins;
                            })
                            .reduce((sum, mins) => sum + mins, 0);
                          return totalMinutes < 2400
                            ? 'Submit Day'
                            : 'Submit Week';
                        })()}
                      </button>
                    </div>
                  </div>

                  {/* Timesheet table */}
                  <table className="timesheet-table">
                    <thead>
                      <tr>
                        <th style={{ textAlign: 'center' }}>Tasks</th>
                        {filteredWeekDays.map((day, index) => {
                          const { regularHours, overtime, totalHours } =
                            calculateProgress(index);
                          const progressColor =
                            totalHours < REGULAR_WORK_HOURS
                              ? PROGRESS_COLOR_MAP.UNDER
                              : PROGRESS_COLOR_MAP.EXACT;
                          return (
                            <th key={index}>
                              {day.toLocaleDateString('en-US', {
                                weekday: 'short',
                                day: 'numeric',
                              })}
                              <div
                                className="progress-bar"
                                title={`Regular: ${formatDecimalHoursToHM(regularHours)}, Total: ${formatDecimalHoursToHM(totalHours)}`}
                              >
                                {/* Regular Hours */}
                                <div
                                  className="progress regular"
                                  style={{
                                    width: `${(regularHours / 8) * 100}%`,
                                    backgroundColor: progressColor,
                                  }}
                                ></div>
                              </div>
                            </th>
                          );
                        })}
                        <th>
                          Total
                        </th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tasks.map((task) => (
                        <tr key={task.uniqueId}>
                          <td id="col1">
                            <div
                              style={{
                                display: 'flex',
                                alignItems: 'stretch',
                                minHeight: '40px',
                              }}
                            >
                              <div
                                style={{
                                  width: '3px',
                                  minWidth: '3px',
                                  borderRadius: '4px',
                                  backgroundColor:
                                    task.project?.color || '#ccc',
                                  marginRight: '5px',
                                }}
                              ></div>
                              <div
                                style={{
                                  display: 'flex',
                                  flexDirection: 'column',
                                  lineHeight: '1.2',
                                  fontSize: '14px',
                                }}
                              >
                                <span
                                  className="task-name"
                                  style={{
                                    fontWeight: '600',
                                    textAlign: 'left',
                                  }}
                                >
                                  {task.taskName || 'Untitled Task'}
                                </span>
                                <span
                                  style={{
                                    fontSize: '11px',
                                    color: '#666',
                                    textAlign: 'left',
                                  }}
                                >
                                  {task.categoryName}{' '}
                                  {task.subCategoryName
                                    ? ` > ${task.subCategoryName}`
                                    : ''}
                                </span>
                              </div>
                            </div>
                          </td>
                          {/* Hour Inputs for Each Day */}
                          {filteredWeekDays.map((_, dayIndex) => (
                            <td key={dayIndex}>
                              <Tooltip
                                label={task.dayStatuses?.[dayIndex]}
                                isDisabled={!task.dayStatuses?.[dayIndex]}
                                placement="top"
                                hasArrow
                                bg={
                                  task.dayStatuses?.[dayIndex] === 'Declined'
                                    ? 'red.600'
                                    : task.dayStatuses?.[dayIndex] ===
                                      'Approved'
                                      ? 'green.500'
                                      : task.dayStatuses?.[dayIndex] ===
                                        'Pending'
                                        ? 'yellow.500'
                                        : 'gray.500'
                                }
                                color="white"
                                fontSize="xs"
                              >
                                <input
                                  type="number"
                                  min="0"
                                  max="12"
                                  step="0.01"
                                  placeholder="0"
                                  value={
                                    task.hours[dayIndex]
                                  }
                                  onChange={(e) => {
                                    const value = e.target.value;
                                   

                                     // REQ: Restrict to max 2 digits before and 2 digits after decimal
                                    if (value !== "" && !/^\d{0,2}(\.\d{0,2})?$/.test(value)) {
                                      return;
                                    }

                                    if (
                                      ['Approved', 'Pending'].includes(
                                        task.dayStatuses?.[dayIndex],
                                      )
                                    ) {
                                      return;
                                    }

                                    const numValue = parseFloat(value);
                                    if (numValue > MAX_DAILY_HOURS) {
                                      handleHourChange(
                                        task.uniqueId,
                                        dayIndex,
                                        "",
                                      );
                                      showToast(
                                        'warning',
                                        `Hours cannot exceed ${MAX_DAILY_HOURS} per day`,
                                      );
                                      return;
                                    }

                                    // No immediate normalization during typing - pass raw value
                                    handleHourChange(
                                      task.uniqueId,
                                      dayIndex,
                                      value,
                                      false
                                    );
                                  }}
                                  // Add pattern attribute to restrict input format
                                  pattern="\d*\.?\d{0,2}"
                                  onKeyDown={(e) => {
                                    const status = task.dayStatuses?.[dayIndex];
                                    if (
                                      ['e', 'E', '+', '-'].includes(e.key) ||
                                      ['Approved', 'Pending'].includes(status)
                                    ) {
                                      e.preventDefault();
                                    }
                                  }}
                                  onWheel={(e) => e.target.blur()}
                                  readOnly={
                                    ['Approved', 'Pending', 'Posted'].includes(
                                      task.dayStatuses?.[dayIndex],
                                    ) && timesheetStatus === 'Pending' // Lock if header is pending
                                      ? true
                                      : ['Approved', 'Posted'].includes(task.dayStatuses?.[dayIndex]) // Always lock Approved/Posted rows
                                  }
                                  onFocus={(e) => {
                                    const status = task.dayStatuses?.[dayIndex];
                                    if (status === 'Approved') {
                                      e.target.style.border = '1px solid green';
                                    } else if (!['Approved'].includes(status)) {
                                      e.target.style.border = '1px solid gray';
                                    }
                                  }}
                                  onBlur={(e) => {
                                    const value = e.target.value;
                                    handleHourChange(
                                      task.uniqueId,
                                      dayIndex,
                                      value,
                                      true // Normalize and format on blur (Tab/Click-away)
                                    );
                                  }}
                                  className={`${task.hours[dayIndex] === 'Approved'
                                      ? 'disabled-input'
                                      : 'normal-input'
                                    } ${getStatusClass(task, dayIndex)}`}
                                />
                              </Tooltip>
                            </td>
                          ))}

                          <td>{formatTotalHoursAndMinutes(task.hours)}</td>

                          <td>
                            {['Posted', 'Approved'].includes(
                              timesheetStatus,
                            ) ? (
                              <Tooltip
                                label="Can't delete after submitted"
                                placement="top"
                              >
                                <button
                                  className="icon-button"
                                  disabled
                                  style={{
                                    cursor: 'not-allowed',
                                    opacity: 0.5,
                                  }}
                                >
                                  <i className="fas fa-trash"></i>
                                </button>
                              </Tooltip>
                            ) : (
                              <Tooltip label="Delete Task" placement="top">
                                <button
                                  className="icon-button"
                                  onClick={() =>
                                    showDeleteConfirmation(
                                      task.id,
                                      task.project.value,
                                      task.category_Id,
                                      task.sub_category_Id,
                                    )
                                  }
                                >
                                  <i className="fas fa-trash"></i>
                                </button>
                              </Tooltip>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr>
                        <td id="col1">Total</td>
                        {filteredWeekDays.map((_, dayIndex) => {
                          const totalForDay = tasks.reduce(
                            (sum, task) =>
                              sum + (parseFloat(task.hours[dayIndex]) || 0),
                            0,
                          );

                          const isInvalid = totalForDay > 24;

                          return (
                            <td
                              key={dayIndex}
                              style={{
                                color: isInvalid ? 'red' : 'inherit',
                                fontWeight: isInvalid ? 'bold' : 'normal',
                              }}
                            >
                              {formatTotalHoursAndMinutes(
                                tasks.map((task) => task.hours[dayIndex]),
                              )}
                              {isInvalid && (
                                <span style={{ marginLeft: '5px' }}>⚠️</span>
                              )}
                            </td>
                          );
                        })}
                        <td>
                          {formatTotalHoursAndMinutes(
                            tasks.flatMap((task) => task.hours),
                          )}
                        </td>

                        <td>
                          <button
                            id="savedraft"
                            onClick={() => {
                              // block save if invalid totals exist
                              const invalidDay = filteredWeekDays.findIndex(
                                (_, dayIndex) => {
                                  const total = tasks.reduce(
                                    (sum, task) =>
                                      sum +
                                      (parseFloat(task.hours[dayIndex]) || 0),
                                    0,
                                  );
                                  return total > 24;
                                },
                              );

                              if (invalidDay >= 0) {
                                showToast(
                                  'error',
                                  `Day ${filteredWeekDays[
                                    invalidDay
                                  ].toLocaleDateString('en-US', {
                                    weekday: 'short',
                                  })} exceeds 24h. Please correct before saving.`,
                                );
                                return;
                              }

                              onSaveDraftOpen();
                            }}
                            disabled={isSaveDraftDisabled}
                            style={{
                              opacity: isSaveDraftDisabled ? 0.5 : 1,
                              cursor: isSaveDraftDisabled
                                ? 'not-allowed'
                                : 'pointer',
                            }}
                          >
                            Save Draft
                          </button>
                        </td>
                      </tr>
                    </tfoot>
                  </table>

                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      marginTop: '20px',
                    }}
                  >
                    <div
                      style={{ marginTop: '0px' }}
                    >
                      {[
                        ...new Map(
                          tasks
                            .filter((task) => task.project)
                            .map((task) => [
                              task.project.label,
                              task.project,
                            ]),
                        ).values(),
                      ].map((project, index) => (
                        <div
                          key={index}
                          style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            marginRight: '15px',
                          }}
                        >
                          <div
                            style={{
                              width: '10px',
                              height: '10px',
                              borderRadius: '50px',
                              backgroundColor: project?.color || '#ccc',
                              marginRight: '5px',
                            }}
                          ></div>
                          <span style={{ fontSize: '12px', color: controlText }}>
                            {project?.label || 'Unnamed Project'}
                          </span>
                        </div>
                      ))}
                    </div>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '15px',
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center' }}>
                        <div
                          style={{
                            width: '10px',
                            height: '10px',
                            backgroundColor: '#c93434',
                            marginRight: '5px',
                            borderRadius: '50px',
                          }}
                        ></div>
                        <span style={{ fontSize: '12px' }}>Under Hours</span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center' }}>
                        <div
                          style={{
                            width: '10px',
                            height: '10px',
                            backgroundColor: '#85e085',
                            marginRight: '5px',
                            borderRadius: '50px',
                          }}
                        ></div>
                        <span style={{ fontSize: '12px' }}>Actual Hours</span>
                      </div>
                    </div>
                  </div>
                  {isApiSuccess && timesheetNotes.length > 0 && (
                    <Box mt={2} pt={2}>
                      <Box
                        p={3}
                        bg="gray.50"
                        borderRadius="md"
                        borderLeft="4px"
                        borderColor={
                          timesheetStatus?.includes('Partially')
                            ? 'blue.500'
                            : timesheetStatus === 'Pending'
                              ? 'red.500'
                              : timesheetStatus === 'Posted'
                                ? 'yellow.500'
                                : timesheetStatus === 'Approved'
                                  ? 'green.500'
                                  : 'gray.500'
                        }
                        backgroundColor={
                          timesheetStatus?.includes('Partially')
                            ? 'blue.100'
                            : timesheetStatus === 'Pending'
                              ? 'red.100'
                              : timesheetStatus === 'Posted'
                                ? 'yellow.100'
                                : timesheetStatus === 'Approved'
                                  ? 'green.100'
                                  : 'gray.100'
                        }
                      >
                        <Flex justify="space-between" mb={2}>
                          <Text
                            fontSize="sm"
                            fontWeight="medium"
                            color="gray.700"
                          >
                            {timesheetNotes[0].date}
                          </Text>
                        </Flex>
                        <Text fontSize="sm" color="gray.800">
                          {timesheetNotes[0].notes}
                        </Text>
                      </Box>
                    </Box>
                  )}

                  {/* Add Task Modal */}
                  <CustomModal
                    isOpen={isOpen}
                    closeOnOverlayClick={false}
                    onClose={closeAddtaskModal}
                  >
                    <ModalOverlay />
                    <ModalContent
                      className="timesheet-tasklist-modal"
                      borderRadius="md"
                      p={4}
                      maxWidth="800px"
                      height="600px"
                    >
                      <ModalHeader
                        textAlign="left"
                        fontSize="2xl"
                        fontWeight="bold"
                      >
                        Task List
                      </ModalHeader>
                      <ModalCloseButton />
                      <ModalBody>
                        <div
                          className="addtaskmodal"
                          style={{
                            display: 'flex',
                            gap: '16px',
                            alignItems: 'center',
                            marginBottom: '16px',
                          }}
                        >
                          <div style={{ width: '250px' }}>
                            <FormControl isRequired>
                              <FormLabel isRequired>Project</FormLabel>
                              <ReactSelect
                                options={projectOptions}
                                styles={projectSelectStyles}
                                menuPortalTarget={document.body}
                                menuPosition="fixed"
                                onChange={handleProjectChange}
                                placeholder="Select Project"
                              />
                            </FormControl>
                          </div>
                          <div style={{ width: '250px' }}>
                            <FormControl>
                              <FormLabel>Search</FormLabel>
                              <Input
                                placeholder="Search..."
                                value={searchTerm}
                                onChange={handleSearchChange}
                                height="38px"
                                bg="white"
                                variant="outline"
                                borderColor="gray.300"
                                focusBorderColor="blue.500"
                                borderRadius="md"
                              />
                            </FormControl>
                          </div>
                        </div>
                        {/* Show these dropdowns ONLY when a project is selected */}
                        {selectedProjectValue && (
                          <div
                            style={{
                              display: 'flex',
                              gap: '12px',
                              marginTop: '10px',
                              width: '100%',
                              alignItems: 'center',
                            }}
                          >
                            <FormControl isRequired isInvalid={errors.category}>
                              <FormLabel>Main Category</FormLabel>

                              <Dropdown
                                type="categories" // backend dropdown type
                                placeholder="Select Category" // NOT starting with "All" → react-select
                                selectedValue={selectedCategory}
                                setSelectedValue={(value) => {
                                  handleCategoryChange(value);
                                  setErrors((prev) => ({
                                    ...prev,
                                    category: '',
                                  }));
                                }}
                              />

                              {errors.category && (
                                <FormErrorMessage>
                                  {errors.category}
                                </FormErrorMessage>
                              )}
                            </FormControl>

                            {/* Sub Category */}
                            <FormControl
                              isRequired
                              isInvalid={errors.subCategory}
                            >
                              <FormLabel>Sub Category</FormLabel>

                              <Dropdown
                                itemsProp={subTasks}
                                type="subcategories"
                                placeholder="Select Task"
                                selectedValue={selectedSubTask}
                                setSelectedValue={(value) => {
                                  handleSubcategoryChange(value);
                                  setSelectedSubTask(value);
                                  setNewTask({
                                    ...newTask,
                                    sub_category_Id: value,
                                  });
                                  setErrors((prev) => ({
                                    ...prev,
                                    subCategory: '',
                                  }));
                                }}
                              />

                              {errors.subCategory && (
                                <FormErrorMessage>
                                  {errors.subCategory}
                                </FormErrorMessage>
                              )}
                            </FormControl>
                          </div>
                        )}

                        <div
                          className="ag-theme-alpine addtask-grid"
                          style={{
                            marginTop: '20px',
                            height: '250px',
                            width: '100%',
                            overflowY: 'auto',
                            position: 'relative',
                          }}
                        >
                          {isAddTaskLoading && (
                            <Center
                              position="absolute"
                              top="0"
                              left="0"
                              right="0"
                              bottom="0"
                              bg="rgba(255, 255, 255, 0.7)"
                              zIndex={10}
                            >
                              <TimeSnapLoader size="lg" text="Loading tasks..." />
                            </Center>
                          )}
                          <AgGridReact
                            ref={gridRef}
                            rowSelection="multiple"
                            suppressRowClickSelection={true}
                            rowMultiSelectWithClick={true}
                            rowHeight={44}
                            headerHeight={44}
                            columnDefs={[
                              {
                                headerName: '',
                                field: 'checkbox',
                                width: 52,
                                headerClass: 'ts-tasklist-checkbox-col',
                                cellClass: 'ts-tasklist-checkbox-col',
                                checkboxSelection: true,
                                headerCheckboxSelection: true,
                                headerCheckboxSelectionFilteredOnly: true,
                                suppressSizeToFit: true,
                              },
                              ...addTaskColumnDefs,
                            ]}
                            rowData={filteredRowData}
                            onSelectionChanged={handleSelectionChanged}
                            suppressNavigable="true"
                            pagination={true}
                            paginationPageSizeSelector={[10, 25, 50, 100]}
                            paginationPageSize={10}
                            suppressPaginationPanel={false}
                            paginationNumberFormatter={(params) =>
                              `${params?.value ?? 0}`
                            }
                            defaultColDef={{ resizable: false }}
                            suppressCellFocus={true}
                            suppressMovableColumns={true}
                            suppressRowDrag={true}
                            suppressMoveWhenRowDragging={true}
                            onGridReady={(params) =>
                              params.api.sizeColumnsToFit()
                            }
                            onRowClicked={(event) => {
                              if (event.node) {
                                event.node.setSelected(
                                  !event.node.isSelected(),
                                );
                              }
                            }}
                          />
                        </div>
                      </ModalBody>
                      <ModalFooter className="timesheet-tasklist-footer">
                        <Flex className="timesheet-tasklist-footer-actions">
                          <Button
                            variant="outline"
                            className="common-button"
                            colorScheme="black"
                            _hover={{
                              bg: 'gray.200',
                              color: 'black',
                              borderColor: 'gray.300',
                            }}
                            onClick={closeAddtaskModal}
                          >
                            Cancel
                          </Button>
                          <Button
                            className="common-button main"
                            onClick={addTask}
                            isLoading={isSubmitting}
                          >
                            Save
                          </Button>
                        </Flex>
                      </ModalFooter>
                    </ModalContent>
                  </CustomModal>

                  {/* Save Draft Modal  */}
                  <Modal
                    isOpen={isSaveDraftOpen}
                    closeOnOverlayClick={false}
                    onClose={onSaveDraftClose}
                    isCentered
                    size="sm"
                  >
                    <ModalOverlay />
                    <ModalContent
                      className="save-draft-modal"
                      w="calc(100vw - 40px)"
                      maxW="460px"
                      mx={4}
                      borderRadius="18px"
                    >
                      <ModalHeader fontSize="18px" pb={2}>Save as Draft</ModalHeader>
                      <ModalCloseButton />
                      <ModalBody pb={3}>
                        <Text color="gray.700" fontSize="16px" lineHeight="1.7">
                          Your timesheet will be saved as a draft until you
                          submit it. You can continue making changes before
                          submitting.
                        </Text>
                      </ModalBody>
                      <ModalFooter pt={4}>
                        <Button
                          variant="outline"
                          className="common-button"
                          data-btn-tone="secondary"
                          minW="128px"
                          onClick={onSaveDraftClose}
                        >
                          Cancel
                        </Button>
                        <Button
                          className="common-button"
                          data-btn-tone="primary"
                          minW="128px"
                          onClick={async () => {
                            await saveDraft();
                            onSaveDraftClose();
                          }}
                          isLoading={isSubmitting}
                        >
                          Save Draft
                        </Button>
                      </ModalFooter>
                    </ModalContent>
                  </Modal>

                  {/* Under 40 hours error modal */}
                  <Modal
                    isOpen={underHoursError}
                    onClose={() => setUnderHoursError(false)}
                  >
                    <ModalOverlay />
                    <ModalContent>
                      <ModalHeader color="red.600">
                        Submission Blocked
                      </ModalHeader>
                      <ModalCloseButton />
                      <ModalBody>
                        <Text fontSize="md" color="gray.800">
                          You cannot submit your timesheet because you’ve logged
                          less than{' '}
                          <Text as="span" fontWeight="bold">
                            40 hours
                          </Text>{' '}
                          this week.
                          <br />
                          Please complete your weekly hours before submitting.
                        </Text>
                      </ModalBody>
                      <ModalFooter>
                        <Button
                          colorScheme="red"
                          onClick={() => setUnderHoursError(false)}
                        >
                          OK
                        </Button>
                      </ModalFooter>
                    </ModalContent>
                  </Modal>

                  {/* Incomplete day hours error modal */}
                  <Modal
                    isOpen={incompleteDayError.isOpen}
                    onClose={() =>
                      setIncompleteDayError({ isOpen: false, dayName: '' })
                    }
                    isCentered
                    size="sm"
                  >
                    <ModalOverlay />
                    <ModalContent
                      className="incomplete-day-modal"
                      w="calc(100vw - 40px)"
                      maxW="460px"
                      mx={4}
                      borderRadius="18px"
                    >
                      <ModalHeader fontSize="18px" pb={2}>
                        Incomplete Day Hours
                      </ModalHeader>
                      <ModalCloseButton />
                      <ModalBody pb={5}>
                        <Text fontSize="16px" color="gray.700" lineHeight="1.7">
                          You have logged less than 8 hours on{' '}
                          <Text as="span" fontWeight="bold">
                            {incompleteDayError.dayName}
                          </Text>
                          .
                          <br />
                          Please complete 8 hours for the day before submitting.
                        </Text>
                        <Flex justify="flex-end" mt={6}>
                          <Button
                            className="main common-button"
                            onClick={() =>
                              setIncompleteDayError({
                                isOpen: false,
                                dayName: '',
                              })
                            }
                          >
                            OK
                          </Button>
                        </Flex>
                      </ModalBody>
                    </ModalContent>
                  </Modal>

                  {/* Zero hours task error modal */}
                  <Modal
                    isOpen={zeroHoursTaskError}
                    onClose={() => setZeroHoursTaskError(false)}
                  >
                    <ModalOverlay />
                    <ModalContent>
                      <ModalHeader color="red.600">
                        Submission Blocked
                      </ModalHeader>
                      <ModalCloseButton />
                      <ModalBody>
                        <Text fontSize="md" color="gray.800">
                          One or more tasks have{' '}
                          <Text as="span" fontWeight="bold">
                            0 hours
                          </Text>{' '}
                          logged.
                          <br />
                          Please enter hours for all tasks or delete the task
                          before submitting.
                        </Text>
                      </ModalBody>
                      <ModalFooter>
                        <Button
                          colorScheme="red"
                          onClick={() => setZeroHoursTaskError(false)}
                        >
                          OK
                        </Button>
                      </ModalFooter>
                    </ModalContent>
                  </Modal>

                  {/* Early Submission Warning Modal */}
                  <Modal
                    isOpen={earlySubmissionWarning}
                    closeOnOverlayClick={false}
                    onClose={() => setEarlySubmissionWarning(false)}
                  >
                    <ModalOverlay />
                    <ModalContent className="early-submit-warning-modal">
                      <ModalHeader>Early Submission Warning</ModalHeader>
                      <ModalCloseButton />
                      <ModalBody>
                        You are submitting this timesheet before the end of the
                        week. Once submitted, no changes can be made. Are you
                        sure you want to proceed?
                      </ModalBody>
                      <ModalFooter>
                        <Flex gap={4} justify="flex-end">
                          <Button
                            gap={2}
                            variant="outline"
                            className="common-button"
                            onClick={() => setEarlySubmissionWarning(false)}
                          >
                            Cancel
                          </Button>
                          <Button
                            className="early-submit-warning-modal__proceed"
                            bg="#f4c842"
                            border="1px solid #f4c842"
                            color="#111827"
                            _hover={{
                              bg: '#eabf34',
                              borderColor: '#eabf34',
                            }}
                            _active={{
                              bg: '#ddb42f',
                              borderColor: '#ddb42f',
                            }}
                            onClick={handleEarlySubmitConfirmation}
                          >
                            Proceed
                          </Button>
                        </Flex>
                      </ModalFooter>
                    </ModalContent>
                  </Modal>
                  {/* Submit Confirmation Modal */}
                  <Modal
                    isOpen={submitConfirmation.isOpen}
                    closeOnOverlayClick={false}
                    onClose={handleSubmitCancel}
                  >
                    <ModalOverlay />
                    <ModalContent className="submit-timesheet-modal">
                      <ModalHeader>Submit Timesheet</ModalHeader>
                      <ModalCloseButton />
                      <ModalBody>
                        {hasEditableTasksInPostedSheet &&
                          (timesheetStatus === 'Posted' ||
                            timesheetStatus === 'Approved' ||
                            timesheetStatus === 'Pending')
                          ? 'Are you sure you want to re-submit this timesheet with corrections? This will send the updated timesheet for re-approval.'
                          : 'Are you sure you want to submit this timesheet?'}
                      </ModalBody>

                      <ModalFooter>
                        <Flex gap={4} justify="flex-end">
                          <Button
                            gap={2}
                            variant="outline"
                            className="common-button"
                            onClick={() =>
                              setSubmitConfirmation({
                                isOpen: false,
                                timesheetId: null,
                              })
                            }
                          >
                            Cancel
                          </Button>
                          <Button
                            className="submit-timesheet-modal__submit"
                            bg="#f4c842"
                            border="1px solid #f4c842"
                            color="#111827"
                            _hover={{
                              bg: '#eabf34',
                              borderColor: '#eabf34',
                            }}
                            _active={{
                              bg: '#ddb42f',
                              borderColor: '#ddb42f',
                            }}
                            onClick={handleSubmitWeek}
                            isLoading={isSubmitting}
                          >
                            {hasEditableTasksInPostedSheet &&
                              (timesheetStatus === 'Posted' ||
                                timesheetStatus === 'Approved' ||
                                timesheetStatus === 'Pending')
                              ? 'Re-Submit'
                              : 'Submit'}
                          </Button>
                        </Flex>
                      </ModalFooter>
                    </ModalContent>
                  </Modal>

                  {/* Navigation Confirmation Modal */}
                  <Modal
                    isOpen={navConfirmation.isOpen}
                    onClose={() =>
                      setNavConfirmation({ isOpen: false, nextAction: null })
                    }
                    isCentered
                  >
                    <ModalOverlay />
                    <ModalContent>
                      <ModalHeader fontSize="lg" fontWeight="bold">
                        Unsaved Changes
                      </ModalHeader>
                      <ModalCloseButton />
                      <ModalBody>
                        <Text>
                          You have unsaved changes, Do you want to continue ?
                        </Text>
                      </ModalBody>
                      <ModalFooter>
                        <Flex w="full" gap={3}>
                          <Spacer />
                          <Button
                            variant="outline"
                            colorScheme="red"
                            size="sm"
                            onClick={() => {
                              setNavConfirmation({
                                isOpen: false,
                                nextAction: null,
                              });
                            }}
                          >
                            Cancel
                          </Button>
                          <Button
                            colorScheme="green"
                            size="sm"
                            onClick={async () => {
                              await saveDraft();
                              if (navConfirmation.nextAction)
                                navConfirmation.nextAction();
                              setNavConfirmation({
                                isOpen: false,
                                nextAction: null,
                              });
                            }}
                            isLoading={isSubmitting}
                          >
                            Save & Continue
                          </Button>
                        </Flex>
                      </ModalFooter>
                    </ModalContent>
                  </Modal>

                  {/* Delete Task Modal */}
                  <Modal
                    isOpen={deleteConfirmation.isOpen}
                    closeOnOverlayClick={false}
                    onClose={handleDeleteCancel}
                    isCentered
                    size="sm"
                  >
                    <ModalOverlay />
                    <ModalContent
                      className="delete-task-modal"
                      w="calc(100vw - 40px)"
                      maxW="460px"
                      mx={4}
                      borderRadius="18px"
                    >
                      <ModalHeader fontSize="18px" pb={2}>Delete Task</ModalHeader>
                      <ModalCloseButton />
                      <ModalBody pb={3}>
                        <Text color="gray.700" fontSize="16px" lineHeight="1.7">
                          Are you sure you want to delete{' '}
                          <Text as="span" fontWeight="bold" color="black.600">
                            {
                              tasks.find(
                                (task) => task.id === deleteConfirmation.taskId,
                              )?.taskName
                            }
                          </Text>
                          ?
                        </Text>
                      </ModalBody>
                      <ModalFooter pt={4}>
                        <Flex gap={4} justify="flex-end">
                          <Button
                            variant="outline"
                            className="common-button"
                            data-btn-tone="secondary"
                            _hover={{
                              bg: 'gray.200',
                              color: 'black',
                              borderColor: 'gray.300',
                            }}
                            onClick={handleDeleteCancel}
                          >
                            Cancel
                          </Button>
                          <Button
                            className="common-button"
                            data-btn-tone="danger"
                            onClick={handleDeleteConfirm}
                            isLoading={isSubmitting}
                          >
                            Delete
                          </Button>
                        </Flex>
                      </ModalFooter>
                    </ModalContent>
                  </Modal>
                </div>
              </div>
            </VStack>
          </TabPanel>

          <TabPanel px={0} pt={4}>
            <div>
              <Flex width="100%">
                <FormControl width="210px">
                  <FormLabel fontSize="sm" fontWeight="bold" mb={1}>
                    Status
                  </FormLabel>
                  <Dropdown
                    type="mytimesheetstatus"
                    placeholder="All Status"
                    selectedValue={myTimesheetFilters.status}
                    setSelectedValue={(value) =>
                      setMyTimesheetFilters({
                        ...myTimesheetFilters,
                        status: value,
                      })
                    }
                  />
                </FormControl>
              </Flex>
              <div
                className="ag-theme-alpine list-table-grid content-surface"
                style={{
                  marginTop: 20,
                  width: '100%',
                  position: 'relative',
                }}
              >
                {isMyTimesheetLoading && (
                  <Center
                    position="absolute"
                    top="0"
                    left="0"
                    right="0"
                    bottom="0"
                    bg="rgba(255, 255, 255, 0.7)"
                    zIndex={10}
                  >
                    <TimeSnapLoader size="lg" text="Loading timesheets..." />
                  </Center>
                )}
                <AgGridReact
                  rowData={filteredMyTimesheets}
                  columnDefs={[
                    {
                      field: 'employeeName',
                      headerName: 'Name',
                      sortable: true,
                    },
                    {
                      field: 'week',
                      headerName: 'Week',
                      sortable: true,
                    },
                    {
                      field: 'totalHours',
                      headerName: 'Hours',
                      sortable: true,
                    },

                    {
                      field: 'status',
                      headerName: 'Status',
                      cellRenderer: (params) => (
                        <Tag
                          className="Badge-lables"
                          colorScheme={STATUS_COLOR_MAP[params.value] || 'gray'}
                        >
                          {params.value}
                        </Tag>
                      ),
                    },
                  ]}
                  defaultColDef={{ flex: 1, minWidth: 100, resizable: false }}
                  suppressMovableColumns={true}
                  suppressRowDrag={true}
                  suppressMoveWhenRowDragging={true}
                  paginationPageSizeSelector={[10, 25, 50, 100]}
                  pagination={true}
                  paginationPageSize={10}
                />
              </div>
            </div>
          </TabPanel>

          <TabPanel px={0} pt={4}>
            <div>
              <Flex width="100%" gap={4} alignItems="end" wrap="nowrap">
                <FormControl width={{ base: '100%', md: '260px' }}>
                  <FormLabel fontSize="sm" fontWeight="bold" mb={1}>
                    Status
                  </FormLabel>
                  <Dropdown
                    type="approvelstatus"
                    placeholder="All Status"
                    selectedValue={timesheetApprovalFilters.status}
                    setSelectedValue={(value) =>
                      setTimesheetApprovalFilters({
                        ...timesheetApprovalFilters,
                        status: value,
                      })
                    }
                  />
                </FormControl>

                <FormControl width={{ base: '100%', md: '320px' }}>
                  <FormLabel fontSize="sm" fontWeight="bold" mb={1}>
                    Search
                  </FormLabel>
                  <Input
                    placeholder="Search..."
                    value={timesheetApprovalFilters.search}
                    onChange={(e) =>
                      setTimesheetApprovalFilters({
                        ...timesheetApprovalFilters,
                        search: e.target.value,
                      })
                    }
                  />
                </FormControl>

                <FormControl width={{ base: '100%', md: '250px' }}>
                  <FormLabel fontSize="sm" fontWeight="bold" mb={1}>
                    From Date
                  </FormLabel>
                  <Input
                    type="date"
                    value={timesheetApprovalFilters.fromDate}
                    onChange={(e) =>
                      setTimesheetApprovalFilters({
                        ...timesheetApprovalFilters,
                        fromDate: e.target.value,
                      })
                    }
                  />
                </FormControl>

                <FormControl width={{ base: '100%', md: '250px' }}>
                  <FormLabel fontSize="sm" fontWeight="bold" mb={1}>
                    To Date
                  </FormLabel>
                  <Input
                    type="date"
                    value={timesheetApprovalFilters.toDate}
                    onChange={(e) =>
                      setTimesheetApprovalFilters({
                        ...timesheetApprovalFilters,
                        toDate: e.target.value,
                      })
                    }
                  />
                </FormControl>
              </Flex>
              <div
                className="ag-theme-alpine list-table-grid content-surface"
                style={{
                  marginTop: 20,
                  width: '100%',
                  position: 'relative',
                }}
              >
                {isApprovalLoading && (
                  <Center
                    position="absolute"
                    top="0"
                    left="0"
                    right="0"
                    bottom="0"
                    bg="rgba(255, 255, 255, 0.7)"
                    zIndex={10}
                  >
                    <TimeSnapLoader size="lg" text="Loading approvals..." />
                  </Center>
                )}
                <AgGridReact
                  rowData={filteredApprovals}
                  columnDefs={columnDefsforapprove}
                  defaultColDef={{
                    flex: 1,
                    minWidth: 100,
                    resizable: false,
                  }}
                  suppressMovableColumns={true}
                  suppressRowDrag={true}
                  suppressMoveWhenRowDragging={true}
                  pagination={true}
                  paginationPageSizeSelector={[10, 25, 50, 100]}
                  paginationPageSize={10}
                />
              </div>
            </div>
            {/* Week wise Approval */}
            <Modal
              isOpen={isApproveOpen}
              closeOnOverlayClick={false}
              onClose={handleApproveClose}
              isCentered
            >
              <ModalOverlay />
              <ModalContent className="timesheet-approval-modal">
                <ModalHeader>
                  <Text fontSize="2xl" fontWeight="bold">
                    Timesheet Approval
                  </Text>
                </ModalHeader>

                <ModalCloseButton />
                <ModalBody
                  className="timesheet-approval-modal__body"
                  display="flex"
                  flexDirection="column"
                  overflow="hidden"
                  pb={6}
                >
                  <Box className="timesheet-approval-toolbar" mb={3}>
                    <Box className="timesheet-approval-info-wrapper">
                      <Box className="timesheet-approval-info">
                        <Box className="timesheet-approval-info__field">
                          <Text className="timesheet-approval-info__label">
                            Employee
                          </Text>
                          <Tooltip
                            label={selectedTimesheet?.employeeName || ''}
                            hasArrow
                            placement="top"
                            isDisabled={!selectedTimesheet?.employeeName}
                          >
                            <Badge
                              className="timesheet-approval-info__badge"
                              px={3}
                              py={1}
                              bg={approvalMetaBadgeBg}
                              color={approvalMetaBadgeColor}
                              borderRadius="xl"
                            >
                              {selectedTimesheet?.employeeName}
                            </Badge>
                          </Tooltip>
                        </Box>

                        <Box className="timesheet-approval-info__field">
                          <Text className="timesheet-approval-info__label">
                            Week
                          </Text>
                          <Badge
                            className="timesheet-approval-info__badge"
                            px={3}
                            py={1}
                            bg={approvalMetaBadgeBg}
                            color={approvalMetaBadgeColor}
                            borderRadius="xl"
                            textTransform="none"
                          >
                            {selectedWeekRange}
                          </Badge>
                        </Box>

                        <Box className="timesheet-approval-info__field">
                          <Text className="timesheet-approval-info__label">
                            Project
                          </Text>
                          <Flex className="timesheet-approval-info__projects" gap={1}>
                            {[
                              ...new Map(
                                (timesheetTasks || []).map((t) => [
                                  t.projectId,
                                  t,
                                ]),
                              ).values(),
                            ].map((p) => (
                              <Tooltip
                                key={p.projectId}
                                label={p.projectName}
                                hasArrow
                                placement="top"
                              >
                                <Badge
                                  className="timesheet-approval-info__badge"
                                  px={3}
                                  py={1}
                                  bg={approvalMetaBadgeBg}
                                  color={approvalMetaBadgeColor}
                                  borderRadius="xl"
                                  textTransform="none"
                                >
                                  {p.projectName}
                                </Badge>
                              </Tooltip>
                            ))}
                          </Flex>
                        </Box>
                      </Box>

                      <HStack
                        className="timesheet-approval-info-wrapper__actions"
                        spacing={3}
                        flexShrink={0}
                      >
                        <Button
                          className="timesheet-approval-action timesheet-approve-btn"
                          colorScheme="green"
                          size="sm"
                          onClick={handleApprove}
                          isLoading={isApproving}
                          isDisabled={
                            selectedTasks.length === 0 ||
                            (selectedTasks.length > 0
                              ? selectedTasks.every((t) => t.status === 'Approved')
                              : (timesheetTasks?.length > 0 &&
                                timesheetTasks.every(
                                  (t) => t.status === 'Approved',
                                )))
                          }
                        >
                          Approve
                        </Button>
                        <Button
                          className="timesheet-approval-action timesheet-decline-btn"
                          colorScheme="red"
                          size="sm"
                          onClick={handleDecline}
                          isLoading={isDeclining}
                          isDisabled={
                            selectedTasks.length === 0 ||
                            (selectedTasks.length > 0
                              ? selectedTasks.every((t) => t.status === 'Declined')
                              : (timesheetTasks?.length > 0 &&
                                !timesheetTasks.some(
                                  (t) =>
                                    t.status !== 'Approved' &&
                                    t.status !== 'Declined',
                                )))
                          }
                        >
                          Decline
                        </Button>
                      </HStack>
                    </Box>
                  </Box>

                  {/* ======================= TABLE ======================= */}
                  {(() => {
                    const safe = Array.isArray(timesheetTasks)
                      ? timesheetTasks
                      : [];
                    const weekRangeLabel =
                      selectedWeekRange || getWeekRangeFromRows(safe);

                    const getTaskKey = (row) => {
                      const cId = row.categoryId || row.category_Id;
                      const scId = row.subCategoryId || row.sub_category_Id;
                      return `${row.projectId}-${row.taskId}-${cId}-${scId}`;
                    };

                    const getDayRowsForTask = (task, dayIndex) =>
                      safe.filter((row) => {
                        if (!row?.date) return false;
                        if (getTaskKey(row) !== getTaskKey(task)) return false;
                        const rowDayIndex = getDayIndexFromDate(new Date(row.date));
                        return rowDayIndex === dayIndex;
                      });

                    const activeEntries = safe.filter((t) => t.isDeleted !== 1);

                    const formatFloatHours = (totalHours) => {
                      const h = Math.floor(totalHours);
                      const m = Math.round((totalHours - h) * 60);
                      return m === 0 ? `${h}h` : `${h}h ${m}m`;
                    };

                    const groupTasks = (entries) => {
                      if (entries.length === 0) return [];
                      const grouped = {};
                      entries.forEach((row) => {
                        if (!row || !row.date) return;
                        const dateObj = new Date(row.date);
                        const dayIndex = getDayIndexFromDate(dateObj);

                        const cId =
                          row.categoryId || row.category_Id || row.Category_Id;
                        const scId =
                          row.subCategoryId ||
                          row.sub_category_Id ||
                          row.Sub_Category_Id;

                        const key = `${row.projectId}-${row.taskId}-${cId}-${scId}`;

                        if (!grouped[key]) {
                          grouped[key] = {
                            projectId: row.projectId,
                            taskId: row.taskId,
                            taskName: row.taskName,
                            category_Id: cId,
                            sub_category_Id: scId,
                            categoryName: row.categoryName || row.CategoryName,
                            subCategoryName:
                              row.subCategoryName || row.SubCategoryName,
                            projectName: row.projectName,
                            hoursPerDay: Array(DAYS_IN_WEEK).fill('0.00'),
                            statusesPerDay: Array(DAYS_IN_WEEK).fill(''),
                          };
                        }
                        const raw = parseFloat(row.hours) || 0;
                        grouped[key].hoursPerDay[dayIndex] = raw;
                        grouped[key].statusesPerDay[dayIndex] =
                          row.status || '';
                      });

                      return Object.values(grouped).map((t) => ({
                        ...t,
                        total: sumDecimalHoursAsFloat(t.hoursPerDay),
                      }));
                    };

                    // GROUP DATA
                    const combinedTasks = groupTasks(activeEntries);

                    const selectable = combinedTasks.filter((t) =>
                      t.statusesPerDay.some((s) => s !== 'Approved'),
                    );

                    const allSelected =
                      selectable.length > 0 &&
                      selectable.every((t) =>
                        selectedTasks.some(
                          (x) =>
                            x.projectId === t.projectId &&
                            x.taskId === t.taskId &&
                            x.category_Id === t.category_Id &&
                            x.sub_category_Id === t.sub_category_Id,
                        ),
                      );

                    const toggle = (task) => {
                      const getIds = (row) => ({
                        cId: row.categoryId || row.category_Id,
                        scId: row.subCategoryId || row.sub_category_Id,
                      });
                      const taskIds = getIds(task);

                      setSelectedTasks((prev) => {
                        const daySelections = prev.filter((p) => p?.date);
                        const taskSelections = prev.filter((p) => !p?.date);
                        const matchesTask = (p) => {
                          const ids = getIds(p);
                          return (
                            p.projectId === task.projectId &&
                            p.taskId === task.taskId &&
                            ids.cId === taskIds.cId &&
                            ids.scId === taskIds.scId
                          );
                        };

                        const hasTask = taskSelections.some(matchesTask);
                        const nextTasks = taskSelections.filter(
                          (p) => !matchesTask(p),
                        );

                        return [
                          ...daySelections,
                          ...(hasTask ? nextTasks : [...nextTasks, task]),
                        ];
                      });
                    };

                    // =================== TABLE UI ===================
                    const selectedDayLabels = Array.from(
                      new Set(
                        selectedDayCells
                          .map((cell) => WEEKDAY_LABELS[cell.dayIndex])
                          .filter(Boolean),
                      ),
                    ).join(', ');
                    const selectedDayDateLabel = selectedDayRows?.[0]?.date
                      ? new Date(selectedDayRows[0].date).toLocaleDateString(
                          DATE_LOCALE,
                          DATE_FORMAT_OPTIONS,
                        )
                      : '';

                    return (
                      <>
                        <div
                          className="timesheet-approval-table-shell"
                          style={{
                            flex: 1,
                            overflowY: 'auto',
                            minHeight: 0,
                            height: '340px',
                            borderRadius: '6px',
                            border: '1px solid #eee',
                          }}
                        >
                          <table className="timesheet-modal-table">
                            <thead
                              style={{
                                position: 'sticky',
                                top: 0,
                                zIndex: 10,
                                backgroundColor: modalTableHeaderBg,
                              }}
                            >
                              <tr>
                                <th
                                  style={{
                                    position: 'sticky',
                                    top: 0,
                                    backgroundColor: modalTableHeaderBg,
                                    zIndex: 10,
                                  }}
                                >
                                  <input
                                    type="checkbox"
                                    checked={allSelected}
                                    onChange={(e) => {
                                      setSelectedDayCells([]);
                                      setSelectedDayRows([]);
                                      setSelectedTasks(
                                        e.target.checked ? selectable : [],
                                      );
                                    }}
                                  />
                                </th>
                                <th
                                  style={{
                                    position: 'sticky',
                                    top: 0,
                                    backgroundColor: modalTableHeaderBg,
                                    zIndex: 10,
                                  }}
                                >
                                  Task
                                </th>
                                {Array.from({ length: DAYS_IN_WEEK }).map((_, i) => (
                                  <th
                                    key={i}
                                    style={{
                                      position: 'sticky',
                                      top: 0,
                                      backgroundColor: modalTableHeaderBg,
                                      zIndex: 10,
                                    }}
                                  >
                                    {weekDays?.[i]?.toLocaleDateString('en-US', {
                                      weekday: 'short',
                                      day: 'numeric',
                                    }) || ''}
                                  </th>
                                ))}
                                <th
                                  style={{
                                    position: 'sticky',
                                    top: 0,
                                    backgroundColor: modalTableHeaderBg,
                                    zIndex: 10,
                                  }}
                                >
                                  Total
                                </th>
                              </tr>
                            </thead>

                            <tbody>
                              {combinedTasks.length > 0 ? (
                                combinedTasks.map((task) => {
                                  const isFullyApproved = task.statusesPerDay.every(
                                    (s) => s === 'Approved',
                                  );
                                  const taskKey = getTaskKey(task);
                                  const isTaskSelected = selectedTasks.some(
                                    (t) =>
                                      t.projectId === task.projectId &&
                                      t.taskId === task.taskId &&
                                      t.category_Id === task.category_Id &&
                                      t.sub_category_Id === task.sub_category_Id,
                                  );
                                  return (
                                    <tr key={taskKey}>
                                      {/* Checkbox */}
                                      <td>
                                        <input
                                          type="checkbox"
                                          checked={isTaskSelected}
                                          disabled={isFullyApproved}
                                          onChange={() =>
                                            !isFullyApproved && toggle(task)
                                          }
                                        />
                                      </td>

                                      {/* Task Name */}
                                      <td>
                                        <Flex align="flex-start" gap="8px">
                                          <Box
                                            width="2px"
                                            height="28px"
                                            bg={task.color}
                                            borderRadius="2px"
                                          />
                                          <div
                                            style={{
                                              display: 'flex',
                                              flexDirection: 'column',
                                              gap: '2px',
                                            }}
                                          >
                                            <span
                                              style={{
                                                fontWeight: '500',
                                                fontSize: '14px',
                                                lineHeight: '1.2',
                                                textAlign: 'left',
                                              }}
                                            >
                                              {task.taskName}
                                            </span>
                                            <span
                                              style={{
                                                fontSize: '9px',
                                                color: '#666',
                                                lineHeight: '1.15',
                                                textAlign: 'left',
                                              }}
                                            >
                                              {task.categoryName}{' '}
                                              {task.subCategoryName
                                                ? ` > ${task.subCategoryName}`
                                                : ''}
                                            </span>
                                          </div>
                                        </Flex>
                                      </td>

                                      {/* Hours */}
                                      {task.hoursPerDay.map((h, i) => {
                                        const dayRows = getDayRowsForTask(task, i);
                                        const isDisabled = dayRows.length === 0;
                                        const isSelectedCell =
                                          selectedDayCells.some(
                                            (cell) =>
                                              cell.key === taskKey &&
                                              cell.dayIndex === i,
                                          ) || isTaskSelected;
                                        return (
                                          <td key={i} style={{ textAlign: 'center' }}>
                                            <div
                                              style={getHourBoxStyle(
                                                task.statusesPerDay[i],
                                                isSelectedCell,
                                                isDisabled,
                                              )}
                                              onClick={() => {
                                                if (isDisabled) return;
                                                const exists = selectedDayCells.some(
                                                  (cell) =>
                                                    cell.key === taskKey &&
                                                    cell.dayIndex === i,
                                                );
                                                const nextCells = exists
                                                  ? selectedDayCells.filter(
                                                      (cell) =>
                                                        !(
                                                          cell.key === taskKey &&
                                                          cell.dayIndex === i
                                                        ),
                                                    )
                                                  : [
                                                      ...selectedDayCells,
                                                      { key: taskKey, dayIndex: i },
                                                    ];
                                                setSelectedDayCells(nextCells);
                                                if (nextCells.length === 0) {
                                                  setSelectedDayRows([]);
                                                  setSelectedTasks((prev) =>
                                                    prev.filter(
                                                      (p) =>
                                                        !p?.date &&
                                                        getTaskKey(p) !== taskKey,
                                                    ),
                                                  );
                                                  return;
                                                }
                                                const rowsForDays = safe.filter(
                                                  (row) => {
                                                    if (!row?.date) return false;
                                                    const rowKey = getTaskKey(row);
                                                    const rowDayIndex =
                                                      getDayIndexFromDate(
                                                        new Date(row.date),
                                                      );
                                                    return nextCells.some(
                                                      (cell) =>
                                                        cell.key === rowKey &&
                                                        cell.dayIndex ===
                                                          rowDayIndex,
                                                    );
                                                  },
                                                );
                                                setSelectedDayRows(rowsForDays);
                                                setSelectedTasks((prev) => {
                                                  const taskSelections = prev.filter(
                                                    (p) =>
                                                      !p?.date &&
                                                      getTaskKey(p) !== taskKey,
                                                  );
                                                  return [
                                                    ...taskSelections,
                                                    ...rowsForDays,
                                                  ];
                                                });
                                              }}
                                            >
                                              {(typeof h === 'number' ||
                                                (typeof h === 'string' && h !== ''))
                                                ? (parseFloat(h) || 0).toFixed(2)
                                                : '0.00'}
                                            </div>
                                          </td>
                                        );
                                      })}

                                      <td>
                                        {formatTotalHoursAndMinutes(
                                          task.hoursPerDay,
                                        )}
                                      </td>
                                    </tr>
                                  );
                                })
                              ) : (
                                <tr>
                                  <td colSpan={10} style={{ textAlign: 'center', padding: '20px' }}>
                                    No active tasks found.
                                  </td>
                                </tr>
                              )}
                            </tbody>

                            <tfoot>
                              <tr>
                                <td
                                  style={{
                                    position: 'sticky',
                                    bottom: 0,
                                    backgroundColor: modalTableHeaderBg,
                                    zIndex: 10,
                                  }}
                                ></td>
                                <td
                                  style={{
                                    position: 'sticky',
                                    bottom: 0,
                                    backgroundColor: modalTableHeaderBg,
                                    zIndex: 10,
                                    fontWeight: 'bold',
                                  }}
                                >
                                  Total
                                </td>

                                {Array.from({ length: DAYS_IN_WEEK }, (_, i) => {
                                  const totalDay = combinedTasks.map(
                                    (t) => t.hoursPerDay?.[i] || 0,
                                  );
                                  return (
                                    <td
                                      key={i}
                                      style={{
                                        position: 'sticky',
                                        bottom: 0,
                                        backgroundColor: modalTableHeaderBg,
                                        zIndex: 10,
                                        fontWeight: 'bold',
                                      }}
                                    >
                                      {formatTotalHoursAndMinutes(totalDay)}
                                    </td>
                                  );
                                })}

                                <td
                                  style={{
                                    position: 'sticky',
                                    bottom: 0,
                                    backgroundColor: modalTableHeaderBg,
                                    zIndex: 10,
                                    fontWeight: 'bold',
                                  }}
                                >
                                  {formatTotalHoursAndMinutes(
                                    combinedTasks.flatMap(
                                      (t) => t.hoursPerDay || [],
                                    ),
                                  )}
                                </td>
                              </tr>
                            </tfoot>
                          </table>
                        </div>

                        {/* Status Legend */}
                        <Box
                          mt={3}
                          display="flex"
                          alignItems="center"
                          justifyContent="flex-end"
                          gap={4}
                          flexWrap="wrap"
                        >
                          {[
                            { label: 'Pending', color: '#FACC15', text: '#854D0E' },
                            { label: 'Approved', color: '#16A34A', text: '#166534' },
                            { label: 'Declined', color: '#DC2626', text: '#991B1B' },
                          ].map((s) => (
                            <Box
                              key={s.label}
                              display="inline-flex"
                              alignItems="center"
                              gap={2}
                              fontSize="12px"
                              color="gray.700"
                            >
                              <Box
                                w="10px"
                                h="10px"
                                borderRadius="50%"
                                bg={s.color}
                              />
                              <span>{s.label}</span>
                            </Box>
                          ))}
                        </Box>

                      </>
                    );
                  })()}

                  {/* NOTES */}
                  <Box mt={6}>
                    <Text fontWeight="semibold" mb={2}>
                      Notes <span style={{ color: 'red' }}>*</span> (Mandatory
                      for Decline)
                    </Text>

                    <FormControl isInvalid={!!notesError[selectedTimesheetId]}>
                      <Textarea
                        className="timesheet-approval-notes"
                        placeholder="Add comments..."
                        maxLength={150}
                        bg="white"
                        borderColor="blue.400"
                        _hover={{
                          borderColor: 'gray.400',
                        }}
                        _focus={{
                          borderColor: notesError[selectedTimesheetId]
                            ? 'red.500'
                            : 'blue.400',
                          boxShadow: 'none',
                        }}
                        value={notesByEmployee[selectedTimesheetId] || ''}
                        onChange={(e) => {
                          const value = e.target.value;

                          // Update notes
                          setNotesByEmployee((prev) => ({
                            ...prev,
                            [selectedTimesheetId]: value,
                          }));

                          // Clear validation once user types
                          if (value.trim() !== '') {
                            setNotesError((prev) => ({
                              ...prev,
                              [selectedTimesheetId]: '',
                            }));
                          }
                        }}
                      />
                      {/* Error message shown below the field */}
                      <FormErrorMessage fontSize="sm">
                        {notesError[selectedTimesheetId]}
                      </FormErrorMessage>
                    </FormControl>
                  </Box>
                </ModalBody>

                <ModalFooter>
                  <Button className="timesheet-approval-close-btn" variant="outline" onClick={handleApproveClose}>
                    Close
                  </Button>
                </ModalFooter>
              </ModalContent>
            </Modal>
          </TabPanel>
        </TabPanels>
      </Tabs>
    </Box>
  );
};
export default Timesheet;