import React, { useEffect, useMemo, useState, useRef } from 'react';
import { Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend,
} from 'chart.js';
import { fetchProjectAnalytics } from 'utils/api';
import './ProjectAnalyticReport.css';
import { TbDeviceDesktopAnalytics } from "react-icons/tb";
import ReactSelect from 'react-select';
import { components as selectComponents } from 'react-select';
import { MdBusiness, MdCheck, MdFolderOpen } from 'react-icons/md';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend
);

const projectSelectStyles = {
  control: (base, state) => ({
    ...base,
    minHeight: 50,
    borderRadius: 12,
    borderColor: state.isFocused ? '#3b82f6' : '#d9e2ec',
    boxShadow: state.isFocused
      ? '0 0 0 4px rgba(59, 130, 246, 0.12)'
      : '0 2px 8px rgba(15, 23, 42, 0.04)',
    '&:hover': { borderColor: '#3b82f6' },
    backgroundColor: '#ffffff',
  }),
  valueContainer: (base) => ({
    ...base,
    padding: '0 14px',
    gap: 8,
  }),
  input: (base) => ({
    ...base,
    margin: 0,
    padding: 0,
  }),
  singleValue: (base) => ({
    ...base,
    margin: 0,
    color: '#0f172a',
    fontWeight: 600,
    fontSize: 16,
  }),
  placeholder: (base) => ({
    ...base,
    margin: 0,
    color: '#64748b',
    fontSize: 15,
  }),
  dropdownIndicator: (base, state) => ({
    ...base,
    color: state.isFocused ? '#3b82f6' : '#94a3b8',
    padding: 8,
  }),
  menu: (base) => ({
    ...base,
    borderRadius: 14,
    overflow: 'hidden',
    border: '1px solid #e2e8f0',
    boxShadow: '0 18px 32px rgba(15, 23, 42, 0.14)',
  }),
  menuList: (base) => ({
    ...base,
    padding: 10,
    background: 'linear-gradient(180deg, #ffffff 0%, #f8fbff 100%)',
  }),
  group: (base) => ({
    ...base,
    marginBottom: 8,
    paddingBottom: 6,
    borderBottom: '1px solid #e2e8f0',
  }),
  groupHeading: (base) => ({
    ...base,
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    color: '#5f7e9d',
    fontSize: 12,
    fontWeight: 700,
    textTransform: 'uppercase',
    padding: '6px 8px',
    marginBottom: 4,
    letterSpacing: '0.4px',
  }),
  option: (base, state) => ({
    ...base,
    borderRadius: 10,
    padding: '12px 12px',
    marginBottom: 6,
    borderLeft: state.isSelected ? '3px solid #3b82f6' : '3px solid transparent',
    backgroundColor: state.isSelected
      ? '#e8f1ff'
      : state.isFocused
        ? '#f1f5f9'
        : '#ffffff',
    color: '#1e293b',
    cursor: 'pointer',
  }),
};

const ProjectOption = (props) => {
  const { data, isSelected } = props;
  const optionLabel = data.displayLabel || data.label;
  return (
    <selectComponents.Option {...props}>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 10,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <MdFolderOpen color={isSelected ? '#1d4ed8' : '#64748b'} size={18} />
          <span style={{ fontWeight: isSelected ? 700 : 500 }}>{optionLabel}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span
            style={{
              color: '#5f7e9d',
              fontWeight: 500,
            }}
          >
            {optionLabel}
          </span>
          {isSelected && <MdCheck color="#2563eb" size={20} />}
        </div>
      </div>
    </selectComponents.Option>
  );
};

const ProjectGroupHeading = (props) => (
  <selectComponents.GroupHeading {...props}>
    <MdBusiness size={16} />
    <span>{props.children}</span>
  </selectComponents.GroupHeading>
);

const ProjectSingleValue = (props) => (
  <selectComponents.SingleValue {...props}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <MdBusiness color="#64748b" size={18} />
      <span>{props.data.label}</span>
    </div>
  </selectComponents.SingleValue>
);

const ProjectMenu = (props) => {
  const { onMenuMouseLeave } = props.selectProps;
  const mergedInnerProps = {
    ...(props.innerProps || {}),
    onMouseLeave: (event) => {
      props.innerProps?.onMouseLeave?.(event);
      onMenuMouseLeave?.();
    },
  };

  return <selectComponents.Menu {...props} innerProps={mergedInnerProps} />;
};

export default function ProjectAnalyticReport({
  projectId,
  projectName,
  projects = [],
  isProjectListLoading = false,
  onBack,
}) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedProjectOption, setSelectedProjectOption] = useState(null);
  const [isProjectMenuOpen, setIsProjectMenuOpen] = useState(false);
  const [hoveredResource, setHoveredResource] = useState(null);
  const [tooltipPosition, setTooltipPosition] = useState({
    left: 0,
    top: 0,
    placement: 'top',
  });

  const RESOURCE_COLORS = [
    '#5fa1f2ff', // blue
    '#34D399', // green
    '#FBBF24', // yellow
    '#F87171', // red
    '#A78BFA', // purple
    '#FB7185', // pink
    '#22D3EE', // cyan
    '#F97316', // orange
    '#84CC16', // lime
    '#0EA5E9', // sky
  ];

  /* =========================
     Fetch API
  ========================= */
  const projectOptions = useMemo(
    () =>
      (projects || []).map((p) => ({
        value: p.projectId,
        label: p.projectName,
      })),
    [projects],
  );

  const groupedProjectOptions = useMemo(() => {
    const groups = {};
    projectOptions.forEach((option) => {
      const name = option.label || '';
      const parts = name
        .split('/')
        .map((part) => part.trim())
        .filter(Boolean);
      const groupLabel = parts.length > 1 ? parts[0].toUpperCase() : 'PROJECTS';
      const displayLabel = parts.length > 1 ? parts.slice(1).join(' / ') : name;

      if (!groups[groupLabel]) {
        groups[groupLabel] = [];
      }

      groups[groupLabel].push({
        ...option,
        displayLabel,
      });
    });

    return Object.entries(groups).map(([label, options]) => ({
      label,
      options,
    }));
  }, [projectOptions]);

  useEffect(() => {
    if (projectId && projectName) {
      setSelectedProjectOption({ value: projectId, label: projectName });
    }
  }, [projectId, projectName]);

  useEffect(() => {
    if (!selectedProjectOption && projectOptions.length > 0) {
      setSelectedProjectOption(projectOptions[0]);
    }
  }, [projectOptions, selectedProjectOption]);

  useEffect(() => {
    const hideTooltip = () => setHoveredResource(null);

    window.addEventListener('scroll', hideTooltip, true);
    window.addEventListener('resize', hideTooltip);

    return () => {
      window.removeEventListener('scroll', hideTooltip, true);
      window.removeEventListener('resize', hideTooltip);
    };
  }, []);

  useEffect(() => {
    const id = selectedProjectOption?.value;
    if (!id) {
      setData(null);
      setLoading(isProjectListLoading);
      return;
    }

    setLoading(true);
    fetchProjectAnalytics(id)
      .then((res) => {
        setData(res);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [selectedProjectOption]);

  /* =========================
     Derived Data (SAFE)
  ========================= */
  

  const tasks = useMemo(() => data?.tasks ?? [], [data]);
const employees = useMemo(() => data?.employees ?? [], [data]);

// Filter active and idle employees
const activeEmployees = useMemo(
  () => employees.filter(e => !e.isIdle),
  [employees]
);

const idleEmployees = useMemo(
  () => employees.filter(e => e.isIdle),
  [employees]
);

// Employee color mapping
const employeeColorMap = {};
activeEmployees.forEach((emp, index) => {
  employeeColorMap[emp.empCode] =
    RESOURCE_COLORS[index % RESOURCE_COLORS.length];
});

// PRODUCTIVITY - Only completed tasks
// const avgProductivity = useMemo(() => {
//   let totalActual = 0;
//   let totalEstimated = 0;

//   tasks.forEach(task => {
//     if (task.taskStatusName === 'Completed') {
//       const estimatedHours = task.estimatedHours || 0;
      
//       task.resources?.forEach(r => {
//         const actualHours = r.actualHours || 0;
//         if (estimatedHours > 0 && actualHours > 0) {
//           totalEstimated += estimatedHours;
//           totalActual += actualHours;
//         }
//       });
//     }
//   });

//   if (!totalActual || totalActual === 0) return 0;
//   return ((totalEstimated / totalActual) * 100).toFixed(1);
// }, [tasks]);

const avgProductivity = useMemo(() => {
  let totalActual = 0;
  let totalEstimated = 0;

  tasks.forEach(task => {
    const estimatedHours = task.estimatedHours || 0;
    
    // Calculate total actual hours for THIS TASK across all resources
    const taskActualTotal = task.resources?.reduce((sum, r) => {
      return sum + (r.actualHours || 0);
    }, 0) || 0;
    
    // Only count COMPLETED tasks with both estimated and actual hours > 0
    if (estimatedHours > 0 && 
        taskActualTotal > 0 && 
        task.taskStatusName === 'Completed') {
      totalEstimated += estimatedHours;  // Count task estimate ONCE (task-based)
      totalActual += taskActualTotal;     // Sum all resource hours for this task
    }
  });

  // Check denominator (what we're dividing by)
  if (!totalActual || totalActual === 0) return 0;

  // Productivity = (Estimated / Actual) × 100
  return ((totalEstimated / totalActual) * 100).toFixed(1);
}, [tasks]);

// BURN RATE - All tasks with hours
// const burnRate = useMemo(() => {
//   let totalActual = 0;
//   let totalEstimated = 0;

//   tasks.forEach(task => {
//     const estimatedHours = task.estimatedHours || 0;
    
//     task.resources?.forEach(r => {
//       const actualHours = r.actualHours || 0;
//       if (estimatedHours > 0 && actualHours > 0) {
//         totalEstimated += estimatedHours;
//         totalActual += actualHours;
//       }
//     });
//   });

//   if (!totalEstimated || totalEstimated === 0) return 0;
//   return totalActual / totalEstimated;
// }, [tasks]);

const burnRate = useMemo(() => {
  let totalActual = 0;
  let totalEstimated = 0;

  tasks.forEach(task => {
    const estimatedHours = task.estimatedHours || 0;
    
    // Calculate total actual hours for THIS TASK across all resources
    const taskActualTotal = task.resources?.reduce((sum, r) => {
      return sum + (r.actualHours || 0);
    }, 0) || 0;
    
    // Count ALL tasks (any status) with both estimated and actual hours > 0
    if (estimatedHours > 0 && taskActualTotal > 0) {
      totalEstimated += estimatedHours;  // Count task estimate ONCE (task-based)
      totalActual += taskActualTotal;     // Sum all resource hours for this task
    }
  });

  // Check denominator
  if (!totalEstimated || totalEstimated === 0) return 0;

  // Burn Rate = Actual / Estimated
  return totalActual / totalEstimated;
}, [tasks]);

// Pastel colors for employee identification
const pastelColors = [
  '#DBEAFE', '#DCFCE7', '#FEF3C7', '#EDE9FE',
  '#FFE4E6', '#ECFEFF', '#F0FDF4', '#FFF7ED'
];

const getEmployeeColor = (empCode) => {
  const index = Math.abs(empCode.toString().split('')
    .reduce((a, b) => a + b.charCodeAt(0), 0));

  return pastelColors[index % pastelColors.length];
};

// Burn rate status indicators
const getBurnRateStatus = (burnRate) => {
  if (burnRate <= 1.05) {
    return { label: 'On Track', type: 'success' };   // Within 5%
  }
  if (burnRate <= 1.25) {
    return { label: 'Over Budget', type: 'warning' }; // 5-25% over
  }
  return { label: 'High Risk', type: 'danger' };     // >25% over
};

const burnStatus = useMemo(() => getBurnRateStatus(burnRate), [burnRate]);

  /* =========================
     Bar Chart (Task × Resource)
  ========================= */
  const barChartData = {
    labels: tasks.map(t => t.taskName),
    datasets: [
      {
        label: 'Estimation',
        data: tasks.map(t => t.estimatedHours || 0),
        backgroundColor: '#b4b7b8ff',
        borderRadius: 4,
        barPercentage: 0.6,
        categoryPercentage: 0.6,
        stack: 'estimated',
      },
      {
        label: 'Overhead',
        data: tasks.map(t => Math.max(0, (t.actualHours || 0) - (t.estimatedHours || 0))),
        backgroundColor: '#ef4444',
        borderRadius: 4,
        barPercentage: 0.6,
        categoryPercentage: 0.6,
        stack: 'estimated',
      },
      ...activeEmployees.map(emp => ({
        label: emp.employeeName,
        data: tasks.map(task => {
          const res = task.resources.find(r => r.empCode === emp.empCode);
          return res ? res.actualHours : 0;
        }),
        backgroundColor: employeeColorMap[emp.empCode],
        borderRadius: 4,
        barPercentage: 0.6,
        categoryPercentage: 0.6,
        stack: 'actual',
      }))
    ],
  };


  const MAX_LABEL_LENGTH = 10;

  const barChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
    },
    scales: {
      x: {
        stacked: true,
        title: {
          display: true,
          text: 'Tasks',
          padding: { top: 15 },
          font: {
            weight: 'bold'
          }
        },
        ticks: {
          callback: function (value) {
            const label = this.getLabelForValue(value);
            return label.length > MAX_LABEL_LENGTH
              ? label.substring(0, MAX_LABEL_LENGTH) + '...'
              : label;
          },
        },
        grid: { display: false },
      },
      y: {
        stacked: true,
        title: {
          display: true,
          text: 'Estimation hours/Actual Hours',
          font: {
            weight: 'bold'
          }
        },
        grid: {
          drawBorder: false,
          color: '#E5E7EB',
        },
      },
    },
  };




  /* =========================
     Donut Charts
  ========================= */
  const activeResources = employees.filter(e => !e.isIdle).length;
  const idleResources = employees.filter(e => e.isIdle).length;

  const statusCounts = {
    'To Do': 0,
    'In Progress': 0,
    'Completed': 0,
    'Hold': 0
  };

  tasks.forEach(t => {
    const s = (t.taskStatusName || '').toLowerCase();
    if (s.includes('progress')) statusCounts['In Progress']++;
    else if (s.includes('completed')) statusCounts['Completed']++;
    else if (s.includes('hold')) statusCounts['Hold']++;
    else statusCounts['To Do']++;
  });

  const resourceDonutData = {
    labels: ['Active', 'Idle'],
    datasets: [{
      data: [activeResources, idleResources],
      backgroundColor: ['#34D399', '#F87171'],
      borderWidth: 0
    }]
  };

  const taskDonutData = {
    labels: ['To Do', 'In Progress', 'Completed', 'Hold'],
    datasets: [{
      data: [
        statusCounts['To Do'],
        statusCounts['In Progress'],
        statusCounts['Completed'],
        statusCounts['Hold']
      ],
      backgroundColor: ['#f0f189ff', '#60A5FA', '#34D399', '#F87171'],
      borderWidth: 0
    }]
  };

  const donutOptions = {
    cutout: '72%',
    plugins: {
      legend: { display: false },
      tooltip: { enabled: false }
    },
    maintainAspectRatio: false
  };



  /* =========================
     Skeleton Loader
  ========================= */
  if (loading) {
    return (
      <div className="analytics-container">
        <div className="skeleton header" />
        <div className="skeleton kpis" />
        <div className="skeleton charts" />
        <div className="skeleton table" />
      </div>
    );
  }

  const isEmpty = !data || (tasks.length === 0 && employees.length === 0);

  // KPI card helper function
  const KpiCard = ({ title, value, icon, badge, badgeType, list, listType }) => {
    const [showList, setShowList] = useState(false);
    const wrapperRef = useRef(null);

     useEffect(() => {
    const handleClickOutside = (event) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setShowList(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
    return (
      <div className="kpi-card">
        <div className="kpi-header">
          <span className="kpi-title">{title}</span>
          <div ref={wrapperRef} style={{ position: 'relative' }}>
            <div
              className={`kpi-icon ${badgeType}`}
              style={{ cursor: list ? 'pointer' : 'default' }}
              onClick={() => list && setShowList(!showList)}
            >
              {icon}
            </div>

            {showList && list && list.length > 0 && (
              <div className="kpi-list-wrapper">
                {list.map((item, i) => {
                  const isObject = typeof item === 'object' && item !== null;
                  const label = isObject ? item.label : item;
                  const type = isObject ? item.type : listType;
                  return (
                    <span key={i} className={`kpi-tag ${type}`}>
                      {label}
                    </span>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        <div className="kpi-value">{value}</div>

        {badge && (
          <div className={`kpi-badge ${badgeType}`}>
            {badge}
          </div>
        )}
      </div>
    );
  };
  const completionPercent = tasks.length
    ? ((statusCounts['Completed'] / tasks.length) * 100).toFixed(0)
    : 0;

  const showResourceTooltip = (resource, event) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const tooltipWidth = 220;
    const tooltipHeight = 104;
    const viewportPadding = 16;
    const centeredLeft = rect.left + rect.width / 2;
    const clampedLeft = Math.min(
      Math.max(centeredLeft, tooltipWidth / 2 + viewportPadding),
      window.innerWidth - tooltipWidth / 2 - viewportPadding,
    );
    const canShowAbove = rect.top > tooltipHeight + viewportPadding;

    setTooltipPosition({
      left: clampedLeft,
      top: canShowAbove ? rect.top : rect.bottom,
      placement: canShowAbove ? 'top' : 'bottom',
    });
    setHoveredResource(resource);
  };

  const hideResourceTooltip = () => {
    setHoveredResource(null);
  };
  const taskStatusList = [
    { label: `To Do (${statusCounts['To Do']})`, type: 'todo' },
    { label: `In Progress (${statusCounts['In Progress']})`, type: 'progress' },
    { label: `Completed (${statusCounts['Completed']})`, type: 'success' },
    { label: `Hold (${statusCounts['Hold']})`, type: 'danger' },
  ];

  /* =========================
     Render
  ========================= */
  return (
    <div className="analytics-container">
            {/* Header */}
      <div className="analytics-header">
        <div className="header-left">
          <div>
            <h2>Project Analytics</h2>
            <span className="subtitle">Performance Review</span>
          </div>
        </div>
        <div className="analytics-header-actions">
          <div className="analytics-project-select">
            <label
              style={{
                display: 'block',
                fontSize: '12px',
                color: '#6b7280',
                marginBottom: '6px',
                textAlign: 'left',
              }}
            >
              Select Project
            </label>
            <ReactSelect
              value={selectedProjectOption}
              onChange={(value) => {
                setSelectedProjectOption(value || null);
                setIsProjectMenuOpen(false);
              }}
              options={groupedProjectOptions}
              placeholder="Select a project"
              styles={projectSelectStyles}
              menuIsOpen={isProjectMenuOpen}
              onMenuOpen={() => setIsProjectMenuOpen(true)}
              onMenuClose={() => setIsProjectMenuOpen(false)}
              onBlur={() => setIsProjectMenuOpen(false)}
              onMenuMouseLeave={() => setIsProjectMenuOpen(false)}
              components={{
                Option: ProjectOption,
                Menu: ProjectMenu,
                SingleValue: ProjectSingleValue,
                GroupHeading: ProjectGroupHeading,
                IndicatorSeparator: () => null,
              }}
              menuPlacement="auto"
              menuPortalTarget={document.body}
              menuPosition="fixed"
            />
          </div>
          {onBack && (
            <button className="back-btn" onClick={onBack}>
              Back
            </button>
          )}
        </div>
      </div>

      {isEmpty ? (
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          height: '500px',
          background: '#ffffff',
          borderRadius: '16px',
          boxShadow: '0 10px 30px rgba(0,0,0,0.04)',
          color: '#6b7280'
        }}>
          <TbDeviceDesktopAnalytics size={64} style={{ marginBottom: '20px', color: '#e5e7eb' }} />
          <h3 style={{ margin: '0 0 8px 0', fontSize: '18px', fontWeight: 600, color: '#374151' }}>
            There is nothing to show
          </h3>
          <p style={{ margin: 0, fontSize: '14px' }}>Please assign resources and tasks.</p>
        </div>
      ) : (
        <>
          {/* KPI Cards */}{' '}
          <div className="kpi-grid">
           <KpiCard
              title="Total Tasks"
              value={tasks.length}
              icon={<i className="fas fa-tasks" />}
              badge={`${completionPercent}% Completed`}
              badgeType="info"   // Blue progress badge
              list={taskStatusList}
              listType="task"
            />
            <KpiCard
              title="Avg. Productivity"
              value={`${avgProductivity}%`}
              icon={<i className="fas fa-chart-line" />}
              badge={`Burn Rate: ${burnRate.toFixed(2)}x · ${burnStatus.label}`}
              badgeType={burnStatus.type}
              list={[
                { label: '≤ 1.05: On Track', type: 'success' },
                { label: '≤ 1.25: Over Budget', type: 'warning' },
                { label: '> 1.25: High Risk', type: 'danger' }
              ]}
              listType="burn"
            />
            <KpiCard
              title="Active Resources"
              value={activeEmployees.length}
              icon={<i className="fas fa-users" />}
              badge={`On ${data.tasks.length} active tasks`}
              badgeType="success"
              list={activeEmployees.map(e => e.employeeName)}
              listType="active"
            />
            <KpiCard
              title="Idle Resources"
              value={idleEmployees.length}
              icon={<i className="fas fa-user-slash" />}
              badge="Needs allocation"
              badgeType="danger"
              list={idleEmployees.map(e => e.employeeName)}
              listType="idle"
            />
          </div>


          {/* Charts */}
          <div className="charts-grid">
            <div className="chart-card">
              <div className='chart-header'>
                <h3>Task × Resource Workload</h3>
                <div className="avatar-legend right overlap">

                  {activeEmployees.map(emp => {
                    const initials = emp.employeeName
                      .split(' ')
                      .map(n => n[0])
                      .join('')
                      .toUpperCase();

                    return (
                      <div
                        key={emp.empCode}
                        className="legend-avatar"
                        style={{
                          backgroundColor: employeeColorMap[emp.empCode],
                          opacity: 0.85
                        }}
                        title={emp.employeeName}
                      >
                        {initials}
                      </div>
                    );
                  })}
                </div>
              </div>
              <div className="chart-body">
                <Bar data={barChartData} options={barChartOptions} />
              </div>
              <div className="bar-chart-legend">
                <div className="legend-right">
                  <div className="legend-item">
                    <span className="dot estimation"></span> Estimation
                  </div>
                  <div className="legend-item">
                    <span className="dot overhead"></span> Overhead
                  </div>
                </div>
              </div>
            </div>
            {/* Productivity Insights */}
            <div className="productivity-card">
              <h3 className="card-title">Productivity Insights</h3>

              {/* Resource Donut */}
              <div className="donut-row">
                <div className="donut-wrapper">
                  <Doughnut
                    data={resourceDonutData}
                    options={donutOptions}
                  />
                  <div className="donut-center">
                    <div className="donut-value">{activeResources + idleResources}</div>
                    <div className="donut-label">RESOURCES</div>
                  </div>
                </div>

                <div className="donut-legend">
                  <div className="legend-item">
                    <span className="dot green"></span> Active ({activeResources})
                  </div>
                  <div className="legend-item">
                    <span className="dot red"></span> Idle ({idleResources})
                  </div>
                </div>
              </div>

              {/* Task Donut */}
              <div className="donut-row">
                <div className="donut-wrapper">
                  <Doughnut
                    data={taskDonutData}
                    options={donutOptions}
                  />
                  <div className="donut-center">
                    <div className="donut-value">{tasks.length}</div>
                    <div className="donut-label">TASKS</div>
                  </div>
                </div>

                <div className="donut-legend">
                  <div className="legend-item">
                    <span className="dot yellow"></span> To Do ({statusCounts['To Do']})
                  </div>
                  <div className="legend-item">
                    <span className="dot blue"></span> In Progress ({statusCounts['In Progress']})
                  </div>
                  <div className="legend-item">
                    <span className="dot green"></span> Completed ({statusCounts['Completed']})
                  </div>
                  <div className="legend-item">
                    <span className="dot red"></span> Hold ({statusCounts['Hold']})
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Table */}

          <div className="table-card">
            <div className='card-title'>
              <h3>Task Overview</h3>
            </div>
            <table>
              <thead>
                <tr>
                  <th>Task</th>
                  <th>Resources</th>
                  <th>Est. Hours</th>
                  <th>Actual Hours</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                {tasks.map(task => (
                  <tr key={task.taskID}>
                    <td className="task-cell">
                      <strong>{task.taskName}</strong>
                    </td>

                    <td>
                      <div className="avatars overlap">
                        {task.resources.map(r => {
                          const initials = r.employeeName
                            .split(' ')
                            .map(s => s[0])
                            .join('')
                            .toUpperCase();

                          return (
                            <div
                              key={r.empCode}
                              className="avatar"
                              style={{
                                backgroundColor: getEmployeeColor(r.empCode)
                              }}
                              onMouseEnter={(event) => showResourceTooltip(r, event)}
                              onMouseLeave={hideResourceTooltip}
                            >
                              {initials}
                            </div>
                          );
                        })}
                      </div>
                    </td>

                    <td>{task.estimatedHours}h</td>

                    <td>
                      <strong>{task.actualHours.toFixed(1)}h</strong>
                    </td>

                    <td>
                      <span
                        className={`status-badge ${task.taskStatusName
                          .toLowerCase()
                          .replace(' ', '-')}`}
                      >
                        {task.taskStatusName}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {hoveredResource && (
            <div
              className={`resource-tooltip ${tooltipPosition.placement === 'bottom' ? 'is-below' : ''}`}
              style={{
                left: `${tooltipPosition.left}px`,
                top: `${tooltipPosition.top}px`,
              }}
            >
              <strong>{hoveredResource.employeeName}</strong>
              <div>Hours: {hoveredResource.actualHours}</div>
              <div>
                Productivity: {Number(hoveredResource.productivityPercent || 0).toFixed(1)}%
              </div>
            </div>
          )}

        </>
      )}
    </div>
  );
}

