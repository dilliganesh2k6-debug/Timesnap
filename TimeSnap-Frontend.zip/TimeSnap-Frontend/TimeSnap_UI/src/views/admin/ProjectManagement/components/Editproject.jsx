﻿import React, {
  useState,
  useMemo,
  useCallback,
  useEffect,
  useRef,
} from 'react';
import { useParams } from 'react-router-dom';
import {
  // Import API functions
  fetchEditProjectDatas,
  addAssignTasks,
  addBulkAssignTasks,
  fetchTeamNamesByProject,
  updateProjectTask,
  deleteTaskByIndexId,
  // getTeamMembersByTeamId,
  removeMemberByProjectIdandEmpcode,
  getProjectMembersByProjectId,
  removeTeamMembers,
  createTeamMember,
  getUserDetails,
  getTaskCategories,
  getTasksByCategory,
} from 'utils/api';
import { clearGridFocus } from 'utils/gridUtils';
import './Editproject.css';
import { statusColorScheme } from 'utils/constants';
import Dropdown from 'components/Dropdown/Dropdown';
import { MAX_EMPLOYEE_NAME_LENGTH } from 'utils/constants';
import 'react-toastify/dist/ReactToastify.css';
import { useCustomToast } from 'utils/toastUtils';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import CustomButton from 'components/button/CustomButton';
import CustomIconButton from 'components/button/CustomIconButton';
import CustomModal from 'components/modal/CustomModal';
import {
  Box,
  Button,
  Flex,
  Select,
  Heading,
  Icon,
  IconButton,
  Input,
  Center,
  Text,
  useColorModeValue,
  Tag,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
  VStack,
  FormControl,
  FormLabel,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  useDisclosure,
  Textarea,
  useToast,
  HStack,
  FormErrorMessage,
  Switch,
  AlertDialog,
  AlertDialogOverlay,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogBody,
  AlertDialogFooter,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Checkbox,
  Avatar,
  Modal,
  Progress,
} from '@chakra-ui/react';
import {
  validateAlphanumericInput,
  projectValidateAlphanumeric,
} from 'utils/constants';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { fetchProfileInfo, fetchUserProfilePicture } from 'utils/api';
import * as XLSX from 'xlsx';
import { FiEdit2, FiTrash2, FiUploadCloud, FiDownload, FiX } from 'react-icons/fi';
import TimeSnapLoader from '../../../../components/loaders/TimeSnapLoader';

const EditprojectGrid = ({
  team,
  projectId,
  teamName,
  isActive,
  managerId,
  clientName,
  projectManagers,
  projectName,
  projectStatus,
  onBack,
}) => {
  const pageBg = useColorModeValue('white', '#0f172a');
  const inputBg = useColorModeValue('white', 'whiteAlpha.100');

  const toast = useToast();
  const showToast = useCustomToast();
  const { projectid } = useParams(); // Get project ID from URL
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [teamMembers, setTeamMembers] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [tabIndex, setTabIndex] = useState(0);
  const [isTaskLoading, setIsTaskLoading] = useState(false);
  const taskModalBg = useColorModeValue('white', '#0f172a');
  const taskModalSurface = useColorModeValue('gray.50', '#111827');
  const taskModalBorder = useColorModeValue('gray.200', 'whiteAlpha.200');
  const taskModalMuted = useColorModeValue('gray.500', 'gray.400');
  const taskModalInputBg = useColorModeValue('white', 'whiteAlpha.100');
  const taskModalInputBorder = useColorModeValue('gray.300', 'whiteAlpha.300');
  const taskActionIconColor = useColorModeValue('gray.700', 'whiteAlpha.900');
  const sidebarBg = useColorModeValue('gray.50', 'whiteAlpha.50');
  const scrollbarThumbBg = useColorModeValue('gray.200', 'gray.600');
  const tableHeaderBg = useColorModeValue('gray.50', 'whiteAlpha.100');

  const [categories, setCategories] = useState([]);
  const [subTasks, setSubTasks] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedSubTask, setSelectedSubTask] = useState('');

  useEffect(() => {
    const fetchCategories = async () => {
      const data = await getTaskCategories();
      setCategories(data);
    };
    console.log('Fetching categories');
    fetchCategories();
  }, []);

  const [teamData, setTeamData] = useState({
    projectId: '',
    teamId: '',
    teamName: '',
    managerId: '',
    managerName: '',
    clientName: '',
    projectManagerName: '',
    projectName: '',
    projectStatus: '',
    empCode: '',
    userName: '',
    members: [],
  });
  const {
    isOpen: isBulkOpen,
    onOpen: onBulkOpen,
    onClose: onBulkClose,
  } = useDisclosure();
  const [bulkTasks, setBulkTasks] = useState([]);
  const [showBulkSaveConfirm, setShowBulkSaveConfirm] = useState(false);
  const [showBulkCancelConfirm, setShowBulkCancelConfirm] = useState(false);
  const [isBulkDirty, setIsBulkDirty] = useState(false);

  useEffect(() => {
    if (isBulkOpen && bulkTasks.length === 0) {
      setBulkTasks([
        {
          id: Date.now(),
          category_Id: '',
          sub_category_Id: '',
          task_Name: '',
          task_Desc: '',
          estimated_hours: '',
          isBillable: false,
          subTasksList: [],
        },
      ]);
    }
  }, [isBulkOpen, bulkTasks.length]);

  const handleBulkUpdate = () => {
    onBulkOpen();
    setIsBulkDirty(false);
  };

  const handleAddBulkRow = () => {
    setBulkTasks((prev) => [
      ...prev,
      {
        id: Date.now(),
        category_Id: '',
        sub_category_Id: '',
        task_Name: '',
        task_Desc: '',
        estimated_hours: '',
        isBillable: false,
        subTasksList: [],
      },
    ]);
    setIsBulkDirty(true);
  };

  const handleDeleteBulkRow = (id) => {
    setBulkTasks((prev) => prev.filter((task) => task.id !== id));
    setIsBulkDirty(true);
  };
  // const [isReadOnly, setIsReadOnly] = useState(false);
  // useEffect(() => {
  //   const accessDetailsString = localStorage.getItem('accessDetails');

  //   let readOnlyFromAccess = false;

  //   if (accessDetailsString) {
  //     try {
  //       const accessDetails = JSON.parse(accessDetailsString);

  //       const screenAccess = accessDetails.find(
  //         (screen) => screen.screenname === 'Project',
  //       );

  //       if (screenAccess) {
  //         readOnlyFromAccess = screenAccess.readOnly === 1;
  //       }
  //     } catch (error) {
  //       console.error('Invalid accessDetails format in localStorage');
  //     }
  //   }

  //   setIsReadOnly(readOnlyFromAccess || !isActive);
  // }, [isActive]);
  const [isReadOnly, setIsReadOnly] = useState(false);

  useEffect(() => {
    const accessDetailsString = localStorage.getItem('accessDetails');
    if (accessDetailsString) {
      try {
        const accessDetails = JSON.parse(accessDetailsString);
        const screenAccess = accessDetails.find(
          (screen) => screen.screenId === 103,
        );
        if (screenAccess) {
          setIsReadOnly(screenAccess.readOnly === 1);
        }
      } catch (error) {
        console.error('Invalid accessDetails format in localStorage');
      }
    }
  }, [isActive]);
  const gridRef = useRef(null);

  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [selectedMembers, setSelectedMembers] = useState([]);
  const teamsPerPage = 7;
  const [userDetails, setUserDetails] = useState([]);
  // Delete Confirmation State
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [memberToDelete, setMemberToDelete] = useState(null);

  const avatarColors = [
    '#f0d8d8',
    '#d7f0e1',
    '#abbced85',
    '#f1d2e7',
    '#dbcdf1ff',
    '#f0ebed',
    '#f19ac4ff',
    '#eff4d5ff',
    '#f4c3c6ff',
    '#cad9d0',
    '#fefefeff',
    '#95c6dc45',
  ];

  const getAvatarColor = (name = '') => {
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    return avatarColors[Math.abs(hash % avatarColors.length)];
  };

  useEffect(() => {
    // Reset search and status filter when tab changes
    setSearchTerm('');
    setProjectSearchTerm('');
    setMemberSearchTerm('');
    setFilters({ status: '', search: '' });

    // Ensure resource dropdown closes when switching tabs
    // and clear any transient dropdown state so it doesn't persist
    setIsDropdownOpen(false);
    setDropdownSearchTerm('');
    setSelectedMembers([]);
    setShowCancelConfirm(false);
  }, [tabIndex]);

  // Fetch user details for dropdown selection
  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const data = await getUserDetails();

        // const updatedUsers = await Promise.all(
        //   data.map(async (u) => {
        //     const profilePhoto = await fetchUserProfilePicture(u.emp_code);
        //     return { ...u, profilePhoto };
        //   }),
        // );

        setUserDetails(data);
      } catch (error) {
        showToast('error', error.message);
      }
    };

    fetchUserDetails();
  }, [toast]);

  const handleCategoryChange = async (categoryId) => {
    // Reset states
    setSelectedCategory(categoryId);
    setSelectedSubTask('');
    setSubTasks([]);

    setNewTask((prev) => ({
      ...prev,
      category_Id: categoryId,
    }));

    if (!categoryId) return;

    // If user selects "Select Category" (empty value)
    if (!categoryId || categoryId === '') {
      // Optional: show message
      // showToast("warning", "Please select a valid main category.");
      return;
    }

    // Otherwise fetch sub tasks
    const data = await getTasksByCategory(categoryId);

    if (data.length === 0) {
      showToast('warning', 'No subcategory found for this main category.');
      return;
    }

    setSubTasks(data);
  };

  // Fetch project members and store managerId
  useEffect(() => {
    const fetchProjectMembers = async () => {
      try {
        const data = await getProjectMembersByProjectId(projectId);

        if (data.length > 0) {
          setTeamData({
            projectId: projectId,
            members: data,
            clientName: data[0].clientName,
            managerId: data[0].managerId, // Store managerId from API response
            projectManagerName: data[0].projectManagerName,
          });
        }
      } catch (err) {
        setError('Failed to load Project members.');
      } finally {
        setLoading(false);
      }
    };

    fetchProjectMembers();
  }, [projectId]);

  const resourceColumnDefs = useMemo(
    () => [
      {
        headerName: 'Name',
        field: 'userName',
        sortable: true,
      },
      {
        headerName: 'Designation',
        field: 'designation',
        sortable: true,
      },
      {
        headerName: 'Actions',
        cellRenderer: (params) => (
          <CustomIconButton
            iconClass="fas fa-trash"
            tooltip="Delete Member"
            onClick={() => confirmTeamMemberDeletion(params.data)}
            isDisabled={isReadOnly}
          >
            <i className="fas fa-trash"></i>
          </CustomIconButton>
        ),
      },
    ],
    [],
  );

  const toggleDropdown = () => {
    if (isDropdownOpen) {
      setSelectedMembers([]);
      setSearchTerm('');
    }
    setIsDropdownOpen(!isDropdownOpen);
  };

  useEffect(() => {
    if (!isDropdownOpen) {
      setSelectedMembers([]);
      setSearchTerm('');
    }
  }, [isDropdownOpen]);

  const handleSelectMember = (emp_code) => {
    setSelectedMembers((prev) =>
      prev.includes(emp_code)
        ? prev.filter((id) => id !== emp_code)
        : [...prev, emp_code],
    );
  };

  // Handle delete action after confirmation
  const handleDelete = async () => {
    if (!memberToDelete) return;

    try {
      setIsSubmitting(true);
      await removeMemberByProjectIdandEmpcode(
        projectId,
        memberToDelete.empCode,
      );
      setTimeout(async () => {
        setTeamData((prevData) => ({
          ...prevData,
          members: prevData.members.filter(
            (member) => member.empCode !== memberToDelete.empCode,
          ),
        }));
        clearGridFocus(gridRef); //  Fix auto-tooltip/focus
      }, 100);
      // Update UI by filtering out deleted member

      showToast(
        'success',
        `Employee ${memberToDelete.userName} has been removed.`,
      );

      setIsDeleteDialogOpen(false);
      setMemberToDelete(null);
      setSearchTerm('');
      setProjectSearchTerm('');
      setMemberSearchTerm('');
      setFilters({ status: '', search: '' });
    } catch (error) {
      showToast('error', error.message || 'Failed to remove Project member.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Open confirmation dialog
  const confirmTeamMemberDeletion = (member) => {
    console.log('Deleting Employee Code:', member.empCode);
    setMemberToDelete(member);
    setIsDeleteDialogOpen(true);
  };

  const defaultColDef = useMemo(
    () => ({
      flex: 1,
      minWidth: 100,
    }),
    [],
  );

  // Add selected Project members
  const handleAddTeamMembers = async () => {
    if (selectedMembers.length === 0) {
      showToast('warning', 'Please select at least one Project member.');
      return;
    }

    try {
      setIsSubmitting(true);
      for (const empCode of selectedMembers) {
        const user = userDetails.find((u) => u.emp_code === empCode);
        if (!user) {
          showToast(
            'error',
            `User with emp_code ${teamData.userName} not found.`,
          );
          continue;
        }

        const newMember = {
          projectId: projectId,
          emp_code: user.emp_code,
          user_name: user.user_name,
        };

        await createTeamMember(newMember);
      }

      showToast('success', 'Project members added successfully.');

      // Refresh member list
      const membersData = await getProjectMembersByProjectId(projectId);
      setTeamData((prevData) => ({
        ...prevData,
        members: membersData,
        managerId: membersData[0]?.managerId || prevData.managerId, // Ensure managerId stays updated
      }));

      setDropdownSearchTerm('');
      setIsDropdownOpen(false);
      setSelectedMembers([]);
    } catch (error) {
      showToast('error', error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  //--------EditProject screen -------//

  // state variables
  const [tasks, setTasks] = useState([]);
  const deleteDisclosure = useDisclosure();
  const cancelRef = React.useRef();
  // const handleTeamSelection = (team) => console.log(`Selected Team: ${team}`);
  const [searchTerm, setSearchTerm] = useState('');
  const [projectSearchTerm, setProjectSearchTerm] = useState('');
  const [memberSearchTerm, setMemberSearchTerm] = useState('');
  const [dropdownSearchTerm, setDropdownSearchTerm] = useState('');

  const [errors, setErrors] = useState({});

  const [filters, setFilters] = useState({
    status: '',
    search: '',
  });
  const [taskToEdit, setTaskToEdit] = useState([]);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [taskToDelete, setTaskToDelete] = useState([]);
  const handleFilterChange = (status) => setFilters(status);

  const handleProjectSearchChange = (e) => {
    const value = e.target.value;
    if (validateAlphanumericInput(value)) {
      setProjectSearchTerm(value);
      setFilters((prevFilters) => ({
        ...prevFilters,
        search: value,
      }));
    }
  };

  const handleMemberSearchChange = (e) => {
    const value = e.target.value;
    if (validateAlphanumericInput(value)) {
      setSearchTerm(value);
      setFilters((prevFilters) => ({
        ...prevFilters,
        search: value,
      }));
    }
  };

  const handleDropdownSearchChange = (e) => {
    const value = e.target.value.replace(/[0-9]/g, '');
    if (value.length <= MAX_EMPLOYEE_NAME_LENGTH) {
      setDropdownSearchTerm(value);
    }
  };

  const filteredProjectMembers = useMemo(() => {
    if (!searchTerm) return teamData.members;

    return teamData.members.filter((member) =>
      member.userName.toLowerCase().includes(searchTerm.toLowerCase()),
    );
  }, [teamData.members, searchTerm]);

  const [newTask, setNewTask] = useState({
    project_Id: projectId,
    category_Id: '',
    sub_category_Id: '',
    task_id: '',
    task_Name: '',
    task_Desc: '',
    estimated_hours: '0',
    actual_hours: 0,
    overhead_hours: 0,
    isBillable: false,
  });
  const [taskCreateMode, setTaskCreateMode] = useState('single');
  const [csvFileName, setCsvFileName] = useState('');
  const createEmptyBulkRow = () => ({
    rowId: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
    task_Name: '',
    task_Desc: '',
    estimated_hours: '0',
    isBillable: false,
    rowError: '',
  });
  const [bulkTaskRows, setBulkTaskRows] = useState([createEmptyBulkRow()]);
  const [conflictStrategy, setConflictStrategy] = useState('Skip');
  const [isDragOver, setIsDragOver] = useState(false);
  const [showUploadConfirm, setShowUploadConfirm] = useState(false);
  const [pendingUploadFile, setPendingUploadFile] = useState(null);
  const [bulkSummary, setBulkSummary] = useState({ total: 0, valid: 0, errors: 0, duplicates: 0 });

  const handleDownloadTemplate = (format = 'excel') => {
    const templateData = [
      ['Task Name', 'Description', 'Estimated Hours', 'Billable'],
      [
        'Initial Design Implementation',
        'Create a consistent set of reusable components and design tokens.',
        '16',
        'Yes',
      ],
      [
        'Authentication Integration',
        'Connect frontend login with backend JWT services.',
        '8',
        'Yes',
      ],
      [
        'Internal Reporting Dashboard',
        'Internal dashboard for project time tracking analysis.',
        '24',
        'No',
      ],
    ];
    const ws = XLSX.utils.aoa_to_sheet(templateData);

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Task Template');
    if (format === 'csv') {
      XLSX.writeFile(wb, 'TimeSnap_Bulk_Template.csv', { bookType: 'csv' });
      return;
    }
    XLSX.writeFile(wb, 'TimeSnap_Bulk_Template.xlsx');
  };


  const onDragOver = (e) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const onDragLeave = () => setIsDragOver(false);

  const onDrop = (e) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleInitialFileUpload(file);
    }
  };

  const {
    isOpen: isAddOpen,
    onOpen: onAddOpen,
    onClose: onAddClose,
  } = useDisclosure();

  const createTaskPayload = (taskInput) => ({
    project_Id: projectId,
    task_Name: taskInput.task_Name,
    task_Desc: taskInput.task_Desc || '',
    estimated_hours: parseFloat(taskInput.estimated_hours) || 0,
    isBillable: !!taskInput.isBillable,
    actual_hours: 0,
    overhead_hours: 0,
  });

  const parseCsvLine = (line) => {
    const fields = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i += 1) {
      const char = line[i];
      if (char === '"') {
        if (inQuotes && line[i + 1] === '"') {
          current += '"';
          i += 1;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        fields.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    fields.push(current.trim());
    return fields;
  };

  const parseCsvRows = (text) => {
    const lines = text
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => line.length > 0);

    if (!lines.length) return [];

    const headerKeys = parseCsvLine(lines[0]).map((h) =>
      h.toLowerCase().replace(/[\s_-]/g, ''),
    );

    const getIndex = (aliases) =>
      headerKeys.findIndex((key) => aliases.includes(key));

    const nameIdx = getIndex(['taskname', 'task']);
    const descIdx = getIndex(['description', 'taskdescription', 'desc']);
    const hoursIdx = getIndex(['estimatedhours', 'hours', 'estimatedhour']);
    const billableIdx = getIndex(['billable', 'isbillable', 'billabletask']);

    if (nameIdx === -1) {
      throw new Error('INFO:Your document should contain the fields in the template.');
    }

    return lines.slice(1).map((line) => {
      const cols = parseCsvLine(line);
      const billableRaw = (cols[billableIdx] || '').toString().toLowerCase();
      return {
        ...createEmptyBulkRow(),
        task_Name: cols[nameIdx] || '',
        task_Desc: descIdx >= 0 ? cols[descIdx] || '' : '',
        estimated_hours:
          hoursIdx >= 0 && /^\d{1,3}$/.test(cols[hoursIdx] || '')
            ? cols[hoursIdx]
            : '0',
        isBillable: ['true', 'yes', '1', 'y'].includes(billableRaw),
      };
    });
  };
  // Status options and corresponding colors
  const statuses = ['Completed', 'In-Progress', 'Hold'];
  const statusColors = {
    Completed: 'green',
    'In-Progress': 'blue',
    Hold: 'red',
  };
  // Counts of tasks based on their status
  const [taskStatusCounts, setTaskStatusCounts] = useState({
    Completed: 0,
    'In-Progress': 0,
    Hold: 0,
  });
  // Function to reset task input fields when closing the Add Task modal
  const handleAddModalClose = () => {
    setNewTask({
      project_Id: projectId,
      category_Id: '',
      sub_category_Id: '',
      task_id: '',
      task_Name: '',
      task_Desc: '',
      estimated_hours: '0',
      actual_hours: 0,
      overhead_hours: 0,
      isBillable: false,
    });
    setTaskCreateMode('single');
    setCsvFileName('');
    setBulkTaskRows([createEmptyBulkRow()]);
    setErrors({});
    onAddClose();
    setSelectedCategory('');
    setSelectedSubTask('');
  };
  useEffect(() => {
    const counts = tasks.reduce(
      (acc, task) => {
        acc[task.statusName] = (acc[task.statusName] || 0) + 1;
        return acc;
      },
      { Completed: 0, InProgress: 0, Hold: 0 },
    );
    setTaskStatusCounts(counts);
  }, [tasks]);
  const handleNewTask = () => {
    setNewTask((prev) => ({
      ...prev,
      project_Id: projectId,
    }));
    setTaskCreateMode('single');
    setCsvFileName('');
    setBulkTaskRows([createEmptyBulkRow()]);
    onAddOpen();
  };
  // Fetch project tasks and team names when projectId changes
  useEffect(() => {
    const fetchEditProjects = async () => {
      setIsTaskLoading(true);
      try {
        const data = await fetchEditProjectDatas(projectId);
        const mapped = data.map((item) => ({
          task_id: item.task_Id,
          taskName: item.task_Name,
          taskDescription: item.task_Desc,
          estimatedHours: item.estimated_hours,
          actualHours: item.actual_hours,
          overheadHours: item.overhead_hours,
          status_Id: item.status_id,
          statusName: item.status_Name,
          categoryName: item.category_Name,
          subCategoryName: item.sub_Category_Name,
        }));
        setTasks(mapped);
        console.log('Fetched tasks:', mapped);
      } catch (error) {
        showToast('error', error.message);
      } finally {
        setIsTaskLoading(false);
      }
    };
    fetchEditProjects();
  }, [projectId, toast, fetchEditProjectDatas]);

  // const handleAssignTask = async () => {
  //   let newErrors = {};

  //   // Required Fields Validation
  //   if (!newTask.task_Id) newErrors.task_Id = 'Task Name is required.';
  //   if (!newTask.estimated_hours)
  //     newErrors.estimated_hours = 'Estimated Hours is required.';

  //   // Validate Estimated Hours (Numeric, 1-500 range, max 2 decimal places)
  //   if (
  //     !/^\d{1,3}(\.\d{0,2})?$/.test(newTask.estimated_hours) ||
  //     newTask.estimated_hours < 1 ||
  //     newTask.estimated_hours > 500
  //   ) {
  //     newErrors.estimated_hours =
  //       'Value must be between 1 and 500  ';
  //   }

  //   // Check if task is already assigned
  //   const isTaskAlreadyAssigned = tasks.some(
  //     (task) => task.task_Id === newTask.task_Id,
  //   );
  //   if (isTaskAlreadyAssigned) {
  //     newErrors.task_Id = 'This task is already assigned to the project.';
  //   }

  //   // Update the errors state
  //   setErrors(newErrors);

  //   // If errors exist, stop form submission
  //   if (Object.keys(newErrors).length > 0) return;

  //   try {
  //     // Payload aligned with your new backend structure
  //     const taskPayload = {
  //       Project_Id: newTask.project_Id,
  //       Task_Id: newTask.task_Id,
  //       Estimated_hours: newTask.estimated_hours,
  //     };

  //     await addAssignTasks(taskPayload);

  //     const data = await fetchEditProjectDatas(projectId);
  //     setTasks(data);

  //     showToast('success', 'The task has been added successfully.');

  //     // Reset form
  //     setNewTask({
  //       project_Id: '',
  //       task_Id: '',
  //       estimated_hours: '',
  //       actual_hours: '0',
  //       overheadHours: '0',
  //       status_id: '',
  //       TaskId: '',
  //       TaskName: '',
  //       status_Name: '',
  //     });

  //     setErrors({});
  //     onAddClose();
  //   } catch (error) {
  //     // setErrors({
  //     //   form:
  //     //     error.response?.data?.message ||
  //     //     'Failed to add the task. Please try again.',
  //     // });
  //     showToast('error', error.message);
  //   }
  // };

  const mapTask = (item) => ({
    task_id: item.task_Id,
    taskName: item.task_Name,
    taskDescription: item.task_Desc,
    estimatedHours: item.estimated_hours,
    actualHours: item.actual_hours,
    overheadHours: item.overhead_hours,
    status_Id: item.status_id,
    statusName: item.status_Name,
    isBillable: item.isBillable === true || item.isBillable === 1,
    // // âœ… CONSISTENT
    // categoryName: item.category_Name,
    // subCategoryName: item.sub_Category_Name,
  });

  const handleAssignTask = async () => {
    let newErrors = {};

    if (!newTask.task_Name?.trim())
      newErrors.task_Name = 'Task Name is required.';

    // if (!newTask.estimated_hours)
    //   newErrors.estimated_hours = 'Estimated Hours is required.';

    // Estimated hours validation
    // if (
    //   !/^\d{1,3}(\.\d{0,2})?$/.test(newTask.estimated_hours) ||
    //   newTask.estimated_hours < 1 ||
    //   newTask.estimated_hours > 500
    // ) {
    //   newErrors.estimated_hours = 'Estimated hours must be between 1 and 500.';
    // }

    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) return;

    try {
      setIsSubmitting(true);
      const payload = createTaskPayload(newTask);

      await addAssignTasks(payload);

      // refresh
      const data = await fetchEditProjectDatas(projectId);

      const mapped = data.map(mapTask);
      setTasks(mapped);

      showToast('success', 'Task added successfully.');

      // reset modal
      setNewTask({
        project_Id: projectId,
        category_Id: '',
        sub_category_Id: '',
        task_Name: '',
        task_Desc: '',
        estimated_hours: '0',
        actual_hours: 0,
        overhead_hours: 0,
      });

      setErrors({});
      onAddClose();
      setSelectedCategory('');
      setSelectedSubTask('');
    } catch (error) {
      showToast('error', error.message || 'Failed to save task.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const parseExcelRows = async (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

          if (jsonData.length < 2) {
            resolve([]);
            return;
          }

          const headers = jsonData[0].map((h) =>
            h?.toString().toLowerCase().replace(/[\s._-]/g, '') || ''
          );

          const getIndex = (aliases) =>
            headers.findIndex((h) => aliases.includes(h));

          const nameIdx = getIndex(['taskname', 'task']);
          const descIdx = getIndex(['description', 'taskdescription', 'desc']);
          const hoursIdx = getIndex(['estimatehours', 'hours', 'estimatedhours', 'estimatedhour']);
          const billableIdx = getIndex(['billable', 'isbillable', 'billabletask']);

          if (nameIdx === -1) {
            throw new Error('INFO:Your document should contain the fields in the template.');
          }

          const rows = jsonData.slice(1).map((cols) => {
            const billableRaw = (cols[billableIdx] ?? '').toString().toLowerCase();
            return {
              ...createEmptyBulkRow(),
              task_Name: cols[nameIdx]?.toString() || '',
              task_Desc: descIdx >= 0 ? cols[descIdx]?.toString() || '' : '',
              estimated_hours:
                hoursIdx >= 0 && !isNaN(parseFloat(cols[hoursIdx]))
                  ? cols[hoursIdx].toString()
                  : '0',
              isBillable: ['true', 'yes', '1', 'y'].includes(billableRaw),
            };
          }).filter(row => row.task_Name);

          resolve(rows);
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = reject;
      reader.readAsArrayBuffer(file);
    });
  };

  const recalculateBulkSummary = (rows) => {
    const total = rows.length;
    const projectTaskNames = new Set(tasks.map(t => t.taskName?.trim().toLowerCase()));

    const errorCount = rows.filter(r => r.rowError).length;
    const duplicateCount = rows.filter(r => r.rowError === 'Duplicate in file.').length;
    const conflictCount = rows.filter(r => !r.rowError && projectTaskNames.has(r.task_Name?.trim().toLowerCase())).length;

    setBulkSummary({
      total,
      valid: total - errorCount - conflictCount,
      errors: errorCount,
      duplicates: duplicateCount,
      conflicts: conflictCount
    });
  };

  const handleBulkRowChange = (rowId, field, value) => {
    setBulkTaskRows((prev) => {
      const newRows = prev.map((row) => {
        if (row.rowId !== rowId) return row;

        let error = row.rowError;
        if (field === 'task_Name') {
          if (!value?.trim()) error = 'Task Name is required.';
          else if (value.length > 100) error = 'Name too long (max 100).';
          else if (!/^[a-zA-Z0-9\s_\/\-]+$/.test(value)) error = 'invalid name';
          else error = '';
        } else if (field === 'estimated_hours') {
          // Format logic: prevent leading zero issues and validate range
          let cleanValue = value.replace(/^0+/, ''); // Remove leading zeros
          if (cleanValue === '' && value === '0') cleanValue = '0'; // Keep '0' if that's all there is
          if (cleanValue.startsWith('.')) cleanValue = '0' + cleanValue; // Fix '.5' to '0.5'
          
          const numValue = parseFloat(cleanValue || '0');
          value = cleanValue; // Reassign to value so the field updates visually
          
          if (!/^\d*(\.\d{0,2})?$/.test(cleanValue) || isNaN(numValue) || numValue < 0 || numValue > 500) {
            error = 'Estimated hours must be between 0 and 500.';
          } else {
            error = ''; // Clear error if it matches
          }
        }

        return {
          ...row,
          [field]: value,
          rowError: error,
        };
      });

      // Re-validate duplicates in the whole set
      const finalRows = newRows.map((row, index, self) => {
        if (row.rowError && row.rowError !== 'Duplicate in file.') return row;

        const isDuplicate = self.findIndex(r =>
          r.task_Name?.trim().toLowerCase() === row.task_Name?.trim().toLowerCase()
        ) !== index && row.task_Name?.trim();

        return { ...row, rowError: isDuplicate ? 'Duplicate in file.' : (row.rowError === 'Duplicate in file.' ? '' : row.rowError) };
      });

      // Check if newly edited cell creates a project conflict and trigger strategy jump
      const projectTaskNames = new Set(tasks.map(t => t.taskName?.trim().toLowerCase()));
      const hasConflicts = finalRows.some(r => !r.rowError && projectTaskNames.has(r.task_Name?.trim().toLowerCase()));

      if (hasConflicts && field !== 'task_Name') {
        // If they manually edit hours, billable, etc. on a conflicting row, switch to overwrite automatically
        const editedRowConflicts = projectTaskNames.has(finalRows.find(r => r.rowId === rowId)?.task_Name?.trim().toLowerCase());
        if (editedRowConflicts) {
          setConflictStrategy('Overwrite');
        }
      } else if (hasConflicts && field === 'task_Name') {
        // if they typed a name that conflicts
        setConflictStrategy('Overwrite');
      }

      recalculateBulkSummary(finalRows);
      return finalRows;
    });
  };

  const handleAddBulkTaskRow = () => {
    const emptyRowIndex = bulkTaskRows.findIndex(row => !row.task_Name?.trim());
    if (emptyRowIndex !== -1) {
      setBulkTaskRows((prev) =>
        prev.map((row, idx) =>
          idx === emptyRowIndex ? { ...row, rowError: 'Task name required' } : row
        )
      );
      const emptyRowId = bulkTaskRows[emptyRowIndex].rowId;
      setTimeout(() => {
        const input = document.getElementById(`bulk-task-name-${emptyRowId}`);
        if (input) input.focus();
      }, 10);
      return;
    }

    setBulkTaskRows((prev) => {
      const newRows = [createEmptyBulkRow(), ...prev];
      recalculateBulkSummary(newRows);
      return newRows;
    });
  };

  const handleRemoveBulkRow = (rowId) => {
    setBulkTaskRows((prev) => {
      let newRows;
      if (prev.length === 1) {
        newRows = [createEmptyBulkRow()];
      } else {
        newRows = prev.filter((row) => row.rowId !== rowId);
      }
      recalculateBulkSummary(newRows);
      return newRows;
    });
  };

  const handleEditBulkRow = (rowId) => {
    const input = document.getElementById(`bulk-task-name-${rowId}`);
    if (input) input.focus();
  };

  const handleInitialFileUpload = (file) => {
    const hasUnsavedModifications = bulkTaskRows.some(row => row.task_Name?.trim() || row.task_Desc?.trim() || parseFloat(row.estimated_hours) > 0);
    if (hasUnsavedModifications) {
      setPendingUploadFile(file);
      setShowUploadConfirm(true);
    } else {
      processFile(file);
    }
  };

  const handleCsvUploadEvent = (event) => {
    const file = event.target.files?.[0];
    if (file) {
      handleInitialFileUpload(file);
    }
    event.target.value = ''; // Reset input
  };

  const cancelUpload = () => {
    setShowUploadConfirm(false);
    setPendingUploadFile(null);
  };

  const confirmUpload = () => {
    setShowUploadConfirm(false);
    if (pendingUploadFile) {
      processFile(pendingUploadFile);
    }
  };

  const processFile = async (file) => {
    if (!file) return;

    const fileName = file.name.toLowerCase();
    const isCsv = fileName.endsWith('.csv');
    const isExcel = fileName.endsWith('.xlsx') || fileName.endsWith('.xls');

    if (!isCsv && !isExcel) {
      showToast('warning', 'Please upload a CSV or Excel file.');
      return;
    }

    try {
      setIsSubmitting(true);
      let parsedRows = [];
      if (isCsv) {
        const text = await file.text();
        parsedRows = parseCsvRows(text);
      } else {
        parsedRows = await parseExcelRows(file);
      }

      // Initial Validation
      const validatedRows = parsedRows.map((row, index, self) => {
        let error = '';
        if (!row.task_Name?.trim()) error = 'Task Name is required.';
        else if (row.task_Name.length > 100) error = 'Name too long (max 100).';
        else if (!/^[a-zA-Z0-9\s_\/\-]+$/.test(row.task_Name)) error = 'invalid name';
        else {
          const numHours = parseFloat(row.estimated_hours);
          if (!/^\d{1,3}(\.\d{0,2})?$/.test(row.estimated_hours?.toString()) || isNaN(numHours) || numHours < 0 || numHours > 500) {
            error = 'Estimated hours must be between 0 and 500.';
          }
        }

        const isDuplicate = self.findIndex(r =>
          r.task_Name?.trim().toLowerCase() === row.task_Name?.trim().toLowerCase()
        ) !== index;

        if (isDuplicate && !error) error = 'Duplicate in file.';

        return { ...row, rowError: error };
      });

      const finalRows = validatedRows.length > 0 ? validatedRows : [createEmptyBulkRow()];

      setCsvFileName(file.name);
      setBulkTaskRows(finalRows);

      const total = finalRows.length;
      const projectTaskNames = new Set(tasks.map(t => t.taskName?.trim().toLowerCase()));

      const errorCount = finalRows.filter(r => r.rowError).length;
      const duplicateCount = finalRows.filter(r => r.rowError === 'Duplicate in file.').length;
      const conflictCount = finalRows.filter(r => !r.rowError && projectTaskNames.has(r.task_Name?.trim().toLowerCase())).length;

      setBulkSummary({
        total,
        valid: total - errorCount - conflictCount, // Now excludes conflicts
        errors: errorCount,
        duplicates: duplicateCount,
        conflicts: conflictCount
      });

      setConflictStrategy('Skip'); // Force strategy to skip on fresh file upload
      setTaskCreateMode('bulk');
      showToast('success', `${validatedRows.length} rows imported.`);
    } catch (err) {
      if (err.message && err.message.startsWith('INFO:')) {
        showToast('info', err.message.replace('INFO:', ''));
      } else {
        showToast('error', err.message || 'Failed to read file.');
      }
    } finally {
      setIsSubmitting(false);
      setPendingUploadFile(null);
    }
  };

  const handleClearFile = () => {
    setCsvFileName('');
    setBulkTaskRows([createEmptyBulkRow()]);
    setBulkSummary({ total: 0, valid: 0, errors: 0, duplicates: 0, conflicts: 0 });
    const fileInput = document.getElementById('bulk-task-csv-upload');
    if (fileInput) fileInput.value = '';
    showToast('info', 'File cleared.');
  };

  const handleBulkAssignTask = async () => {
    // If there is ANY row with an empty task name, we show validation error for it
    const emptyRowIndex = bulkTaskRows.findIndex(row => !row.task_Name?.trim());
    if (emptyRowIndex !== -1) {
      setBulkTaskRows((prev) => 
        prev.map((row, idx) => !row.task_Name?.trim() ? { ...row, rowError: 'Task Name is required.' } : row)
      );
      setTimeout(() => {
        const input = document.getElementById(`bulk-task-name-${bulkTaskRows[emptyRowIndex].rowId}`);
        if (input) input.focus();
      }, 10);
      return;
    }

    const rowsToCreate = bulkTaskRows.filter(
      (row) => row.task_Name?.trim() || row.task_Desc?.trim(),
    );

    if (!rowsToCreate.length) {
      showToast('warning', 'Add at least one task row.');
      return;
    }

    let hasValidationError = false;
    const validatedRows = rowsToCreate.map((row, index, self) => {
      let error = '';
      if (!row.task_Name?.trim()) {
        error = 'Task name required';
      } else if (!/^[a-zA-Z0-9\s_\/\-]+$/.test(row.task_Name)) {
        error = 'invalid name';
      } else {
        const numHours = parseFloat(row.estimated_hours);
        if (!/^\d{1,3}(\.\d{0,2})?$/.test(row.estimated_hours?.toString()) || isNaN(numHours) || numHours < 0 || numHours > 500) {
          error = 'Estimated hours must be between 0 and 500.';
        } else {
          const isDuplicate = self.findIndex(r =>
            r.task_Name?.trim().toLowerCase() === row.task_Name?.trim().toLowerCase()
          ) !== index;
          if (isDuplicate) error = 'Duplicate in file.';
        }
      }

      if (error) hasValidationError = true;
      return { ...row, rowError: error };
    });

    setBulkTaskRows((prev) =>
      prev.map((row) => {
        const matched = validatedRows.find((v) => v.rowId === row.rowId);
        return matched ? matched : row;
      }),
    );

    if (hasValidationError) {
      showToast('warning', 'Please fix all errors before saving.');
      return;
    }

    try {
      setIsSubmitting(true);

      const payload = {
        Project_Id: parseInt(projectId),
        Tasks: validatedRows.map((row) => ({
          Task_Name: row.task_Name,
          Task_Desc: row.task_Desc || '',
          Estimated_hours: parseFloat(row.estimated_hours) || 0,
          IsBillable: !!row.isBillable,
        })),
        Strategy: conflictStrategy === 'Overwrite' ? 1 : conflictStrategy === 'AddAsCopy' ? 2 : 0
      };

      const result = await addBulkAssignTasks(payload);

      const data = await fetchEditProjectDatas(projectId);
      const mapped = data.map(mapTask);
      setTasks(mapped);

      const added = result.addedCount || 0;
      const updated = result.updatedCount || 0;
      const skipped = result.skippedCount || 0;
      const totalProcessed = added + updated + skipped;

      showToast('success', `Processed ${totalProcessed} tasks: ${added} added, ${updated} updated, ${skipped} skipped.`);

      if (result.errors && result.errors.length > 0) {
        // Map backend errors back to rows if possible
        const backendErrors = {};
        result.errors.forEach(err => {
          backendErrors[err.taskName.toLowerCase()] = err.error;
        });

        setBulkTaskRows(prev => {
          const updatedRows = prev.map(row => ({
            ...row,
            rowError: backendErrors[row.task_Name?.toLowerCase()] || row.rowError
          }));
          recalculateBulkSummary(updatedRows);
          return updatedRows;
        });

        // Don't close modal if there are errors to fix
        const totalResolved = (result.addedCount || 0) + (result.updatedCount || 0);
        if (totalResolved === 0) {
          showToast('warning', 'No tasks were saved. Please check the errors.');
        }
      } else {
        handleAddModalClose();
        setBulkSummary({ total: 0, valid: 0, errors: 0, duplicates: 0 });
        setCsvFileName('');
      }
    } catch (err) {
      showToast('error', err.message || 'Failed to create tasks.');
    } finally {
      setIsSubmitting(false);
    }
  };

  useEffect(() => {
    // Disable scroll on the body
    document.body.style.overflow = 'hidden';

    // Clean up: Restore the scroll when the component unmounts
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, []);
  // function for edit task
  const handleEditTask = (task) => {
    setTaskToEdit({
      task_id: task.task_id, // correct
      taskName: task.taskName,
      estimatedHours: task.estimatedHours?.toString() || '0',
      statusId: task.status_Id ?? '', // map status properly
      // categoryName: task.categoryName,
      // subCategoryName: task.subCategoryName,
      isBillable: task.isBillable ?? false,
    });
    console.log('Editing Task:', task);
    setIsEditOpen(true);
  };

  // function for save new task
  const handleSaveTask = async () => {
    const numericValue = parseFloat(taskToEdit.estimatedHours);

    // Validation: 1-500 with up to 2 decimals
    // if (
    //   !/^\d{1,3}(\.\d{0,2})?$/.test(taskToEdit.estimatedHours) ||
    //   numericValue < 1 ||
    //   numericValue > 500
    // ) {
    //   setTaskToEdit((prev) => ({
    //     ...prev,
    //     error: 'Estimated hours must be between 1 and 500  ',
    //   }));
    //   return;
    // }

    const updatedTask = {
      estimated_hours: Number(taskToEdit.estimatedHours) || 0,
      status_id: taskToEdit.statusId,
      Billable: taskToEdit.isBillable,
    };

    try {
      setIsSubmitting(true);
      await updateProjectTask(taskToEdit.task_id, updatedTask);
      setTimeout(async () => {
        const data = await fetchEditProjectDatas(projectId);
        const mapped = data.map(mapTask);
        setTasks(mapped);
        console.log('Updated tasks:', data);
        clearGridFocus(gridRef); //  Prevent tooltip from sticking on first row
      }, 100);

      showToast(
        'success',
        `The task ${taskToEdit.taskName} has been updated successfully.`,
      );
      setSelectedCategory('');
      setSelectedSubTask('');
      setIsEditOpen(false);

      setSearchTerm('');
      setProjectSearchTerm('');
      setMemberSearchTerm('');
      setFilters({ status: '', search: '' });
    } catch (error) {
      showToast(
        'error',
        error.response?.data?.message ||
        'Failed to update the task. Please try again.',
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // function for filter status
  const filteredTasks = tasks.filter((task) => {
    const matchesStatus =
      !filters.status ||
      task.status_Id.toString() === filters.status.toString();

    const matchesSearch =
      !filters.search ||
      task.taskName.toLowerCase().includes(filters.search.toLowerCase());

    return matchesStatus && matchesSearch;
  });
  // function to delete a task
  const handleDeleteTask = (task) => {
    setTaskToDelete({
      task_id: task.task_id,
      taskName: task.taskName,
      statusId: task.statusId || '',
    });
    deleteDisclosure.onOpen();
  };

  const confirmDelete = async () => {
    try {
      setIsSubmitting(true);
      if (taskToDelete.status_id) {
        showToast('error', 'You cannot delete this Task');
        deleteDisclosure.onClose();
        setIsSubmitting(false);
        return;
      }
      await deleteTaskByIndexId(taskToDelete.task_id);

      setTimeout(async () => {
        const data = await fetchEditProjectDatas(projectId);
        const mapped = data.map((item) => ({
          task_id: item.task_Id,
          taskName: item.task_Name,
          taskDescription: item.task_Desc,
          estimatedHours: item.estimated_hours,
          actualHours: item.actual_hours,
          overheadHours: item.overhead_hours,
          status_Id: item.status_id,
          statusName: item.status_Name,
          categoryName: item.category_Name,
          subCategoryName: item.sub_Category_Name,
        }));
        setTasks(mapped);
        clearGridFocus(gridRef); //  Fix auto-tooltip/focus
      }, 100);
      showToast(
        'success',
        `The task ${taskToDelete.taskName} has been deleted successfully.`,
      );
      deleteDisclosure.onClose();
      setSearchTerm('');
      setProjectSearchTerm('');
      setMemberSearchTerm('');
      setFilters({ status: '', search: '' });
    } catch (error) {
      showToast('warning', error.message || 'Faild to delete');
      deleteDisclosure.onClose();
      setSearchTerm('');
      setProjectSearchTerm('');
      setMemberSearchTerm('');
      setFilters({ status: '', search: '' });
    } finally {
      setTaskToDelete(null);
      setIsSubmitting(false);
    }
  };

  const getInitials = (fullName = '') => {
    if (!fullName) return '';

    // Split by space & remove empty values
    const parts = fullName.trim().split(' ').filter(Boolean);

    const firstInitial = parts[0]?.[0] || '';
    const lastInitial = parts.length > 1 ? parts[parts.length - 1][0] : ''; // last word always

    return (firstInitial + lastInitial).toUpperCase();
  };

  const handleBulkCategoryChange = async (params, val) => {
    const data = await getTasksByCategory(val);
    params.data.category_Id = val;
    params.data.sub_category_Id = '';
    params.data.subTasksList = data;
    params.api.applyTransaction({ update: [params.data] });
    setIsBulkDirty(true);
  };

  const handleBulkSave = () => {
    setShowBulkSaveConfirm(true);
  };

  const confirmBulkSave = () => {
    setShowBulkSaveConfirm(false);
    onBulkClose();
    setBulkTasks([]);
    showToast('success', 'Bulk tasks added successfully (Simulation).');
  };

  const handleBulkCancel = () => {
    if (isBulkDirty) {
      setShowBulkCancelConfirm(true);
    } else {
      onBulkClose();
      setBulkTasks([]);
    }
  };

  const confirmBulkCancel = () => {
    setShowBulkCancelConfirm(false);
    onBulkClose();
    setBulkTasks([]);
  };

  const [showCancelConfirm, setShowCancelConfirm] = useState(false);

  const closeDropdownImmediately = () => {
    setDropdownSearchTerm('');
    setSelectedMembers([]);
    setIsDropdownOpen(false);
  };

  const handleCancelRequest = () => {
    if (selectedMembers.length > 0) {
      // ðŸ”” Ask before clearing
      setShowCancelConfirm(true);
    } else {
      // âœ… Nothing selected â†’ close safely
      closeDropdownImmediately();
    }
  };

  // column definition
  const columnDefs = [
    {
      headerName: 'Task Name',
      field: 'taskName',
      sortable: true,
      flex: 2,
    },
    {
      headerName: 'Estimated Hours',
      field: 'estimatedHours',
      sortable: true,
      flex: 1,
    },
    {
      headerName: 'Actual Hours',
      field: 'actualHours',
      sortable: true,
      flex: 1,
    },
    {
      headerName: 'Overhead Hours',
      field: 'overheadHours',
      sortable: true,
      flex: 1,
    },
    {
      headerName: 'Status',
      field: 'statusName',
      cellRenderer: ({ value }) => (
        <Tag className="Badge-lables" colorScheme={statusColorScheme[value]}>
          {value}
        </Tag>
      ),
    },
    {
      headerName: 'Actions',
      field: 'actions',
      flex: 1,
      cellRenderer: (params) => (
        <Box display="flex" justifyContent="left">
          {/* Edit Task button */}
          <CustomIconButton
            iconClass="fas fa-edit"
            tooltip="Edit Task"
            onClick={() => handleEditTask(params.data)}
            isDisabled={isReadOnly}
          />
          {/* Delete Task button */}
          <CustomIconButton
            iconClass="fas fa-trash"
            tooltip="Delete Task"
            onClick={() => handleDeleteTask(params.data)}
            isDisabled={isReadOnly}
          />
        </Box>
      ),
    },
  ];

  const bulkColumnDefs = [
    // {
    //   headerName: 'Category',
    //   field: 'category_Id',
    //   cellRenderer: (params) => (
    //     <Dropdown
    //       type="categories"
    //       itemsProp={categories}
    //       placeholder="Select"
    //       selectedValue={params.data.category_Id}
    //       setSelectedValue={(val) => handleBulkCategoryChange(params, val)}
    //     />
    //   ),
    //   flex: 1.5,
    // },
    // {
    //   headerName: 'Sub Category',
    //   field: 'sub_category_Id',
    //   cellRenderer: (params) => (
    //     <Dropdown
    //       type="subcategories"
    //       itemsProp={params.data.subTasksList || []}
    //       placeholder="Select"
    //       selectedValue={params.data.sub_category_Id}
    //       setSelectedValue={(val) => {
    //         params.data.sub_category_Id = val;
    //         params.api.applyTransaction({ update: [params.data] });
    //         setIsBulkDirty(true);
    //       }}
    //     />
    //   ),
    //   flex: 1.5,
    // },
    {
      headerName: 'Task Name',
      field: 'task_Name',
      editable: true,
      onCellValueChanged: () => setIsBulkDirty(true),
      flex: 2,
      cellRenderer: (params) => (
        <Flex align="center" gap={2} height="100%">
          <Text isTruncated color={params.data.rowError ? 'red.500' : 'inherit'}>
            {params.value}
          </Text>
          {params.data.rowError && (
            <Tag size="sm" colorScheme="red" variant="solid" fontSize="10px">
              Error
            </Tag>
          )}
        </Flex>
      )
    },
    {
      headerName: 'Estimated Hours',
      field: 'estimated_hours',
      editable: true,
      onCellValueChanged: () => setIsBulkDirty(true),
      flex: 1,
    },
    {
      headerName: 'Billable',
      field: 'isBillable',
      cellRenderer: (params) => (
        <Flex justify="center" align="center" height="100%">
          <Switch
            isChecked={params.data.isBillable}
            onChange={(e) => {
              params.data.isBillable = e.target.checked;
              params.api.applyTransaction({ update: [params.data] });
              setIsBulkDirty(true);
              recalculateBulkSummary(bulkTaskRows);
            }}
          />
        </Flex>
      ),
      flex: 0.8,
    },
    {
      headerName: 'Action',
      cellRenderer: (params) => (
        <Flex justify="center" align="center" height="100%">
          <CustomIconButton
            iconClass="fas fa-trash"
            tooltip="Delete Row"
            onClick={() => handleRemoveBulkRow(params.data.rowId)}
            color="red.500"
          />
        </Flex>
      ),
      flex: 0.6,
    },
  ];

  const managerList = projectManagers ? projectManagers.split(',') : [];
  return (
    <Box
      className="editproject-modern page-content-wrapper"
      bg={pageBg}
      minH="calc(100vh - var(--header-height))"
    >
      <ToastContainer />

      <Flex direction="column" mb={6} className="editproject-header">
        <Flex
          justifyContent="space-between"
          alignItems="center"
          mb={0}
          className="editproject-header-row"
        >
          <Flex alignItems="center" gap={3} className="editproject-title-wrap">
            <Heading className="editproject-title">{projectName}</Heading>

            <Tag
              className="Badge-lables editproject-status-tag"
              colorScheme={statusColorScheme[projectStatus]}
            >
              {projectStatus}
            </Tag>
          </Flex>
          <HStack spacing={4}>
            <Button
              aria-label="Back"
              className="editproject-back-icon-btn"
              onClick={onBack}
              leftIcon={<Text as="span" fontSize="18px" lineHeight="1">←</Text>}
            >
              Back
            </Button>
          </HStack>
        </Flex>
      </Flex>

      <div className="manager editproject-meta-row">
        <div className="manager-title editproject-meta-title">Project Manager :</div>
        <div className="manager-list">
          {managerList.map((name, index) => (
            <div key={index} className="manager-label">
              <div className="manager-avatar"></div>
              <span className="manager-name">{name.trim()}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="manager editproject-meta-row">
        <div className="Client-title editproject-meta-title">Client :</div>
        <div className="manager-label">
          <div className="manager-avatar"></div>
          <span className="manager-name">{clientName}</span>
        </div>
      </div>

      {/* Tabbed Interface */}
      <Tabs
        index={tabIndex}
        onChange={(index) => setTabIndex(index)}
        variant="unstyled"
        colorScheme="gray"
        pt={2}
        px={0}
        className="editproject-tabs"
      >
        {/* Tab Headers */}
        <TabList
          className="editproject-tablist"
          display="flex"
          alignItems="center"
          w="100%"
          borderBottom="none"
          justifyContent="space-between"
        >
          <Flex className="editproject-tab-group">
            <Tab
              className="editproject-tab"
              _selected={{
                bg: '#315C8C',
                color: '#FFFFFF',
                borderColor: '#2A4F7C',
                fontWeight: '700',
                boxShadow: '0 6px 14px rgba(42, 79, 124, 0.25)',
              }}
            >
              Resource Allocation
            </Tab>
            <Tab
              className="editproject-tab"
              _selected={{
                bg: '#315C8C',
                color: '#FFFFFF',
                borderColor: '#2A4F7C',
                fontWeight: '700',
                boxShadow: '0 6px 14px rgba(42, 79, 124, 0.25)',
              }}
            >
              Project Task Allocation
            </Tab>
          </Flex>

          {/* Status Counter Box - Aligning on Same Line */}
          {/* Status Counter Box - show ONLY for Project Task Allocation tab */}
          {tabIndex === 1 && (
            <Flex gap={2} className="editproject-status-cards">
              {statuses.map((status) => (
                <Box
                  key={status}
                  w="122px"
                  borderWidth={1}
                  borderRadius="12px"
                  textAlign="center"
                  boxShadow="none"
                  transition="all 0.2s ease"
                  bg={`${statusColors[status]}.50`}
                  borderColor={`${statusColors[status]}.200`}
                  _hover={{
                    transform: 'scale(1.03)',
                    boxShadow: 'md',
                    borderColor: `${statusColors[status]}.400`,
                  }}
                >
                  <VStack spacing={1}>
                    <Text
                      fontSize="md"
                      fontWeight="semibold"
                      textTransform="capitalize"
                      color={`${statusColors[status]}.700`}
                    >
                      {status}
                    </Text>
                    <Text
                      fontSize="md"
                      fontWeight="bold"
                      color={`${statusColors[status]}.800`}
                    >
                      {taskStatusCounts[status] || 0}
                    </Text>
                  </VStack>
                </Box>
              ))}
            </Flex>
          )}
        </TabList>

        {/*Project Task allocation Tab Panels */}
        <TabPanels>
          <TabPanel p={0}>
            <Flex
              justifyContent="space-between"
              alignItems="center"
              className="editproject-controls-row"
            >
              <Box
                display="flex"
                width="400px"
                gap={4}
                mb={4}
                className="editproject-filter-left"
              >
                <Box className="list-search-wrap editproject-search-wrap">
                  <Input
                    placeholder="Search..."
                    bg={inputBg}
                    size="md"
                    variant="outline"
                    borderColor="#d9e5f2"
                    focusBorderColor="#315C8C"
                    borderRadius="md"
                    className="list-search-input"
                    value={searchTerm}
                    onChange={handleMemberSearchChange}
                  />
                </Box>
              </Box>
              <div className="multi-select-container">
                <button className="filter-btn" onClick={toggleDropdown}>
                  Assign Resource from the List
                  {/* <span className="count">{selectedMembers.length}</span> */}
                  <span className="dropdown-caret">v</span>
                </button>
                <div className="dropdown-wrapper">
                  {isDropdownOpen && (
                    <div className="modern-dropdown-container">
                      {/* Header + Search */}
                      <div className="modern-dropdown-header">
                        <input
                          type="text"
                          placeholder="Filter By Name"
                          className="modern-search-input"
                          value={dropdownSearchTerm}
                          onChange={handleDropdownSearchChange}
                        />

                        <button
                          className="modern-close-btn"
                          // onClick={() => {
                          //   setDropdownSearchTerm('');
                          //   setSelectedMembers([]);
                          //   setIsDropdownOpen(false);
                          // }}
                          onClick={handleCancelRequest}
                        >
                          ×
                        </button>
                      </div>

                      <div className="avatar-chip">
                        {/* Selected Avatars Preview */}
                        {selectedMembers.length > 0 && (
                          <div className="selected-avatars-container">
                            {selectedMembers.map((empId) => {
                              const user = userDetails.find(
                                (u) => u.emp_code === empId,
                              );
                              if (!user) return null;

                              return (
                                <div className="avatar-chip" key={empId}>
                                  <div className="tooltip-wrapper">
                                    <span className="tooltip-text">
                                      {user.user_name}
                                    </span>

                                    {/* <span className="modern-avatar avatar-photo-container">
                                      {user.profilePhoto ? (
                                        <img
                                          src={user.profilePhoto}
                                          alt={user.user_name}
                                          className="avatar-photo-img"
                                        />
                                      ) : (
                                        <span
                                          className="avatar-initial"
                                          style={{
                                            backgroundColor: getAvatarColor(
                                              user.user_name,
                                            ),
                                          }}
                                        >
                                          {getInitials(user.user_name)}
                                        </span>
                                      )}
                                    </span> */}
                                    <span className="modern-avatar avatar-photo-container">
                                      <span
                                        className="avatar-initial"
                                        style={{
                                          backgroundColor: getAvatarColor(
                                            user.user_name,
                                          ),
                                        }}
                                      >
                                        {getInitials(user.user_name)}
                                      </span>
                                    </span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>

                      {/* Resource List */}
                      <ul className="modern-dropdown-list">
                        {userDetails
                          .filter(
                            (u) =>
                              (u.user_name?.toLowerCase() ?? '').includes(
                                dropdownSearchTerm.toLowerCase(),
                              ) ||
                              (u.email_Id?.toLowerCase() ?? '').includes(
                                dropdownSearchTerm.toLowerCase(),
                              ),
                          )
                          .map((user) => (
                            <li key={user.emp_code} className="modern-item">
                              <label className="modern-item-content">
                                <input
                                  type="checkbox"
                                  checked={selectedMembers.includes(
                                    user.emp_code,
                                  )}
                                  onChange={() =>
                                    handleSelectMember(user.emp_code)
                                  }
                                  className="modern-checkbox"
                                />

                                <span className="modern-avatar avatar-photo-container">
                                  {/* {user.profilePhoto ? (
                                    <img
                                      src={user.profilePhoto}
                                      className="avatar-photo-img"
                                    />
                                  ) : (
                                    <span
                                      className="avatar-initial"
                                      style={{
                                        backgroundColor: getAvatarColor(
                                          user.user_name,
                                        ),
                                      }}
                                    >
                                      {getInitials(user.user_name)}
                                    </span>
                                  )} */}
                                  <span
                                    className="avatar-initial"
                                    style={{
                                      backgroundColor: getAvatarColor(
                                        user.user_name,
                                      ),
                                    }}
                                  >
                                    {getInitials(user.user_name)}
                                  </span>
                                </span>

                                <div className="modern-user-info">
                                  <span className="modern-name">
                                    {user.user_name}
                                  </span>
                                  {user.email_Id && (
                                    <span className="modern-email">
                                      {user.email_Id}
                                    </span>
                                  )}
                                </div>
                              </label>
                            </li>
                          ))}
                      </ul>

                      {/* Footer Buttons */}
                      <div className="modern-footer">
                        <button
                          className="modern-btn resource-dropdown outline"
                          // onClick={() => {
                          //   setDropdownSearchTerm('');
                          //   setSelectedMembers([]);
                          //   setIsDropdownOpen(false);
                          // }}
                          onClick={handleCancelRequest}
                        >
                          Cancel
                        </button>

                        <button
                          className="modern-btn primary"
                          onClick={handleAddTeamMembers}
                          disabled={isReadOnly || isSubmitting}
                        >
                          {isSubmitting ? <TimeSnapLoader variant="inline" size="sm" /> : 'Add'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* ================= CONFIRMATION POPUP ================= */}
                {showCancelConfirm && (
                  <div className="confirm-overlay">
                    <div className="confirm-modal">
                      <h3 className="confirm-title">
                        Cancel Employee Selection
                      </h3>

                      <p className="confirm-message">
                        {/* Selected resources will be cleared.
        <br /> */}
                        Do you want to cancel the Selected Employees?
                      </p>

                      <div className="confirm-actions">
                        <button
                          className="confirm-btn cancel"
                          onClick={() => setShowCancelConfirm(false)}
                        >
                          Cancel
                        </button>

                        <button
                          className="confirm-btn delete"
                          onClick={() => {
                            setShowCancelConfirm(false);
                            closeDropdownImmediately();
                          }}
                        >
                          Continue
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </Flex>
            {/* AG Grid Table */}

            <Box>
              <div
                className="ag-theme-alpine list-table-grid content-surface editproject-grid resource-grid"
                style={{
                  minHeight: 280,
                  width: '100%',
                  position: 'relative',
                }}
              >
                {loading && (
                  <Center
                    position="absolute"
                    top="0"
                    left="0"
                    right="0"
                    bottom="0"
                    bg="rgba(255, 255, 255, 0.7)"
                    zIndex={10}
                  >
                    <TimeSnapLoader size="lg" text="Loading members..." />
                  </Center>
                )}
                <AgGridReact
                  rowData={filteredProjectMembers}
                  columnDefs={resourceColumnDefs}
                  defaultColDef={{
                    flex: 1,
                    minWidth: 100,
                    resizable: false,
                    suppressMovable: true,
                  }}
                  pagination={true}
                  paginationPageSize={10}
                  paginationPageSizeSelector={[10, 25, 50, 100]}
                  suppressMovableColumns={true}
                  suppressRowDrag={true}
                  suppressMoveWhenRowDragging={true}
                />
              </div>
            </Box>

            <AlertDialog
              isOpen={isDeleteDialogOpen}
              leastDestructiveRef={cancelRef}
              onClose={() => setIsDeleteDialogOpen(false)}
            >
              <AlertDialogOverlay>
                <AlertDialogContent>
                  <AlertDialogHeader fontSize="lg" fontWeight="bold">
                    Delete Project Member
                  </AlertDialogHeader>

                  <AlertDialogBody>
                    Are you sure you want to delete{' '}
                    <Text as="span" fontWeight="bold">
                      {memberToDelete?.userName}
                    </Text>
                    ?
                  </AlertDialogBody>

                  <AlertDialogFooter style={{ display: 'flex', gap: '10px' }}>
                    <CustomButton
                      label="Cancel"
                      onClick={() => setIsDeleteDialogOpen(false)}
                      variant="outline"
                      colorScheme="black"
                      className="common-button"
                    />
                    <CustomButton
                      label="Delete"
                      onClick={handleDelete}
                      colorScheme="red"
                      className="common-button"
                      isLoading={isSubmitting}
                    />
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialogOverlay>
            </AlertDialog>
          </TabPanel>
          {/* second Tab - Project Tasks */}
          <TabPanel p={0}>
            {/* Task Controls */}
            <Flex
              justifyContent="space-between"
              alignItems="center"
              className="editproject-controls-row"
            >
              <Box
                display="flex"
                width="400px"
                gap={4}
                mb={5}
                className="editproject-filter-left"
              >
                <Box className="list-filter-select">
                  <Dropdown
                    type="projecttaskstatus"
                    placeholder="All Status"
                    selectedValue={filters.status}
                    setSelectedValue={(value) =>
                      setFilters({ ...filters, status: value })
                    }
                  />
                </Box>
                <Box className="list-search-wrap editproject-search-wrap">
                  <Input
                    placeholder="Search..."
                    bg={inputBg}
                    size="md"
                    variant="outline"
                    borderColor="#d9e5f2"
                    focusBorderColor="#315C8C"
                    borderRadius="md"
                    className="list-search-input"
                    value={projectSearchTerm}
                    onChange={handleProjectSearchChange}
                  />
                </Box>
              </Box>
              {/* Grouping buttons for uniform styling if needed */}
              <Flex gap={2}>
                {/* <Button
                  className="main common-button xsmall"
                  onClick={handleBulkUpdate}
                  isDisabled={isReadOnly}
                // Optionally add a specific class or icon if desired
                >
                  Bulk Update
                </Button> */}
                <Button
                  className="page-primary-cta"
                  onClick={handleNewTask}
                  isDisabled={isReadOnly}
                >
                  + Add Task
                </Button>
              </Flex>
            </Flex>

            {/* Data Grid */}
            <Box>
              <div
                className="ag-theme-alpine list-table-grid content-surface editproject-grid task-grid"
                style={{
                  minHeight: 280,
                  width: '100%',
                  position: 'relative',
                }}
              >
                {isTaskLoading && (
                  <Center
                    position="absolute"
                    top="0"
                    left="0"
                    right="0"
                    bottom="0"
                    bg="rgba(255, 255, 255, 0.7)"
                    zIndex={10}
                  >
                    <TimeSnapLoader size="lg" text="Loading tasks..." />
                  </Center>
                )}
                <AgGridReact
                  columnDefs={columnDefs}
                  rowData={filteredTasks}
                  defaultColDef={{
                    flex: 1,
                    minWidth: 100,
                    resizable: false,
                    suppressMovable: true,
                  }}
                  pagination={true}
                  paginationPageSize={10}
                  paginationPageSizeSelector={[10, 25, 50, 100]}
                  suppressMovableColumns={true}
                  suppressRowDrag={true}
                  suppressMoveWhenRowDragging={true}
                  context={{ isReadOnly }}
                  reactiveCustomComponents={true}
                />
              </div>
            </Box>
            {/* Modal for Add New Task */}
            <CustomModal
              isOpen={isAddOpen}
              closeOnOverlayClick={false}
              onClose={handleAddModalClose}
              size="lg"
              blockScrollOnMount={true}
              preserveScrollBarGap={true}
              scrollBehavior="inside"
            >
              <ModalOverlay />
              <ModalContent
                className="editproject-addtask-modal"
                w="calc(100vw - 64px)"
                maxW="1480px"
                h="88vh"
                maxH="760px"
                display="flex"
                flexDirection="column"
                bg={taskModalBg}
                borderRadius="16px"
                border="1px solid"
                borderColor={taskModalBorder}
                boxShadow="xl"
                transition="all 0.3s ease"
              >
                <ModalHeader
                  className="editproject-addtask-header"
                  pb={3}
                  px={7}
                  pt={5}
                  borderBottom="1px solid"
                  borderColor={taskModalBorder}
                >
                  Add Task
                </ModalHeader>
                <ModalCloseButton onClick={handleAddModalClose} />
                <ModalBody
                  className="editproject-addtask-body"
                  bg={taskModalBg}
                  p={5}
                  overflow="hidden"
                  display="flex"
                  flexDirection="column"
                >
                  <VStack spacing={5} align="stretch" flex={1} overflow="hidden">
                    {/* <Flex gap={2} justifyContent="flex-start" p={2} bg={taskModalSurface} border="1px solid" borderColor={taskModalBorder} borderRadius="full" w="fit-content"> */}
                    {/* <Button
                        size="sm"
                        borderRadius="full"
                        px={5}
                        variant={taskCreateMode === 'single' ? 'solid' : 'outline'}
                        colorScheme={taskCreateMode === 'single' ? 'green' : 'gray'}
                        onClick={() => setTaskCreateMode('single')}
                      >
                        Single
                      </Button> */}
                    {/* <Button
                        size="sm"
                        borderRadius="full"
                        px={5}
                        variant={taskCreateMode === 'bulk' ? 'solid' : 'outline'}
                        colorScheme={taskCreateMode === 'bulk' ? 'green' : 'gray'}
                        onClick={() => setTaskCreateMode('bulk')}
                      >
                        Bulk / CSV
                      </Button> */}
                    {/* </Flex> */}
                    {/* {taskCreateMode === 'single' ? (
                      <Flex gap={0} align="start" h="480px"> */}
                    {/* Left Sidebar: Project Context */}
                    {/* <VStack
                          w="320px"
                          h="480px"
                          spacing={0}
                          align="stretch"
                          flexShrink={0}
                          borderRadius="0 0 0 12px"
                          borderRight="1px solid"
                          borderColor={taskModalBorder}
                          bg={sidebarBg}
                        > */}
                    {/* <VStack p={6} spacing={6} align="stretch" h="100%">
                            <Text fontSize="md" fontWeight="bold" color="gray.600">
                              Project Details
                            </Text>
                            
                            <VStack spacing={5} align="stretch">
                              <Box>
                                <Text fontSize="14px" fontWeight="bold" color="gray.500" mb={1}>Project Name</Text>
                                <Text fontSize="sm" fontWeight="bold" color="gray.700" noOfLines={2}>{teamData.projectName || 'N/A'}</Text>
                              </Box>
                              
                              <Box>
                                <Text fontSize="14px" fontWeight="bold" color="gray.500" mb={1}>Client</Text>
                                <Text fontSize="sm" fontWeight="bold" color="gray.700">{teamData.clientName || 'N/A'}</Text>
                              </Box>
                              
                              <Box>
                                <Text fontSize="14px" fontWeight="bold" color="gray.500" mb={1}>Project Manager</Text>
                                <Text fontSize="sm" fontWeight="bold" color="gray.700">{teamData.projectManagerName || 'N/A'}</Text>
                              </Box>
                              
                              <Box>
                                <Text fontSize="14px" fontWeight="bold" color="gray.500" mb={1}>Status</Text>
                                <Tag size="sm" colorScheme="green" variant="subtle" fontWeight="bold">
                                  {teamData.projectStatus || 'Active'}
                                </Tag>
                              </Box>
                            </VStack> */}

                    {/* <Box mt="auto" p={4} borderRadius="12px" bg="white" border="1px solid" borderColor={taskModalBorder} shadow="sm">
                              <Text fontSize="10px" color="gray.500" fontWeight="bold" mb={2} textTransform="uppercase">Quick Tip</Text>
                              <Text fontSize="xs" color="gray.600" lineHeight="tall">
                                Use meaningful names and descriptions to help your team understand the work better.
                              </Text>
                            </Box> */}
                    {/* </VStack> */}
                    {/* </VStack> */}

                    {/* Right Content: Single Task Form */}
                    {/* <VStack flex={1} align="stretch" justify="center" h="400px" overflowY="auto"> */}
                    {/* <Box maxW="750px" w="100%" mx="auto"> */}
                    {/* <VStack spacing={6} align="stretch"> */}
                    {/* <Box> */}
                    {/* <Text fontSize="lg" fontWeight="bold" color="gray.700">Add New Task</Text> */}
                    {/* <Text fontSize="sm" color="gray.500">Fill in the details below to create a single project task.</Text> */}
                    {/* </Box> */}

                    {/* <FormControl isRequired isInvalid={!!errors.task_Name}>
                                <FormLabel fontSize="sm" fontWeight="bold" color="gray.500">Task Name</FormLabel>
                                <Input
                                  placeholder="Enter Task Name"
                                  size="lg"
                                  borderRadius="10px"
                                  bg={taskModalInputBg}
                                  borderColor={taskModalInputBorder}
                                  value={newTask.task_Name}
                                  onChange={(e) => {
                                    setNewTask({ ...newTask, task_Name: e.target.value });
                                    setErrors((prev) => ({ ...prev, task_Name: '' }));
                                  }}
                                  _focus={{ borderColor: "green.500", boxShadow: "0 0 0 1px green.500" }}
                                />
                                {errors.task_Name && (
                                  <FormErrorMessage>{errors.task_Name}</FormErrorMessage>
                                )}
                              </FormControl>

                              <FormControl>
                                <FormLabel fontSize="sm" fontWeight="bold" color="gray.500">Description</FormLabel>
                                <Input
                                  placeholder="Enter Description"
                                  size="lg"
                                  borderRadius="10px"
                                  bg={taskModalInputBg}
                                  borderColor={taskModalInputBorder}
                                  value={newTask.task_Desc}
                                  rows={3}
                                  onChange={(e) =>
                                    setNewTask({ ...newTask, task_Desc: e.target.value })
                                  }
                                  _focus={{ borderColor: "green.500", boxShadow: "0 0 0 1px green.500" }}
                                />
                              </FormControl>

                              <HStack spacing={8} align="start">
                                <FormControl isInvalid={!!errors.estimated_hours} flex={1}>
                                  <FormLabel fontSize="sm" fontWeight="bold" color="gray.500">Estimated Hours</FormLabel>
                                  <Input
                                    type="text"
                                    size="lg"
                                    borderRadius="10px"
                                    value={newTask.estimated_hours}
                                    placeholder="0"
                                    bg={taskModalInputBg}
                                    borderColor={taskModalInputBorder}
                                    onFocus={() => {
                                      if (newTask.estimated_hours === '0') {
                                        setNewTask({ ...newTask, estimated_hours: '' });
                                      }
                                    }}
                                    onBlur={() => {
                                      if (newTask.estimated_hours === '') {
                                        setNewTask({ ...newTask, estimated_hours: '0' });
                                      }
                                    }}
                                    onChange={(e) => {
                                      const value = e.target.value;
                                      if (value === '') {
                                        setNewTask({ ...newTask, estimated_hours: '' });
                                        return;
                                      }
                                      if (/^\d{0,3}$/.test(value)) {
                                        setNewTask({ ...newTask, estimated_hours: value });
                                      }
                                    }}
                                    _focus={{ borderColor: "green.500", boxShadow: "0 0 0 1px green.500" }}
                                  />
                                </FormControl>
                              </HStack>

                                <FormControl display="flex" alignItems="center" width="auto">
                                  <FormLabel fontSize="sm" fontWeight="bold" color="gray.500" mb={0} mr={3}>Billable</FormLabel>
                                  <Switch
                                    size="lg"
                                    colorScheme="green"
                                    isChecked={newTask.isBillable}
                                    onChange={(e) =>
                                      setNewTask({
                                        ...newTask,
                                        isBillable: e.target.checked,
                                      })
                                    }
                                  />
                                </FormControl>
                            </VStack>
                          </Box>
                        </VStack>
                      </Flex> */}
                    {/* ) : (
                      <> */}
                    <Flex
                      className="editproject-addtask-content"
                      gap={4}
                      align="stretch"
                      flex={1}
                      flexDirection={{ base: "column", lg: "row" }}
                      overflow="hidden"
                    >
                      {/* Left Sidebar: Import Section */}
                      <VStack
                        className="editproject-addtask-left"
                        w={{ base: "100%", lg: "360px" }}
                        h="100%"
                        overflowY="auto"
                        spacing={0}
                        align="stretch"
                        flexShrink={0}
                        borderRadius={{ base: "12px", lg: "14px" }}
                        border="1px solid"
                        borderColor={taskModalBorder}
                        bg={taskModalSurface}
                        transition="all 0.3s ease"
                      >
                        <VStack p={4} spacing={3} align="stretch" flex={1}>
                          <Flex justify="space-between" align="center">
                            <FormLabel mb={0} fontSize="md" fontWeight="bold" color="gray.600">Import Tasks</FormLabel>
                            <Menu>
                              <MenuButton
                                as={Button}
                                size="sm"
                                variant="link"
                                colorScheme="green"
                                leftIcon={<Icon as={FiDownload} />}
                              >
                                Download Template
                              </MenuButton>
                              <MenuList>
                                <MenuItem onClick={() => handleDownloadTemplate('excel')}>
                                  Download Excel (.xlsx)
                                </MenuItem>
                                <MenuItem onClick={() => handleDownloadTemplate('csv')}>
                                  Download CSV (.csv)
                                </MenuItem>
                              </MenuList>
                            </Menu>
                          </Flex>

                          <FormControl flex={csvFileName ? "none" : 1} h={csvFileName ? "180px" : "auto"} display="flex" flexDirection="column" minH="180px">
                            <Input
                              id="bulk-task-csv-upload"
                              type="file"
                              accept=".csv, .xlsx"
                              onChange={handleCsvUploadEvent}
                              display="none"
                            />
                            <Box
                              as="label"
                              htmlFor="bulk-task-csv-upload"
                              onDragOver={onDragOver}
                              onDragLeave={onDragLeave}
                              onDrop={onDrop}
                              p={4}
                              display="flex"
                              flexDirection="column"
                              alignItems="center"
                              justifyContent="center"
                              cursor="pointer"
                              border="2px dashed"
                              borderColor={isDragOver ? 'green.500' : taskModalInputBorder}
                              borderRadius="12px"
                              bg={isDragOver ? 'green.50' : taskModalInputBg}
                              transition="all 0.2s ease"
                              h="100%"
                              position="relative"
                              _hover={{ borderColor: 'green.400', bg: "white" }}
                            >
                              {csvFileName && (
                                <IconButton
                                  aria-label="Clear file"
                                  icon={<FiX />}
                                  size="sm"
                                  position="absolute"
                                  top={2}
                                  right={2}
                                  variant="ghost"
                                  colorScheme="gray"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    handleClearFile();
                                  }}
                                  zIndex={2}
                                  borderRadius="full"
                                  _hover={{ color: "red.500", bg: "red.50" }}
                                />
                              )}
                              <VStack spacing={2}>
                                <Icon as={FiUploadCloud} color={isDragOver ? 'green.500' : 'gray.400'} boxSize={8} />
                                <VStack spacing={0}>
                                  <Text fontWeight="bold" fontSize="sm">
                                    {csvFileName ? 'File Ready' : 'Click or Drag File'}
                                  </Text>
                                  <Text fontSize="10px" color="gray.500" textAlign="center">
                                    {csvFileName || 'Supported: .csv, .xlsx'}
                                  </Text>
                                </VStack>
                              </VStack>
                            </Box>
                          </FormControl>

                          {csvFileName && (
                            <VStack spacing={3} align="stretch" mt={2}>
                              <Box p={3} borderRadius="12px" bg="white" border="1px solid" borderColor={taskModalBorder} shadow="sm">
                                <Text fontSize="14px" color="gray.500" fontWeight="bold" mb={2}>Import Summary</Text>
                                <HStack justify="space-between" divider={<Box w="1px" h="20px" bg="gray.100" />}>
                                  <VStack align="center" spacing={0} flex={1}>
                                    <Text fontSize="md" fontWeight="bold">{bulkSummary.total}</Text>
                                    <Text fontSize="12px" color="gray.400" fontWeight="bold">Total</Text>
                                  </VStack>
                                  <VStack align="center" spacing={0} flex={1}>
                                    <Text fontSize="md" fontWeight="bold" color="green.600">{bulkSummary.valid}</Text>
                                    <Text fontSize="12px" color="green.500" fontWeight="bold">Valid</Text>
                                  </VStack>
                                  <VStack align="center" spacing={0} flex={1}>
                                    <Text fontSize="md" fontWeight="bold" color="orange.600">{bulkSummary.conflicts}</Text>
                                    <Text fontSize="12px" color="orange.500" fontWeight="bold">Conflicts</Text>
                                  </VStack>
                                </HStack>
                              </Box>

                              {/* <Box pt={2}>
                                <FormLabel fontSize="14px" fontWeight="bold" mb={2} color="gray.500">Conflict Strategy</FormLabel>
                                <Select
                                  size="sm"
                                  variant="outline"
                                  borderRadius="8px"
                                  value={conflictStrategy}
                                  onChange={(e) => setConflictStrategy(e.target.value)}
                                  bg="white"
                                  borderColor={taskModalInputBorder}
                                  _hover={{ borderColor: "green.400" }}
                                  _focus={{ borderColor: "green.500", boxShadow: "0 0 0 1px green.500" }}
                                >
                                  <option value="Skip">Skip Existing</option>
                                  <option value="Overwrite">Overwrite Existing</option>
                                </Select>
                              </Box> */}
                            </VStack>
                          )}
                          {isSubmitting && <Progress size="xs" isIndeterminate colorScheme="green" borderRadius="full" mt={2} />}
                        </VStack>
                      </VStack>

                      {/* Right Section: Task Preview Table */}
                      <VStack
                        className="editproject-addtask-right"
                        flex={1}
                        spacing={4}
                        align="stretch"
                        px={{ base: 2, md: 3, lg: 4 }}
                        pt={{ base: 3, md: 3, lg: 3 }}
                        pb={{ base: 3, md: 3, lg: 4 }}
                        overflow="hidden"
                        display="flex"
                        flexDirection="column"
                        h="100%"
                      >
                        <Flex justifyContent="space-between" alignItems="center" flexShrink={0}>
                          <Text fontWeight="bold" fontSize="md" color="gray.700">Preview & Edit Rows</Text>
                          <Button
                            size="sm"
                            colorScheme="green"
                            variant="solid"
                            leftIcon={<Icon as={FiEdit2} />}
                            borderRadius="full"
                            px={4}
                            onClick={handleAddBulkTaskRow}
                          >
                            Add Row
                          </Button>
                        </Flex>

                        <Box
                          flex={1}
                          overflowY="auto"
                          border="1px solid"
                          borderColor={taskModalBorder}
                          borderRadius="12px"
                          bg="white"
                          position="relative"
                          sx={{
                            '&::-webkit-scrollbar': {
                              width: '6px',
                            },
                            '&::-webkit-scrollbar-track': {
                              background: 'transparent',
                            },
                            '&::-webkit-scrollbar-thumb': {
                              background: scrollbarThumbBg,
                              borderRadius: '2px',
                            },
                          }}
                        >
                          <Box
                            display="grid"
                            gridTemplateColumns="1.2fr 1.6fr 100px 80px 80px"
                            gap={3}
                            px={4}
                            py={3}
                            alignItems="center"
                            position="sticky"
                            top="0"
                            zIndex={2}
                            bg={tableHeaderBg}
                            borderBottom="1px solid"
                            borderColor={taskModalBorder}
                          >
                            <Text fontSize="14px" fontWeight="bold" color="gray.600">Task Name<span style={{ color: 'red' }}>*</span></Text>
                            <Text fontSize="14px" fontWeight="bold" color="gray.600">Description</Text>
                            <Text fontSize="14px" fontWeight="bold" color="gray.600" textAlign="center">Hours</Text>
                            <Text fontSize="14px" fontWeight="bold" color="gray.600" textAlign="center">Billable</Text>
                            <Text fontSize="14px" fontWeight="bold" color="gray.600" textAlign="center">Action</Text>
                          </Box>

                          <Box px={{ base: 2, md: 3 }} py={{ base: 2, md: 3 }}>
                            {bulkTaskRows.map((row) => {
                              const isProjectConflict = !row.rowError && tasks.some(t => t.taskName?.trim().toLowerCase() === row.task_Name?.trim().toLowerCase());
                              return (
                                <Box
                                  key={row.rowId}
                                  mb={1}
                                  p={1}
                                  border="1px solid "
                                  borderColor={row.rowError ? 'red.200' : isProjectConflict ? 'orange.200' : 'transparent'}
                                  borderRadius="8px"
                                  bg={row.rowError ? 'red.50' : isProjectConflict ? 'orange.50' : 'transparent'}
                                  _hover={{ bg: row.rowError ? 'red.50' : isProjectConflict ? 'orange.50' : 'gray.50' }}
                                >
                                  <Box
                                    display="grid"
                                    gridTemplateColumns="1.2fr 1.6fr 100px 80px 80px"
                                    gap={3}
                                    alignItems="center"
                                  >
                                    <Input
                                      id={`bulk-task-name-${row.rowId}`}
                                      size="sm"
                                      placeholder="Task name"
                                      bg="white"
                                      borderColor={row.rowError ? 'red.300' : taskModalInputBorder}
                                      value={row.task_Name}
                                      onChange={(e) => handleBulkRowChange(row.rowId, 'task_Name', e.target.value)}
                                    />
                                    <Input
                                      size="sm"
                                      placeholder="Description"
                                      bg="white"
                                      borderColor={taskModalInputBorder}
                                      value={row.task_Desc}
                                      onChange={(e) => handleBulkRowChange(row.rowId, 'task_Desc', e.target.value)}
                                    />
                                    <Input
                                      size="sm"
                                      textAlign="center"
                                      bg="white"
                                      borderColor={taskModalInputBorder}
                                      value={row.estimated_hours}
                                      onFocus={() => {
                                        if (row.estimated_hours === '0') {
                                          handleBulkRowChange(row.rowId, 'estimated_hours', '');
                                        }
                                      }}
                                      onBlur={() => {
                                        if (row.estimated_hours === '') {
                                          handleBulkRowChange(row.rowId, 'estimated_hours', '0');
                                        }
                                      }}
                                      onChange={(e) => {
                                        handleBulkRowChange(
                                          row.rowId,
                                          'estimated_hours',
                                          e.target.value
                                        );
                                      }}
                                    />
                                    <Flex justify="center">
                                      <Switch
                                        size="sm"
                                        colorScheme="green"
                                        isChecked={row.isBillable}
                                        onChange={(e) => handleBulkRowChange(row.rowId, 'isBillable', e.target.checked)}
                                      />
                                    </Flex>
                                    <Flex justify="center">
                                      <IconButton
                                        aria-label="Delete row"
                                        size="xs"
                                        icon={<FiTrash2 />}
                                        variant="ghost"
                                        colorScheme="red"
                                        onClick={() => handleRemoveBulkRow(row.rowId)}
                                      />
                                    </Flex>
                                  </Box>
                                  {(row.rowError || isProjectConflict) && (
                                    <Text mt={1} px={1} fontSize="10px" color={row.rowError ? 'red.600' : 'orange.700'}>
                                      {row.rowError || 'Already exists.'}
                                    </Text>
                                  )}
                                </Box>
                              );
                            })}
                          </Box>
                        </Box>
                      </VStack>
                    </Flex>
                    {/* </>
                    )} */}
                  </VStack>
                </ModalBody>

                <ModalFooter
                  className="editproject-addtask-footer"
                  bg={taskModalBg}
                  px={7}
                  py={4}
                  borderTop="1px solid"
                  borderColor={taskModalBorder}
                >
                  <Flex gap={3} justify="flex-end" w="100%">
                    <CustomButton
                      label="Cancel"
                      onClick={handleAddModalClose}
                      variant="outline"
                      colorScheme="black"
                      className="common-button"
                    />
                    <CustomButton
                      label={taskCreateMode === 'bulk' ? 'Save All' : 'Save'}
                      onClick={handleBulkAssignTask}
                      colorScheme="green"
                      className="common-button"
                      isLoading={isSubmitting}
                    />
                  </Flex>
                </ModalFooter>
              </ModalContent>
            </CustomModal>

            {/* Confirm Upload Dialog */}
            <AlertDialog
              isOpen={showUploadConfirm}
              leastDestructiveRef={cancelRef}
              onClose={cancelUpload}
            >
              <AlertDialogOverlay>
                <AlertDialogContent>
                  <AlertDialogHeader fontSize="lg" fontWeight="bold">
                    Import Tasks
                  </AlertDialogHeader>
                  <AlertDialogBody>
                    You have unsaved changes. Importing a file will discard them. Do you want to continue?
                  </AlertDialogBody>
                  <AlertDialogFooter>
                    <Flex gap={3}>
                      <CustomButton
                        label="No"
                        onClick={cancelUpload}
                        variant="outline"
                        colorScheme="black"
                      />
                      <CustomButton
                        label="Yes"
                        onClick={confirmUpload}
                        colorScheme="green"
                      />
                    </Flex>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialogOverlay>
            </AlertDialog>

            {/* Modal for Edit Task */}
            <CustomModal
              isOpen={isEditOpen}
              closeOnOverlayClick={false}
              onClose={() => setIsEditOpen(false)}
              size="md"
            >
              <ModalOverlay />
              <ModalContent
                className="editproject-edit-task-modal"
                w="calc(100vw - 40px)"
                maxW="760px"
                borderRadius="18px"
              >
                <ModalHeader pb={2}>Edit Task</ModalHeader>
                <ModalCloseButton />
                <ModalBody pb={4}>
                  <VStack spacing={3.5}>
                    {/* Team Name (Read-Only) */}
                    <FormControl>
                      <FormLabel>Task Name</FormLabel>
                      <Input
                        type="text"
                        value={taskToEdit?.taskName || ''}
                        isReadOnly
                      />
                    </FormControl>

                    <FormControl isInvalid={!!taskToEdit?.error}>
                      <FormLabel>Estimated Hours</FormLabel>

                      <Input
                        type="text"
                        value={taskToEdit.estimatedHours}
                        onFocus={() => {
                          if (taskToEdit.estimatedHours === '0') {
                            setTaskToEdit({
                              ...taskToEdit,
                              estimatedHours: '',
                            });
                          }
                        }}
                        onBlur={() => {
                          if (taskToEdit.estimatedHours === '') {
                            setTaskToEdit({
                              ...taskToEdit,
                              estimatedHours: '0',
                            });
                          }
                        }}
                        onChange={(e) => {
                          const value = e.target.value;

                          if (value === '') {
                            setTaskToEdit({
                              ...taskToEdit,
                              estimatedHours: '',
                            });
                            return;
                          }

                          // âœ… integers only
                          if (/^\d{0,3}$/.test(value)) {
                            setTaskToEdit({
                              ...taskToEdit,
                              estimatedHours: value,
                              error: '',
                            });
                          }
                        }}
                      />
                    </FormControl>
                    {/* Status Dropdown */}
                    <FormControl isRequired>
                      <FormLabel>Status</FormLabel>
                      <Dropdown
                        type="projecttaskstatus"
                        placeholder="Select status"
                        selectedValue={taskToEdit.statusId || ''}
                        setSelectedValue={(value) =>
                          setTaskToEdit({
                            ...taskToEdit,
                            statusId: value,
                          })
                        }
                      />
                    </FormControl>
                    <Box display="flex" alignItems="center" width="100%">
                      <Text fontSize="md">Billable Task</Text>
                      <Switch
                        marginLeft={2}
                        isChecked={taskToEdit.isBillable}
                        onChange={(e) =>
                          setTaskToEdit({
                            ...taskToEdit,
                            isBillable: e.target.checked,
                          })
                        }
                      />
                    </Box>
                  </VStack>
                </ModalBody>

                <ModalFooter pt={4}>
                  <Flex gap={4} justify="flex-end" mt={3}>
                    <CustomButton
                      label="Cancel"
                      onClick={() => setIsEditOpen(false)}
                      variant="outline"
                      colorScheme="black"
                      className="common-button"
                    />
                    <CustomButton
                      label="Save"
                      onClick={handleSaveTask}
                      colorScheme="green"
                      className="common-button"
                      isLoading={isSubmitting}
                    />
                  </Flex>
                </ModalFooter>
              </ModalContent>
            </CustomModal>

            {/* Delete Confirmation Modal */}
            <AlertDialog
              isOpen={deleteDisclosure.isOpen}
              leastDestructiveRef={cancelRef}
              closeOnOverlayClick={false}
              onClose={deleteDisclosure.onClose}
            >
              <AlertDialogOverlay>
                <AlertDialogContent>
                  <AlertDialogHeader fontSize="lg" fontWeight="bold">
                    <Flex justify="space-between" align="center">
                      Delete Task
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={deleteDisclosure.onClose}
                        isDisabled={isReadOnly}
                        _hover={{ bg: 'transparent' }}
                      >
                        ×
                      </Button>
                    </Flex>
                  </AlertDialogHeader>

                  <AlertDialogBody>
                    Are you sure you want to delete "{taskToDelete?.taskName}"
                  </AlertDialogBody>

                  <AlertDialogFooter>
                    <Flex gap={4} justify="flex-end" mt={3}>
                      <CustomButton
                        label="Cancel"
                        onClick={deleteDisclosure.onClose}
                        variant="outline"
                        colorScheme="black"
                        className="common-button"
                      />
                      <CustomButton
                        label="Delete"
                        isDisabled={isReadOnly}
                        onClick={confirmDelete}
                        colorScheme="red"
                        className="common-button"
                        isLoading={isSubmitting}
                      />
                    </Flex>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialogOverlay>
            </AlertDialog>
            {/* Bulk Update Modal */}
            <CustomModal
              isOpen={isBulkOpen}
              closeOnOverlayClick={false}
              onClose={handleBulkCancel}
              size="6xl"
            >
              <ModalOverlay />
              <ModalContent>
                <ModalHeader>
                  <Flex justify="space-between" align="center">
                    <Text>Bulk Update Tasks</Text>
                    <Button
                      variant="solid"
                      colorScheme="blue"
                      size="sm"
                      onClick={handleAddBulkRow}
                      leftIcon={<i className="fas fa-plus"></i>}
                    >
                      Add Row
                    </Button>
                  </Flex>
                </ModalHeader>
                <ModalCloseButton onClick={handleBulkCancel} />
                <ModalBody>
                  <Box height="400px" width="100%" className="ag-theme-alpine">
                    <AgGridReact
                      rowData={bulkTasks}
                      columnDefs={bulkColumnDefs}
                      defaultColDef={{
                        flex: 1,
                        minWidth: 100,
                        resizable: true,
                        suppressMovable: true,
                      }}
                      onCellValueChanged={() => setIsBulkDirty(true)}
                    />
                  </Box>
                </ModalBody>
                <ModalFooter>
                  <Flex gap={4} justify="flex-end">
                    <CustomButton
                      label="Cancel"
                      onClick={handleBulkCancel}
                      variant="outline"
                      colorScheme="black"
                      className="common-button"
                    />
                    <CustomButton
                      label="Save"
                      onClick={handleBulkSave}
                      colorScheme="green"
                      className="common-button"
                      isDisabled={bulkTasks.length === 0}
                    />
                  </Flex>
                </ModalFooter>
              </ModalContent>
            </CustomModal>

            {/* Bulk Save Confirmation */}
            <AlertDialog
              isOpen={showBulkSaveConfirm}
              leastDestructiveRef={cancelRef}
              onClose={() => setShowBulkSaveConfirm(false)}
            >
              <AlertDialogOverlay>
                <AlertDialogContent>
                  <AlertDialogHeader fontSize="lg" fontWeight="bold">
                    Save Bulk Tasks
                  </AlertDialogHeader>
                  <AlertDialogBody>
                    Are you sure you want to save all tasks?
                  </AlertDialogBody>
                  <AlertDialogFooter>
                    <Flex gap={3}>
                      <CustomButton
                        label="No"
                        onClick={() => setShowBulkSaveConfirm(false)}
                        variant="outline"
                        colorScheme="black"
                      />
                      <CustomButton
                        label="Yes, Save"
                        onClick={confirmBulkSave}
                        colorScheme="green"
                      />
                    </Flex>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialogOverlay>
            </AlertDialog>

            {/* Bulk Cancel Confirmation */}
            <AlertDialog
              isOpen={showBulkCancelConfirm}
              leastDestructiveRef={cancelRef}
              onClose={() => setShowBulkCancelConfirm(false)}
            >
              <AlertDialogOverlay>
                <AlertDialogContent>
                  <AlertDialogHeader fontSize="lg" fontWeight="bold">
                    Cancel Bulk Update
                  </AlertDialogHeader>
                  <AlertDialogBody>
                    You have unsaved changes. Are you sure you want to cancel?
                  </AlertDialogBody>
                  <AlertDialogFooter>
                    <Flex gap={3}>
                      <CustomButton
                        label="No"
                        onClick={() => setShowBulkCancelConfirm(false)}
                        variant="outline"
                        colorScheme="black"
                      />
                      <CustomButton
                        label="Yes, Cancel"
                        onClick={confirmBulkCancel}
                        colorScheme="red"
                      />
                    </Flex>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialogOverlay>
            </AlertDialog>
          </TabPanel>
        </TabPanels>
      </Tabs >
    </Box >
  );
};

export default EditprojectGrid;



