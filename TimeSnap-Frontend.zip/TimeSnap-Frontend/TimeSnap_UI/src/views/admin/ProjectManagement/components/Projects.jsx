import React, { useState, useEffect, useRef } from 'react';
import {
  // Import API functions
  fetchProjectManagementDatas,
  addProject,
  deleteProject,
  updateProject,
} from 'utils/api';
import Dropdown from 'components/Dropdown/Dropdown';
import { statusColorScheme } from 'utils/constants';
import { clearGridFocus } from 'utils/gridUtils';

import './Project.css';
import { useCustomToast } from 'utils/toastUtils';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import CustomButton from 'components/button/CustomButton';
import CustomIconButton from 'components/button/CustomIconButton';
import {
  Button,
  Flex,
  Heading,
  Input,
  Tag,
  Box,
  useDisclosure,
  Modal,
  IconButton,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  useToast,
  Text,
  InputGroup,
  FormControl,
  FormLabel,
  HStack,
  Tooltip,
  SimpleGrid,
  FormErrorMessage,
} from '@chakra-ui/react';
import {
  validateAlphanumericInput,
  projectValidateAlphanumeric,
  ValidateProjectNameField,
} from 'utils/constants';
import EditprojectGrid from './Editproject';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import Editproject from './Editproject';
import { FaUsers } from 'react-icons/fa';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import ProjectAnalyticReport from './ProjectAnalyticReport';
import { useLoader } from 'contexts/LoaderContext';
import CustomModal from 'components/modal/CustomModal';
import TimeSnapLoader from '../../../../components/loaders/TimeSnapLoader';

const Projects = () => {
  const showToast = useCustomToast();
  // Modal control states
  const {
    isOpen: isAddModalOpen,
    onOpen: onAddModalOpen,
    onClose: onAddModalClose,
  } = useDisclosure();
  const {
    isOpen: isViewModalOpen,
    onOpen: onViewmodalOpen,
    onClose: onViewModalClose,
  } = useDisclosure();
  const {
    isOpen: isDeleteModalOpen,
    onOpen: onDeleteModalOpen,
    onClose: onDeleteModalClose,
  } = useDisclosure();
  // Initial state for a new project
  const initialProjectState = {
    name: '',
    clientId: '',
    projectCategoryId: '',
    departmentId: '',
    managerId: '',
    // status: 5,
    progress: 0,
    startDate: '',
    dueDate: '',
    color: '',
    selectedTeams: [],
    availableTeams: [],
  };
  const [isReadOnly, setIsReadOnly] = useState(false);

  useEffect(() => {
    const accessDetailsString = localStorage.getItem('accessDetails');
    if (accessDetailsString) {
      try {
        const accessDetails = JSON.parse(accessDetailsString);
        const screenAccess = accessDetails.find(
          (screen) => screen.screenId === 103,
        );
        if (screenAccess) {
          setIsReadOnly(screenAccess.readOnly === 1);
        }
      } catch (error) {
        console.error('Invalid accessDetails format in localStorage');
      }
    }
  }, []);
  const gridRef = useRef(null);

  const [newProject, setNewProject] = useState(initialProjectState);
  const handleModalClose = () => {
    setNewProject(initialProjectState);
    onAddModalClose();
    setErrors({});
  };
  const toast = useToast();
  const [editingProject, setEditingProject] = useState({
    projectName: '',
    projectId: null,
    departmentId: '',
    statusId: '',
    managerId: [],
  });

  const {
    isOpen: isEditModalOpen,
    onOpen: onEditModalOpen,
    onClose: onEditModalClose,
  } = useDisclosure();
  const { showGlobalLoader, hideGlobalLoader, isGlobalLoading } = useLoader();
  const [activeView, setActiveView] = useState('Projects');
  const [projects, setProjects] = useState([]);
  const [nameError, setNameError] = useState('');
  const [selectedProject, setSelectedProject] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [selectedTeams, setSelectedTeams] = useState([]);
  const [selectedManager, setSelectedManager] = useState('');
  const [projectToEdit, setProjectToEdit] = useState('');
  const [errors, setErrors] = useState({});
  const [isGridLoading, setIsGridLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [filters, setFilters] = useState({
    department: '',
    status: '',
    search: '',
  });
  const validateProjectName = (name) => {
    return !name.includes(' ');
  };
  // Fetch data from the GET API
  useEffect(() => {
    const fetchProjects = async () => {
      showGlobalLoader();
      try {
        const data = await fetchProjectManagementDatas();
        setProjects(data);
        console.log(data);
      } catch (error) {
        showToast('error', error.message);
      } finally {
        hideGlobalLoader();
      }
    };
    // Fetch projects when modal closes or when returning to Projects view
    if (!isAddModalOpen && activeView === 'Projects') {
      fetchProjects();
    }
  }, [toast, isAddModalOpen, activeView]); // Add activeView to dependency array

  useEffect(() => {
    if (
      activeView === 'Projects' &&
      (filters.department || filters.status || filters.search)
    ) {
      setFilters({
        department: '',
        status: '',
        search: '',
      });
    }
  }, [activeView]);

  const handleAddModalOpen = () => {
    setNewProject(initialProjectState);
    onAddModalOpen();
  };

  const handleEditModalOpen = (project) => {
    console.log('---- OPEN EDIT MODAL ----');
    console.log('RAW project:', project);

    // The backend sends managerIds → we rename and use it
    const managerIdsArray = Array.isArray(project.managerIds)
      ? project.managerIds
      : [];

    console.log('Manager IDs extracted from API:', managerIdsArray);

    setEditingProject({
      projectId: project.projectId,
      projectName: project.projectName,
      departmentId: project.departmentId,
      statusId: project.status_Id ?? project.statusId,
      managerId: managerIdsArray, // <-- Correct mapping
    });
    setErrors({});

    console.log('EditingProject AFTER set:', {
      projectId: project.projectId,
      projectName: project.projectName,
      departmentId: project.departmentId,
      statusId: project.status_Id ?? project.statusId,
      managerId: managerIdsArray,
    });

    onEditModalOpen();
  };

  // function to update project data
  const handleUpdateProject = async () => {
    const hasManager =
      Array.isArray(editingProject.managerId) &&
      editingProject.managerId.length > 0;
    if (!hasManager) {
      setErrors((prev) => ({
        ...prev,
        managerId: 'Manager selection is required.',
      }));
      return;
    }

    setIsSubmitting(true);
    try {
      const updateData = {
        Department_Id: parseInt(editingProject.departmentId),
        Status_Id: parseInt(editingProject.statusId),
        managers: editingProject.managerId,
      };
      await updateProject(editingProject.projectId, updateData);
      setTimeout(async () => {
        const data = await fetchProjectManagementDatas(updateData);
        setProjects(data);
        clearGridFocus(gridRef); // Prevent tooltip from sticking on first row
      }, 100);

      showToast(
        'success',
        `The project "${editingProject.projectName}" has been updated successfully.`,
      );

      onEditModalClose();
      setFilters({
        department: '',
        status: '',
        search: '',
      });
    } catch (error) {
      showToast('warning', `${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };
  useEffect(() => {
    // Disable scroll on the body
    document.body.style.overflow = 'hidden';

    // Clean up: Restore the scroll when the component unmounts
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, []);
  // function for fiters based on department,status,projectname
  const filteredProjects = projects.filter((project) => {
    const matchDepartment =
      !filters.department ||
      project.departmentId.toString() === filters.department.toString();

    const matchStatus =
      !filters.status ||
      project.status_Id.toString() === filters.status.toString();

    const matchSearch =
      !filters.search ||
      project.projectName?.toLowerCase().includes(filters.search.toLowerCase());

    return matchStatus && matchDepartment && matchSearch;
  });
  // function for add new project
  const handleAddProject = async () => {
    let newErrors = {};

    // Required Fields Validation
    if (!newProject.name.trim()) newErrors.name = 'Project Name is required.';
    else if (!ValidateProjectNameField(newProject.name)) {
      newErrors.name =
        'Project name must contain at least one character or number.';
    }

    if (!newProject.clientId)
      newErrors.clientId = 'Client selection is required.';
    if (!newProject.projectCategoryId)
      newErrors.projectCategoryId = 'Project Category is required.';
    if (!newProject.departmentId)
      newErrors.departmentId = 'Department selection is required.';
    if (!newProject.managerId)
      newErrors.managerId = 'Manager selection is required.';
    if (!newProject.color) newErrors.color = 'Color selection is required.';
    if (!newProject.startDate) newErrors.startDate = 'Start Date is required.';

    // Due Date Validation
    if (newProject.startDate && newProject.dueDate) {
      const startDate = new Date(newProject.startDate);
      const dueDate = new Date(newProject.dueDate);
      if (dueDate < startDate) {
        newErrors.dueDate = 'Due Date must be after Start Date.';
      }
    }

    // Update the errors state
    setErrors(newErrors);

    // If errors exist, stop form submission
    if (Object.keys(newErrors).length > 0) return;

    // Proceed with form submission if no errors
    try {
      setIsSubmitting(true);
      const projectPayload = {
        project_name: newProject.name,
        client_Id: newProject.clientId,
        projectCategoryId: newProject.projectCategoryId,
        start_date: newProject.startDate,
        due_date: newProject.dueDate || null,
        department_Id: newProject.departmentId,
        // status_Id: newProject.status || 1,
        managers: newProject.managerId,
        color_Code: newProject.color || null,
      };

      await addProject(projectPayload);
      const data = await fetchProjectManagementDatas();
      setProjects(data);
      showToast(
        'success',
        `Project "${newProject.name}" has been added successfully.`,
      );

      // Reset Form and Errors
      setNewProject({
        name: '',
        clientId: '',
        projectCategoryId: '',
        startDate: '',
        dueDate: '',
        departmentId: '',
        status: '',
        managerId: '',
        color: '',
      });

      setErrors({});
      onAddModalClose();
    } catch (error) {
      // Get the specific error message from the API response if available
      let errorMessage;

      if (error.response && error.response.data) {
        // If the error response contains a specific message
        errorMessage =
          typeof error.response.data === 'string'
            ? error.response.data
            : error.response.data.message ||
              'Failed to add Project. Please try again.';
      } else if (error.message) {
        // If the error object itself has a message
        errorMessage = error.message;
      } else {
        // Default fallback message
        errorMessage = 'Failed to add Project. Please try again.';
      }

      showToast('error', errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };
  // function for delete project
  // function for delete project
  const handleDeleteProject = async () => {
    setIsSubmitting(true);
    try {
      await deleteProject(selectedProject.projectId);

      setTimeout(async () => {
        const data = await fetchProjectManagementDatas();
        setProjects(data);
        clearGridFocus(gridRef); //  Fix auto-tooltip/focus
      }, 100);
      showToast(
        'success',
        `The "${selectedProject?.projectName}" has been deleted successfully.`,
      );
      onDeleteModalClose();
      setFilters({
        department: '',
        status: '',
        search: '',
      });
    } catch (error) {
      showToast(
        'warning',
        error.message || 'Failed to delete Project. Please try again.',
      );
      onDeleteModalClose();
      setFilters({
        department: '',
        status: '',
        search: '',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditViewDetails = (project) => {
    const isActive = project.statusId === 1 || project.status_Id === 1;

    setSelectedProject({
      projectId: project.projectId,

      projectName: project.projectName,

      managerId: project.manager_id,

      clientName: project.clientName,

      projectManagers: project.projectManagers,

      projectStatus: project.projectStatus,

      isActive: isActive,
    });

    setActiveView('Editproject');
  };

  // const handleViewAnalytics = (project) => {
  //   console.log('Clicked project row:', project);

  //   if (!project || !project.projectId) {
  //     console.error('Invalid project object:', project);
  //     return;
  //   }

  //   setSelectedProject({
  //     projectId: project.projectId, // ✅ CORRECT
  //     projectName: project.projectName, // ✅ CORRECT
  //   });

  //   setActiveView('ProjectAnalytics');
  // };

  const handleBackToManagement = () => {
    setActiveView('Projects');
    setSearchTerm('');
    setSelectedStatus('');
    setSelectedDepartment('');
    setSelectedFilter('');
  };

  const getStatusBadgeClass = (value = '') => {
    const normalized = value.toString().toLowerCase();
    if (normalized.includes('active')) return 'status-active';
    if (normalized.includes('inactive')) return 'status-inactive';
    if (normalized.includes('progress') || normalized.includes('pending')) return 'status-progress';
    if (normalized.includes('complete')) return 'status-completed';
    return '';
  };

  const columns = [
    {
      headerName: 'Project Name',
      field: 'projectName',
      sortable: true,
    },
    {
      headerName: 'Department',
      field: 'departmentName',
      sortable: true,
    },
    {
      headerName: 'Status',
      field: 'projectStatus',
      cellRenderer: ({ value }) => (
        <Tag className={`Badge-lables status-pill ${getStatusBadgeClass(value)}`} colorScheme={statusColorScheme[value]}>
          {value}
        </Tag>
      ),
    },

    {
      headerName: 'Actions',
      cellRenderer: (params) => (
        <Box display="flex" justifyContent="left">
          {/* View Project details button */}
          <CustomIconButton
            iconClass="fas fa-user-plus"
            tooltip="Assign Task & Resources"
            onClick={() => handleEditViewDetails(params.data)}
          />
          {/* Edit Project button */}
          <CustomIconButton
            iconClass="fas fa-edit"
            tooltip="Edit Project"
            onClick={() => handleEditModalOpen(params.data)}
            isDisabled={isReadOnly}
          />
          {/* Delete Project button */}
          <CustomIconButton
            iconClass="fas fa-trash"
            tooltip="Delete Project"
            onClick={() => {
              setSelectedProject(params.data);
              onDeleteModalOpen();
            }}
            isDisabled={isReadOnly}
          />
          {/* View Analytics */}
          {/* <CustomIconButton
            iconClass="fas fa-eye"
            tooltip="View Project Analytics"
            onClick={() => handleViewAnalytics(params.data)}
          /> */}
        </Box>
      ),
    },
  ];

  return (
    <div>
      {activeView === 'Projects' && (
        <Box className="list-table-page">
          <ToastContainer />
          <Flex className="page-header-zone">
            <Heading className="page-title">Project</Heading>
            <Button
              className="page-primary-cta"
              onClick={handleAddModalOpen}
              isDisabled={isReadOnly}
              size="sm"
              minW="unset"
              width="auto"
            >
              Add
            </Button>
          </Flex>
          <Flex className="list-filter-bar" width="100%">
            {/* Left Side Filters */}
            <Flex gap={3} align="center">
              {/* Department Dropdown */}
              <Box className="list-filter-select">
                <Dropdown
                  type="departments"
                  placeholder="All Departments"
                  selectedValue={filters.department}
                  setSelectedValue={(value) =>
                    setFilters({ ...filters, department: value })
                  }
                />
              </Box>

              {/* Project Status Dropdown */}
              <Box className="list-filter-select">
                <Dropdown
                  type="projectstatus"
                  placeholder="All Status"
                  selectedValue={filters.status}
                  setSelectedValue={(value) =>
                    setFilters({ ...filters, status: value })
                  }
                />
              </Box>

              {/* Search Box - Reduced Size */}
              <Box className="list-search-wrap">
                <Input
                  className="list-search-input"
                  placeholder="Search..."
                  size="sm"
                  variant="outline"
                  value={filters.search}
                  onChange={(e) => {
                    const value = e.target.value;
                    if (projectValidateAlphanumeric(value)) {
                      setFilters({ ...filters, search: value });
                    }
                  }}
                />
              </Box>
            </Flex>
          </Flex>
          {/* Ag Grid */}
          <div
            className="ag-theme-alpine list-table-grid content-surface"
            style={{ width: '100%', position: 'relative' }}
          >
            <AgGridReact
              rowData={filteredProjects}
              suppressNoRowsOverlay={isGlobalLoading || isGridLoading}
              columnDefs={columns}
              defaultColDef={{
                flex: 1,
                minWidth: 100,
                resizable: false,
                suppressMovable: true,
              }}
              suppressDragLeaveHidesColumns={true}
              suppressRowDrag={true}
              suppressMoveWhenRowDragging={true}
              pagination={true}
              paginationPageSize={10}
              paginationPageSizeSelector={[10, 25, 50, 100]}
            />
            {isGridLoading && (
              <Box
                position="absolute"
                top="0"
                left="0"
                right="0"
                bottom="0"
                bg="whiteAlpha.600"
                zIndex="10"
                display="flex"
                alignItems="center"
                justifyContent="center"
              >
                <TimeSnapLoader size="lg" text="Loading projects..." />
              </Box>
            )}
          </div>
        </Box>
      )}
      {/* {activeView === 'Editproject' && (
        <EditprojectGrid
          projectId={selectedProject.projectId}
          projectName={selectedProject.projectName}
          managerId={selectedProject.manager_id} // Passing manager_id
          projectStatus={selectedProject.projectStatus} // Passing projectStatus
          onBack={handleBackToManagement}
        />
      )} */}

      {activeView === 'Editproject' && selectedProject && (
        <>
          {console.log('Passing to EditprojectGrid:', selectedProject)}
          <EditprojectGrid
            projectId={selectedProject.projectId}
            projectName={selectedProject.projectName}
            managerId={selectedProject.managerId}
            clientName={selectedProject.clientName}
            projectManagers={selectedProject.projectManagers}
            projectStatus={selectedProject.projectStatus}
            isActive={selectedProject.isActive}
            onBack={handleBackToManagement}
          />
        </>
      )}
      {activeView === 'ProjectAnalytics' && selectedProject && (
        <ProjectAnalyticReport
          projectId={selectedProject.projectId}
          projectName={selectedProject.projectName}
          projects={projects}
          onBack={() => setActiveView('Projects')}
        />
      )}

      {/* Add Project Modal */}
      <CustomModal
        isOpen={isAddModalOpen}
        closeOnOverlayClick={false}
        onClose={onAddModalClose}
      >
        <ModalOverlay />
        <ModalContent className="settings-add-modal-content" borderRadius="md" p={4} maxH="1000vh">
          <ModalHeader textAlign="left" fontSize="2xl" fontWeight="bold">
            Create Project
          </ModalHeader>
          <ModalCloseButton onClick={handleModalClose} />
          <ModalBody>
            {/* Project Name & Color Code field */}
            <Flex mb={5} gap={4}>
              <FormControl flex="2" isInvalid={!!errors.name}>
                <FormLabel fontSize="md" fontWeight="medium">
                  Project Name{' '}
                  <span style={{ color: 'red', fontSize: '14px' }}> * </span>
                </FormLabel>
                <Input
                  value={newProject.name}
                  onChange={(e) => {
                    const { value } = e.target;
                    const pattern = /^[a-zA-Z0-9 _-]*$/; // Allow only allowed chars in real-time

                    if (!pattern.test(value)) {
                      return; // Ignore the invalid keypress
                    }

                    setNewProject({ ...newProject, name: value });

                    if (!ValidateProjectNameField(value)) {
                      setErrors((prev) => ({
                        ...prev,
                        name: 'Project name must contain at least one character or number.',
                      }));
                    } else if (value.length > 30) {
                      setErrors((prev) => ({
                        ...prev,
                        name: 'Project name must be 30 characters or less.',
                      }));
                    } else {
                      setErrors((prev) => ({ ...prev, name: '' }));
                    }
                  }}
                  size="sm"
                  borderRadius="5px"
                  focusBorderColor={errors?.name ? 'red.500' : 'blue.500'}
                  placeholder="Project Name"
                />
                <FormErrorMessage>{errors.name}</FormErrorMessage>
              </FormControl>

              <FormControl flex="1" isInvalid={!!errors?.color}>
                <FormLabel fontSize="md" fontWeight="medium">
                  {' '}
                  Choose Color Code{' '}
                  <span style={{ color: 'red', fontSize: '14px' }}> * </span>
                </FormLabel>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  {/* native color picker */}
                  <Input
                    type="color"
                    value={newProject.color || '#000000'}
                    onChange={(e) => {
                      setNewProject({ ...newProject, color: e.target.value });
                      setErrors((prev) => ({ ...prev, color: '' }));
                    }}
                    size="sm"
                    borderRadius="5px"
                    width="60px"
                    p={0}
                    cursor="pointer"
                  />

                  {/* hex code input */}
                  <Input
                    value={newProject.color || ''}
                    placeholder="#RRGGBB"
                    onChange={(e) => {
                      const raw = e.target.value.trim();
                      // allow user to type without forcing leading '#'
                      const prefixed = raw.startsWith('#') ? raw : `#${raw}`;

                      const isValidHex =
                        /^#([0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})$/.test(prefixed);

                      if (isValidHex) {
                        // normalize 3-digit to 6-digit and uppercase
                        const normalize = (hex) => {
                          if (hex.length === 4) {
                            return (
                              '#' +
                              hex
                                .slice(1)
                                .split('')
                                .map((c) => c + c)
                                .join('')
                            ).toUpperCase();
                          }
                          return hex.toUpperCase();
                        };

                        const normalized = normalize(prefixed);
                        setNewProject({ ...newProject, color: normalized });
                        setErrors((prev) => ({ ...prev, color: '' }));
                      } else {
                        // keep raw input (so user can continue typing) but do not change
                        // the visible color picker until a valid hex is entered
                        setNewProject({ ...newProject, color: raw });
                      }
                    }}
                    size="sm"
                    borderRadius="5px"
                    width="120px"
                  />
                </div>
                <FormErrorMessage>{errors.color}</FormErrorMessage>
              </FormControl>
            </Flex>
            <Flex mb={1} gap={4} align="flex-start">
              <HStack alignItems="flex-start" mb={5}>
                {/* Start Date Field */}
                <FormControl isInvalid={errors?.startDate} isRequired>
                  <FormLabel fontWeight="medium">Start Date</FormLabel>
                  <Input
                    type="date"
                    value={newProject.startDate || ''}
                    onChange={(e) => {
                      setNewProject({
                        ...newProject,
                        startDate: e.target.value,
                      });
                      setErrors((prev) => ({ ...prev, startDate: '' }));
                    }}
                    onFocus={(e) => {
                      try {
                        e.target?.showPicker && e.target.showPicker();
                      } catch (err) {}
                    }}
                    onKeyDown={(e) => {
                      if (e.key && e.key.length === 1) e.preventDefault();
                    }}
                  />
                  <FormErrorMessage>{errors.startDate}</FormErrorMessage>
                </FormControl>

                {/* Due Date Field */}
                <FormControl>
                  <FormLabel fontWeight="medium">Due Date</FormLabel>
                  <Input
                    type="date"
                    min={new Date().toISOString().slice(0, 10)}
                    value={newProject.dueDate ? newProject.dueDate : ''}
                    onChange={(e) =>
                      setNewProject({ ...newProject, dueDate: e.target.value })
                    }
                    onFocus={(e) => {
                      try {
                        e.target?.showPicker && e.target.showPicker();
                      } catch (err) {}
                    }}
                    onKeyDown={(e) => {
                      if (e.key && e.key.length === 1) e.preventDefault();
                    }}
                  />
                </FormControl>
              </HStack>
            </Flex>
            {/* Client and Category field */}
            <Flex mb={5} gap={4}>
              <FormControl isInvalid={errors?.clientId}>
                <FormLabel fontSize="md" fontWeight="medium">
                  Client{' '}
                  <span style={{ color: 'red', fontSize: '14px' }}> * </span>
                </FormLabel>
                <Dropdown
                  type="clients"
                  placeholder="Select Client"
                  selectedValue={newProject.clientId}
                  setSelectedValue={(value) => {
                    setNewProject({ ...newProject, clientId: value });
                    setErrors((prev) => ({ ...prev, clientId: '' }));
                  }}
                />
                <FormErrorMessage>{errors.clientId}</FormErrorMessage>
              </FormControl>
              <FormControl isInvalid={errors?.projectCategoryId}>
                <FormLabel fontSize="md" fontWeight="medium">
                  Project Category{' '}
                  <span style={{ color: 'red', fontSize: '14px' }}> * </span>
                </FormLabel>
                <Dropdown
                  type="projectcategories"
                  placeholder="Select Project Category"
                  selectedValue={newProject.projectCategoryId}
                  setSelectedValue={(value) => {
                    setNewProject({ ...newProject, projectCategoryId: value });
                    setErrors((prev) => ({ ...prev, projectCategoryId: '' }));
                  }}
                />
                <FormErrorMessage>{errors.projectCategoryId}</FormErrorMessage>
              </FormControl>
            </Flex>
            {/* Department and Status field */}
            <Flex mb={1} gap={4}>
              <FormControl flex="1" isInvalid={errors?.departmentId}>
                <FormLabel fontSize="md" fontWeight="medium">
                  Department{' '}
                  <span style={{ color: 'red', fontSize: '14px' }}> * </span>
                </FormLabel>
                <Dropdown
                  type="departments"
                  placeholder="Select Department"
                  selectedValue={newProject.departmentId}
                  setSelectedValue={(value) => {
                    setNewProject({ ...newProject, departmentId: value });
                    setErrors((prev) => ({ ...prev, departmentId: '' }));
                  }}
                />
                <FormErrorMessage>{errors.departmentId}</FormErrorMessage>
              </FormControl>

              <FormControl
                flex="1"
                isInvalid={errors?.managerId}
              >
                <FormLabel fontSize="md" fontWeight="medium">
                  Manager{' '}
                  <span style={{ color: 'red', fontSize: '14px' }}> * </span>
                </FormLabel>
                <Dropdown
                  type="reportingto"
                  placeholder="Select Managers"
                  isMulti={true}
                  selectedValue={newProject.managerId}
                  setSelectedValue={(ids) => {
                    setNewProject((prev) => ({
                      ...prev,
                      managerId: ids,
                    }));
                    setErrors((prev) => ({ ...prev, managerId: '' }));
                  }}
                />

                <FormErrorMessage>{errors.managerId}</FormErrorMessage>
              </FormControl>
            </Flex>
          </ModalBody>
          <ModalFooter>
            <Flex gap={4} justify="flex-end" mt={3}>
              <CustomButton
                label="Cancel"
                onClick={handleModalClose}
                variant="outline"
                colorScheme="black"
                className="common-button"
              />
              <CustomButton
                label="Save"
                onClick={handleAddProject}
                colorScheme="green"
                className="common-button"
                isLoading={isSubmitting}
              />
            </Flex>
          </ModalFooter>
        </ModalContent>
      </CustomModal>

      {/* Edit Modal */}
      <CustomModal
        isOpen={isEditModalOpen}
        closeOnOverlayClick={false}
        onClose={onEditModalClose}
      >
        <ModalOverlay />
        <ModalContent className="project-edit-modal-content">
          <ModalHeader>Edit Project</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <FormControl mb={4}>
              <FormLabel>Project Name</FormLabel>
              <InputGroup>
                <Input
                  type="text"
                  value={editingProject.projectName || ''}
                  isReadOnly
                  size="sm"
                  borderRadius="5px"
                  focusBorderColor="blue.500"
                  zIndex={2}
                />
              </InputGroup>
            </FormControl>

            <FormControl mb={4}>
              <FormLabel>Department</FormLabel>
              <Dropdown
                type="departments"
                selectedValue={editingProject.departmentId}
                defaultValue={editingProject.departmentId}
                setSelectedValue={(value) =>
                  setEditingProject({ ...editingProject, departmentId: value })
                }
              />
            </FormControl>

            <FormControl mb={4}>
              <FormLabel>Status</FormLabel>
              <Dropdown
                type="projectstatus"
                selectedValue={editingProject.statusId?.toString()}
                defaultValue={editingProject.statusId?.toString()}
                setSelectedValue={(value) =>
                  setEditingProject({
                    ...editingProject,
                    statusId: parseInt(value),
                  })
                }
              />
            </FormControl>

            <FormControl mb={4} isInvalid={errors?.managerId}>
                  <FormLabel fontSize="md" fontWeight="medium">
                  Manager{' '}
                  <span style={{ color: 'red', fontSize: '14px' }}> * </span>
                </FormLabel>
              <Dropdown
                type="reportingto"
                placeholder="Select Managers"
                isMulti={true}
                selectedValue={editingProject.managerId || []}
                setSelectedValue={(ids) => {
                  setEditingProject((prev) => ({
                    ...prev,
                    managerId: Array.isArray(ids) ? ids : [],
                  }));
                  setErrors((prev) => ({ ...prev, managerId: '' }));
                }}
              />
              <FormErrorMessage>{errors.managerId}</FormErrorMessage>
            </FormControl>
          </ModalBody>

          <ModalFooter>
            <Flex gap={4} justify="flex-end" mt={3}>
              <CustomButton
                label="Cancel"
                onClick={onEditModalClose}
                variant="outline"
                colorScheme="black"
                className="common-button"
              />
              <CustomButton
                label="Save"
                onClick={handleUpdateProject}
                colorScheme="green"
                className="common-button"
                isLoading={isSubmitting}
              />
            </Flex>
          </ModalFooter>
        </ModalContent>
      </CustomModal>

      {/* Delete Modal */}
      <Modal
        isOpen={isDeleteModalOpen}
        closeOnOverlayClick={false}
        onClose={onDeleteModalClose}
        isCentered
      >
        <ModalOverlay />
        <ModalContent className="project-delete-warning-modal">
          <ModalHeader>Delete Project</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Text>
              Are you sure you want to delete{' '}
              <Text as="span" fontWeight="bold">
                {selectedProject?.projectName}
              </Text>
              ?
            </Text>
          </ModalBody>
          <ModalFooter>
            <Flex gap={4} justify="flex-end">
              <CustomButton
                label="Cancel"
                onClick={onDeleteModalClose}
                variant="outline"
                colorScheme="black"
                className="common-button"
              />
              <CustomButton
                label="Delete"
                onClick={handleDeleteProject}
                colorScheme="red"
                className="common-button"
                isLoading={isSubmitting}
              />
            </Flex>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </div>
  );
};

export default Projects;
