import React, { useEffect, useState } from 'react';
import { fetchEmployeeDetails, fetchUserProfilePicture } from 'utils/api';
import { useLoader } from 'contexts/LoaderContext';
import { useCustomToast } from 'utils/toastUtils';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { LOCAL_STORAGE_KEYS, formatDate } from 'utils/constants';
import {
  Avatar,
  Box,
  Button,
  Flex,
  Grid,
  GridItem,
  HStack,
  Icon,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Text,
  VStack,
} from '@chakra-ui/react';
import {
  FaBarcode,
  FaBirthdayCake,
  FaCalendar,
  FaEnvelope,
  FaHeart,
  FaIdBadge,
  FaMapMarkerAlt,
  FaNetworkWired,
  FaTransgender,
  FaUserCheck,
  FaUsers,
  FaUserTag,
  FaUserTie,
} from 'react-icons/fa';
import { MdContactPhone, MdPhone } from 'react-icons/md';
import { FiArrowLeft } from 'react-icons/fi';

const naValues = ['NA', '0', '', null, undefined];

const isInvalidValue = (value) => naValues.includes(value);

const resolveDisplayValue = (value) => (isInvalidValue(value) ? null : value);

const getEmergencyContactValue = (details) => {
  const name = resolveDisplayValue(details?.emgContactName) || '';
  const relation = resolveDisplayValue(details?.emgContactRelation) || '';
  const phone = resolveDisplayValue(details?.emgContactPhoneNo) || '';

  if (name && relation && phone) return `${name} (${relation}) - ${phone}`;
  if (name && relation) return `${name} (${relation})`;
  if (name && phone) return `${name} - ${phone}`;
  if (relation && phone) return `${relation} - ${phone}`;
  if (name) return name;
  if (relation) return relation;
  if (phone) return phone;
  return null;
};

const InfoRow = ({ icon: IconComponent, label, value }) => (
  <Flex
    align="center"
    gap={4}
    px={4}
    py={4}
    border="1px solid"
    borderColor="#D9E5F2"
    borderRadius="12px"
    bg="#FFFFFF"
    minH="78px"
  >
    <Flex
      w="34px"
      h="34px"
      borderRadius="10px"
      align="center"
      justify="center"
      bg="linear-gradient(135deg, rgba(167, 199, 236, 0.28), rgba(49, 92, 140, 0.12))"
      color="#2A4F7C"
      flexShrink={0}
    >
      <Icon as={IconComponent} boxSize={4} />
    </Flex>
    <Box minW={0}>
      <Text
        fontSize="11px"
        fontWeight={700}
        textTransform="uppercase"
        letterSpacing="0.08em"
        color="#6F88A8"
        mb={1}
      >
        {label}
      </Text>
      <Text
        fontSize="13px"
        fontWeight={600}
        color={value ? '#1F2F45' : '#8BA1BE'}
        noOfLines={2}
      >
        {value || 'Not available'}
      </Text>
    </Box>
  </Flex>
);

export default function UserDetailsPage({ emp_code, onBack }) {
  const showToast = useCustomToast();
  const { showGlobalLoader, hideGlobalLoader } = useLoader();
  const [activeTab, setActiveTab] = useState(0);
  const [userDetails, setUserDetails] = useState(null);
  const [profilePhoto, setProfilePhoto] = useState(null);

  useEffect(() => {
    const loadUserDetails = async () => {
      const roleId = localStorage.getItem(LOCAL_STORAGE_KEYS.ROLE_ID);
      if (!emp_code || !roleId) return;

      showGlobalLoader();
      try {
        const response = await fetchEmployeeDetails(emp_code, roleId);
        const { employeeData, roletitle } = response;
        const formattedData = {
          name: employeeData.username,
          emailId: employeeData.email_id,
          phoneNo: employeeData.phoneNo,
          location: employeeData.location,
          dateOfBirth: employeeData.dateofbirth,
          gender: employeeData.gender,
          maritalStatus: employeeData.maritalStatus,
          emgContactName: employeeData.emg_ContactName,
          emgContactPhoneNo: employeeData.emg_ContactPhoneNo,
          emgContactRelation: employeeData.emg_ContactRelation,
          designation: employeeData.designation,
          isBillable: employeeData.isBillable,
          employmentType: employeeData.employmentType,
          employmentType_Id: employeeData.employmentType_Id,
          departmentName: employeeData.departmentName,
          teamName: employeeData.teamName,
          reportingTo: employeeData.reportingTo,
          joiningDate: employeeData.joiningDate,
          emp_code: employeeData.emp_code,
          roleTitle: roletitle,
        };

        setUserDetails(formattedData);
      } catch (error) {
        showToast('error', 'Unable to load Employee details. Please try again later.');
      } finally {
        hideGlobalLoader();
      }
    };

    loadUserDetails();
  }, [emp_code]);

  useEffect(() => {
    const loadProfilePicture = async () => {
      if (!userDetails || !userDetails.emp_code) return;
      const imageUrl = await fetchUserProfilePicture(userDetails.emp_code);
      if (imageUrl) setProfilePhoto(imageUrl);
    };

    loadProfilePicture();
  }, [userDetails]);

  return (
    <Box className="page-content-wrapper">
      <ToastContainer />
      <Box
        border="1px solid"
        borderColor="#D9E5F2"
        borderRadius="18px"
        bg="#FFFFFF"
        boxShadow="0 1px 3px rgba(31, 47, 69, 0.06), 0 6px 16px rgba(42, 79, 124, 0.05)"
        overflow="hidden"
      >
        <Flex
          px={{ base: 5, md: 7 }}
          py={{ base: 5, md: 5 }}
          align={{ base: 'flex-start', md: 'center' }}
          justify="space-between"
          direction={{ base: 'column', md: 'row' }}
          gap={3}
          bg="linear-gradient(90deg, rgba(167, 199, 236, 0.22), rgba(49, 92, 140, 0.1))"
          borderBottom="1px solid"
          borderColor="#D9E5F2"
        >
          <HStack spacing={4} align="center">
            <Avatar
              size="lg"
              name={userDetails?.name}
              src={profilePhoto || undefined}
              bg="linear-gradient(135deg, #3A699A, #2A4F7C)"
              color="#FFFFFF"
              border="3px solid"
              borderColor="#FFFFFF"
              boxShadow="0 8px 24px rgba(42, 79, 124, 0.24)"
            />
            <VStack align="flex-start" spacing={1}>
              <Text
                fontSize={{ base: '22px', md: '24px' }}
                lineHeight="1.1"
                fontWeight={800}
                color="#1F2F45"
                letterSpacing="-0.03em"
              >
                {userDetails?.name || 'Loading profile...'}
              </Text>
              <HStack spacing={2} flexWrap="wrap">
                <Text fontSize="13px" color="#4A617F" noOfLines={1}>
                  {userDetails?.emailId || 'No email available'}
                </Text>
              </HStack>
            </VStack>
          </HStack>

          <Button
            onClick={onBack}
            leftIcon={<Icon as={FiArrowLeft} boxSize={4} />}
            h="38px"
            px={3.5}
            borderRadius="10px"
            bg="#F2F7FD"
            border="1px solid #C8D9EC"
            color="#2B5383"
            fontSize="14px"
            fontWeight={700}
            lineHeight="1"
            _hover={{
              bg: '#E8F1FB',
              borderColor: '#9FBCE0',
              transform: 'translateY(-1px)',
            }}
            _active={{ bg: '#DFECFA', transform: 'translateY(0)' }}
          >
            Back
          </Button>
        </Flex>

        <Box px={{ base: 4, md: 6 }} py={{ base: 4, md: 4 }} bg="#F6F9FD">
          <Tabs
            index={activeTab}
            onChange={setActiveTab}
            colorScheme="blue"
            variant="unstyled"
          >
            <TabList
              p={1}
              bg="#EDF4FC"
              border="1px solid"
              borderColor="#D9E5F2"
              borderRadius="12px"
              w="fit-content"
              mb={4}
              gap={1}
            >
              <Tab
                px={4}
                h="36px"
                fontSize="13px"
                fontWeight={700}
                color="#4A617F"
                borderRadius="9px"
                border="1px solid transparent"
                _selected={{
                  bg: 'linear-gradient(135deg, #245186, #2F6BA8)',
                  color: '#FFFFFF',
                  borderColor: '#1E4A79',
                  boxShadow: '0 8px 18px rgba(36, 81, 134, 0.35)',
                }}
              >
                Professional Details
              </Tab>
              <Tab
                px={4}
                h="36px"
                fontSize="13px"
                fontWeight={700}
                color="#4A617F"
                borderRadius="9px"
                border="1px solid transparent"
                _selected={{
                  bg: 'linear-gradient(135deg, #245186, #2F6BA8)',
                  color: '#FFFFFF',
                  borderColor: '#1E4A79',
                  boxShadow: '0 8px 18px rgba(36, 81, 134, 0.35)',
                }}
              >
                Personal Details
              </Tab>
            </TabList>

            <TabPanels>
              <TabPanel p={0}>
                <Grid templateColumns={{ base: '1fr', md: '1fr 1fr' }} gap={4}>
                  <GridItem>
                    <InfoRow
                      icon={FaBarcode}
                      label="Employee Code"
                      value={userDetails?.emp_code ? `E0${userDetails.emp_code}` : null}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaIdBadge}
                      label="Designation"
                      value={resolveDisplayValue(userDetails?.designation)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaUserCheck}
                      label="Billable"
                      value={
                        userDetails?.isBillable === undefined
                          ? null
                          : userDetails?.isBillable
                            ? 'Yes'
                            : 'No'
                      }
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaUserTag}
                      label="Employment Type"
                      value={resolveDisplayValue(userDetails?.employmentType)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaNetworkWired}
                      label="Department"
                      value={resolveDisplayValue(userDetails?.departmentName)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaUsers}
                      label="Team"
                      value={resolveDisplayValue(userDetails?.teamName)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaUserTie}
                      label="Reporting To"
                      value={resolveDisplayValue(userDetails?.reportingTo)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaCalendar}
                      label="Joining Date"
                      value={userDetails?.joiningDate ? formatDate(userDetails.joiningDate) : null}
                    />
                  </GridItem>
                </Grid>
              </TabPanel>

              <TabPanel p={0}>
                <Grid templateColumns={{ base: '1fr', md: '1fr 1fr' }} gap={4}>
                  <GridItem>
                    <InfoRow
                      icon={FaEnvelope}
                      label="Email"
                      value={resolveDisplayValue(userDetails?.emailId)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={MdPhone}
                      label="Phone"
                      value={resolveDisplayValue(userDetails?.phoneNo)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaMapMarkerAlt}
                      label="Location"
                      value={resolveDisplayValue(userDetails?.location)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaBirthdayCake}
                      label="Date of Birth"
                      value={userDetails?.dateOfBirth ? formatDate(userDetails.dateOfBirth) : null}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaTransgender}
                      label="Gender"
                      value={resolveDisplayValue(userDetails?.gender)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaHeart}
                      label="Marital Status"
                      value={resolveDisplayValue(userDetails?.maritalStatus)}
                    />
                  </GridItem>
                  <GridItem colSpan={{ base: 1, md: 2 }}>
                    <InfoRow
                      icon={MdContactPhone}
                      label="Emergency Contact"
                      value={getEmergencyContactValue(userDetails)}
                    />
                  </GridItem>
                </Grid>
              </TabPanel>
            </TabPanels>
          </Tabs>
        </Box>
      </Box>
    </Box>
  );
}
