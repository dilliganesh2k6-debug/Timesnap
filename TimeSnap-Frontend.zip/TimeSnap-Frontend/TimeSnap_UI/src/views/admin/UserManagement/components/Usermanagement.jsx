import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  // functions for API calls
  fetchUserManagementDatas,
  addUsers,
  updateUsers,
  deleteUser,
  resetUserPassword,
  fetchApprovalTimesheetData,
} from 'utils/api';
import { useCustomToast } from 'utils/toastUtils';
import { clearGridFocus } from 'utils/gridUtils';
import Dropdown from 'components/Dropdown/Dropdown';
import {
  statusColorScheme,
  validateStringInput,
  MAX_NAME_LENGTH,
  formatDate,
} from 'utils/constants';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {
  // Chakra UI components for layout and design
  Box,
  Heading,
  Button,
  Tag,
  Select,
  Input,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  ModalCloseButton,
  Tabs,
  TabList,
  Tab,
  TabPanels,
  VStack,
  TabPanel,
  Flex,
  Text,
  FormControl,
  FormErrorMessage,
  Checkbox,
  FormLabel,
} from '@chakra-ui/react';
import {
  MAX_EMPLOYEE_NAME_LENGTH,
  ROLE_ID,
  LOCAL_STORAGE_KEYS,
} from 'utils/constants';
import Userinfo from './Userinfo';
import './Usermanagement.css';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import CustomButton from 'components/button/CustomButton';
import CustomIconButton from 'components/button/CustomIconButton';
import { useLoader } from 'contexts/LoaderContext';
import CustomModal from 'components/modal/CustomModal';
import TimeSnapLoader from '../../../../components/loaders/TimeSnapLoader';

const Usermanagement = () => {
  // State for reset password loading
  // State for reset password loading
  const [isResetLoading, setIsResetLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isGridLoading, setIsGridLoading] = useState(false);

  const isAdmin = localStorage.getItem('IS_ADMIN') === 'true';
  const empCode = localStorage.getItem(LOCAL_STORAGE_KEYS.EMP_CODE);
  console.log('log in user value:', empCode);
  const { showGlobalLoader, hideGlobalLoader, isGlobalLoading } = useLoader();

  // ==================== STATE VARIABLES ====================
  const showToast = useCustomToast(); // Custom hook to show styled toasts
  const roleId = localStorage.getItem(LOCAL_STORAGE_KEYS.ROLE_ID);
  const [activeView, setActiveView] = useState('Usermanagement');
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [employeeCodeError, setEmployeeCodeError] = useState('');
  const [isPhoneTouched, setIsPhoneTouched] = useState(false);
  const [isEmgPhoneTouched, setIsEmgPhoneTouched] = useState(false);
  const gridRef = useRef(null);
  const [emailError, setEmailError] = useState('');
  // Suggested domain behaviour for official emails
  const suggestedDomain = 'ciglobalsolutions.com';
  const [showDomainSuggestion, setShowDomainSuggestion] = useState(false);
  // When we programmatically accept the suggestion we want to skip the
  // onBlur-triggered validation that can run with the old value. This ref
  // is set to true before accepting and cleared by the onBlur handler.
  const ignoreNextBlurValidationRef = useRef(false);
  const [teams] = useState([]);
  const [isReadOnly, setIsReadOnly] = useState(false); // For readonly function
  const [users, setUsers] = useState([]); // Stores all users

  // ==================== EFFECT HOOKS ====================
  useEffect(() => {
    const accessDetailsString = localStorage.getItem('accessDetails');
    if (accessDetailsString) {
      try {
        const accessDetails = JSON.parse(accessDetailsString);
        const screenAccess = accessDetails.find(
          (screen) => screen.screenId === 104, // Pass Sceeen Id to know user have which type of access(Full Access or Read Only)
        );
        if (screenAccess) {
          setIsReadOnly(screenAccess.readOnly === 1);
        }
      } catch (error) {
        console.error('Invalid accessDetails format in localStorage');
      }
    }
  }, []);

  /**
 Effect: Disable page scrolling while component is mounted
Prevents background scrolling for better UX when viewing profile. 
Cleanup function restores normal scrolling on component unmount.
*/

  useEffect(() => {
    // Disable scroll on the body
    document.body.style.overflow = 'hidden';

    //  Restore the scroll when the component unmounts
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, []);

  // Fetch user data
  useEffect(() => {
    const loadUsers = async () => {
      showGlobalLoader();
      try {
        const data = await fetchUserManagementDatas();
        setUsers(data);
      } catch (error) {
        console.error('Error fetching user data:', error);
      } finally {
        hideGlobalLoader();
      }
    };
    loadUsers();
  }, []);

  // ==================== EVENT HANDLERS ====================

  // Function to validate email format and check for a Official domain
  const validateEmail = (email) => {
    const emailRegex = /^[a-z0-9._]+@[a-z]+\.[a-z]{2,}$/; // lowercase letters, numbers, . and _ allowed
    const domain = email.split('@')[1]; // Extract domain

    if (!email) {
      setEmailError('Enter your official email ID.');
      return false;
    }

    //  Reject if contains capital letters
    if (/[A-Z]/.test(email)) {
      setEmailError('Email should not contain capital letters.');
      return false;
    }

    // Reject if username has invalid characters (anything except letters, numbers, dot, underscore)
    const username = email.split('@')[0];
    if (/[^a-z0-9._]/.test(username)) {
      setEmailError('Email username contains invalid characters.');
      return false;
    }

    // Reject if domain has numbers (e.g., 4567.com)
    if (/\d/.test(domain)) {
      setEmailError('Domain should not contain numbers.');
      return false;
    }

    // Basic email format check
    if (!emailRegex.test(email)) {
      setEmailError('Enter a valid email ID.');
      return false;
    }

    // Reject common public domains
    if (
      !domain ||
      domain.includes('gmail') ||
      domain.includes('yahoo') ||
      domain.includes('outlook') ||
      domain.includes('hotmail')
    ) {
      setEmailError('Enter your official company email ID.');
      return false;
    }

    // Passed all checks
    setEmailError('');
    return true;
  };

  // Handles email input change
  const handleEmailChange = (e) => {
    const value = e.target.value;
    setNewUser({ ...newUser, email: value });
    // Suggest domain when user types '@' and hasn't completed domain part
    const atIndex = value.indexOf('@');
    if (atIndex !== -1) {
      const after = value.slice(atIndex + 1);
      // show suggestion when there's no domain yet or user typed a partial that matches
      if (
        after.length === 0 ||
        (!after.includes('.') && suggestedDomain.startsWith(after))
      ) {
        setShowDomainSuggestion(true);
      } else {
        setShowDomainSuggestion(false);
      }
      // if user already typed the full suggested domain, hide suggestion
      if (value.toLowerCase().includes(`@${suggestedDomain}`)) {
        setShowDomainSuggestion(false);
      }
    } else {
      setShowDomainSuggestion(false);
    }

    // Validate only if input is not empty
    if (value.trim() !== '') {
      validateEmail(value);
      setNewUser((prev) => ({
        ...prev,
        email: value,
        errors: { ...prev.errors, email: undefined },
      }));
    }
  };

  const maritalStatusOptions = [
    { id: 'UnMarried', name: 'UnMarried' },
    { id: 'Married', name: 'Married' },
  ];

  const genderOptions = [
    { id: 'Male', name: 'Male' },
    { id: 'Female', name: 'Female' },
    { id: 'Prefer not to say', name: 'Prefer not to say' },
  ];

  // Accept the suggested domain and (optionally) move focus to the next focusable element
  const acceptSuggestedDomainAndFocusNext = (currentElement) => {
    const val = currentElement?.value || '';
    const atIndex = val.indexOf('@');
    const prefix = atIndex !== -1 ? val.slice(0, atIndex + 1) : val + '@';
    const newEmail = prefix + suggestedDomain;
    // Prevent the onBlur handler from validating the old (pre-completion) value
    // while we programmatically accept the suggestion.
    ignoreNextBlurValidationRef.current = true;
    setNewUser((prev) => ({
      ...prev,
      email: newEmail,
      errors: { ...prev.errors, email: undefined },
    }));
    setShowDomainSuggestion(false);
    validateEmail(newEmail);

    // Move focus to next focusable element (simulate normal Tab)
    try {
      const focusable = Array.from(
        document.querySelectorAll(
          'a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"])',
        ),
      ).filter((el) => !el.disabled && el.offsetParent !== null);
      const idx = focusable.indexOf(currentElement);
      if (idx >= 0 && idx < focusable.length - 1) {
        focusable[idx + 1].focus();
      }
    } catch (err) {
      // ignore focus errors
    }
  };
  /**
   * Validates and handles employee code changes
   * Ensures only numeric values between 3-4 digits are accepted
   */
  const handleEmployeeCodeChange = (e) => {
    const value = e.target.value;

    // Only allow numbers
    if (!/^\d*$/.test(value)) {
      setEmployeeCodeError('Please enter numbers only');
      return;
    }
    // Check length constraints
    if (value.length > 0 && (value.length < 3 || value.length > 4)) {
      setEmployeeCodeError('Employee code must be 3-4 digits');
    } else {
      setEmployeeCodeError('');
    }
    setNewUser({
      ...newUser,
      employeecode: value,
    });
    clearFieldError('employeecode', value);
  };

  // Filters for department, status, and search input
  const [filters, setFilters] = useState({
    department: '',
    status: '',
    search: '',
  });

  // Resets filters
  const resetFilters = () => {
    setFilters({
      department: '',
      status: '',
      search: '',
    });
  };

  //Handler for viewing user details
  const handleViewDetails = (user) => {
    setSelectedTeam(user.employeeCode);
    setActiveView('Userinfo');
    resetFilters();
  };

  //Handler to go back to the main user management view
  const handleBackToManagement = () => {
    setActiveView('Usermanagement');
    resetFilters();
  };

  // State for managing modal type and visibility
  const [modalState, setModalState] = useState({
    type: null,
    isOpen: false,
  });

  // State for storing the currently selected user for edit/delete operations
  const [selectedUser, setSelectedUser] = useState(null);
  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    employeecode: '',
    departments: '',
    status: '',
    designation: '',
    workingstatus: '',
    dateOfJoining: '',
    dateofbirth: '',
    Gender: '',
    roles: '',
    employmenttype: '',
    isBillable: false,
    reportingRights: false,
    isAdmin: false,
    phoneNo: '',
    location: '',
    maritalStatus: '',
    emgContactName: '',
    emgContactRelation: '',
    emgContactPhoneNo: '',
    teamName: '',
    ReportingId: '',
  });

  /**
    Filters users based on department, status, and search criteria
    Returns an array of users that match all applied filters
  */
  const processedUsers = users.filter((user) => {
    const matchesDepartment =
      !filters.department ||
      user.departmentId.toString() === filters.department.toString();
    const matchesStatus =
      !filters.status ||
      user.status_Id.toString() === filters.status.toString();
    const matchesSearch =
      !filters.search ||
      user.userName?.toLowerCase().includes(filters.search.toLowerCase()) ||
      user.department?.toLowerCase().includes(filters.search.toLowerCase()) ||
      user.designation?.toLowerCase().includes(filters.search.toLowerCase()) ||
      user.teamName?.toLowerCase().includes(filters.search.toLowerCase());

    return matchesDepartment && matchesStatus && matchesSearch;
  });

  const clearFieldError = (field, value) => {
    setNewUser((prev) => ({
      ...prev,
      [field]: value,
      errors: {
        ...prev.errors,
        [field]: undefined,
      },
    }));
  };

  const capitalizeWords = (str) => {
    if (!str) return '';
    const trimmed = str.trim();
    if (trimmed.toLowerCase() === 'na') return 'NA';
    return trimmed
      .toLowerCase()
      .split(/\s+/)
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  // Handler for confirming password reset
  const handleConfirmResetPassword = async () => {
    if (!selectedUser?.employeeCode) return;
    setIsResetLoading(true);
    try {
      await resetUserPassword(selectedUser.employeeCode);
      showToast('success', `Password reset to default successfully.`);
      closeModal();
    } catch (error) {
      showToast(error.message || 'Failed to reset password', 'error');
    } finally {
      setIsResetLoading(false);
    }
  };

  const userToAdd = {
    userName: capitalizeWords(newUser.name),
    email: newUser.email,
    emp_code: newUser.employeecode,
    Department_Id: newUser.departments,
    WorkingStatusId: newUser.workingstatus,
    JoiningDate: newUser.dateOfJoining,
    DOB: newUser.dateofbirth,
    Gender: newUser.Gender || 'Prefer not to say',
    Location: capitalizeWords(newUser.location || 'NA'),
    Marital_status: newUser.maritalStatus || 'NA',
    Phone_no: newUser.phoneNo || 0,
    TeamId: newUser.teamId || 0,
    StatusId: 1,
    Role_Id: newUser.roles,
    IsBillable: newUser.isBillable,
    IsAdmin: newUser.isAdmin,
    employmentType_ID: newUser.employmenttype,
    Emg_ContactName: capitalizeWords(newUser.emgContactName || 'NA'),
    Emg_ContactRelation: capitalizeWords(newUser.emgContactRelation || 'NA'),
    Emg_ContactPhoneNo: newUser.emgContactPhoneNo || 0,
    Designation_Id: newUser.designation,
    ReportingId: newUser.ReportingId || 0,
    ReportingRights: newUser.reportingRights,
  };
  /**
   * Handles adding a new user
   * Validates required fields and sends data to API
   */
  const handleAddUser = async () => {
    setIsSubmitting(true);
    let errors = {};

    if (!newUser.name?.trim()) errors.name = 'Name is required.';
    if (!newUser.email?.trim()) {
      errors.email = 'Email is required.';
    } else {
      const email = newUser.email.trim().toLowerCase();
      const emailRegex = /^[a-z0-9._]+@[a-z]+\.[a-z]{2,}$/; // lowercase letters, numbers, ., _ allowed
      const [username, domain] = email.split('@');

      // Invalid if contains uppercase (we already lowercased, so just for clarity)
      if (/[A-Z]/.test(newUser.email)) {
        errors.email = '';
      }
      // Invalid username characters
      else if (/[^a-z0-9._]/.test(username)) {
        errors.email = '';
      }
      // Invalid if domain has numbers (like 4567.com)
      else if (/\d/.test(domain)) {
        errors.email = '';
      }
      //Invalid if not matching general pattern
      else if (!emailRegex.test(email)) {
        errors.email = 'Enter a valid email ID.';
      }
      // Invalid if public email domain
      else if (
        !domain ||
        domain.includes('gmail') ||
        domain.includes('yahoo') ||
        domain.includes('outlook') ||
        domain.includes('hotmail')
      ) {
        errors.email = '';
      }
    }
    if (!newUser.employeecode)
      errors.employeecode = 'Employee Code is required.';
    if (!newUser.employmenttype)
      errors.employmenttype = 'Employment Type is required.';
    if (!newUser.workingstatus)
      errors.workingstatus = 'Working Status is required.';
    if (!newUser.ReportingId) errors.ReportingId = 'Reporting To is required.';
    if (!newUser.designation) errors.designation = 'Designation is required.';
    if (!newUser.dateOfJoining)
      errors.dateOfJoining = 'Date of Joining is required.';
    if (!newUser.dateofbirth) errors.dateofbirth = 'Date of Birth is required.';
    if (!newUser.departments) errors.departments = 'Department is required.';
    if (!newUser.Gender) errors.Gender = 'Gender selection is required.';
    if (!newUser.roles) errors.roles = 'Role selection is required.';

    // Check phone number length
    if (
      newUser.phoneNo &&
      newUser.phoneNo.length > 0 &&
      newUser.phoneNo.length !== 10
    ) {
      errors.phoneNo = 'Phone number must be exactly 10 digits.';
    }

    if (
      newUser.emgContactPhoneNo &&
      newUser.emgContactPhoneNo.length > 0 &&
      newUser.emgContactPhoneNo.length !== 10
    ) {
      errors.emgContactPhoneNo =
        'Emergency Contact Phone number must be exactly 10 digits.';
    }

    // If there are validation errors, show them and return
    if (Object.keys(errors).length > 0) {
      setNewUser((prev) => ({ ...prev, errors }));
      setIsSubmitting(false);
      return;
    }

    try {
      const addedUser = await addUsers(userToAdd); // Call API to add user
      if (!addedUser.success) throw new Error(addedUser.message);
      // Refresh user list after successful addition
      const updatedUserList = await fetchUserManagementDatas();
      setUsers(updatedUserList);

      showToast('success', `${newUser.name} has been added successfully.`);

      closeModal();
    } catch (error) {
      // Handle error and show appropriate message
      const errorMessage =
        error.response?.data?.message ||
        error.message ||
        'Unable to add the user. Please try again.';

      showToast('warning', errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  /**
   * Handles updating an existing user's information
   * Validates required fields and sends update to API
   */
  const handleEditUser = async () => {
    setIsSubmitting(true);
    if (!newUser.name || !newUser.departments) {
      setIsSubmitting(false);
      return;
    }
    const updateRequest = {
      emp_code: selectedUser.employeeCode,
      userName: capitalizeWords(newUser.name),
      email: newUser.email,
      department_Id: parseInt(newUser.departments),
      statusId: parseInt(newUser.status),
      designation_Id: parseInt(newUser.designation),
      workingStatusId: parseInt(newUser.workingstatus),
      employmentType_ID: parseInt(newUser.employmenttype),
      role_Id: parseInt(newUser.roles),
      teamId: parseInt(newUser.teamId) || 0,
      joiningDate: newUser.dateOfJoining,
      Location: capitalizeWords(newUser.location || 'NA'),
      phone_no: newUser.phoneNo || 0,
      isBillable: newUser.isBillable,
      isAdmin: newUser.isAdmin,
      dob: newUser.dateofbirth || '',
      marital_status: newUser.maritalStatus,
      gender: newUser.Gender,
      Emg_ContactName: capitalizeWords(newUser.emgContactName || 'NA'),
      Emg_ContactRelation: capitalizeWords(newUser.emgContactRelation || 'NA'),
      Emg_ContactPhoneNo: newUser.emgContactPhoneNo || 0,
      reportingId: parseInt(newUser.ReportingId),
      reportingrights: newUser.reportingrights,
    };
    if (
      (newUser.phoneNo?.trim()?.length > 0 && newUser.phoneNo.length !== 10) ||
      (newUser.emgContactPhoneNo?.trim()?.length > 0 &&
        newUser.emgContactPhoneNo.length !== 10)
    ) {
      const errors = {};
      if (
        newUser.phoneNo &&
        newUser.phoneNo.length > 0 &&
        newUser.phoneNo.length !== 10
      ) {
        errors.phoneNo = 'Phone number must be exactly 10 digits.';
      }
      if (
        newUser.emgContactPhoneNo &&
        newUser.emgContactPhoneNo.length > 0 &&
        newUser.emgContactPhoneNo.length !== 10
      ) {
        errors.emgContactPhoneNo =
          'Emergency Contact Phone number must be exactly 10 digits.';
      }
      setNewUser((prev) => ({ ...prev, errors }));
      setIsSubmitting(false);
      return;
    }

    try {
      await updateUsers(updateRequest);
      setTimeout(async () => {
        const data = await fetchUserManagementDatas();
        setUsers(data);
        clearGridFocus(gridRef); //  Fix auto-tooltip/focus
      }, 100);
      showToast('success', `${newUser.name} details updated successfully.`);
      closeModal();
    } catch (error) {
      console.error('Error updating user:', error);
      showToast(
        'warning',
        `${newUser.name}'s Role cannot be changed because the employee is assigned to a team or project`,
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  /**
   * Handles deleting a user
   * Confirms the action and calls the delete API
   */
  const handleDeleteUser = async () => {
    setIsSubmitting(true);
    try {
      await deleteUser(selectedUser.employeeCode); // Call API to delete user
      setTimeout(async () => {
        const updatedList = await fetchUserManagementDatas();
        setUsers(updatedList);
        clearGridFocus(gridRef); //  Fix auto-tooltip/focus
      }, 100);

      resetFilters();
      showToast('success', `${selectedUser.userName} has been deleted`);

      closeModal();
    } catch (error) {
      console.error('waring deleting user:', error);
      closeModal();
      setTimeout(async () => {
        const updatedList = await fetchUserManagementDatas();
        setUsers(updatedList);
        clearGridFocus(gridRef); //  Fix auto-tooltip/focus
      }, 100);
      showToast('warning', 'Active users cannot be marked as deleted ');
    } finally {
      setIsSubmitting(false);
    }
  };

  const reportingParams = useMemo(() => {
    if (!selectedUser?.employeeCode) return {};
    return { empCode: selectedUser.employeeCode };
  }, [selectedUser?.employeeCode]);

  // ==================== Column Definition Section ====================
  const getStatusBadgeClass = (value = '') => {
    const normalized = value.toString().toLowerCase();
    if (normalized.includes('active')) return 'status-active';
    if (normalized.includes('inactive')) return 'status-inactive';
    if (normalized.includes('progress') || normalized.includes('pending')) return 'status-progress';
    if (normalized.includes('complete')) return 'status-completed';
    return '';
  };

  const [columnDefs] = useState([
    // Column definitions for AG Grid
    {
      field: 'employeeCode',
      headerName: 'Emp Code',
      sortable: true,
      filter: false,
      valueFormatter: (params) => `E0${params.value}`,
    },
    {
      field: 'userName',
      headerName: 'Name',
      sortable: true,
      filter: false,
    },
    {
      field: 'department',
      headerName: 'Department',
      sortable: true,
      filter: false,
    },
    {
      field: 'designation',
      headerName: 'Designation',
      sortable: true,
      filter: false,
    },

    {
      field: 'joiningDate',
      headerName: 'Joining Date',
      sortable: true,
      valueFormatter: (params) => formatDate(params.value),
    },
    {
      field: 'status',
      headerName: 'Status',
      sortable: true,
      cellRenderer: (params) => {
        const status = params.value;

        return (
          <Tag
            className={`Badge-lables status-pill ${getStatusBadgeClass(status)}`}
            colorScheme={statusColorScheme[status] || 'gray'}
          >
            {status}
          </Tag>
        );
      },
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 150,
      cellRenderer: (params) => {
        const { isReadOnly } = params.context;
        // NEW → Dynamic admin check from backend response
        const isAdmin = localStorage.getItem('IS_ADMIN') === 'true';
        return (
          <div className="action-buttons">
            <CustomIconButton
              iconClass="fas fa-eye"
              tooltip="View Employee Details"
              onClick={() => handleViewDetails(params.data)} //View Employee Details
            />
            <CustomIconButton
              iconClass="fas fa-edit"
              tooltip="Edit Employee"
              onClick={() => openModal('edit', params.data)} //Edit Employee Details
              isDisabled={isReadOnly}
            />
            <CustomIconButton
              iconClass="fas fa-trash"
              tooltip="Delete Employee"
              onClick={() => openModal('delete', params.data)} // Delete Employee
              isDisabled={isReadOnly}
            />
            {/*  Reset password only visible for dynamic-admin users */}
            {isAdmin && (
              <CustomIconButton
                iconClass="fa-solid fa-user-lock"
                tooltip="Reset Password"
                onClick={() => openModal('resetPassword', params.data)}
                isDisabled={isReadOnly}
              />
            )}
          </div>
        );
      },
    },
  ]);

  // ==================== MODAL CONTROL FUNCTIONS ====================

  /**
   * Opens modal based on type (add, edit, delete)
   * If editing or deleting, also sets the selected user data
   */
  const openModal = (type, user = null) => {
    setModalState({ type, isOpen: true });
    if (user) {
      setSelectedUser({ ...user });
      if (type === 'edit') {
        setNewUser({
          name: user.userName,
          email: user.email,
          employeecode: user.employeeCode,
          departments: user.departmentId?.toString() || '',
          status: user.status_Id?.toString() || '',
          designation: user.designation_Id?.toString() || '',
          workingstatus: user.working_status_Id?.toString() || '',
          employmenttype: user.employmentTypeId?.toString() || '',
          roles: user.roleId?.toString() || '',
          teamId: user.team_id?.toString() || '',
          dateOfJoining: user.joiningDate || '',
          location: user.location || '',
          maritalStatus: user.maritalStatus || '',
          Gender: user.gender || '',
          dateofbirth: user.dob || '',
          emgContactName: user.emgContactName || '',
          emgContactRelation: user.emgContactRelation || '',
          phoneNo:
            user.phoneNo && user.phoneNo !== 0 ? user.phoneNo.toString() : '',
          emgContactPhoneNo:
            user.emgContactPhoneno && user.emgContactPhoneno !== 0
              ? user.emgContactPhoneno.toString()
              : '',
          ReportingId: user.reportingId?.toString() || '',
          reportingrights: user.reportingrights || false,
          isBillable: user.isBillable || false,
          isAdmin: user.isAdmin || false,
        });
      }
      setIsPhoneTouched(false);
      setIsEmgPhoneTouched(false);
    }
  };

  /**
   * Closes any open modal and resets all related states
   */
  const closeModal = () => {
    setModalState({ type: null, isOpen: false });
    setEmailError('');
    setEmployeeCodeError('');
    setIsPhoneTouched(false);
    setSelectedUser(null);
    setNewUser({
      // Reset form data
      name: '',
      email: '',
      employeecode: '',
      departments: '',
      status: 'Active',
      designation: '',
      workingstatus: '',
      dateOfJoining: '',
      dateofbirth: '',
      Gender: '',
      roles: '',
      employmenttype: '',
      isBillable: false,
      reportingRights: false,
      isAdmin: false,
      phoneNo: '',
      location: '',
      maritalStatus: '',
      emgContactName: '',
      emgContactRelation: '',
      emgContactPhoneNo: '',
      teamName: '',
      errors: {},
    });
    setFilters((prevFilters) => ({
      ...prevFilters,
      department: '',
      status: '',
    }));
  };

  // ==================== MAIN COMPONENT RENDER ====================
  return (
    <div id="user">
      {activeView === 'Usermanagement' && (
        <Box className="list-table-page">
          <ToastContainer />
          <Flex className="page-header-zone">
            <Heading className="page-title">Employee</Heading>
            <Button
              className="page-primary-cta"
              onClick={() => openModal('add')}
              isDisabled={isReadOnly}
            >
              Add
            </Button>
          </Flex>
          <Flex className="list-filter-bar">
            <Box className="list-filter-select">
              <Dropdown
                type="departments"
                placeholder="All Departments"
                selectedValue={filters.department}
                setSelectedValue={(value) =>
                  setFilters({ ...filters, department: value })
                }
              />
            </Box>
            <Box className="list-filter-select">
              <Dropdown
                type="activeinactivestatus"
                placeholder="All Status"
                selectedValue={filters.status}
                setSelectedValue={(value) =>
                  setFilters({ ...filters, status: value })
                }
              />
            </Box>
            <Box className="list-search-wrap">
              <Input
                className="list-search-input"
                placeholder="Search..."
                maxLength={MAX_EMPLOYEE_NAME_LENGTH}
                onChange={(e) =>
                  setFilters({ ...filters, search: e.target.value })
                }
              />
            </Box>
          </Flex>
          {/* AG Grid for displaying users */}
          <div
            className="ag-theme-alpine ag-grid-container list-table-grid content-surface"
            style={{ position: 'relative' }}
          >
            {isGridLoading && (
              <Box
                position="absolute"
                top="0"
                left="0"
                right="0"
                bottom="0"
                bg="whiteAlpha.600"
                zIndex="10"
                display="flex"
                alignItems="center"
                justifyContent="center"
              >
                <TimeSnapLoader size="lg" text="Loading users..." />
              </Box>
            )}
            <AgGridReact
              rowData={processedUsers}
              suppressNoRowsOverlay={isGlobalLoading || isGridLoading}
              columnDefs={columnDefs}
              suppressMovableColumns={true}
              suppressRowDrag={true}
              suppressMoveWhenRowDragging={true}
              defaultColDef={{
                flex: 1,
                minWidth: 100,
                resizable: false,
              }}
              pagination={true}
              paginationPageSize={10}
              paginationPageSizeSelector={[10, 25, 50, 100]}
              context={{ isReadOnly }} // Pass isReadOnly as context to grid
              reactiveCustomComponents={true} // Ensure custom components react to updates
            />
          </div>
          {/* ==================== MODAL Section ==================== */}
          {/* Add Modal */}

          <CustomModal
            isOpen={modalState.type === 'add'}
            closeOnOverlayClick={false}
            onClose={closeModal}
            size="3xl"
          >
            <ModalOverlay />
            <ModalContent className="modal-content-layout">
              <ModalHeader
                className="user-modal-header"
                textAlign="center"
                p={2}
                fontWeight="bold"
                fontSize="lg"
              >
                Create Employee
              </ModalHeader>
              <ModalCloseButton />
              <ModalBody className="user-modal-body" paddingY={0} flex="1" overflow="auto">
                <Tabs className="user-form-tabs" isFitted variant="enclosed">
                  <TabList className="user-form-tablist">
                    <Tab
                      _selected={{
                        bg: '#315C8C',
                        color: '#FFFFFF',
                        borderBottomColor: 'transparent',
                        fontWeight: '700',
                      }}
                    >
                      Professional Details{' '}
                      <Text as="span" color="red.500">
                        *
                      </Text>
                    </Tab>
                    <Tab
                      _selected={{
                        bg: '#315C8C',
                        color: '#FFFFFF',
                        borderBottomColor: 'transparent',
                        fontWeight: '700',
                      }}
                    >
                      Personal Details{' '}
                      <Text as="span" color="red.500">
                        *
                      </Text>
                    </Tab>
                  </TabList>
                  <TabPanels>
                    {/* ==================== Professional DETAILS TAB ==================== */}
                    <TabPanel className="user-form-tabpanel">
                      <VStack spacing={4} align="stretch">
                        <Flex gap={3}>
                          <Box flex={1}>
                            <FormControl
                              isRequired
                              isInvalid={!!newUser.errors?.name}
                            >
                              <FormLabel fontWeight="medium">Name</FormLabel>
                              <Input
                                placeholder="Enter"
                                size="md"
                                maxLength={MAX_NAME_LENGTH}
                                value={newUser.name}
                                onChange={(e) => {
                                  const newValue = e.target.value;
                                  if (
                                    newValue === '' ||
                                    validateStringInput(newValue)
                                  ) {
                                    setNewUser((prev) => ({
                                      ...prev,
                                      name: newValue,
                                      errors: {
                                        ...prev.errors,
                                        name: newValue
                                          ? undefined
                                          : prev.errors?.name,
                                      },
                                    }));
                                  }
                                }}
                              />
                              {newUser.errors?.name && (
                                <Text color="red.500">
                                  {newUser.errors.name}
                                </Text>
                              )}
                            </FormControl>
                          </Box>
                          <Box flex={1}>
                            <FormControl
                              isRequired
                              isInvalid={
                                !!emailError || !!newUser.errors?.email
                              }
                            >
                              <FormLabel fontWeight="medium">
                                Official Email
                              </FormLabel>
                              <Box position="relative">
                                {/* Overlay preview input showing suggested full email (read-only, gray) */}
                                {showDomainSuggestion && (
                                  <Input
                                    readOnly
                                    pointerEvents="none"
                                    size="md"
                                    value={
                                      (newUser.email || '').includes('@')
                                        ? `${(newUser.email || '').split('@')[0]}@${suggestedDomain}`
                                        : `${newUser.email || ''}@${suggestedDomain}`
                                    }
                                    style={{
                                      position: 'absolute',
                                      top: 0,
                                      left: 0,
                                      width: '100%',
                                      color: '#9CA3AF', // gray
                                      background: 'transparent',
                                      borderColor: 'transparent',
                                      zIndex: 0,
                                    }}
                                  />
                                )}

                                {/* Actual input placed above the preview */}
                                <Input
                                  type="email"
                                  placeholder="Enter"
                                  size="md"
                                  value={newUser.email}
                                  onChange={handleEmailChange}
                                  onBlur={(e) => {
                                    // If we just accepted the suggestion via Enter/Tab,
                                    // skip validating here because we've already validated
                                    // the completed value in acceptSuggestedDomainAndFocusNext.
                                    if (ignoreNextBlurValidationRef.current) {
                                      ignoreNextBlurValidationRef.current = false;
                                      setShowDomainSuggestion(false);
                                      return;
                                    }
                                    if (e.target.value.trim() !== '') {
                                      validateEmail(e.target.value); // validate only if something is typed
                                    } else {
                                      setEmailError('');
                                    }
                                  }}
                                  onKeyDown={(e) => {
                                    if (
                                      (e.key === 'Enter' || e.key === 'Tab') &&
                                      showDomainSuggestion
                                    ) {
                                      // For Enter and Tab, accept the suggested domain.
                                      e.preventDefault();
                                      acceptSuggestedDomainAndFocusNext(
                                        e.target,
                                      );
                                    }
                                  }}
                                  style={{
                                    position: 'relative',
                                    zIndex: 1,
                                    background: 'transparent',
                                  }}
                                />
                              </Box>
                              {emailError && (
                                <Text color="red.500" fontSize="sm" mt={1}>
                                  {emailError}
                                </Text>
                              )}
                              {newUser.errors?.email && (
                                <Text color="red.500">
                                  {newUser.errors.email}
                                </Text>
                              )}
                            </FormControl>
                          </Box>
                        </Flex>
                        <Flex gap={3}>
                          <Box flex={1}>
                            <FormControl
                              isRequired
                              isInvalid={
                                !!employeeCodeError ||
                                !!newUser.errors?.employeecode
                              }
                            >
                              <FormLabel fontWeight="medium">
                                Employee Code
                              </FormLabel>
                              <Input
                                placeholder="Enter"
                                value={newUser.employeecode || ''}
                                onChange={handleEmployeeCodeChange}
                                maxLength={4}
                              />
                              {employeeCodeError && (
                                <Text color="red.500" fontSize="sm" mt={1}>
                                  {employeeCodeError}
                                </Text>
                              )}
                              {newUser.errors?.employeecode && (
                                <Text color="red.500">
                                  {newUser.errors.employeecode}
                                </Text>
                              )}
                            </FormControl>
                          </Box>
                          <Box flex={1}>
                            <FormControl
                              isRequired
                              isInvalid={!!newUser.errors?.dateOfJoining}
                            >
                              <FormLabel fontWeight="medium">
                                Joining Date
                              </FormLabel>
                              <Input
                                type="date"
                                max={new Date().toISOString().slice(0, 10)}
                                value={newUser.dateOfJoining}
                                onChange={(e) =>
                                  clearFieldError(
                                    'dateOfJoining',
                                    e.target.value,
                                  )
                                }
                                onFocus={(e) => {
                                  try {
                                    e.target?.showPicker &&
                                      e.target.showPicker();
                                  } catch (err) {}
                                }}
                                onKeyDown={(e) => {
                                  if (e.key && e.key.length === 1)
                                    e.preventDefault();
                                }}
                              />
                              {newUser.errors?.dateOfJoining && (
                                <Text color="red.500">
                                  {newUser.errors.dateOfJoining}
                                </Text>
                              )}
                            </FormControl>
                          </Box>
                          <Box flex={1}>
                            <FormControl
                              isRequired
                              isInvalid={!!newUser.errors?.roles}
                            >
                              <FormLabel fontWeight="medium">Role</FormLabel>
                              <Dropdown
                                type="roles"
                                placeholder="Select "
                                selectedValue={newUser.roles || ''}
                                setSelectedValue={(value) =>
                                  clearFieldError('roles', value)
                                }
                              />

                              {newUser.errors?.roles && (
                                <Text color="red.500">
                                  {newUser.errors.roles}
                                </Text>
                              )}
                            </FormControl>
                          </Box>
                        </Flex>
                        <Flex gap={3}>
                          <Box flex={1}>
                            <FormControl
                              isRequired
                              isInvalid={!!newUser.errors?.employmenttype}
                            >
                              <FormLabel fontWeight="medium">
                                Employment Type
                              </FormLabel>
                              <Dropdown
                                type="employmenttype"
                                placeholder="Select "
                                selectedValue={newUser.employmenttype || ''}
                                setSelectedValue={(value) =>
                                  clearFieldError('employmenttype', value)
                                }
                              />
                              {newUser.errors?.employmenttype && (
                                <Text color="red.500">
                                  {newUser.errors.employmenttype}
                                </Text>
                              )}
                            </FormControl>
                          </Box>
                          <Box flex={1}>
                            <FormControl
                              isRequired
                              isInvalid={!!newUser.errors?.designation}
                            >
                              <FormLabel fontWeight="medium">
                                Designation
                              </FormLabel>
                              <Dropdown
                                type="designation"
                                placeholder="Select "
                                selectedValue={newUser.designation || ''}
                                setSelectedValue={(value) =>
                                  clearFieldError('designation', value)
                                }
                              />
                              {newUser.errors?.designation && (
                                <Text color="red.500">
                                  {newUser.errors.designation}
                                </Text>
                              )}
                            </FormControl>
                          </Box>
                          <Box flex={1}>
                            <FormControl
                              isRequired
                              isInvalid={!!newUser.errors?.departments}
                            >
                              <FormLabel fontWeight="medium">
                                Department
                              </FormLabel>
                              <Dropdown
                                type="departments"
                                placeholder="Select  "
                                selectedValue={newUser.departments || ''}
                                setSelectedValue={(value) =>
                                  clearFieldError('departments', value)
                                }
                              />
                              {newUser.errors?.departments && (
                                <Text color="red.500">
                                  {newUser.errors.departments}
                                </Text>
                              )}
                            </FormControl>
                          </Box>
                        </Flex>
                        <Flex gap={3}>
                          <Box flex={30}>
                            <FormControl
                              isRequired
                              isInvalid={!!newUser.errors?.workingstatus}
                            >
                              <FormLabel fontWeight="medium">
                                Working Status
                              </FormLabel>
                              <Dropdown
                                type="workingstatus"
                                placeholder="Select "
                                selectedValue={newUser.workingstatus || ''}
                                setSelectedValue={(value) =>
                                  clearFieldError('workingstatus', value)
                                }
                              />
                              {newUser.errors?.workingstatus && (
                                <Text color="red.500">
                                  {newUser.errors.workingstatus}
                                </Text>
                              )}
                            </FormControl>
                          </Box>

                          <Box flex={30}>
                            <FormControl isInvalid={!!newUser.errors?.teamId}>
                              <FormLabel fontWeight="medium">
                                Team Name
                              </FormLabel>
                              <Dropdown
                                type="teams"
                                placeholder="Select  "
                                selectedValue={newUser.teamId || ''}
                                options={teams.map((team) => ({
                                  value: team.Id,
                                  label: team.Name,
                                }))}
                                setSelectedValue={(value) =>
                                  setNewUser({ ...newUser, teamId: value })
                                }
                              />
                              {newUser.errors?.teamId && (
                                <Text color="red.500">
                                  {newUser.errors.teamId}
                                </Text>
                              )}
                            </FormControl>
                          </Box>

                          <Box flex={30}>
                            <FormControl
                              isRequired
                              isInvalid={!!newUser.errors?.ReportingId}
                            >
                              <FormLabel fontWeight="medium">
                                Reporting To
                              </FormLabel>
                              <Dropdown
                                type="reportingto"
                                placeholder="Select  "
                                selectedValue={newUser.ReportingId || ''}
                                setSelectedValue={(value) =>
                                  setNewUser((prev) => ({
                                    ...prev,
                                    ReportingId: value,
                                    errors: {
                                      ...prev.errors,
                                      ReportingId: '', // clear the error when value is selected
                                    },
                                  }))
                                }
                              />
                              {newUser.errors?.ReportingId && (
                                <Text color="red.500">
                                  {newUser.errors.ReportingId}
                                </Text>
                              )}
                            </FormControl>
                          </Box>

                          <Box flex={1}></Box>
                        </Flex>
                      </VStack>
                    </TabPanel>
                    {/* ==================== PERSONAL DETAILS TAB ==================== */}
                    <TabPanel className="user-form-tabpanel">
                      <VStack spacing={4} align="stretch">
                        <Flex gap={3}>
                          <Box flex={1}>
                            <FormControl
                              isInvalid={
                                !!newUser.errors?.phoneNo &&
                                newUser.phoneNo !== '' &&
                                newUser.phoneNo?.length !== 10
                              }
                            >
                              <FormLabel fontWeight="medium">
                                Phone Number
                              </FormLabel>
                              <Input
                                placeholder="Enter"
                                type="tel"
                                value={newUser.phoneNo || ''}
                                onChange={(e) => {
                                  const value = e.target.value;
                                  if (
                                    /^\d*$/.test(value) &&
                                    value.length <= 10
                                  ) {
                                    setNewUser((prev) => {
                                      const updatedUser = {
                                        ...prev,
                                        phoneNo: value,
                                        errors: {
                                          ...prev.errors,
                                          phoneNo:
                                            value === '' || value.length === 10
                                              ? undefined
                                              : prev.errors?.phoneNo,
                                        },
                                      };
                                      return updatedUser;
                                    });
                                  }
                                }}
                                maxLength={10}
                              />
                              {newUser.errors?.phoneNo &&
                                newUser.phoneNo !== '' &&
                                newUser.phoneNo?.length !== 10 && (
                                  <Text color="red.500" fontSize="sm" mt={2}>
                                    {newUser.errors.phoneNo}
                                  </Text>
                                )}
                            </FormControl>
                          </Box>
                          <Box flex={1}>
                            <FormControl>
                              <FormLabel fontWeight="medium">
                                Location
                              </FormLabel>
                              <Input
                                placeholder="Enter"
                                value={newUser.location || ''}
                                onChange={(e) => {
                                  const value = e.target.value;
                                  if (
                                    value === '' ||
                                    validateStringInput(value)
                                  ) {
                                    setNewUser({ ...newUser, location: value });
                                  }
                                }}
                                maxLength={MAX_NAME_LENGTH}
                              />
                            </FormControl>
                          </Box>
                        </Flex>
                        <Flex gap={3}>
                          <Box flex={7}>
                            <FormControl>
                              <FormLabel fontWeight="medium">
                                Marital Status
                              </FormLabel>
                              <Dropdown
                                placeholder="Select"
                                itemsProp={maritalStatusOptions} // ✅ static data
                                selectedValue={newUser.maritalStatus}
                                setSelectedValue={(value) =>
                                  setNewUser({
                                    ...newUser,
                                    maritalStatus: value, // ✅ same as e.target.value
                                  })
                                }
                              />
                            </FormControl>
                          </Box>
                          <Box flex={6}>
                            <FormControl
                              isRequired
                              isInvalid={!!newUser.errors?.Gender}
                            >
                              <FormLabel fontWeight="medium">Gender</FormLabel>
                              <Dropdown
                                placeholder="Select"
                                itemsProp={genderOptions} // ✅ static options
                                selectedValue={newUser.Gender || ''}
                                setSelectedValue={
                                  (value) => clearFieldError('Gender', value) // ✅ old logic preserved
                                }
                              />
                              {newUser.errors?.Gender && (
                                <Text color="red.500">
                                  {newUser.errors.Gender}
                                </Text>
                              )}
                            </FormControl>
                          </Box>

                          <Box flex={6}>
                            <FormControl
                              isRequired
                              isInvalid={!!newUser.errors?.dateofbirth}
                            >
                              <FormLabel fontWeight="medium">
                                Date of Birth
                              </FormLabel>
                              <Input
                                type="date"
                                max={new Date().toISOString().slice(0, 10)}
                                value={newUser.dateofbirth || ''}
                                onChange={(e) =>
                                  // setNewUser({
                                  //   ...newUser,
                                  //   dateofbirth: e.target.value,
                                  // })
                                  clearFieldError('dateofbirth', e.target.value)
                                }
                                onFocus={(e) => {
                                  try {
                                    e.target?.showPicker &&
                                      e.target.showPicker();
                                  } catch (err) {}
                                }}
                                onKeyDown={(e) => {
                                  if (e.key && e.key.length === 1)
                                    e.preventDefault();
                                }}
                              />
                              {newUser.errors?.dateofbirth && (
                                <Text color="red.500">
                                  {newUser.errors.dateofbirth}
                                </Text>
                              )}
                            </FormControl>
                          </Box>
                          <Box flex={2}></Box>
                        </Flex>

                        {/* Emergency Contact Section-separate section */}
                        <Box className="user-emergency-card" mt={4} p={3} borderWidth="1px" borderRadius="lg">
                          <FormLabel fontWeight="bold" fontSize="lg" mb={3}>
                            Emergency Contact
                          </FormLabel>

                          {/* Emergency contact - 3 fields in one row */}
                          <Flex gap={3}>
                            <Box flex={1}>
                              <FormControl>
                                <FormLabel fontWeight="medium">Name</FormLabel>
                                <Input
                                  placeholder="Enter"
                                  value={newUser.emgContactName || ''}
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    if (
                                      value === '' ||
                                      validateStringInput(value)
                                    ) {
                                      setNewUser({
                                        ...newUser,
                                        emgContactName: value,
                                      });
                                    }
                                  }}
                                  maxLength={MAX_NAME_LENGTH}
                                />
                              </FormControl>
                            </Box>

                            <Box flex={1}>
                              <FormControl>
                                <FormLabel fontWeight="medium">
                                  Relation
                                </FormLabel>
                                <Input
                                  placeholder="Enter"
                                  value={newUser.emgContactRelation || ''}
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    if (
                                      value === '' ||
                                      validateStringInput(value)
                                    ) {
                                      setNewUser({
                                        ...newUser,
                                        emgContactRelation: value,
                                      });
                                    }
                                  }}
                                  maxLength={MAX_NAME_LENGTH}
                                />
                              </FormControl>
                            </Box>

                            <Box flex={1}>
                              <FormControl
                                isInvalid={
                                  !!newUser.errors?.emgContactPhoneNo &&
                                  newUser.emgContactPhoneNo !== '' &&
                                  newUser.emgContactPhoneNo?.length !== 10
                                }
                              >
                                <FormLabel fontWeight="medium">
                                  Phone Number
                                </FormLabel>
                                <Input
                                  placeholder="Enter"
                                  type="tel"
                                  value={newUser.emgContactPhoneNo || ''}
                                  onChange={(e) => {
                                    const value = e.target.value;

                                    if (
                                      /^\d*$/.test(value) &&
                                      value.length <= 10
                                    ) {
                                      setNewUser((prev) => {
                                        const updatedUser = {
                                          ...prev,
                                          emgContactPhoneNo: value,
                                          errors: {
                                            ...prev.errors,
                                            emgContactPhoneNo:
                                              value === '' ||
                                              value.length === 10
                                                ? undefined
                                                : prev.errors
                                                    ?.emgContactPhoneNo,
                                          },
                                        };
                                        return updatedUser;
                                      });
                                    }
                                  }}
                                  maxLength={10}
                                />
                                {newUser.errors?.emgContactPhoneNo &&
                                  newUser.emgContactPhoneNo !== '' &&
                                  newUser.emgContactPhoneNo?.length !== 10 && (
                                    <Text color="red.500" fontSize="sm" mt={2}>
                                      {newUser.errors.emgContactPhoneNo}
                                    </Text>
                                  )}
                              </FormControl>
                            </Box>
                          </Flex>
                        </Box>
                      </VStack>
                    </TabPanel>
                  </TabPanels>
                </Tabs>
              </ModalBody>
              <ModalFooter className="user-modal-footer">
                <Flex
                  className="user-modal-footer-row"
                  w="100%"
                  justifyContent="space-between"
                  alignItems="center"
                >
                  <Flex className="user-modal-permissions">
                  <Checkbox
                    isChecked={newUser?.isBillable || false}
                    onChange={(e) =>
                      setNewUser({ ...newUser, isBillable: e.target.checked })
                    }
                    colorScheme="blue"
                    size="sm"
                    borderColor="blackAlpha.600"
                  >
                    Billable Resource
                  </Checkbox>
                  <Checkbox
                    isChecked={newUser.isAdmin || false}
                    onChange={(e) => {
                      const checked = e.target.checked;
                      setNewUser({
                        ...newUser,
                        isAdmin: checked,
                        reportingRights: checked ? true : newUser.reportingRights,
                      });
                    }}
                    colorScheme="blue"
                    size="sm"
                    borderColor="blackAlpha.600"
                  >
                    Is Admin
                  </Checkbox>
                  <Checkbox
                    isChecked={newUser.reportingRights}
                    onChange={(e) =>
                      setNewUser({
                        ...newUser,
                        reportingRights: e.target.checked,
                      })
                    }
                    colorScheme="blue"
                    size="sm"
                    isDisabled={newUser.isAdmin}
                    borderColor="blackAlpha.600"
                  >
                    Timesheet Approval Rights
                  </Checkbox>
                  </Flex>
                  <Flex gap={4} justify="flex-end">
                    <CustomButton
                      label="Cancel"
                      onClick={closeModal}
                      variant="outline"
                      colorScheme="black"
                      className="common-button"
                    />
                    <CustomButton
                      label="Save"
                      onClick={handleAddUser}
                      colorScheme="green"
                      className="common-button"
                      isLoading={isSubmitting}
                    />
                  </Flex>
                </Flex>
              </ModalFooter>
            </ModalContent>
          </CustomModal>
          {/* Edit Modal */}
          <CustomModal
            isOpen={modalState.type === 'edit'}
            closeOnOverlayClick={false}
            onClose={closeModal}
            size="3xl"
          >
            <ModalOverlay />
            <ModalContent className="modal-content-layout">
              <ModalHeader
                className="user-modal-header"
                textAlign="center"
                p={2}
                fontWeight="bold"
                fontSize="lg"
              >
                Edit Employee
              </ModalHeader>
              <ModalCloseButton />
              <ModalBody className="user-modal-body" paddingY={0} flex="1" overflow="auto">
                <Tabs className="user-form-tabs" isFitted variant="enclosed">
                  <TabList className="user-form-tablist">
                    <Tab
                      _selected={{
                        bg: '#315C8C',
                        color: '#FFFFFF',
                        borderBottomColor: 'transparent',
                        fontWeight: '700',
                      }}
                    >
                      Professional Details{' '}
                      <Text as="span" color="red.500">
                        *
                      </Text>
                    </Tab>
                    <Tab
                      _selected={{
                        bg: '#315C8C',
                        color: '#FFFFFF',
                        borderBottomColor: 'transparent',
                        fontWeight: '700',
                      }}
                    >
                      Personal Details{' '}
                      <Text as="span" color="red.500">
                        *
                      </Text>
                    </Tab>
                  </TabList>

                  <TabPanels>
                    {/* ==================== PROFESSIONAL DETAILS TAB ==================== */}
                    <TabPanel className="user-form-tabpanel">
                      <VStack spacing={4} align="stretch">
                        <Flex gap={3}>
                          <Box flex={1}>
                            <FormControl isRequired>
                              <FormLabel fontWeight="medium">Name</FormLabel>
                              <Input
                                size="md"
                                value={newUser.name}
                                isReadOnly
                              />
                            </FormControl>
                          </Box>
                          <Box flex={1}>
                            <FormControl isRequired>
                              <FormLabel fontWeight="medium">
                                Official Email
                              </FormLabel>
                              <Input
                                type="email"
                                size="md"
                                value={newUser.email}
                                isReadOnly
                              />
                            </FormControl>
                          </Box>
                        </Flex>
                        <Flex gap={3}>
                          <Box flex={1}>
                            <FormControl isRequired>
                              <FormLabel fontWeight="medium">
                                Employee Code
                              </FormLabel>
                              <Input value={newUser.employeecode} isReadOnly />
                            </FormControl>
                          </Box>
                          <Box flex={1}>
                            <FormControl isRequired>
                              <FormLabel fontWeight="medium">
                                Joining Date
                              </FormLabel>
                              <Input
                                type="date"
                                value={newUser.dateOfJoining}
                                isReadOnly
                                onChange={(e) =>
                                  clearFieldError(
                                    'dateOfJoining',
                                    e.target.value,
                                  )
                                }
                              />
                            </FormControl>
                          </Box>
                          <Box flex={1}>
                            <FormControl isRequired>
                              <FormLabel fontWeight="medium">Role</FormLabel>
                              <Dropdown
                                type="roles"
                                selectedValue={newUser.roles}
                                setSelectedValue={(value) =>
                                  clearFieldError('roles', value)
                                }
                              />
                            </FormControl>
                          </Box>
                        </Flex>
                        <Flex gap={3}>
                          <Box flex={1}>
                            <FormControl isRequired>
                              <FormLabel fontWeight="medium">
                                Employment Type
                              </FormLabel>
                              <Dropdown
                                type="employmenttype"
                                selectedValue={newUser.employmenttype || ''}
                                setSelectedValue={(value) =>
                                  setNewUser({
                                    ...newUser,
                                    employmenttype: value,
                                  })
                                }
                              />
                            </FormControl>
                          </Box>
                          <Box flex={1}>
                            <FormControl isRequired>
                              <FormLabel fontWeight="medium">
                                Designation
                              </FormLabel>
                              <Dropdown
                                type="designation"
                                selectedValue={newUser.designation || ''}
                                setSelectedValue={(value) =>
                                  setNewUser({ ...newUser, designation: value })
                                }
                              />
                            </FormControl>
                          </Box>
                          <Box flex={1}>
                            <FormControl isRequired>
                              <FormLabel fontWeight="medium">
                                Department
                              </FormLabel>
                              <Dropdown
                                type="departments"
                                selectedValue={newUser.departments}
                                setSelectedValue={(value) =>
                                  setNewUser({ ...newUser, departments: value })
                                }
                              />
                            </FormControl>
                          </Box>
                        </Flex>
                        <Flex gap={3}>
                          <Box flex={8}>
                            <FormControl isRequired>
                              <FormLabel fontWeight="medium">
                                Working Status
                              </FormLabel>
                              <Dropdown
                                type="workingstatus"
                                selectedValue={newUser.workingstatus || ''}
                                setSelectedValue={(value) =>
                                  setNewUser({
                                    ...newUser,
                                    workingstatus: value,
                                  })
                                }
                              />
                            </FormControl>
                          </Box>

                          <Box flex={8}>
                            <FormControl>
                              <FormLabel fontWeight="medium">
                                Team Name
                              </FormLabel>
                              <Dropdown
                                type="teams"
                                placeholder="Select"
                                selectedValue={newUser.teamId || ''}
                                options={teams.map((team) => ({
                                  value: team.Id,
                                  label: team.Name,
                                }))}
                                setSelectedValue={(value) =>
                                  setNewUser({ ...newUser, teamId: value })
                                }
                              />
                            </FormControl>
                          </Box>

                          <Box flex={10}>
                            <FormControl isRequired>
                              <FormLabel fontWeight="medium">
                                Reporting To
                              </FormLabel>
                              <Dropdown
                                type="reportingto"
                                placeholder="Select"
                                selectedValue={newUser.ReportingId}
                                setSelectedValue={(value) =>
                                  setNewUser((prev) => ({
                                    ...prev,
                                    ReportingId: value,
                                  }))
                                }
                                extraParams={reportingParams}
                              />
                            </FormControl>
                          </Box>
                        </Flex>
                      </VStack>
                    </TabPanel>

                    {/* ==================== PERSONAL DETAILS TAB ==================== */}
                    <TabPanel className="user-form-tabpanel">
                      <VStack spacing={4} align="stretch">
                        <Flex gap={3} align="center">
                          <Box flex={1}>
                            <FormControl
                              isInvalid={
                                isPhoneTouched &&
                                newUser.phoneNo &&
                                newUser.phoneNo.length > 0 &&
                                newUser.phoneNo.length !== 10
                              }
                            >
                              <FormLabel fontWeight="medium">
                                Phone Number
                              </FormLabel>
                              <Input
                                type="tel"
                                placeholder="Enter"
                                value={newUser.phoneNo || ''}
                                onChange={(e) => {
                                  const value = e.target.value;
                                  setIsPhoneTouched(true);
                                  if (
                                    /^\d*$/.test(value) &&
                                    value.length <= 10
                                  ) {
                                    setNewUser((prev) => ({
                                      ...prev,
                                      phoneNo: value,
                                    }));
                                  }
                                }}
                                maxLength={10}
                              />
                              {isPhoneTouched &&
                                newUser.phoneNo !== '' &&
                                newUser.phoneNo?.length !== 10 && (
                                  <FormErrorMessage>
                                    Phone number must be 10 digits
                                  </FormErrorMessage>
                                )}
                            </FormControl>
                          </Box>
                          <Box flex={1}>
                            <FormControl>
                              <FormLabel fontWeight="medium">
                                Location
                              </FormLabel>
                              <Input
                                placeholder="Enter"
                                value={
                                  newUser.location === 'NA'
                                    ? ''
                                    : newUser.location || ''
                                }
                                onChange={(e) => {
                                  const value = e.target.value;
                                  if (
                                    value === '' ||
                                    validateStringInput(value)
                                  ) {
                                    setNewUser((prev) => ({
                                      ...prev,
                                      location: value,
                                    }));
                                  }
                                }}
                                maxLength={MAX_NAME_LENGTH}
                              />
                            </FormControl>
                          </Box>
                          <Box flex={1}>
                            <FormControl isRequired>
                              <FormLabel fontWeight="medium">Status</FormLabel>
                              <Dropdown
                                type="activeinactivestatus"
                                selectedValue={newUser.status}
                                setSelectedValue={(value) =>
                                  setNewUser({ ...newUser, status: value })
                                }
                              />
                            </FormControl>
                          </Box>
                        </Flex>
                        <Flex gap={3}>
                          <Box flex={7}>
                            <FormControl>
                              <FormLabel fontWeight="medium">
                                Marital Status
                              </FormLabel>
                              <Select
                                placeholder="Select "
                                value={newUser.maritalStatus || ''}
                                onChange={(e) =>
                                  setNewUser({
                                    ...newUser,
                                    maritalStatus: e.target.value,
                                  })
                                }
                              >
                                <option value="UnMarried">UnMarried</option>
                                <option value="Married">Married</option>
                              </Select>
                            </FormControl>
                          </Box>
                          <Box flex={6}>
                            <FormControl isRequired>
                              <FormLabel fontWeight="medium">Gender</FormLabel>
                              <Select
                                value={newUser.Gender || ''}
                                onChange={(e) =>
                                  setNewUser({
                                    ...newUser,
                                    Gender: e.target.value,
                                  })
                                }
                              >
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Prefer not to say">
                                  Prefer not to say
                                </option>
                              </Select>
                            </FormControl>
                          </Box>

                          <Box flex={6}>
                            <FormControl isRequired>
                              <FormLabel fontWeight="medium">
                                Date of Birth
                              </FormLabel>
                              <Input
                                type="date"
                                isReadOnly
                                value={newUser.dateofbirth || ''}
                                onChange={(e) =>
                                  setNewUser({
                                    ...newUser,
                                    dateofbirth: e.target.value,
                                  })
                                }
                              />
                            </FormControl>
                          </Box>
                          <Box flex={2}></Box>
                        </Flex>
                        {/* Emergency Contact Section-separate section */}
                        <Box className="user-emergency-card" mt={4} p={3} borderWidth="1px" borderRadius="lg">
                          <FormLabel fontWeight="bold" fontSize="lg" mb={3}>
                            Emergency Contact
                          </FormLabel>
                          <Flex gap={3}>
                            <Box flex={1}>
                              <FormControl
                                isInvalid={
                                  !newUser.emgContactName ||
                                  !validateStringInput(newUser.emgContactName)
                                }
                              >
                                <FormLabel fontWeight="medium">Name</FormLabel>
                                <Input
                                  placeholder="Enter"
                                  value={
                                    newUser.emgContactName === 'NA'
                                      ? ''
                                      : newUser.emgContactName || ''
                                  }
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    if (
                                      value === '' ||
                                      validateStringInput(value)
                                    ) {
                                      setNewUser({
                                        ...newUser,
                                        emgContactName: value,
                                      });
                                    }
                                  }}
                                  maxLength={MAX_NAME_LENGTH}
                                />
                              </FormControl>
                            </Box>
                            <Box flex={1}>
                              <FormControl
                                isInvalid={
                                  !newUser.emgContactRelation ||
                                  !validateStringInput(
                                    newUser.emgContactRelation,
                                  )
                                }
                              >
                                <FormLabel fontWeight="medium">
                                  Relation
                                </FormLabel>
                                <Input
                                  placeholder="Enter"
                                  value={
                                    newUser.emgContactRelation === 'NA'
                                      ? ''
                                      : newUser.emgContactRelation || ''
                                  }
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    if (
                                      value === '' ||
                                      validateStringInput(value)
                                    ) {
                                      setNewUser({
                                        ...newUser,
                                        emgContactRelation: value,
                                      });
                                    }
                                  }}
                                  maxLength={MAX_NAME_LENGTH}
                                />
                              </FormControl>
                            </Box>
                            <Box flex={1}>
                              <FormControl
                                isInvalid={
                                  isEmgPhoneTouched &&
                                  newUser.emgContactPhoneNo &&
                                  newUser.emgContactPhoneNo.length > 0 &&
                                  newUser.emgContactPhoneNo.length !== 10
                                }
                              >
                                <FormLabel fontWeight="medium">
                                  Emergency Phone Number
                                </FormLabel>
                                <Input
                                  placeholder="Enter"
                                  type="tel"
                                  value={newUser.emgContactPhoneNo || ''}
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    setIsEmgPhoneTouched(true);
                                    if (
                                      /^\d*$/.test(value) &&
                                      value.length <= 10
                                    ) {
                                      setNewUser((prev) => ({
                                        ...prev,
                                        emgContactPhoneNo: value,
                                      }));
                                    }
                                  }}
                                  maxLength={10}
                                />
                                {isEmgPhoneTouched &&
                                  newUser.emgContactPhoneNo !== '' &&
                                  newUser.emgContactPhoneNo?.length !== 10 && (
                                    <FormErrorMessage>
                                      Phone number must be 10 digits
                                    </FormErrorMessage>
                                  )}
                              </FormControl>
                            </Box>
                          </Flex>
                        </Box>
                      </VStack>
                    </TabPanel>
                  </TabPanels>
                </Tabs>
              </ModalBody>

              <ModalFooter className="user-modal-footer">
                <Flex
                  className="user-modal-footer-row"
                  w="100%"
                  justifyContent="space-between"
                  alignItems="center"
                >
                  <Flex className="user-modal-permissions">
                  <Checkbox
                    isChecked={newUser.isBillable}
                    onChange={(e) =>
                      setNewUser({ ...newUser, isBillable: e.target.checked })
                    }
                    colorScheme="blue"
                    size="sm"
                  >
                    Billable Resource
                  </Checkbox>
                  <Checkbox
                    isChecked={newUser.isAdmin || false}
                    onChange={(e) => {
                      const checked = e.target.checked;
                      setNewUser({
                        ...newUser,
                        isAdmin: checked,
                        reportingrights: checked ? true : newUser.reportingrights,
                      });
                    }}
                    colorScheme="blue"
                    size="sm"
                    borderColor="blackAlpha.600"
                  >
                    Is Admin
                  </Checkbox>

                  <Checkbox
                    isChecked={newUser.reportingrights}
                    onChange={(e) =>
                      setNewUser({
                        ...newUser,
                        reportingrights: e.target.checked,
                      })
                    }
                    colorScheme="blue"
                    size="sm"
                    isDisabled={newUser.isAdmin}
                    borderColor="blackAlpha.600"
                  >
                    Timesheet Approval Rights
                  </Checkbox>
                  </Flex>
                  <Flex gap={4} justify="flex-end">
                    <CustomButton
                      label="Cancel"
                      onClick={closeModal}
                      variant="outline"
                      colorScheme="black"
                      className="common-button"
                    />
                    <CustomButton
                      label="Save"
                      onClick={handleEditUser}
                      colorScheme="green"
                      isLoading={isSubmitting}
                    />
                  </Flex>
                </Flex>
              </ModalFooter>
            </ModalContent>
          </CustomModal>

          {/* Reset Password Modal */}
          <Modal
            isOpen={modalState.type === 'resetPassword'}
            closeOnOverlayClick={false}
            onClose={closeModal}
          >
            <ModalOverlay />
            <ModalContent className="user-alert-modal-content">
              <ModalHeader>Reset Password</ModalHeader>
              <ModalCloseButton />
              <ModalBody>
                <Text>
                  Are you sure you want to reset{' '}
                  <Text as="span" fontWeight="bold">
                    {selectedUser?.userName}
                  </Text>
                  's password?
                </Text>
              </ModalBody>
              <ModalFooter>
                <Flex gap={4} justify="flex-end">
                  <CustomButton
                    label="Cancel"
                    onClick={closeModal}
                    variant="outline"
                    colorScheme="black"
                    className="common-button"
                  />
                  <CustomButton
                    label={isResetLoading ? 'Resetting...' : 'Reset'}
                    onClick={handleConfirmResetPassword}
                    colorScheme="red"
                    className="common-button"
                    isLoading={isResetLoading}
                    isDisabled={isResetLoading}
                  />
                </Flex>
              </ModalFooter>
            </ModalContent>
          </Modal>

          {/* Delete Modal */}
          <Modal
            isOpen={modalState.type === 'delete'}
            closeOnOverlayClick={false}
            onClose={closeModal}
            isCentered
          >
            <ModalOverlay />
            <ModalContent className="user-alert-modal-content">
              <ModalHeader>Delete Employee</ModalHeader>
              <ModalCloseButton />
              <ModalBody>
                <Text>
                  Are you sure you want to delete{' '}
                  <Text as="span" fontWeight="bold">
                    {selectedUser?.userName}
                  </Text>
                  ?
                </Text>
              </ModalBody>
              <ModalFooter>
                <Flex gap={4} justify="flex-end">
                  <CustomButton
                    label="Cancel"
                    onClick={closeModal}
                    variant="outline"
                    colorScheme="black"
                    className="common-button"
                  />
                  <CustomButton
                    label="Delete"
                    onClick={handleDeleteUser}
                    colorScheme="red"
                    className="common-button"
                    isLoading={isSubmitting}
                  />
                </Flex>
              </ModalFooter>
            </ModalContent>
          </Modal>
        </Box>
      )}
      {activeView === 'Userinfo' && (
        <Userinfo emp_code={selectedTeam} onBack={handleBackToManagement} />
      )}
    </div>
  );
};

export default Usermanagement;
