import React, { useEffect, useMemo, useState } from 'react';
import ProjectAnalyticReport from 'views/admin/ProjectManagement/components/ProjectAnalyticReport';
import { fetchProjectManagementDatas } from 'utils/api';

const Insights = () => {
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);
  const [isProjectsLoading, setIsProjectsLoading] = useState(true);

  useEffect(() => {
    const loadProjects = async () => {
      try {
        const response = await fetchProjectManagementDatas();
        const mapped = (response || []).map((project) => ({
          projectId: project.projectId,
          projectName: project.projectName,
        }));
        setProjects(mapped);
        if (mapped.length > 0) {
          setSelectedProject(mapped[0]);
        }
      } catch (error) {
        console.error('Error fetching insights projects:', error);
        setProjects([]);
      } finally {
        setIsProjectsLoading(false);
      }
    };

    loadProjects();
  }, []);

  const projectId = useMemo(() => selectedProject?.projectId, [selectedProject]);
  const projectName = useMemo(
    () => selectedProject?.projectName || 'Insights',
    [selectedProject],
  );

  return (
    <ProjectAnalyticReport
      projectId={projectId}
      projectName={projectName}
      projects={projects}
      isProjectListLoading={isProjectsLoading}
    />
  );
};

export default Insights;

