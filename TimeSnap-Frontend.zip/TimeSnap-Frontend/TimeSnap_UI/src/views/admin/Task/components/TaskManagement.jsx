import React, { useState, useMemo, useEffect, useRef } from 'react';
import Dropdown from 'components/Dropdown/Dropdown';
import { useCustomToast } from 'utils/toastUtils';
import CustomButton from 'components/button/CustomButton';
import CustomIconButton from 'components/button/CustomIconButton';
import { clearGridFocus } from 'utils/gridUtils';
import { useLoader } from "contexts/LoaderContext";

import {
  Box,
  Heading,
  Button,
  Input,
  // Modal, // Replaced by CustomModal
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  ModalCloseButton,
  FormLabel,
  FormControl,
  useToast,
  Text,
  Flex,
  IconButton,
  Tooltip,
  Switch,
  Tabs,
  TabList,
  TabPanels,
  TabPanel,
  Tab,
} from '@chakra-ui/react';
import CustomModal from 'components/modal/CustomModal'; // Import CustomModal
import {
  validateAlphanumericInput,
  projectValidateAlphanumeric,
  ValidateNameField,
  validateDescriptionInput,
} from 'utils/constants';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import {
  fetchTasks,
  addTasks,
  EditTasks,
  deleteTask,
  fetchCategories,
  addCategories,
  updateCategory,
  deleteCategory,
} from 'utils/api'; // Import API functions
import { MAX_INPUT_LENGTH } from 'utils/constants';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const Taskmanagement = () => {
  // const initialRef = useRef(null); // Removed manual ref
  const showToast = useCustomToast();
  const { showGlobalLoader, hideGlobalLoader, isGlobalLoading } = useLoader();
  // State variables for storing task data
  const [tasks, setTasks] = useState([]); // Stores fetched tasks
  const [categoryList, setCategoryList] = useState([]); // Stores task main categories
  const [selectedTask, setSelectedTask] = useState(null); // Stores selected task for editing or deleting
  // Stores search and filter criteria
  const [filters, setFilters] = useState({
    category: '',
    search: '',
  });
  // Initial structure of a new task
  const initialTaskState = {
    id: tasks.id,
    taskName: '',
    description: '',
    categoryId: '',
    errors: {}, // Stores validation errors
  };
  const [newTask, setNewTask] = useState(initialTaskState);
  // State for handling modals (Add, Edit, Delete)
  const [modalState, setModalState] = useState({
    type: null,
    isOpen: false,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCategorySubmitting, setIsCategorySubmitting] = useState(false);
  const [isMainCatLoading, setIsMainCatLoading] = useState(false);
  const gridRef = useRef(null);
  const mainCategoryGridRef = useRef(null);

  const toast = useToast();
  const isTaskCategory = (cat) =>
    cat?.type === 'TaskCategories' ||
    (!!cat?.typeOfCategory &&
      cat.typeOfCategory.toLowerCase().includes('task')) ||
    (!!cat?.categoryType &&
      cat.categoryType.toLowerCase().includes('task'));

  const taskCategories = useMemo(
    () => categoryList.filter(isTaskCategory),
    [categoryList],
  );

  const taskCategoryOptions = useMemo(
    () =>
      taskCategories.map((cat) => ({
        id: cat.categoryId || cat.id,
        name: cat.categoryName || cat.name,
      })),
    [taskCategories],
  );

  // Fetch tasks + task categories
  useEffect(() => {
    const fetchTaskAndCategoryData = async () => {
      showGlobalLoader();
      setIsMainCatLoading(true);
      try {
        const [taskData, allCategories] = await Promise.all([
          fetchTasks(),
          fetchCategories(),
        ]);
        setTasks(taskData);
        setCategoryList(allCategories);
      } catch (error) {
        showToast('error', 'Unable to load task data from the server.');
      } finally {
        setIsMainCatLoading(false);
        hideGlobalLoader();
      }
    };
    fetchTaskAndCategoryData();
  }, []);
  const [isReadOnly, setIsReadOnly] = useState(false);

  useEffect(() => {
    const accessDetailsString = localStorage.getItem('accessDetails');
    if (accessDetailsString) {
      try {
        const accessDetails = JSON.parse(accessDetailsString);
        const screenAccess = accessDetails.find(
          (screen) => screen.screenId === 106,
        );
        if (screenAccess) {
          setIsReadOnly(screenAccess.readOnly === 1);
        }
      } catch (error) {
        console.error('Invalid accessDetails format in localStorage');
      }
    }
  }, []);

  // Filter tasks based on search and category selection
  const filteredTask = tasks.filter((task) => {
    const matchcategory =
      !filters.category ||
      task.categoryId?.toString() === filters.category.toString();

    const matchesSearch =
      !filters.search ||
      task.taskName?.toLowerCase().includes(filters.search.toLowerCase()) ||
      task.description?.toLowerCase().includes(filters.search.toLowerCase()) ||
      task.categoryName?.toLowerCase().includes(filters.search.toLowerCase());

    return matchcategory && matchesSearch;
  });

  const [mainCategoryFilters, setMainCategoryFilters] = useState({
    search: '',
  });

  const filteredMainCategories = useMemo(() => {
    const search = mainCategoryFilters.search.trim().toLowerCase();
    if (!search) return taskCategories;

    return taskCategories.filter((cat) => {
      const name = (cat.categoryName || cat.name || '').toLowerCase();
      const desc = (
        cat.categoryDescription ||
        cat.description ||
        ''
      ).toLowerCase();
      return name.includes(search) || desc.includes(search);
    });
  }, [taskCategories, mainCategoryFilters.search]);

  // function for Add new task
  const handleAddTask = async () => {
    let errors = {};

    const taskNameTrimmed = newTask.taskName.trim();

    // Check if empty
    if (!taskNameTrimmed) {
      errors.taskName = 'Task Name is required.';
    }
    // Check if too long
    else if (taskNameTrimmed.length > 30) {
      errors.taskName = 'Task Name must not exceed 30 characters.';
    }
    // Check if contains only special characters
    else if (!ValidateNameField(taskNameTrimmed)) {
      errors.taskName =
        'Task Name must contain at least one character or number.';
    }

    if (!newTask.description.trim()) {
      errors.description = 'Task Description is required.';
    }

    if (!newTask.categoryId) {
      errors.categoryId = 'Task Category is required.';
    }

    // Duplicate task name check (case-insensitive)
    const isDuplicate = tasks.some(
      (task) =>
        task.taskName.trim().toLowerCase() === taskNameTrimmed.toLowerCase() &&
        task.categoryId === newTask.categoryId,
    );
    if (isDuplicate) {
      errors.taskName = 'Task Name already exists.';
    }

    if (Object.keys(errors).length > 0) {
      setNewTask((prev) => ({ ...prev, errors }));
      return;
    }

    try {
      setIsSubmitting(true);
      await addTasks(newTask);
      const data = await fetchTasks();
      setTasks(data);

      showToast('success', `${newTask.taskName} has been added successfully.`);
      setNewTask(initialTaskState); // Reset form
      closeModal();
    } catch (error) {
      showToast(
        'warning',
        error.message || 'Unable to add the task. Please try again.',
      );
    } finally {
      setIsSubmitting(false);
    }
  };
  useEffect(() => {
    // Disable scroll on the body
    document.body.style.overflow = 'hidden';

    // Clean up: Restore the scroll when the component unmounts
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, []);
  // function for Edit existing task
  const handleEditTask = async () => {
    let errors = {};

    const taskNameTrimmed = newTask.taskName.trim();

    // Check if empty
    if (!taskNameTrimmed) {
      errors.taskName = 'Task Name is required.';
    }
    // Check if contains only special characters
    else if (!ValidateNameField(taskNameTrimmed)) {
      errors.taskName =
        'Task Name must contain at least one character or number.';
    }

    if (!newTask.description.trim()) {
      errors.description = 'Task Description is required.';
    }

    if (!newTask.categoryId) {
      errors.categoryId = 'Task Category is required.';
    }

    // Check for duplicate but exclude current task
    const isDuplicate = tasks.some(
      (task) =>
        task.taskName.trim().toLowerCase() === taskNameTrimmed.toLowerCase() &&
        task.categoryId === newTask.categoryId &&
        task.id !== newTask.id,
    );

    if (isDuplicate) {
      errors.taskName = 'Task Name already exists.';
    }

    if (Object.keys(errors).length > 0) {
      setNewTask((prev) => ({ ...prev, errors }));
      return;
    }

    try {
      setIsSubmitting(true);
      await EditTasks(newTask.id, newTask);
      setTimeout(async () => {
        const data = await fetchTasks();
        setTasks(data);
        clearGridFocus(gridRef);
      }, 100);

      showToast(
        'success',
        `Task '${newTask.taskName}' has been updated successfully.`,
      );
      closeModal();
      setFilters({
        category: '',
        search: '',
      });
    } catch (error) {
      showToast(
        'warning',
        error.message || 'Unable to update the task. Please try again.',
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // function for Delete task
  const handleDeleteTask = async () => {
    try {
      setIsSubmitting(true);
      await deleteTask(selectedTask.id);
      setTimeout(async () => {
        const data = await fetchTasks();
        setTasks(data);
        clearGridFocus(gridRef);
      }, 100);
      setTasks(tasks.filter((t) => t.id !== selectedTask.id));

      showToast('success', `Task '${selectedTask.taskName}' has been Deleted.`);
      closeModal();
      setFilters({
        category: '',
        search: '',
      });
    } catch (error) {
      showToast(
        'warning',
        error.message || 'Unable to delete the task. Please try again.',
      );
      closeModal();
      setFilters({
        category: '',
        search: '',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const initialMainCategoryState = {
    id: '',
    categoryName: '',
    categoryDescription: '',
    errors: {},
  };
  const [mainCategoryForm, setMainCategoryForm] = useState(
    initialMainCategoryState,
  );
  const [selectedMainCategory, setSelectedMainCategory] = useState(null);
  const [mainCategoryModalState, setMainCategoryModalState] = useState({
    type: null,
    isOpen: false,
  });

  const openMainCategoryModal = (type, category = null) => {
    setMainCategoryModalState({ type, isOpen: true });
    if (category) {
      setSelectedMainCategory(category);
      setMainCategoryForm({
        id: category.categoryId || category.id,
        categoryName: category.categoryName || category.name || '',
        categoryDescription:
          category.categoryDescription || category.description || '',
        errors: {},
      });
    } else {
      setSelectedMainCategory(null);
      setMainCategoryForm(initialMainCategoryState);
    }
  };

  const closeMainCategoryModal = () => {
    setMainCategoryModalState({ type: null, isOpen: false });
    setSelectedMainCategory(null);
    setMainCategoryForm(initialMainCategoryState);
  };

  const validateMainCategory = () => {
    const errors = {};
    if (!mainCategoryForm.categoryName.trim()) {
      errors.categoryName = 'Main category name is required.';
    }
    if (!mainCategoryForm.categoryDescription.trim()) {
      errors.categoryDescription = 'Main category description is required.';
    }
    setMainCategoryForm((prev) => ({ ...prev, errors }));
    return Object.keys(errors).length === 0;
  };

  const refreshTaskCategories = async () => {
    const categories = await fetchCategories();
    setCategoryList(categories);
  };

  const handleAddMainCategory = async () => {
    if (!validateMainCategory()) return;
    try {
      setIsCategorySubmitting(true);
      await addCategories({
        type: 'TaskCategories',
        categoryName: mainCategoryForm.categoryName.trim(),
        categoryDescription: mainCategoryForm.categoryDescription.trim(),
      });
      await refreshTaskCategories();
      showToast(
        'success',
        `Main category '${mainCategoryForm.categoryName}' added successfully.`,
      );
      closeMainCategoryModal();
    } catch (error) {
      showToast(
        'warning',
        error.message || 'Unable to add main category. Please try again.',
      );
    } finally {
      setIsCategorySubmitting(false);
    }
  };

  const handleEditMainCategory = async () => {
    if (!validateMainCategory()) return;
    try {
      setIsCategorySubmitting(true);
      await updateCategory(mainCategoryForm.id, {
        id: mainCategoryForm.id,
        name: mainCategoryForm.categoryName.trim(),
        description: mainCategoryForm.categoryDescription.trim(),
        type: 'TaskCategories',
      });
      await refreshTaskCategories();
      clearGridFocus(mainCategoryGridRef);
      showToast(
        'success',
        `Main category '${mainCategoryForm.categoryName}' updated successfully.`,
      );
      closeMainCategoryModal();
    } catch (error) {
      showToast(
        'warning',
        error.message || 'Unable to update main category. Please try again.',
      );
    } finally {
      setIsCategorySubmitting(false);
    }
  };

  const handleDeleteMainCategory = async () => {
    if (!selectedMainCategory) return;
    try {
      setIsCategorySubmitting(true);
      await deleteCategory(selectedMainCategory.categoryId || selectedMainCategory.id);
      await refreshTaskCategories();
      clearGridFocus(mainCategoryGridRef);
      showToast(
        'success',
        `Main category '${selectedMainCategory.categoryName || selectedMainCategory.name}' deleted successfully.`,
      );
      closeMainCategoryModal();
    } catch (error) {
      showToast('warning', 'Cannot delete assigned main category.');
    } finally {
      setIsCategorySubmitting(false);
    }
  };
  // coloumn definition
  const columnDefs = useMemo(
    () => [
      {
        headerName: 'Category',
        field: 'categoryName',
        sortable: true,
        flex: 1,
        minWidth: 150,
        resizable: false,
      },
      {
        headerName: 'Subcategory',
        field: 'taskName',
        sortable: true,
        flex: 1.1,
        minWidth: 170,
        resizable: false,
      },
      {
        headerName: 'Description',
        field: 'description',
        flex: 1.5,
        minWidth: 190,
        resizable: true,
      },
      {
        headerName: 'Actions',
        field: 'actions',
        width: 120,
        minWidth: 120,
        maxWidth: 120,
        sortable: false,
        resizable: false,
        cellRenderer: (params) => (
          <Box display="flex" justifyContent="flex-start" alignItems="center" gap={1}>
            <CustomIconButton
              iconClass="fas fa-edit"
              tooltip="Edit Task"
              isDisabled={isReadOnly}
              onClick={() => openModal('edit', params.data)}
            />
            <CustomIconButton
              iconClass="fas fa-trash"
              tooltip="Delete Task"
              isDisabled={isReadOnly}
              onClick={() => openModal('delete', params.data)}
            />
          </Box>
        ),
      },
    ],
    [isReadOnly],
  );

  const mainCategoryColumnDefs = useMemo(
    () => [
      {
        headerName: 'Main Category',
        field: 'categoryName',
        sortable: true,
        flex: 1,
        minWidth: 170,
        resizable: false,
      },
      {
        headerName: 'Description',
        field: 'categoryDescription',
        sortable: true,
        flex: 1.5,
        minWidth: 190,
        resizable: true,
      },
      {
        headerName: 'Actions',
        width: 120,
        minWidth: 120,
        maxWidth: 120,
        sortable: false,
        resizable: false,
        cellRenderer: (params) => (
          <Box display="flex" justifyContent="flex-start" alignItems="center" gap={1}>
            <CustomIconButton
              iconClass="fas fa-edit"
              tooltip="Edit Main Category"
              isDisabled={isReadOnly}
              onClick={() => openMainCategoryModal('edit', params.data)}
            />
            <CustomIconButton
              iconClass="fas fa-trash"
              tooltip="Delete Main Category"
              isDisabled={isReadOnly}
              onClick={() => openMainCategoryModal('delete', params.data)}
            />
          </Box>
        ),
      },
    ],
    [isReadOnly],
  );
  // Open the modal for Add/Edit/Delete operations
  // const openModal = (type, task = null) => {
  //   setModalState({ type, isOpen: true });
  //   if (task) {
  //     setSelectedTask(task);
  //     if (type === 'edit') {
  //       setNewTask(task);
  //     }
  //   }
  // };

  const openModal = (type, task = null) => {
    setModalState({ type, isOpen: true });

    if (task) {
      setSelectedTask({
        ...task,
        id: task.sub_category_Id,
      });

      if (type === 'edit') {
        setNewTask({
          ...task,
          id: task.sub_category_Id,
        });
      }
    }
  };

  // Close the modal and reset form fields
  const closeModal = () => {
    setModalState({ type: null, isOpen: false });
    setNewTask({
      taskName: '',
      description: '',
      categoryId: '',
      // billable: false,
    });
    setSelectedTask(null);
  };

  return (
    <Box className="list-table-page">
      <ToastContainer />
      <Flex className="page-header-zone">
        <Heading className="page-title">Task</Heading>
      </Flex>

      <Tabs variant="unstyled" w="100%">
        <TabList
          border="1px solid #c9d9eb"
          borderRadius="12px"
          p="6px"
          gap="6px"
          bg="#eef4fb"
          w="fit-content"
          mb={4}
        >
          <Tab
            px={5}
            py={2.5}
            borderRadius="10px"
            fontWeight={700}
            color="#2e5f95"
            _selected={{
              bg: '#2f5f95',
              color: '#ffffff',
              boxShadow: '0 6px 14px rgba(47,95,149,0.24)',
            }}
          >
            Main Category
          </Tab>
          <Tab
            px={5}
            py={2.5}
            borderRadius="10px"
            fontWeight={700}
            color="#2e5f95"
            _selected={{
              bg: '#2f5f95',
              color: '#ffffff',
              boxShadow: '0 6px 14px rgba(47,95,149,0.24)',
            }}
          >
            Sub Category
          </Tab>
        </TabList>

        <TabPanels>
          <TabPanel p={0}>
            <Heading className="section-title" size="md" mb={3}>
              Main Category
            </Heading>
            <Box className="list-filter-bar">
              <Box className="list-search-wrap">
                <Input
                  className="list-search-input"
                  placeholder="Search main category..."
                  value={mainCategoryFilters.search}
                  onChange={(e) => {
                    const value = e.target.value;
                    if (validateAlphanumericInput(value)) {
                      setMainCategoryFilters({ search: value });
                    }
                  }}
                  variant="outline"
                />
              </Box>
              <Button
                className="page-primary-cta"
                isDisabled={isReadOnly}
                onClick={() => openMainCategoryModal('add')}
              >
                Add
              </Button>
            </Box>

            <div
              className="ag-theme-alpine list-table-grid content-surface task-grid-no-pinned-divider"
              style={{
                width: '100%',
                position: 'relative',
              }}
            >
              {isMainCatLoading && (
                <Flex
                  position="absolute"
                  top="0"
                  left="0"
                  right="0"
                  bottom="0"
                  bg="rgba(255,255,255,0.7)"
                  alignItems="center"
                  justifyContent="center"
                  zIndex={10}
                >
                  <Text color="#2E5F95" fontWeight={700}>
                    Loading main categories...
                  </Text>
                </Flex>
              )}
              <AgGridReact
                ref={mainCategoryGridRef}
                rowData={filteredMainCategories}
                suppressNoRowsOverlay={isGlobalLoading || isMainCatLoading}
                columnDefs={mainCategoryColumnDefs}
                pagination={true}
                paginationPageSize={10}
                suppressMovableColumns={true}
                suppressRowDrag={true}
                suppressMoveWhenRowDragging={true}
                paginationPageSizeSelector={[10, 25, 50, 100]}
                context={{ isReadOnly }}
                reactiveCustomComponents={true}
              />
            </div>
          </TabPanel>

          <TabPanel p={0}>
            <Heading className="section-title" size="md" mb={3}>
              Sub Category
            </Heading>
            <Box className="list-filter-bar">
              <Box className="list-filter-select">
                <Dropdown
                  type="Categories"
                  placeholder="All category"
                  selectedValue={filters.category}
                  itemsProp={taskCategoryOptions}
                  setSelectedValue={(value) =>
                    setFilters({ ...filters, category: value })
                  }
                />
              </Box>
              <Box className="list-search-wrap">
                <Input
                  className="list-search-input"
                  placeholder="Search..."
                  value={filters.search}
                  onChange={(e) => {
                    const value = e.target.value;
                    if (validateAlphanumericInput(value)) {
                      setFilters({ ...filters, search: value });
                    }
                  }}
                  variant="outline"
                />
              </Box>
              <Button
                className="page-primary-cta"
                isDisabled={isReadOnly}
                onClick={() => openModal('add')}
              >
                Add
              </Button>
            </Box>

            <div
              className="ag-theme-alpine list-table-grid content-surface task-grid-no-pinned-divider"
              style={{
                width: '100%',
              }}
            >
              <AgGridReact
                rowData={filteredTask}
                suppressNoRowsOverlay={isGlobalLoading}
                columnDefs={columnDefs}
                pagination={true}
                paginationPageSize={10}
                suppressMovableColumns={true}
                suppressRowDrag={true}
                suppressMoveWhenRowDragging={true}
                paginationPageSizeSelector={[10, 25, 50, 100]}
                context={{ isReadOnly }}
                reactiveCustomComponents={true}
              />
            </div>
          </TabPanel>
        </TabPanels>
      </Tabs>

      <CustomModal
        isOpen={mainCategoryModalState.isOpen}
        closeOnOverlayClick={false}
        onClose={closeMainCategoryModal}
        isCentered={mainCategoryModalState.type === 'delete'}
      >
        <ModalOverlay />
        <ModalContent
          className={
            mainCategoryModalState.type === 'delete'
              ? 'shared-delete-warning-modal'
              : 'settings-add-modal-content'
          }
        >
          <ModalHeader>
            {mainCategoryModalState.type === 'add'
              ? 'Create Main Category'
              : mainCategoryModalState.type === 'edit'
                ? 'Edit Main Category'
                : 'Delete Main Category'}
          </ModalHeader>
          <ModalCloseButton onClick={closeMainCategoryModal} />
          <ModalBody>
            {mainCategoryModalState.type !== 'delete' ? (
              <>
                <FormControl
                  isRequired
                  isInvalid={!!mainCategoryForm.errors?.categoryName}
                  mb={3}
                >
                  <FormLabel>Name</FormLabel>
                  <Input
                    placeholder="Main category name"
                    value={mainCategoryForm.categoryName}
                    onChange={(e) => {
                      const value = e.target.value;
                      if (validateAlphanumericInput(value)) {
                        setMainCategoryForm((prev) => ({
                          ...prev,
                          categoryName: value,
                          errors: { ...prev.errors, categoryName: '' },
                        }));
                      }
                    }}
                  />
                  {mainCategoryForm.errors?.categoryName && (
                    <Text color="red.500" fontSize="sm">
                      {mainCategoryForm.errors.categoryName}
                    </Text>
                  )}
                </FormControl>
                <FormControl
                  isRequired
                  isInvalid={!!mainCategoryForm.errors?.categoryDescription}
                >
                  <FormLabel>Description</FormLabel>
                  <Input
                    placeholder="Main category description"
                    value={mainCategoryForm.categoryDescription}
                    onChange={(e) => {
                      const value = e.target.value;
                      if (validateDescriptionInput(value)) {
                        setMainCategoryForm((prev) => ({
                          ...prev,
                          categoryDescription: value,
                          errors: { ...prev.errors, categoryDescription: '' },
                        }));
                      }
                    }}
                  />
                  {mainCategoryForm.errors?.categoryDescription && (
                    <Text color="red.500" fontSize="sm">
                      {mainCategoryForm.errors.categoryDescription}
                    </Text>
                  )}
                </FormControl>
              </>
            ) : (
              <p>
                Are you sure you want to delete the main category "
                {selectedMainCategory?.categoryName || selectedMainCategory?.name}"?
              </p>
            )}
          </ModalBody>
          <ModalFooter>
            {mainCategoryModalState.type === 'delete' ? (
              <Flex gap={4} justify="flex-end" mt={3}>
                <CustomButton
                  label="Cancel"
                  onClick={closeMainCategoryModal}
                  variant="outline"
                  colorScheme="black"
                  className="common-button"
                />
                <CustomButton
                  label="Delete"
                  onClick={handleDeleteMainCategory}
                  colorScheme="red"
                  className="common-button"
                  isLoading={isCategorySubmitting}
                />
              </Flex>
            ) : (
              <Flex gap={4} mt={3}>
                <CustomButton
                  label="Cancel"
                  onClick={closeMainCategoryModal}
                  variant="outline"
                  colorScheme="black"
                  className="common-button"
                />
                <CustomButton
                  label="Save"
                  isDisabled={isReadOnly}
                  onClick={
                    mainCategoryModalState.type === 'edit'
                      ? handleEditMainCategory
                      : handleAddMainCategory
                  }
                  colorScheme="green"
                  className="common-button"
                  isLoading={isCategorySubmitting}
                />
              </Flex>
            )}
          </ModalFooter>
        </ModalContent>
      </CustomModal>

      <CustomModal
        isOpen={modalState.isOpen}
        closeOnOverlayClick={false}
        onClose={closeModal}
        isCentered={modalState.type === 'delete'}
      // initialFocusRef={initialRef} // handled internally
      >
        <ModalOverlay />
        <ModalContent
          className={
            modalState.type === 'delete'
              ? 'shared-delete-warning-modal'
              : 'settings-add-modal-content'
          }
        >
          <ModalHeader>
            {modalState.type === 'add'
              ? 'Create Subcategory'
              : modalState.type === 'edit'
                ? 'Edit Subcategory'
                : 'Delete Subcategory'}
          </ModalHeader>
          <ModalCloseButton onClick={closeModal} />
          <ModalBody>
            {modalState.type !== 'delete' ? (
              <>
                <FormControl
                  isRequired
                  isInvalid={!!newTask.errors?.categoryId}
                  mb={3}
                // ref={initialRef} // removed
                >
                  <FormLabel fontSize="md" fontWeight="medium">
                    Categories
                  </FormLabel>
                  <Dropdown
                    type="Categories"
                    placeholder="Select category"
                    selectedValue={newTask.categoryId}
                    itemsProp={taskCategoryOptions}
                    setSelectedValue={(value) =>
                      setNewTask({
                        ...newTask,
                        categoryId: value,
                        errors: { ...newTask.errors, categoryId: '' },
                      })
                    }
                  />
                  {newTask.errors?.categoryId && (
                    <Text color="red.500" fontSize="sm">
                      {newTask.errors.categoryId}
                    </Text>
                  )}
                </FormControl>
                <FormControl
                  isRequired
                  isInvalid={!!newTask.errors?.taskName}
                  mb={3}
                >
                  <FormLabel fontSize="md" fontWeight="medium">
                    Name
                  </FormLabel>
                  <Input
                    placeholder="Subcategory Name"
                    value={newTask.taskName}
                    onChange={(e) => {
                      const value = e.target.value;

                      // Allow alphabets, numbers, spaces, underscores and hyphens
                      if (/^[a-zA-Z0-9 _-]*$/.test(value) || value === '') {
                        // Set the value and clear any previous errors
                        setNewTask({
                          ...newTask,
                          taskName: value,
                          errors: { ...newTask.errors, taskName: '' },
                        });
                      }
                    }}
                    onBlur={() => {
                      // Validate on blur to check if input is only special characters
                      const value = newTask.taskName.trim();

                      // Check if the value contains at least one alphanumeric character
                      const containsAlphanumeric = /[a-zA-Z0-9]/.test(value);

                      if (value && !containsAlphanumeric) {
                        setNewTask({
                          ...newTask,
                          errors: {
                            ...newTask.errors,
                            taskName:
                              'Task name must contain at least one letter or number.',
                          },
                        });
                      }
                    }}
                    maxLength={30}
                  />

                  {newTask.errors?.taskName && (
                    <Text color="red.500" fontSize="sm">
                      {newTask.errors.taskName}
                    </Text>
                  )}
                </FormControl>
                <FormControl
                  isRequired
                  isInvalid={!!newTask.errors?.description}
                  mb={3}
                >
                  <FormLabel fontSize="md" fontWeight="medium">
                    Description
                  </FormLabel>
                  <Input
                    placeholder="Subcategory Description"
                    value={newTask.description}
                    onChange={(e) => {
                      if (validateDescriptionInput(e.target.value)) {
                        setNewTask({
                          ...newTask,
                          description: e.target.value,
                          errors: { ...newTask.errors, description: '' },
                        });
                      }
                    }}
                  />
                  {newTask.errors?.description && (
                    <Text color="red.500" fontSize="sm">
                      {newTask.errors.description}
                    </Text>
                  )}
                </FormControl>

                {/* <Box mt={3} display={'flex'} alignItems={'space-between'}>
                  <Text fontSize="md">Billable Task</Text>
                  <Switch
                    marginLeft={2}
                    isChecked={newTask.billable}
                    onChange={(e) =>
                      setNewTask({ ...newTask, billable: e.target.checked })
                    }
                  />
                </Box> */}
              </>
            ) : (
              <p>
                Are you sure you want to delete the task "
                {selectedTask.taskName}"?
              </p>
            )}
          </ModalBody>

          <ModalFooter>
            {modalState.type === 'delete' ? (
              <Flex gap={4} justify="flex-end" mt={3}>
                <CustomButton
                  label="Cancel"
                  onClick={closeModal}
                  variant="outline"
                  colorScheme="black"
                  className="common-button"
                />
                <CustomButton
                  label="Delete"
                  onClick={handleDeleteTask}
                  colorScheme="red"
                  className="common-button"
                  isLoading={isSubmitting}
                />
              </Flex>
            ) : (
              <Flex gap={4} mt={3}>
                <CustomButton
                  label="Cancel"
                  onClick={closeModal}
                  variant="outline"
                  colorScheme="black"
                  className="common-button"
                />
                <CustomButton
                  label={modalState.type === 'edit' ? 'Save' : 'Save'}
                  isDisabled={isReadOnly}
                  onClick={
                    modalState.type === 'edit' ? handleEditTask : handleAddTask
                  }
                  colorScheme={modalState.type === 'edit' ? 'green' : 'green'}
                  className="common-button"
                  isLoading={isSubmitting}
                />
              </Flex>
            )}
          </ModalFooter>
        </ModalContent>
      </CustomModal>
    </Box>
  );
};

export default Taskmanagement;
