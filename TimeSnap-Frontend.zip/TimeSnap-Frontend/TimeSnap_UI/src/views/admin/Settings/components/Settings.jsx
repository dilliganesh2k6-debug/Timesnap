import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Box,
  Button,
  Flex,
  Heading,
  VStack,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  useToast,
  useDisclosure,
  IconButton,
  Input,
  FormLabel,
  FormControl,
  Tooltip,
  Table,
  Tbody,
  Td,
  Th,
  Thead,
  Tr,
  Text,
  Switch,
  AlertDialog,
  AlertDialogBody,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogContent,
  AlertDialogOverlay,
  // Modal, // Replaced by CustomModal
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  InputGroup,
  InputLeftElement,
  FormErrorMessage,
  Center,
} from '@chakra-ui/react';
import CustomModal from 'components/modal/CustomModal'; // Import CustomModal
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import './Settings.css';
import Dropdown from 'components/Dropdown/Dropdown';
import { useCustomToast } from 'utils/toastUtils'; // for show toast
import CustomButton from 'components/button/CustomButton'; // for button css
import { clearGridFocus } from 'utils/gridUtils';
import CustomIconButton from 'components/button/CustomIconButton'; // for button css
import { useLoader } from 'contexts/LoaderContext';
import { FiSearch } from 'react-icons/fi';
import TimeSnapLoader from '../../../../components/loaders/TimeSnapLoader';

import {
  // Import API functions
  fetchRoles,
  addRole,
  updateRole,
  deleteRole,
  fetchAccessRights,
  saveAccessRights,
  fetchDepartments,
  addDepartment,
  updateDepartment,
  deleteDepartment,
  fetchCategories,
  addCategories,
  updateCategory,
  deleteCategory,
} from 'utils/api';

import { validateAlphanumericInput } from 'utils/constants';
import { validateDescriptionInput } from 'utils/constants';

export default function SettingsScreen() {
  const initialRef = useRef(null);
  const showToast = useCustomToast(); // Custom toast notification function
  const { showGlobalLoader, hideGlobalLoader, isGlobalLoading } = useLoader();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isDeptLoading, setIsDeptLoading] = useState(false);
  const [isCatLoading, setIsCatLoading] = useState(false);
  const [isRoleLoading, setIsRoleLoading] = useState(false);
  const [isAccessLoading, setIsAccessLoading] = useState(false);
  const [projectSearchQuery, setProjectSearchQuery] = useState('');

  const isProjectCategory = (cat) =>
    (cat.type === 'ProjectCategories') ||
    (!!cat.typeOfCategory && cat.typeOfCategory.toLowerCase().includes('project')) ||
    (!!cat.categoryType && cat.categoryType.toLowerCase().includes('project'));

  const refreshSearch = () => {
    setSearchQuery('');
    setProjectSearchQuery('');
  };
  const resetFields = () => {
    setDepartmentData({ departmentName: '', departmentDescription: '' });
    setCategoryData({
      categoryName: '',
      categoryDescription: '',
      categoryType: '',
    });
    setRoleData({ roleTitle: '', rolePermissions: '' });
    refreshSearch(); // Add this line to clear search when switching tabs
  };
  const toast = useToast();
  const cancelRef = useRef(); // Reference for alert dialog cancel button
  // Function to reset form fields for different sections
  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value); // Update search query
  };
  const [isReadOnly, setIsReadOnly] = useState(false);

  useEffect(() => {
    const accessDetailsString = localStorage.getItem('accessDetails');
    if (accessDetailsString) {
      try {
        const accessDetails = JSON.parse(accessDetailsString);
        const screenAccess = accessDetails.find(
          (screen) => screen.screenId === 107,
        );
        if (screenAccess) {
          setIsReadOnly(screenAccess.readOnly === 1);
        }
      } catch (error) {
        console.error('Invalid accessDetails format in localStorage');
      }
    }
  }, []);
  const gridRef = useRef(null);
  const {
    isOpen: isDeptModalOpen,
    onOpen: openDeptModal,
    onClose: closeDeptModal,
  } = useDisclosure();

  const {
    isOpen: isEditDeptModalOpen,
    onOpen: openEditDeptModal,
    onClose: closeEditDeptModal,
  } = useDisclosure();

  const [newDepartment, setNewDepartment] = useState({
    departmentName: '',
    departmentDescription: '',
    errors: {},
  });

  const {
    isOpen: isCategoryModalOpen,
    onOpen: openCategoryModal,
    onClose: closeCategoryModal,
  } = useDisclosure();

  const {
    isOpen: isEditCategoryOpen,
    onOpen: openEditCategoryModal,
    onClose: closeEditCategory,
  } = useDisclosure();

  const [newCategory, setNewCategory] = useState({
    categoryType: '',
    categoryName: '',
    categoryDescription: '',
    errors: {},
  });

  const {
    isOpen: isRoleModalOpen,
    onOpen: openRoleModal,
    onClose: closeRoleModal,
  } = useDisclosure();

  const {
    isOpen: isEditRoleOpen,
    onOpen: openEditRoleModal,
    onClose: closeEditRole,
  } = useDisclosure();

  const [newRole, setNewRole] = useState({
    roleTitle: '',
    rolePermissions: '',
    errors: {},
  });
  const [isRoleSelected, setIsRoleSelected] = useState(false);

  const [selectedDepartment, setSelectedDepartment] = useState([]);

  // state variables
  const [hasChanges, setHasChanges] = useState(false); // Tracks if changes are made in access rights
  const [departmentList, setDepartmentList] = useState([]); // Stores department data
  const departmentDisclosure = useDisclosure();
  const [departmentData, setDepartmentData] = useState({
    departmentName: '',
    departmentDescription: '',
    errors: {},
  });

  // const [selectedDepartment, setSelectedDepartment] = useState([]);
  // Fetch departments data from the API
  useEffect(() => {
    const fetchDepartmentsData = async () => {
      showGlobalLoader();
      try {
        const data = await fetchDepartments();
        setDepartmentList(data);
      } catch (error) {
        showToast('error', 'There was an error fetching department data.');
      } finally {
        hideGlobalLoader();
      }
    };

    fetchDepartmentsData();
  }, []);

  const handleOpenAddDepartmentModal = () => {
    setNewDepartment({
      departmentName: '',
      departmentDescription: '',
      errors: {},
    }); // Reset form fields & errors
    openDeptModal();
  };
  // Function for add a new department
  const handleAddDepartment = async () => {
    let errors = {};

    if (!newDepartment.departmentName.trim()) {
      errors.departmentName = 'Department name is required.';
    }
    if (!newDepartment.departmentDescription.trim()) {
      errors.departmentDescription = 'Department description is required.';
    }

    if (Object.keys(errors).length > 0) {
      setNewDepartment((prev) => ({ ...prev, errors }));
      return;
    }

    try {
      setIsSubmitting(true);
      await addDepartment(newDepartment);
      const updatedDepartmentList = await fetchDepartments();
      setDepartmentList(updatedDepartmentList);
      showToast(
        'success',
        `Department ${newDepartment.departmentName} added successfully.`,
      );
      setNewDepartment({
        departmentName: '',
        departmentDescription: '',
        errors: {},
      });
      closeDeptModal(); // Close modal after saving
    } catch (error) {
      showToast('error', error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditDepartment = (department) => {
    setDepartmentData({
      departmentId: department.departmentId,
      departmentName: department.departmentName,
      departmentDescription: department.departmentDescription,
      errors: {},
    });
    openEditDeptModal();
  };

  const handleUpdateDepartment = async () => {
    const errors = {};
    if (!departmentData.departmentName.trim()) {
      errors.departmentName = 'Department name is required';
    }
    if (!departmentData.departmentDescription.trim()) {
      errors.departmentDescription = 'Department Description is required';
    }

    if (Object.keys(errors).length > 0) {
      setDepartmentData((prev) => ({
        ...prev,
        errors,
      }));
      return;
    }
    try {
      setIsSubmitting(true);
      const updatedDepartmentData = {
        departmentId: departmentData.departmentId,
        departmentName: departmentData.departmentName,
        departmentDescription: departmentData.departmentDescription,
      };
      await updateDepartment(
        updatedDepartmentData.departmentId,
        updatedDepartmentData,
      );
      setTimeout(async () => {
        const updatedDepartmentList = await fetchDepartments();
        setDepartmentList(updatedDepartmentList);
        clearGridFocus(gridRef); // Prevent tooltip/focus glitch
      }, 100);
      showToast(
        'success',
        `Department '${updatedDepartmentData.departmentName}' has been updated successfully.`,
      );
      closeEditDeptModal();
      setSearchQuery('');
    } catch (error) {
      showToast(
        'error',
        error.message || 'Unable to update the department . please try again!!',
      );
    } finally {
      setIsSubmitting(false);
    }
  };
  // Function for delete a department
  const handleDeleteDepartment = async () => {
    if (selectedDepartment) {
      try {
        setIsSubmitting(true);
        await deleteDepartment(selectedDepartment.departmentId);

        setTimeout(async () => {
          const updatedDepartmentList = await fetchDepartments();
          setDepartmentList(updatedDepartmentList);
          clearGridFocus(gridRef); // Prevent tooltip/focus glitch
        }, 100);
        showToast(
          'success',
          `Department '${selectedDepartment.departmentName}'has been successfully deleted.`,
        );
      } catch (error) {
        showToast('warning', error.message || 'Failed to delete Department.');
      } finally {
        setIsSubmitting(false);
      }
      setSelectedDepartment(null);
    }
    departmentDisclosure.onClose();
    setSearchQuery('');
  };
  // Function for open the delete department modal
  const handleDeptDeleteButtonClick = (department) => {
    setSelectedDepartment(department);
    departmentDisclosure.onOpen();
  };

  //category
  const [categoryList, setCategoryList] = useState([]);
  const categoryDisclosure = useDisclosure();
  const [categoryData, setCategoryData] = useState({
    categoryType: '', // Added categoryType
    categoryName: '',
    categoryDescription: '',
    errors: {},
  });
  const [selectedCategory, setselectedCategory] = useState(null);

  // Fetch categories data from the API
  useEffect(() => {
    const fetchCategorieData = async () => {
      setIsCatLoading(true);
      try {
        const data = await fetchCategories();
        setCategoryList(data);
      } catch (error) {
        showToast('error', 'There was an error fetching category data.');
      } finally {
        setIsCatLoading(false);
      }
    };
    fetchCategorieData();
  }, []);

  const handleOpenAddCategoryModal = (type = '') => {
    setNewCategory({
      categoryName: '',
      categoryDescription: '',
      categoryType: type, // can be 'TaskCategories' or 'ProjectCategories'
      errors: {},
    }); // Reset form fields & errors
    openCategoryModal();
  };

  const validateCategoryData = () => {
    let errors = {};

    // Category type must be selected
    if (!newCategory.categoryType) {
      errors.categoryType = 'Category type is required.';
    }

    // Category name validations
    const name = newCategory.categoryName.trim();
    if (!name) {
      errors.categoryName = 'Category name is required.';
    } else if (name.length < 3) {
      errors.categoryName = 'Category name must be at least 3 characters long.';
    }

    // Category description validations
    const description = newCategory.categoryDescription.trim();
    if (!description) {
      errors.categoryDescription = 'Category description is required.';
    } else if (description.length < 5) {
      errors.categoryDescription =
        'Category description must be at least 5 characters long.';
    }

    setNewCategory((prevState) => ({
      ...prevState,
      errors: errors,
    }));

    return Object.keys(errors).length === 0; // Returns true if no errors exist
  };

  // Function to add a new category
  const handleAddCategory = async () => {
    if (!validateCategoryData()) return;

    try {
      setIsSubmitting(true);
      const categoryPayload = {
        type:
          newCategory.categoryType === 'TaskCategories'
            ? 'TaskCategories'
            : 'ProjectCategories',
        categoryName: newCategory.categoryName.trim(),
        categoryDescription: newCategory.categoryDescription.trim(),
      };

      await addCategories(categoryPayload);
      const updatedCategoryList = await fetchCategories();
      setCategoryList(updatedCategoryList);

      showToast(
        'success',
        `Category '${newCategory.categoryName}' has been added successfully.`,
      );

      // Reset form
      setNewCategory({
        categoryType: '',
        categoryName: '',
        categoryDescription: '',
        errors: {},
      });

      closeCategoryModal();
    } catch (error) {
      const message =
        error.response?.data?.message || 'Already exists. Please try again.';
      showToast('error', message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditCategory = (category) => {
    console.log('Editing Category:', category);

    setCategoryData({
      id: category.categoryId || category.id,
      categoryType: category.typeOfCategory || '',
      name: category.categoryName || category.name,
      description: category.categoryDescription || category.description,
      errors: {},
    });

    openEditCategoryModal();
  };
  useEffect(() => {
    // Disable scroll on the body
    document.body.style.overflow = 'hidden';

    // Clean up: Restore the scroll when the component unmounts
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, []);
  useEffect(() => {
    setCategoryData((prev) => ({ ...prev }));
  }, [categoryData.categoryType]);

  const handleUpdateCategory = async () => {
    const errors = {};
    if (!categoryData.name.trim()) {
      errors.name = 'Category name is required';
    }
    if (!categoryData.description.trim()) {
      errors.description = 'Category Description is required';
    }

    if (Object.keys(errors).length > 0) {
      setCategoryData((prev) => ({
        ...prev,
        errors,
      }));
      return;
    }
    try {
      setIsSubmitting(true);
      if (!categoryData.id) {
        showToast('error', 'Category ID is missing. Cannot update.');
        return;
      }

      let categoryTypeEnum = '';
      if (categoryData.categoryType === 'Project Category') {
        categoryTypeEnum = 'ProjectCategories';
      } else if (categoryData.categoryType === 'Task Category') {
        categoryTypeEnum = 'TaskCategories';
      }

      const updatedCategoryData = {
        id: categoryData.id, // Ensure ID is passed
        name: categoryData.name,
        description: categoryData.description,
        // typeOfCategory: categoryData.categoryType,
        type: categoryTypeEnum,
      };

      await updateCategory(updatedCategoryData.id, updatedCategoryData);
      setTimeout(async () => {
        const updatedCategoryList = await fetchCategories();
        setCategoryList(updatedCategoryList);
        clearGridFocus(gridRef); //  Prevent tooltip/focus glitch
      }, 100);

      showToast(
        'success',
        `Category '${updatedCategoryData.name}' has been updated successfully.`,
      );

      closeEditCategory();
      setSearchQuery('');
    } catch (error) {
      console.error('Error updating category:', error);
      showToast(
        'error',
        error.message || 'Unable to update the category. Please try again!',
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // Function to delete a category
  const handleDeleteCategory = async () => {
    if (selectedCategory) {
      try {
        setIsSubmitting(true);
        // Ensure the correct ID is used for deletion
        const categoryId = selectedCategory.categoryId || selectedCategory.id;

        if (!categoryId) {
          showToast('error', 'Invalid category ID.');
          return;
        }

        // Call the API to delete the category
        await deleteCategory(categoryId);
        setTimeout(async () => {
          const updatedCategoryLists = await fetchCategories();
          setCategoryList(updatedCategoryLists);
          clearGridFocus(gridRef); //  Fix auto-tooltip/focus
        }, 100);

        showToast(
          'success',
          `Category '${selectedCategory.categoryName || selectedCategory.name}' has been successfully deleted.`,
        );
      } catch (error) {
        showToast('warning', 'Can not Delete the Assigned category.');
      } finally {
        setIsSubmitting(false);
      }
      setselectedCategory(null);
    }
    categoryDisclosure.onClose();
    setSearchQuery('');
  };

  // Function to open the delete category modal
  const handleDeleteButtonClick = (category) => {
    setselectedCategory(category);
    categoryDisclosure.onOpen();
  };

  // Modify your handleToggleChange function
  // const handleToggleChange = (index, field, value) => {
  //   const updatedData = [...accessData];
  //   updatedData[index][field] = value;
  //   setAccessData(updatedData);

  //   // Set hasChanges to true when any toggle is changed
  //   setHasChanges(true);
  // };
  const handleToggleChange = (index, field, value) => {
    const updatedData = [...accessData];
    const current = updatedData[index];

    if (field === 'hideShow') {
      current.hideShow = value;

      if (value) {
        // If enabling hide/show and both access are false, enable fullAccess
        if (!current.fullAccess && !current.readOnly) {
          current.fullAccess = true;
        }
      } else {
        // If disabling hide/show, disable both access rights
        current.fullAccess = false;
        current.readOnly = false;
      }
    } else if (field === 'fullAccess') {
      current.fullAccess = value;

      if (value) {
        // Enable hide/show and disable readOnly
        current.hideShow = true;
        current.readOnly = false;
      } else {
        // If both fullAccess and readOnly are off, disable hide/show
        if (!current.readOnly) {
          current.hideShow = false;
        }
      }
    } else if (field === 'readOnly') {
      current.readOnly = value;

      if (value) {
        // Enable hide/show and disable fullAccess
        current.hideShow = true;
        current.fullAccess = false;
      } else {
        // If both fullAccess and readOnly are off, disable hide/show
        if (!current.fullAccess) {
          current.hideShow = false;
        }
      }
    }

    updatedData[index] = current;
    setAccessData(updatedData);
    setHasChanges(true);
  };

  //role
  const [roleList, setRoleList] = useState([]);
  const [rolesDropdownKey, setRolesDropdownKey] = useState(0);
  const rolesDisclosure = useDisclosure();
  const [roleData, setRoleData] = useState({
    roleTitle: '',
    rolePermissions: '',
    errors: {},
  });
  const [selectedRole, setSelectedRole] = useState(null);

  useEffect(() => {
    const fetchRoleData = async () => {
      setIsRoleLoading(true);
      try {
        const data = await fetchRoles();
        setRoleList(data);
      } catch (error) {
        showToast('error', 'Failed to fetch roles.');
      } finally {
        setIsRoleLoading(false);
      }
    };

    fetchRoleData();
  }, []);

  const handleOpenAddRoleModal = () => {
    setNewRole({ roleTitle: '', rolePermissions: '', errors: {} }); // Reset form fields & errors
    openRoleModal();
  };

  // function for add new role
  const handleAddRole = async () => {
    let errors = {};

    if (!newRole.roleTitle.trim()) {
      errors.roleTitle = 'Role name is required.';
    }
    if (!newRole.rolePermissions.trim()) {
      errors.rolePermissions = 'Role description is required.';
    }

    if (Object.keys(errors).length > 0) {
      setNewRole((prev) => ({ ...prev, errors }));
      return;
    }

    try {
      setIsSubmitting(true);
      await addRole(newRole);
      const updatedRoleList = await fetchRoles();
      setRoleList(updatedRoleList);
      setRolesDropdownKey((prev) => prev + 1);

      showToast('success', 'Role added successfully.');
      setNewRole({ roleTitle: '', rolePermissions: '', errors: {} });
      closeRoleModal(); // Close modal after saving
    } catch (error) {
      showToast('error', error.message);
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleEditRole = (role) => {
    setRoleData({
      roleId: role.roleId,
      roleTitle: role.roleTitle,
      rolePermissions: role.rolePermissions,
      errors: {},
    });
    openEditRoleModal();
  };

  const handleUpdateRole = async () => {
    const errors = {};
    if (!roleData.roleTitle.trim()) {
      errors.roleTitle = 'Role name is required';
    }
    if (!roleData.rolePermissions.trim()) {
      errors.rolePermissions = 'Role Description is required';
    }

    if (Object.keys(errors).length > 0) {
      setRoleData((prev) => ({
        ...prev,
        errors,
      }));
      return;
    }
    try {
      setIsSubmitting(true);
      const updatedRoleData = {
        roleId: roleData.roleId,
        roleTitle: roleData.roleTitle,
        rolePermissions: roleData.rolePermissions,
      };
      await updateRole(updatedRoleData.roleId, updatedRoleData);

      setTimeout(async () => {
        const updatedRoleList = await fetchRoles();
        setRoleList(updatedRoleList);
        setRolesDropdownKey((prev) => prev + 1);
        clearGridFocus(gridRef); //  Prevent tooltip/focus glitch
      }, 100);
      showToast(
        'success',
        `Role '${updatedRoleData.roleTitle}' has been updated successfully.`,
      );
      closeEditRole();
      setSearchQuery('');
    } catch (error) {
      showToast(
        'error',
        error.message || 'Unable to update the Role . please try again!!',
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // funtion for delete role
  const handleDeleteRole = async () => {
    if (selectedRole) {
      try {
        setIsSubmitting(true);
        // const roleToDelete = roleList[selectedRole];
        await deleteRole(selectedRole.roleId);

        setTimeout(async () => {
          const UpdatedRoleList = await fetchRoles();
          setRoleList(UpdatedRoleList);
          setRolesDropdownKey((prev) => prev + 1);

          clearGridFocus(gridRef); //  Fix auto-tooltip/focus
        }, 100);
        showToast(
          'success',

          `Role '${selectedRole.roleTitle}' has been successfully deleted.`,
        );
      } catch (error) {
        showToast('warning', error.message || 'Failed to delete Role.');
      } finally {
        setIsSubmitting(false);
      }
      setSelectedRole(null);
    }
    rolesDisclosure.onClose();
    setSearchQuery('');
  };
  // Function to open the delete role modal
  const handleRoleDeleteButtonClick = (role) => {
    setSelectedRole(role);
    rolesDisclosure.onOpen();
  };
  //access rights
  const [role, setRole] = useState(null);
  const [accessData, setAccessData] = useState([
    {
      screenName: 'My Profile',
      screenId: 111,
      hideShow: false,
      fullAccess: false,
      readOnly: false,
    },
    {
      screenName: 'Timesheet',
      screenId: 102,
      hideShow: false,
      fullAccess: false,
      readOnly: false,
    },
    {
      screenName: 'Project',
      screenId: 103,
      hideShow: false,
      fullAccess: false,
      readOnly: false,
    },
    {
      screenName: 'Employee',
      screenId: 104,
      hideShow: false,
      fullAccess: false,
      readOnly: false,
    },
    {
      screenName: 'Team',
      screenId: 105,
      hideShow: false,
      fullAccess: false,
      readOnly: false,
    },
    {
      screenName: 'Task',
      screenId: 106,
      hideShow: false,
      fullAccess: false,
      readOnly: false,
    },
    {
      screenName: 'Settings',
      screenId: 107,
      hideShow: false,
      fullAccess: false,
      readOnly: false,
    },
    {
      screenName: 'Client',
      screenId: 108,
      hideShow: false,
      fullAccess: false,
      readOnly: false,
    },
    {
      screenName: 'Reports',
      screenId: 109,
      hideShow: false,
      fullAccess: false,
      readOnly: false,
    },
    {
      screenName: 'Audit Log',
      screenId: 110,
      hideShow: false,
      fullAccess: false,
      readOnly: false,
    },
  ]);

  const [rowData, setRowData] = useState(accessData);
  useEffect(() => {
    setRowData(accessData);
  }, [accessData]);

  // Reset access data when role changes
  const handleRoleChange = (roleId) => {
    setRole({ RoleId: roleId });
    // Reset hasChanges when selecting a new role
    setHasChanges(false);

    // Reset all toggles to false first
    setAccessData((prevData) =>
      prevData.map((item) => ({
        ...item,
        hideShow: false,
        fullAccess: false,
        readOnly: false,
      })),
    );
  };

  // Fetch Access Data from API
  useEffect(() => {
    const fetchAccess = async () => {
      if (role?.RoleId) {
        setIsAccessLoading(true);
        try {
          const data = await fetchAccessRights(role.RoleId);
          setAccessData(data);
          console.log(fetchAccessRights);
        } catch (error) {
          showToast('warning', 'There is no Access Rights for this role.');
        } finally {
          setIsAccessLoading(false);
        }
      }
    };

    fetchAccess();
  }, [role]);

  // function for save access rights
  const handleSaveAccessRights = async () => {
    const payload = {
      role_Id: role.RoleId,
      accessData: accessData.map((item) => ({
        screenName: item.screenName,
        screenId: item.screenId ? item.screenId.toString() : null,
        hideShow: item.hideShow,
        fullAccess: item.fullAccess,
        readOnly: item.readOnly,
      })),
    };

    try {
      setIsSubmitting(true);
      await saveAccessRights(payload);
      showToast('success', 'Access rights saved successfully.');
      // Reset hasChanges after successful save
      setHasChanges(false);
    } catch (error) {
      showToast('error', 'Failed to save access rights.');
    } finally {
      setIsSubmitting(false);
    }
  };
  useEffect(() => {
    // Reset toggles when a valid role is selected
    if (role?.RoleId) {
      setIsRoleSelected(true);
    } else {
      setIsRoleSelected(false);
    }

    // Reset the access data (you can customize this if needed)
    setAccessData((prevData) =>
      prevData.map((item) => ({
        ...item,
        hideShow: false,
        fullAccess: false,
        readOnly: false,
      })),
    );
  }, [role]);
  const columnDefsAccessRights = useMemo(
    () => [
      {
        headerName: 'Screen Name',
        field: 'screenName',
        flex: 1,
        sortable: false,
        filter: false,
      },
      {
        headerName: 'Hide/Show',
        field: 'hideShow',
        flex: 1,
        sortable: false,
        filter: false,
        headerClass: 'custom-header-center',
        cellRenderer: (params) => {
          const isDisabled =
            !isRoleSelected ||
            (['Dashboard', 'My Profile'].includes(params.data.screenName) &&
              [].includes(params.data.screenName) &&
              (params.data.hideShow ||
                params.data.fullAccess ||
                params.data.readOnly));

          return (
            <Box display="flex" mt={2}>
              <Switch
                isChecked={params.value}
                onChange={(e) =>
                  handleToggleChange(
                    params.node.rowIndex,
                    'hideShow',
                    e.target.checked,
                  )
                }
                size="sm"
                isDisabled={isDisabled}
              />
            </Box>
          );
        },
      },
      {
        headerName: 'Full Access',
        field: 'fullAccess',
        flex: 1,
        sortable: false,
        filter: false,
        headerClass: 'custom-header-center',
        cellRenderer: (params) => {
          const isDisabled =
            !isRoleSelected ||
            (['Dashboard', 'My Profile'].includes(params.data.screenName) &&
              [].includes(params.data.screenName) &&
              (params.data.hideShow ||
                params.data.fullAccess ||
                params.data.readOnly));

          return (
            <Box display="flex" mt={2}>
              <Switch
                isChecked={params.value}
                onChange={(e) =>
                  handleToggleChange(
                    params.node.rowIndex,
                    'fullAccess',
                    e.target.checked,
                  )
                }
                size="sm"
                isDisabled={isDisabled}
              />
            </Box>
          );
        },
      },
      {
        headerName: 'Read Only',
        field: 'readOnly',
        flex: 1,
        sortable: false,
        filter: false,
        headerClass: 'custom-header-center',
        cellRenderer: (params) => {
          const isDisabled =
            !isRoleSelected ||
            (['Dashboard', 'My Profile'].includes(params.data.screenName) &&
              [].includes(params.data.screenName) &&
              (params.data.hideShow ||
                params.data.fullAccess ||
                params.data.readOnly));

          return (
            <Box display="flex" mt={2}>
              <Switch
                isChecked={params.value}
                onChange={(e) =>
                  handleToggleChange(
                    params.node.rowIndex,
                    'readOnly',
                    e.target.checked,
                  )
                }
                size="sm"
                isDisabled={isDisabled}
              />
            </Box>
          );
        },
      },
    ],
    [role, handleToggleChange],
  );

  return (
    <Box className="list-table-page">
      <ToastContainer />
      <Heading className="page-title" mb={5}>
        Settings
      </Heading>

      <Tabs
        variant="unstyled"
        colorScheme="gray"
        mt={4}
        px={0}
        onChange={async (index) => {
          resetFields();

          if (index !== 3) {
            setRole(null);
            setAccessData((prevAccessData) =>
              prevAccessData.map((item) => ({
                ...item,
                hideShow: false,
                fullAccess: false,
                readOnly: false,
              })),
            );
          } else {
            if (role?.RoleId) {
              setIsAccessLoading(true);
              try {
                const freshData = await fetchAccessRights(role.RoleId);
                setAccessData(freshData);
              } catch (error) {
                showToast('error', 'Failed to fetch access rights.');
              } finally {
                setIsAccessLoading(false);
              }
            }
          }
        }}
      >
        <TabList borderBottom="none" mb={4}>
          <Tab
            _selected={{
              borderBottom: 'none',
              color: '#2A4F7C',
              fontWeight: '700',
            }}
          >
            Department
          </Tab>
          <Tab
            _selected={{
              borderBottom: 'none',
              color: '#2A4F7C',
              fontWeight: '700',
            }}
          >
            Category
          </Tab>
          <Tab
            _selected={{
              borderBottom: 'none',
              color: '#2A4F7C',
              fontWeight: '700',
            }}
          >
            Roles
          </Tab>
          <Tab
            _selected={{
              borderBottom: 'none',
              color: '#2A4F7C',
              fontWeight: '700',
            }}
          >
            Access Rights
          </Tab>
        </TabList>

        <TabPanels>
          {/* Department tab */}
          <TabPanel px={0} pt={0}>
            <VStack spacing={5} align="stretch">
              <div>
                <div>
                  <Flex w="100%" align="center" wrap="wrap" gap={4}>
                    <Flex alignItems="center" size="md">
                      <InputGroup size="md">
                        <InputLeftElement pointerEvents="none">
                          <FiSearch color="#9CA3AF" size={15} />
                        </InputLeftElement>
                        <Input
                          id="search-input"
                          placeholder="Search..."
                          value={searchQuery}
                          onChange={(e) => {
                            const value = e.target.value;
                            if (validateAlphanumericInput(value)) {
                              setSearchQuery(value);
                            }
                          }}
                          borderRadius="md"
                          borderColor="gray.400"
                          focusBorderColor="blue.500"
                          pl="40px"
                        />
                      </InputGroup>
                    </Flex>

                    {/* Add Department Button */}
                    <Box>
                      <Button
                        className="main common-button settings page-primary-cta"
                        onClick={handleOpenAddDepartmentModal}
                        isDisabled={isReadOnly}
                      >
                        Add
                      </Button>
                    </Box>
                  </Flex>
                </div>
              </div>
              <div
                className="ag-theme-alpine list-table-grid content-surface"
                style={{ width: '100%', position: 'relative' }}
              >
                {isDeptLoading && (
                  <Center
                    position="absolute"
                    top="0"
                    left="0"
                    right="0"
                    bottom="0"
                    bg="rgba(255, 255, 255, 0.7)"
                    zIndex={10}
                  >
                    <TimeSnapLoader size="lg" text="Loading departments..." />
                  </Center>
                )}
                <AgGridReact
                  suppressMovableColumns={true}
                  suppressRowDrag={true}
                  suppressMoveWhenRowDragging={true}
                  suppressNoRowsOverlay={isGlobalLoading || isDeptLoading}
                  rowData={
                    searchQuery
                      ? departmentList.filter((departmentData) =>
                          departmentData.departmentName
                            .toLowerCase()
                            .includes(searchQuery.toLowerCase()),
                        )
                      : departmentList
                  }
                  columnDefs={[
                    {
                      headerName: 'Name',
                      field: 'departmentName',
                      sortable: true,
                      flex: 1,
                      resizable: false,
                    },
                    {
                      headerName: 'Description',
                      field: 'departmentDescription',
                      sortable: true,
                      resizable: true,
                      flex: 1,
                      resizable: true,
                    },

                    {
                      headerName: 'Actions',
                      resizable: false,
                      cellRenderer: (params) => (
                        <Box display="flex" justifyContent="left">
                          {/* Edit Button */}
                          <CustomIconButton
                            iconClass="fas fa-edit"
                            tooltip="Edit Department"
                            onClick={() => handleEditDepartment(params.data)}
                            isDisabled={isReadOnly}
                          />
                          <CustomIconButton
                            iconClass="fas fa-trash"
                            tooltip="Delete Department"
                            onClick={() =>
                              handleDeptDeleteButtonClick(params.data)
                            }
                            isDisabled={isReadOnly}
                          />
                        </Box>
                      ),
                    },
                  ]}
                  defaultColDef={{
                    flex: 1,
                    minWidth: 100,
                    resizable: true,
                  }}
                  pagination={true}
                  paginationPageSize={10}
                  paginationPageSizeSelector={[10, 25, 50, 100]}
                />
              </div>
            </VStack>
            {/* Add Department Modal */}
            <CustomModal
              isOpen={isDeptModalOpen}
              closeOnOverlayClick={false}
              onClose={closeDeptModal}
              isCentered
              initialFocusRef={initialRef}
            >
              <ModalOverlay />
              <ModalContent className="settings-add-modal-content">
                <ModalHeader>Create Department</ModalHeader>
                <ModalCloseButton />
                <ModalBody>
                  <FormControl
                    isRequired
                    isInvalid={!!newDepartment.errors?.departmentName}
                  >
                    <FormLabel> Name</FormLabel>
                    <Input
                      ref={initialRef}
                      placeholder="Enter name..."
                      value={newDepartment.departmentName}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (validateAlphanumericInput(value)) {
                          setNewDepartment((prev) => ({
                            ...prev,
                            departmentName: value,
                            errors: { ...prev.errors, departmentName: '' },
                          }));
                        }
                      }}
                    />
                    {newDepartment.errors?.departmentName && (
                      <Text color="red.500">
                        {newDepartment.errors.departmentName}
                      </Text>
                    )}
                  </FormControl>

                  <FormControl
                    isRequired
                    mt={4}
                    isInvalid={!!newDepartment.errors?.departmentDescription}
                  >
                    <FormLabel> Description</FormLabel>
                    <Input
                      placeholder="Enter description..."
                      value={newDepartment.departmentDescription}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (validateDescriptionInput(value)) {
                          setNewDepartment((prev) => ({
                            ...prev,
                            departmentDescription: e.target.value,
                            errors: {
                              ...prev.errors,
                              departmentDescription: '',
                            },
                          }));
                        }
                      }}
                    />
                    {newDepartment.errors?.departmentDescription && (
                      <Text color="red.500">
                        {newDepartment.errors.departmentDescription}
                      </Text>
                    )}
                  </FormControl>
                </ModalBody>

                <ModalFooter>
                  <Button
                    variant="outline"
                    colorScheme="black"
                    className="common-button"
                    mr={3}
                    onClick={closeDeptModal}
                  >
                    Cancel
                  </Button>
                  <CustomButton
                    label="Save"
                    colorScheme="blue"
                    className="common-button"
                    onClick={handleAddDepartment}
                    isLoading={isSubmitting}
                  />
                </ModalFooter>
              </ModalContent>
            </CustomModal>

            {/* Edit Department Modal */}
            <CustomModal
              isOpen={isEditDeptModalOpen}
              closeOnOverlayClick={false}
              onClose={closeEditDeptModal}
              isCentered
              initialFocusRef={initialRef}
            >
              <ModalOverlay />
              <ModalContent className="settings-add-modal-content">
                <ModalHeader>Edit Department</ModalHeader>
                <ModalCloseButton />
                <ModalBody>
                  <FormControl
                    isRequired
                    isInvalid={!!departmentData.errors?.departmentName}
                  >
                    <FormLabel>Name</FormLabel>
                    <Input
                      ref={initialRef}
                      placeholder="Enter name..."
                      value={departmentData.departmentName}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (validateAlphanumericInput(value)) {
                          setDepartmentData((prev) => ({
                            ...prev,
                            departmentName: e.target.value,
                            errors: { ...prev.errors, departmentName: '' },
                          }));
                        }
                      }}
                    />
                    {departmentData.errors?.departmentName && (
                      <Text color="red.500">
                        {departmentData.errors.departmentName}
                      </Text>
                    )}
                  </FormControl>

                  <FormControl
                    isRequired
                    mt={4}
                    isInvalid={!!departmentData.errors?.departmentDescription}
                  >
                    <FormLabel>Description</FormLabel>
                    <Input
                      placeholder="Enter description..."
                      value={departmentData.departmentDescription}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (validateDescriptionInput(value)) {
                          setDepartmentData((prev) => ({
                            ...prev,
                            departmentDescription: e.target.value,
                            errors: {
                              ...prev.errors,
                              departmentDescription: '',
                            },
                          }));
                        }
                      }}
                    />
                    {departmentData.errors?.departmentDescription && (
                      <Text color="red.500">
                        {departmentData.errors.departmentDescription}
                      </Text>
                    )}
                  </FormControl>
                </ModalBody>

                <ModalFooter>
                  <Flex gap={4} justify="flex-end" mt={3}>
                    <Button
                      variant="outline"
                      colorScheme="black"
                      className="common-button"
                      mr={3}
                      onClick={closeEditDeptModal}
                    >
                      Cancel
                    </Button>
                    <CustomButton
                      label="Save"
                      colorScheme="blue"
                      onClick={handleUpdateDepartment}
                      className="common-button"
                      isLoading={isSubmitting}
                    />
                  </Flex>
                </ModalFooter>
              </ModalContent>
            </CustomModal>

            {/* Delete Confirmation Dialog for department */}
            <AlertDialog
              isOpen={departmentDisclosure.isOpen}
              leastDestructiveRef={cancelRef}
              closeOnOverlayClick={false}
              onClose={departmentDisclosure.onClose}
              isCentered
            >
              <AlertDialogOverlay>
                <AlertDialogContent className="settings-alert-warning-modal">
                  <AlertDialogHeader fontSize="lg" fontWeight="bold">
                    <Flex justify="space-between" align="center">
                      Delete Department
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={departmentDisclosure.onClose}
                        _hover={{ bg: 'transparent' }}
                      >
                        <i className="fas fa-times"></i>
                      </Button>
                    </Flex>
                  </AlertDialogHeader>
                  <AlertDialogBody>
                    {selectedDepartment
                      ? `Are you sure you want to delete the department "${selectedDepartment.departmentName}"?  `
                      : 'Are you sure you want to delete this department?'}
                  </AlertDialogBody>
                  <AlertDialogFooter style={{ display: 'flex', gap: '10px' }}>
                    <CustomButton
                      label="Cancel"
                      ref={cancelRef}
                      onClick={departmentDisclosure.onClose}
                      variant="outline"
                      colorScheme="black"
                      className="common-button"
                    />

                    <CustomButton
                      label="Delete"
                      onClick={handleDeleteDepartment}
                      colorScheme="red"
                      className="common-button"
                      isLoading={isSubmitting}
                    />
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialogOverlay>
            </AlertDialog>
          </TabPanel>

          {/* Category Tab */}
          <TabPanel px={0} pt={0}>
            <VStack spacing={5} align="stretch">
              <Flex w="100%" gap={6} wrap="wrap">

                {/* Project Categories Grid */}
                <Box flex="1 1 450px">
                  <Heading size="md" mb={3}>Project Category</Heading>
                  <Flex w="100%" align="center" wrap="wrap" gap={4} mb={3}>
                    <Flex alignItems="center">
                      <InputGroup size="md">
                        <InputLeftElement pointerEvents="none">
                          <FiSearch color="#9CA3AF" size={15} />
                        </InputLeftElement>
                        <Input
                          id="project-search-input"
                          placeholder="Search Name..."
                          value={projectSearchQuery}
                          onChange={(e) => {
                            const value = e.target.value;
                            if (validateAlphanumericInput(value)) {
                              setProjectSearchQuery(e.target.value);
                            }
                          }}
                          borderRadius="md"
                          borderColor="gray.400"
                          focusBorderColor="blue.500"
                          pl="40px"
                        />
                      </InputGroup>
                    </Flex>

                    <Box>
                      <Button
                        className="main common-button settings page-primary-cta"
                        onClick={() => handleOpenAddCategoryModal('ProjectCategories')}
                        isDisabled={isReadOnly}
                      >
                        Add
                      </Button>
                    </Box>
                  </Flex>

                  <div className="ag-theme-alpine list-table-grid content-surface" style={{ width: '100%', position: 'relative' }}>
                    {isCatLoading && (
                      <Center
                        position="absolute"
                        top="0"
                        left="0"
                        right="0"
                        bottom="0"
                        bg="rgba(255, 255, 255, 0.7)"
                        zIndex={10}
                      >
                        <TimeSnapLoader size="lg" text="Loading categories..." />
                      </Center>
                    )}
                    <AgGridReact
                      suppressNoRowsOverlay={isGlobalLoading || isCatLoading}
                      rowData={
                        projectSearchQuery
                          ? categoryList.filter((category) =>
                            isProjectCategory(category) &&
                            ((category.categoryName || category.name || '')
                              .toLowerCase()
                              .includes(projectSearchQuery.toLowerCase())),
                          )
                          : categoryList.filter(isProjectCategory)
                      }
                      columnDefs={[
                        {
                          headerName: 'Name',
                          field: 'categoryName',
                          sortable: true,
                          flex: 1,
                          resizable: false,
                        },
                        {
                          headerName: 'Description',
                          field: 'categoryDescription',
                          sortable: true,
                          resizable: true,
                          flex: 1,
                        },
                        {
                          headerName: 'Actions',
                          resizable: false,
                          cellRenderer: (params) => (
                            <Box display="flex" justifyContent="left">
                              <CustomIconButton
                                iconClass="fas fa-edit"
                                tooltip="Edit Category"
                                onClick={() => handleEditCategory(params.data)}
                                isDisabled={isReadOnly}
                              />
                              <CustomIconButton
                                iconClass="fas fa-trash"
                                tooltip="Delete Category"
                                onClick={() => handleDeleteButtonClick(params.data)}
                                isDisabled={isReadOnly}
                              />
                            </Box>
                          ),
                          flex: 1,
                        },
                      ]}
                      defaultColDef={{
                        flex: 1,
                        minWidth: 100,
                        resizable: true,
                      }}
                      pagination={true}
                      paginationPageSize={10}
                      paginationPageSizeSelector={[10, 25, 50, 100]}
                    />
                  </div>
                </Box>

              </Flex>
            </VStack>
            {/* Add Category Modal */}
            <CustomModal
              isOpen={isCategoryModalOpen}
              closeOnOverlayClick={false}
              onClose={closeCategoryModal}
              isCentered
              initialFocusRef={initialRef}
            >
              <ModalOverlay />
              <ModalContent className="settings-add-modal-content">
                <ModalHeader
                  fontSize="20px"
                  fontWeight="bold"
                  color="gray.700"
                >
                  {newCategory.categoryType === 'ProjectCategories'
                    ? 'Project Category'
                    : newCategory.categoryType === 'TaskCategories'
                      ? 'Task Category'
                      : ''}
                </ModalHeader>

                <ModalCloseButton />
                <ModalBody>
                  {/* <FormControl
                    isRequired
                    isInvalid={!!newCategory.errors?.categoryType}
                    mb={4}
                    top={2}
                  >
                    <FormLabel>Type of Category</FormLabel>

                    <Dropdown
                      placeholder="Select Category"
                      itemsProp={[
                        { id: "TaskCategories", name: "Task" },
                        { id: "ProjectCategories", name: "Project" },
                      ]}
                      selectedValue={newCategory.categoryType}
                      setSelectedValue={(value) =>
                        setNewCategory((prev) => ({
                          ...prev,
                          categoryType: value,
                          errors: { ...prev.errors, categoryType: '' },
                        }))
                      }
                      isDisabled={!!newCategory.categoryType}
                    />

                    {newCategory.errors?.categoryType && (
                      <Text color="red.500" fontSize="sm">
                        {newCategory.errors.categoryType}
                      </Text>
                    )}
                  </FormControl> */}

                  <FormControl
                    isRequired
                    isInvalid={!!newCategory.errors?.categoryName}
                  >
                    <FormLabel>Name</FormLabel>
                    <Input
                      ref={initialRef}
                      placeholder="Enter name..."
                      value={newCategory.categoryName}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (validateAlphanumericInput(value)) {
                          setNewCategory((prev) => ({
                            ...prev,
                            categoryName: e.target.value,
                            errors: { ...prev.errors, categoryName: '' },
                          }));
                        }
                      }}
                    />
                    {newCategory.errors?.categoryName && (
                      <Text color="red.500">
                        {newCategory.errors.categoryName}
                      </Text>
                    )}
                  </FormControl>

                  <FormControl
                    isRequired
                    mt={4}
                    isInvalid={!!newCategory.errors?.categoryDescription}
                  >
                    <FormLabel> Description</FormLabel>
                    <Input
                      placeholder="Enter description..."
                      value={newCategory.categoryDescription}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (validateDescriptionInput(value)) {
                          setNewCategory((prev) => ({
                            ...prev,
                            categoryDescription: e.target.value,
                            errors: { ...prev.errors, categoryDescription: '' },
                          }));
                        }
                      }}
                    />
                    {newCategory.errors?.categoryDescription && (
                      <Text color="red.500">
                        {newCategory.errors.categoryDescription}
                      </Text>
                    )}
                  </FormControl>
                  {/* Category Type Dropdown */}
                  {/* <FormControl
                    isRequired
                    isInvalid={!!newCategory.errors?.categoryType}
                    mb={4}
                    top={2}
                  >
                    <FormLabel>Type of Category </FormLabel>
                    <Select
                      placeholder="Select Category"
                      value={newCategory.categoryType}
                      onChange={(e) =>
                        setNewCategory((prev) => ({
                          ...prev,
                          categoryType: e.target.value,
                          errors: { ...prev.errors, categoryType: '' },
                        }))
                      }
                    >
                      <option value="TaskCategories">Task</option>
                      <option value="ProjectCategories">Project</option>
                    </Select>
                    {newCategory.errors?.categoryType && (
                      <Text color="red.500" fontSize="sm">
                        {newCategory.errors.categoryType}
                      </Text>
                    )}
                  </FormControl> */}
                </ModalBody>

                <ModalFooter>
                  <Button
                    variant="outline"
                    colorScheme="black"
                    className="common-button"
                    mr={3}
                    onClick={closeCategoryModal}
                  >
                    Cancel
                  </Button>
                  <CustomButton
                    label="Save"
                    colorScheme="blue"
                    className="common-button"
                    onClick={handleAddCategory}
                    isLoading={isSubmitting}
                  />
                </ModalFooter>
              </ModalContent>
            </CustomModal>
            {/* Edit Category Modal */}
            <CustomModal
              isOpen={isEditCategoryOpen}
              closeOnOverlayClick={false}
              onClose={closeEditCategory}
              isCentered
              initialFocusRef={initialRef}
            >
              <ModalOverlay />
              <ModalContent className="settings-add-modal-content">
                <ModalHeader
                  fontSize="20px"
                  fontWeight="bold"
                  color="gray.700"
                >
                  {categoryData.categoryType === 'Project Category'
                    ? 'Project Category'
                    : categoryData.categoryType === 'Task Category'
                      ? 'Task Category'
                      : ''}
                </ModalHeader>

                <ModalCloseButton />
                <ModalBody>
                  {/* 
                   <FormControl
                    isInvalid={!!categoryData.errors?.categoryType}
                    mb={4}
                    top={2}
                  >
                    <FormLabel>Type of Category</FormLabel>
                    <Input
                      isReadOnly
                      value={categoryData.categoryType || ''}
                      onChange={() => { }} // no need to handle changes for a readonly field
                    />
                    {categoryData.errors?.categoryType && (
                      <Text color="red.500" fontSize="sm">
                        {categoryData.errors.categoryType}
                      </Text>
                    )}
                  </FormControl> */}

                  <FormControl
                    isRequired
                    isInvalid={!!categoryData.errors?.name}
                  >
                    <FormLabel>Name</FormLabel>
                    <Input
                      ref={initialRef}
                      placeholder="Enter name..."
                      value={categoryData.name}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (validateAlphanumericInput(value)) {
                          setCategoryData((prev) => ({
                            ...prev,
                            name: e.target.value,
                            errors: { ...prev.errors, name: '' },
                          }));
                        }
                      }}
                    />
                    {categoryData.errors?.name && (
                      <Text color="red.500">{categoryData.errors.name}</Text>
                    )}
                  </FormControl>

                  <FormControl
                    isRequired
                    mt={4}
                    isInvalid={!!categoryData.errors?.description}
                  >
                    <FormLabel>Description</FormLabel>
                    <Input
                      placeholder="Enter description..."
                      value={categoryData.description}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (validateDescriptionInput(value)) {
                          setCategoryData((prev) => ({
                            ...prev,
                            description: e.target.value,
                            errors: { ...prev.errors, description: '' },
                          }));
                        }
                      }}
                    />
                    {categoryData.errors?.description && (
                      <Text color="red.500">
                        {categoryData.errors.description}
                      </Text>
                    )}
                  </FormControl>
                  {/* Category Type Dropdown */}
                  {/* <FormControl
                    isRequired
                    isInvalid={!!categoryData.errors?.categoryType}
                    mb={4}
                    top={2}
                  >
                    <FormLabel>Type of Category</FormLabel>
                    <Select
                      isReadOnly
                      value={categoryData.categoryType || ''}
                      onChange={(e) =>
                        setCategoryData((prev) => ({
                          ...prev,
                          categoryType: e.target.value,
                          errors: { ...prev.errors, categoryType: '' },
                        }))
                      }
                    >
                      <option value="Task Category">Task Category</option>
                      <option value="Project Category">Project Category</option>
                    </Select>
                    {categoryData.errors?.categoryType && (
                      <Text color="red.500" fontSize="sm">
                        {categoryData.errors.categoryType}
                      </Text>
                    )}
                  </FormControl> */}
                </ModalBody>

                <ModalFooter>
                  <Flex gap={4} justify="flex-end" mt={3}>
                    <Button
                      variant="outline"
                      colorScheme="black"
                      className="common-button"
                      mr={3}
                      onClick={closeEditCategory}
                    >
                      Cancel
                    </Button>
                    <CustomButton
                      label="Save"
                      colorScheme="blue"
                      onClick={handleUpdateCategory}
                      className="common-button"
                      isLoading={isSubmitting}
                    />
                  </Flex>
                </ModalFooter>
              </ModalContent>
            </CustomModal>
            {/* Delete Confirmation Dialog for Category */}
            <AlertDialog
              isOpen={categoryDisclosure.isOpen}
              leastDestructiveRef={cancelRef}
              closeOnOverlayClick={false}
              onClose={categoryDisclosure.onClose}
              isCentered
            >
              <AlertDialogOverlay>
                <AlertDialogContent className="settings-alert-warning-modal">
                  <AlertDialogHeader fontSize="lg" fontWeight="bold">
                    <Flex justify="space-between" align="center">
                      Delete Category
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={categoryDisclosure.onClose}
                        _hover={{ bg: 'transparent' }}
                      >
                        <i className="fas fa-times"></i>
                      </Button>
                    </Flex>
                  </AlertDialogHeader>

                  <AlertDialogBody>
                    {selectedCategory
                      ? `Are you sure you want to delete the Category "${selectedCategory.categoryName}"?.`
                      : 'Are you sure you want to delete the Category?'}
                  </AlertDialogBody>
                  <AlertDialogFooter style={{ display: 'flex', gap: '10px' }}>
                    <CustomButton
                      label="Cancel"
                      ref={cancelRef}
                      onClick={categoryDisclosure.onClose}
                      variant="outline"
                      colorScheme="black"
                      className="common-button"
                    />

                    <CustomButton
                      label="Delete"
                      onClick={handleDeleteCategory}
                      colorScheme="red"
                      className="common-button"
                      isLoading={isSubmitting}
                    />
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialogOverlay>
            </AlertDialog>
          </TabPanel>

          {/* Role Tab */}
          <TabPanel px={0} pt={0}>
            <VStack spacing={5} align="stretch">
              <div>
                <div>
                  <Flex w="100%" align="center" wrap="wrap" gap={4}>
                    <Flex alignItems="center">
                      <InputGroup size="md">
                        <InputLeftElement pointerEvents="none">
                          <FiSearch color="#9CA3AF" size={15} />
                        </InputLeftElement>
                        <Input
                          id="search-input"
                          placeholder="Search..."
                          value={searchQuery}
                          onChange={(e) => {
                            const value = e.target.value;
                            if (validateAlphanumericInput(value)) {
                              setSearchQuery(e.target.value);
                            }
                          }}
                          borderRadius="md"
                          borderColor="gray.400"
                          focusBorderColor="blue.500"
                          pl="40px"
                        />
                      </InputGroup>
                    </Flex>

                    {/* Add Role Button */}
                    <Box>
                      <Button
                        className="main common-button settings page-primary-cta"
                        onClick={handleOpenAddRoleModal}
                        isDisabled={isReadOnly}
                      >
                        Add
                      </Button>
                    </Box>
                  </Flex>
                </div>
              </div>
              <div
                className="ag-theme-alpine list-table-grid content-surface"
                style={{ width: '100%', position: 'relative' }}
              >
                {isRoleLoading && (
                  <Center
                    position="absolute"
                    top="0"
                    left="0"
                    right="0"
                    bottom="0"
                    bg="rgba(255, 255, 255, 0.7)"
                    zIndex={10}
                  >
                    <TimeSnapLoader size="lg" text="Loading roles..." />
                  </Center>
                )}
                <AgGridReact
                  suppressMovableColumns={true}
                  suppressRowDrag={true}
                  suppressMoveWhenRowDragging={true}
                  suppressNoRowsOverlay={isGlobalLoading || isRoleLoading}
                  rowData={
                    searchQuery
                      ? roleList.filter((role) =>
                          role.roleTitle
                            .toLowerCase()
                            .includes(searchQuery.toLowerCase()),
                        )
                      : roleList
                  }
                  columnDefs={[
                    {
                      headerName: 'Name',
                      field: 'roleTitle',
                      sortable: true,
                      flex: 1,
                      resizable: false,
                    },
                    {
                      headerName: 'Description',
                      field: 'rolePermissions',
                      sortable: true,
                      resizable: true,
                      flex: 1,
                      resizable: true,
                    },
                    {
                      headerName: 'Actions',
                      resizable: false,
                      cellRenderer: (params) => (
                        <Box display="flex" justifyContent="left">
                          {/* Edit Button */}
                          <CustomIconButton
                            iconClass="fas fa-edit"
                            tooltip="Edit Role"
                            onClick={() => handleEditRole(params.data)}
                            isDisabled={isReadOnly}
                          />
                          <CustomIconButton
                            iconClass="fas fa-trash"
                            tooltip="Delete Role"
                            onClick={() =>
                              handleRoleDeleteButtonClick(params.data)
                            }
                            isDisabled={isReadOnly}
                          />
                        </Box>
                      ),
                      flex: 1,
                    },
                  ]}
                  defaultColDef={{
                    flex: 1,
                    minWidth: 100,
                    resizable: true,
                  }}
                  pagination={true}
                  paginationPageSize={10}
                  paginationPageSizeSelector={[10, 25, 50, 100]}
                />
              </div>
            </VStack>

            {/* Add Role Modal */}
            <CustomModal
              isOpen={isRoleModalOpen}
              closeOnOverlayClick={false}
              onClose={closeRoleModal}
              isCentered
              initialFocusRef={initialRef}
            >
              <ModalOverlay />
              <ModalContent className="settings-add-modal-content">
                <ModalHeader>Create Role</ModalHeader>
                <ModalCloseButton />
                <ModalBody>
                  <FormControl
                    isRequired
                    isInvalid={!!newRole.errors?.roleTitle}
                  >
                    <FormLabel> Name</FormLabel>
                    <Input
                      ref={initialRef}
                      placeholder="Enter name..."
                      value={newRole.roleTitle}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (validateAlphanumericInput(value)) {
                          setNewRole((prev) => ({
                            ...prev,
                            roleTitle: e.target.value,
                            errors: { ...prev.errors, roleTitle: '' },
                          }));
                        }
                      }}
                    />
                    {newRole.errors?.roleTitle && (
                      <Text color="red.500">{newRole.errors.roleTitle}</Text>
                    )}
                  </FormControl>

                  <FormControl
                    isRequired
                    mt={4}
                    isInvalid={!!newRole.errors?.rolePermissions}
                  >
                    <FormLabel> Description</FormLabel>
                    <Input
                      placeholder="Enter description..."
                      value={newRole.rolePermissions}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (validateDescriptionInput(value)) {
                          setNewRole((prev) => ({
                            ...prev,
                            rolePermissions: e.target.value,
                            errors: { ...prev.errors, rolePermissions: '' },
                          }));
                        }
                      }}
                    />
                    {newRole.errors?.rolePermissions && (
                      <Text color="red.500">
                        {newRole.errors.rolePermissions}
                      </Text>
                    )}
                  </FormControl>
                </ModalBody>

                <ModalFooter>
                  <Button
                    variant="outline"
                    colorScheme="black"
                    className="common-button"
                    mr={3}
                    onClick={closeRoleModal}
                  >
                    Cancel
                  </Button>
                  <CustomButton
                    label="Save"
                    colorScheme="blue"
                    className="common-button"
                    onClick={handleAddRole}
                    isLoading={isSubmitting}
                  />
                </ModalFooter>
              </ModalContent>
            </CustomModal>

            {/* Edit Role Modal */}
            <CustomModal
              isOpen={isEditRoleOpen}
              closeOnOverlayClick={false}
              onClose={closeEditRole}
              isCentered
              initialFocusRef={initialRef}
            >
              <ModalOverlay />
              <ModalContent className="settings-add-modal-content">
                <ModalHeader>Edit Role</ModalHeader>
                <ModalCloseButton />
                <ModalBody>
                  <FormControl
                    isRequired
                    isInvalid={!!roleData.errors?.roleTitle}
                  >
                    <FormLabel>Name</FormLabel>
                    <Input
                      ref={initialRef}
                      placeholder="Enter name..."
                      value={roleData.roleTitle}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (validateAlphanumericInput(value)) {
                          setRoleData((prev) => ({
                            ...prev,
                            roleTitle: e.target.value,
                            errors: { ...prev.errors, roleTitle: '' },
                          }));
                        }
                      }}
                    />
                    {roleData.errors?.roleTitle && (
                      <Text color="red.500">{roleData.errors.roleTitle}</Text>
                    )}
                  </FormControl>

                  <FormControl
                    isRequired
                    mt={4}
                    isInvalid={!!roleData.errors?.rolePermissions}
                  >
                    <FormLabel>Description</FormLabel>
                    <Input
                      placeholder="Enter description..."
                      value={roleData.rolePermissions}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (validateDescriptionInput(value)) {
                          setRoleData((prev) => ({
                            ...prev,
                            rolePermissions: e.target.value,
                            errors: { ...prev.errors, rolePermissions: '' },
                          }));
                        }
                      }}
                    />
                    {roleData.errors?.rolePermissions && (
                      <Text color="red.500">
                        {roleData.errors.rolePermissions}
                      </Text>
                    )}
                  </FormControl>
                </ModalBody>

                <ModalFooter>
                  <Flex gap={4} justify="flex-end" mt={3}>
                    <Button
                      variant="outline"
                      colorScheme="black"
                      className="common-button"
                      mr={3}
                      onClick={closeEditRole}
                    >
                      Cancel
                    </Button>
                    <CustomButton
                      label="Save"
                      colorScheme="blue"
                      onClick={handleUpdateRole}
                      className="common-button"
                      isLoading={isSubmitting}
                    />
                  </Flex>
                </ModalFooter>
              </ModalContent>
            </CustomModal>
            {/* Delete Confirmation Dialog for role */}
            <AlertDialog
              isOpen={rolesDisclosure.isOpen}
              leastDestructiveRef={cancelRef}
              closeOnOverlayClick={false}
              onClose={rolesDisclosure.onClose}
              isCentered
            >
              <AlertDialogOverlay>
                <AlertDialogContent className="settings-alert-warning-modal">
                  <AlertDialogHeader fontSize="lg" fontWeight="bold">
                    <Flex justify="space-between" align="center">
                      Delete Role
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={rolesDisclosure.onClose}
                        _hover={{ bg: 'transparent' }}
                      >
                        <i className="fas fa-times"></i>
                      </Button>
                    </Flex>
                  </AlertDialogHeader>
                  <AlertDialogBody>
                    {selectedRole
                      ? `Are you sure you want to delete the role "${selectedRole.roleTitle}"? `
                      : 'Are you sure you want to delete this Role?'}
                  </AlertDialogBody>
                  <AlertDialogFooter style={{ display: 'flex', gap: '10px' }}>
                    <CustomButton
                      label="Cancel"
                      onClick={rolesDisclosure.onClose}
                      variant="outline"
                      colorScheme="black"
                      className="common-button"
                    />
                    <CustomButton
                      label="Delete"
                      onClick={handleDeleteRole}
                      colorScheme="red"
                      className="common-button"
                      isLoading={isSubmitting}
                    />
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialogOverlay>
            </AlertDialog>
          </TabPanel>
          <TabPanel px={0} pt={0}>
            <VStack align="stretch">
              <div>
                <Flex
                  w="100%"
                  justify="space-between"
                  align="center"
                  wrap="wrap"
                  gap={4}
                  mb={3}
                >
                  {/* Role Selection - Modified to use handleRoleChange */}
                 <Box sx={{ width: 250, minWidth: 250 }}>
  <Dropdown
    key={rolesDropdownKey}
    type="roles"
    id="role-title"
    placeholder="Select role"
    selectedValue={role?.RoleId || ''}
    setSelectedValue={handleRoleChange}
  />
</Box>


                  {/* Save Button */}
                  <Box>
                    <Button
                      className="settingsAccessRights"
                      top="-7px"
                      border="1px solid black"
                      onClick={handleSaveAccessRights}
                      isDisabled={!hasChanges || !role || isReadOnly}
                      isLoading={isSubmitting}
                    >
                      Save
                    </Button>
                  </Box>
                </Flex>
              </div>

              {/* Access Rights Table */}
              <div
                className="ag-theme-alpine list-table-grid content-surface"
                style={{
                  height: '410px', // smaller height
                  width: '100%',
                  overflow: 'hidden', // let ag-grid handle scroll
                  position: 'relative',
                }}
              >
                {isAccessLoading && (
                  <Center
                    position="absolute"
                    top="0"
                    left="0"
                    right="0"
                    bottom="0"
                    bg="rgba(255, 255, 255, 0.7)"
                    zIndex={10}
                  >
                    <TimeSnapLoader size="lg" text="Loading access rights..." />
                  </Center>
                )}
                <AgGridReact
                  suppressMovableColumns={true}
                  suppressRowDrag={true}
                  suppressMoveWhenRowDragging={true}
                  suppressNoRowsOverlay={isGlobalLoading || isAccessLoading}
                  rowData={rowData}
                  columnDefs={columnDefsAccessRights}
                  defaultColDef={{
                    flex: 1,
                    minWidth: 100,
                    resizable: false,
                  }}
                  pagination={true}
                  paginationPageSize={10}
                  paginationPageSizeSelector={[10, 25, 50, 100]}
                  domLayout="normal"
                />
              </div>
            </VStack>
          </TabPanel>
        </TabPanels>
      </Tabs>
    </Box>
  );
}


