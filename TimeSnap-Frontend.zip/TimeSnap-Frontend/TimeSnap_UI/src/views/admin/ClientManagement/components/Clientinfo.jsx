import React, { useState, useEffect, useRef } from 'react';
import {
  Box,
  Button,
  Flex,
  Heading,
  VStack,
  useToast,
  useDisclosure,
  Input,
  FormLabel,
  Tooltip,
  AlertDialog,
  AlertDialogBody,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogContent,
  AlertDialogOverlay,
  Text,
  FormControl,
  IconButton,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  InputGroup,
  InputLeftElement,
} from '@chakra-ui/react';
import { clearGridFocus } from 'utils/gridUtils';
import { validateAlphanumericInput } from 'utils/constants';
import { MAX_NAME_LENGTH } from 'utils/constants';
import { AgGridReact } from 'ag-grid-react';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import CustomButton from 'components/button/CustomButton';
import CustomIconButton from 'components/button/CustomIconButton';
import CustomModal from 'components/modal/CustomModal';
import { MdGroups } from 'react-icons/md';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { fetchClients, addClient, updateClient, deleteClient } from 'utils/api'; // Import API functions
import { useCustomToast } from 'utils/toastUtils';
import { MAX_EMPLOYEE_NAME_LENGTH } from 'utils/constants';
import { useLoader } from "contexts/LoaderContext";
export default function ClientInfo() {
  const initialRef = useRef(null);
  const showToast = useCustomToast();
  const [searchQuery, setSearchQuery] = useState(''); // Stores search input value
  const {
    isOpen: isClientModalOpen,
    onOpen: openClientModal,
    onClose: closeClientModal,
  } = useDisclosure();

  const {
    isOpen: isEditClientModalOpen,
    onOpen: openEditClientModal,
    onClose: closeEditClientModal,
  } = useDisclosure();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [newClient, setNewClient] = useState({
    clientName: '',
    clientLocation: '',
    errors: {},
  });
  const { isOpen, onOpen, onClose } = useDisclosure(); // Modal state control for delete confirmation
  const cancelRef = useRef(); // Reference for alert dialog cancel button
  const [isReadOnly, setIsReadOnly] = useState(false);
  const { showGlobalLoader, hideGlobalLoader, isGlobalLoading } = useLoader();

  useEffect(() => {
    const accessDetailsString = localStorage.getItem('accessDetails');
    if (accessDetailsString) {
      try {
        const accessDetails = JSON.parse(accessDetailsString);
        const screenAccess = accessDetails.find(
          (screen) => screen.screenId === 108,
        );
        if (screenAccess) {
          setIsReadOnly(screenAccess.readOnly === 1);
        }
      } catch (error) {
        console.error('Invalid accessDetails format in localStorage');
      }
    }
  }, []);

  // State variables
  const [clientList, setClientList] = useState([]); // Stores the list of clients fetched from the API
  const [filteredClientList, setFilteredClientList] = useState([]); // Stores filtered clients based on search
  // Stores input data for new clients
  const [clientData, setClientData] = useState({
    clientName: '',
    clientLocation: '',
  });
  const [clientErrors, setClientErrors] = useState({}); // Stores validation errors
  const [selectedClient, setSelectedClient] = useState(null); // Index of selected client for deletion

  // Fetch client data from API
  useEffect(() => {
    const fetchClientData = async () => {
      showGlobalLoader();
      try {
        const data = await fetchClients();
        setClientList(data);
      } catch (error) {
        showToast('error', 'Failed to fetch clients.');
      } finally {
        hideGlobalLoader();
      }
    };

    fetchClientData();
  }, []);
  const gridRef = useRef(null);
  // Handle search functionality
  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredClientList(clientList);
    } else {
      const lowercasedQuery = searchQuery.toLowerCase();
      const filtered = clientList.filter(
        (client) =>
          client.clientName?.toLowerCase().includes(lowercasedQuery) ||
          client.clientLocation?.toLowerCase().includes(lowercasedQuery),
      );
      setFilteredClientList(filtered);
    }
  }, [searchQuery, clientList]);

  const handleOpenAddClientModal = () => {
    setNewClient({ clientName: '', clientLocation: '', errors: {} }); // Reset form fields & errors
    openClientModal();
  };
  useEffect(() => {
    // Disable scroll on the body
    document.body.style.overflow = 'hidden';

    // Clean up: Restore the scroll when the component unmounts
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, []);
  // function for Add Client
  const handleAddClient = async () => {
    setIsSubmitting(true);
    let errors = {};
    if (!newClient.clientName.trim()) {
      errors.clientName = 'Client name is required.';
    }
    if (!newClient.clientLocation.trim()) {
      errors.clientLocation = 'Client location is required.';
    }
    if (Object.keys(errors).length > 0) {
      setNewClient((prev) => ({ ...prev, errors }));
      setIsSubmitting(false);
      return;
    }
    try {
      await addClient(newClient);
      const updatedClientList = await fetchClients();
      setClientList(updatedClientList);
      showToast(
        'success',
        `Client '${newClient.clientName}' has been added successfully.`,
      );
      setNewClient({ clientName: '', clientLocation: '', errors: {} });
      setClientErrors({});
      closeClientModal();
    } catch (error) {
      showToast('error', error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditClient = (client) => {
    setClientData({
      clientId: client.clientId,
      clientName: client.clientName,
      clientLocation: client.clientLocation,
      errors: {},
    });
    openEditClientModal();
  };
  const handleUpdateClient = async () => {
    setIsSubmitting(true);
    const errors = {};
    if (!clientData.clientName.trim()) {
      errors.clientName = 'Client name is required';
    }
    if (!clientData.clientLocation.trim()) {
      errors.clientLocation = 'Client location is required';
    }

    if (Object.keys(errors).length > 0) {
      setClientData((prev) => ({
        ...prev,
        errors,
      }));
      setIsSubmitting(false);
      return;
    }
    try {
      const updatedClientData = {
        clientId: clientData.clientId,
        clientName: clientData.clientName,
        clientLocation: clientData.clientLocation,
      };
      await updateClient(updatedClientData.clientId, updatedClientData);
      setTimeout(async () => {
        const updatedData = await fetchClients();
        setClientList(updatedData);

        clearGridFocus(gridRef);
      }, 100);
      const updateClientList = await fetchClients();
      setClientList(updateClientList);
      showToast(
        'success',
        `Client '${updatedClientData.clientName}' has been updated successfully.`,
      );
      closeEditClientModal();
      setSearchQuery('');
    } catch (error) {
      showToast(
        'error',
        error.message || 'Unable to update the Client . please try again!!',
      );
    } finally {
      setIsSubmitting(false);
    }
  };
  // // Function to handle input changes and clear errors
  // const handleInputChange = (field, value) => {
  //   setClientData((prev) => ({ ...prev, [field]: value }));
  //   // Clear error message for the current field if it's valid
  //   setClientErrors((prevErrors) => ({
  //     ...prevErrors,
  //     [field]: value.trim() ? '' : prevErrors[field],
  //   }));
  // };
  // Function to handle search input changes
  const handleSearchChange = (e) => {
    const value = e.target.value;
    if (validateAlphanumericInput(value)) {
      setSearchQuery(value);
    }
  };
  // Function to delete a client
  const handleDeleteClient = async () => {
    setIsSubmitting(true);
    if (selectedClient !== null) {
      try {
        // const clientToDelete = clientList[selectedClient];
        await deleteClient(selectedClient.clientId); // Call the delete API
        setTimeout(async () => {
          const updatedClientList = await fetchClients();
          setClientList(updatedClientList);
          clearGridFocus(gridRef); //  Fix auto-tooltip/focus
        }, 100);

        showToast(
          'success',
          `Client '${selectedClient.clientName}' has been successfully deleted.`,
        );
      } catch (error) {
        showToast('warning', error.message || 'Failed to delete client.');
      }
      setSelectedClient(null);
      setTimeout(async () => {
        const updatedClientList = await fetchClients();
        setClientList(updatedClientList);
        clearGridFocus(gridRef); //  Fix auto-tooltip/focus
      }, 100);
    }
    setSearchQuery('');
    onClose(); // Close delete confirmation dialog
    setIsSubmitting(false);
  };
  // Open delete confirmation modal
  const handleDeleteButtonClick = (client) => {
    setSelectedClient(client);
    onOpen();
  };

  return (
    <Box className="list-table-page">
      <ToastContainer />
      <Flex className="page-header-zone">
        <Heading className="page-title">Client</Heading>
        <Button
          className="page-primary-cta"
          onClick={handleOpenAddClientModal}
          isDisabled={isReadOnly}
        >
          Add
        </Button>
      </Flex>
      <VStack spacing={5} align="stretch">
        <div>
          <div>
            <Flex className="list-filter-bar" w="100%" align="center" wrap="wrap" gap={4}>
              <Flex alignItems="center">
                <Box className="list-search-wrap">
                  <InputGroup size="md">
                    <Input
                      className="list-search-input"
                      id="search-input"
                      placeholder="Search..."
                      value={searchQuery}
                      onChange={handleSearchChange}
                    />
                  </InputGroup>
                </Box>
              </Flex>
            </Flex>
          </div>
        </div>
        <div className="ag-theme-alpine list-table-grid content-surface" style={{ width: '100%' }}>
          <AgGridReact
            ref={gridRef}
            suppressMovableColumns={true}
            suppressRowDrag={true}
            suppressMoveWhenRowDragging={true}
            rowData={filteredClientList}
            suppressNoRowsOverlay={isGlobalLoading}
            // column definition
            columnDefs={[
              {
                headerName: 'Client Name',
                field: 'clientName',
                sortable: true,
                resizable: false,
              },
              {
                headerName: 'Client Location',
                field: 'clientLocation',
                sortable: true,
                resizable: false,
              },
              {
                headerName: 'Actions',
                resizable: false,
                cellRenderer: (params) => (
                  <Box display="flex" justifyContent="left">
                    <CustomIconButton
                      iconClass="fas fa-edit"
                      tooltip="Edit Client"
                      onClick={() => handleEditClient(params.data)}
                      isDisabled={isReadOnly}
                    />
                    <CustomIconButton
                      iconClass="fas fa-trash"
                      tooltip="Delete Client"
                      onClick={() => handleDeleteButtonClick(params.data)}
                      isDisabled={isReadOnly}
                    />
                  </Box>
                ),
              },
            ]}
            defaultColDef={{
              flex: 1,
              minWidth: 100,
              resizable: true,
            }}
            pagination={true}
            paginationPageSize={10}
            paginationPageSizeSelector={[10, 25, 50, 100]}
          />
        </div>
      </VStack>
      {/* Add Client Modal */}
      {/* Add Client Modal */}
      <CustomModal
        isOpen={isClientModalOpen}
        onClose={closeClientModal}
        closeOnOverlayClick={false}
        isCentered
      // title="Add Client" // Removed: using ModalHeader
      >
        <ModalOverlay />
        <ModalContent
          className="client-add-modal-content"
          w="calc(100vw - 32px)"
          maxW="600px"
        >
          <ModalHeader>Add Client</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <FormControl isRequired isInvalid={!!newClient.errors?.clientName}>
              <FormLabel> Name</FormLabel>
              <Input
                // ref={initialRef} // Removed: CustomModal handles focus
                placeholder="Enter name..."
                value={newClient.clientName}
                onChange={(e) => {
                  const value = e.target.value;
                  if (validateAlphanumericInput(value)) {
                    setNewClient((prev) => ({
                      ...prev,
                      clientName: e.target.value,
                      errors: { ...prev.errors, clientName: '' },
                    }));
                  }
                }}
              />
              {newClient.errors?.clientName && (
                <Text color="red.500">{newClient.errors.clientName}</Text>
              )}
            </FormControl>

            <FormControl
              isRequired
              mt={4}
              isInvalid={!!newClient.errors?.clientLocation}
            >
              <FormLabel>Location</FormLabel>
              <Input
                placeholder="Enter Location..."
                value={newClient.clientLocation}
                maxLength={MAX_NAME_LENGTH}
                onChange={(e) => {
                  const value = e.target.value;
                  if (/^[A-Za-z\s]*$/.test(value)) {
                    setNewClient((prev) => ({
                      ...prev,
                      clientLocation: value,
                      errors: { ...prev.errors, clientLocation: '' },
                    }));
                  }
                }}
              />
              {newClient.errors?.clientLocation && (
                <Text color="red.500">{newClient.errors.clientLocation}</Text>
              )}
            </FormControl>
          </ModalBody>

          <ModalFooter>
            <Button
              variant="outline"
              colorScheme="black"
              className="common-button"
              mr={3}
              onClick={closeClientModal}
            >
              Cancel
            </Button>
            <CustomButton
              label="Save"
              colorScheme="green"
              className="common-button"
              onClick={handleAddClient}
              isLoading={isSubmitting}
            />
            {/* <Button
              colorScheme="green"
              className="common-button"
              onClick={handleAddClient}
            >
              Save
            </Button> */}
          </ModalFooter>
        </ModalContent>
      </CustomModal>

      {/* Edit Client Modal */}
      <CustomModal
        isOpen={isEditClientModalOpen}
        closeOnOverlayClick={false}
        onClose={closeEditClientModal}
        isCentered
      // initialFocusRef={initialRef} // Removed: CustomModal handles focus
      >
        <ModalOverlay />
        <ModalContent
          className="client-add-modal-content"
          w="calc(100vw - 32px)"
          maxW="600px"
        >
          <ModalHeader>Edit Client</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <FormControl isRequired isInvalid={!!clientData.errors?.clientName}>
              <FormLabel>Name</FormLabel>
              <Input
                // ref={initialRef} // Removed: CustomModal handles focus
                placeholder="Enter name..."
                value={clientData.clientName}
                onChange={(e) => {
                  const value = e.target.value;
                  if (validateAlphanumericInput(value)) {
                    setClientData((prev) => ({
                      ...prev,
                      clientName: e.target.value,
                      errors: { ...prev.errors, clientName: '' },
                    }));
                  }
                }}
              />
              {clientData.errors?.clientName && (
                <Text color="red.500">{clientData.errors.clientName}</Text>
              )}
            </FormControl>

            <FormControl
              isRequired
              mt={4}
              isInvalid={!!clientData.errors?.clientLocation}
            >
              <FormLabel>Location</FormLabel>
              <Input
                placeholder="Enter Location..."
                value={clientData.clientLocation}
                maxLength={MAX_NAME_LENGTH}
                onChange={(e) => {
                  const value = e.target.value;
                  if (/^[A-Za-z\s]*$/.test(value)) {
                    setClientData((prev) => ({
                      ...prev,
                      clientLocation: value,
                      errors: { ...prev.errors, clientLocation: '' },
                    }));
                  }
                }}
              />
              {clientData.errors?.clientLocation && (
                <Text color="red.500">{clientData.errors.clientLocation}</Text>
              )}
            </FormControl>
          </ModalBody>

          <ModalFooter>
            <Flex gap={4} justify="flex-end" mt={3}>
              <Button
                variant="outline"
                colorScheme="black"
                className="common-button"
                mr={3}
                onClick={closeEditClientModal}
              >
                Cancel
              </Button>
              <CustomButton
                label="Save"
                colorScheme="green"
                onClick={handleUpdateClient}
                className="common-button"
                isLoading={isSubmitting}
              />
            </Flex>
          </ModalFooter>
        </ModalContent>
      </CustomModal>

      {/*  delete Confirmation Dialog */}
      <AlertDialog
        isOpen={isOpen}
        closeOnOverlayClick={false}
        leastDestructiveRef={cancelRef}
        onClose={onClose}
        isCentered
      >
        <AlertDialogOverlay>
          <AlertDialogContent className="client-alert-warning-modal">
            <Button
              onClick={onClose}
              position="absolute"
              top="8px"
              right="8px"
              bg="transparent"
              _hover={{ bg: 'gray.200' }}
            >
              ✖
            </Button>
            <AlertDialogHeader fontSize="lg" fontWeight="bold">
              Delete Client
            </AlertDialogHeader>

            <AlertDialogBody>
              {selectedClient
                ? `Are you sure you want to delete the client "${selectedClient.clientName}"? `
                : 'Are you sure you want to delete this client?'}
            </AlertDialogBody>

            <AlertDialogFooter style={{ display: 'flex', gap: '10px' }}>
              <CustomButton
                label="Cancel"
                ref={cancelRef}
                onClick={onClose}
                variant="outline"
                colorScheme="black"
                className="common-button"
              />

              <CustomButton
                label="Delete"
                onClick={handleDeleteClient}
                colorScheme="red"
                className="common-button"
                isLoading={isSubmitting}
              />
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialogOverlay>
      </AlertDialog>
    </Box >
  );
}
