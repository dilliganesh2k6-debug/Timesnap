import React, { useEffect, useState } from 'react';
import { fetchAuditLogs, fetchDropdownData } from 'utils/api';
import {
  Box,
  Button,
  Flex,
  FormControl,
  FormLabel,
  Heading,
  Input,
  InputGroup,
  InputLeftElement,
  useColorModeValue,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  useDisclosure,
  Text,
  VStack,
  HStack,
  Divider,
} from '@chakra-ui/react';
import { FiSearch, FiRotateCcw, FiArrowRight } from 'react-icons/fi';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import '../../ProjectManagement/components/Project.css';
import TimeSnapLoader from '../../../../components/loaders/TimeSnapLoader';

const safeParse = (v) => {
  if (!v) return {};
  try {
    return typeof v === 'string' ? JSON.parse(v) : v;
  } catch {
    return {};
  }
};

const getChangedKeys = (oldObj = {}, newObj = {}) => {
  const keys = Array.from(
    new Set([...Object.keys(oldObj), ...Object.keys(newObj)]),
  );

  return keys.filter((k) => {
    const o = oldObj[k];
    const n = newObj[k];

    if (o == n) {
      if (typeof o !== 'object') return false;
      return JSON.stringify(o) !== JSON.stringify(n);
    }
    return true;
  });
};

const formatKeyLabel = (k) => {
  const kl = k.toLowerCase();
  const map = {
    emp_code: 'Employee Code',
    user_name: 'User Name',
    employee_name: 'User Name',
    task_name: 'Task Name',
    taskname: 'Task Name',
    project_name: 'Project Name',
    projectname: 'Project Name',
    category_name: 'Category Name',
    categoryname: 'Category Name',
    sub_category_name: 'Subcategory Name',
    client_name: 'Client Name',
    clientname: 'Client Name',
    client_location: 'Client Location',
    clientlocation: 'Client Location',
    task_id: 'Task Id',
    estimated_hours: 'Estimated Hours',
    actual_hours: 'Actual Hours',
    overhead_hours: 'Overhead Hours',
    statusname: 'Status',
    status_name: 'Status',
    status_id: 'Status',
    statusid: 'Status',
  };

  if (map[kl]) return map[kl];

  return k
    .replace(/([A-Z])/g, ' $1')
    .replace(/_/g, ' ')
    .trim()
    .split(' ')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(' ');
};

const formatValue = (k, v, lookups) => {
  if (v === null || v === undefined || v === '') return '-';
  const key = k.toLowerCase();

  if (['isbillable', 'isadmin', 'isdelete', 'reportingrights'].includes(key)) {
    return v === true || v === 1 || String(v).toLowerCase() === 'true'
      ? 'Yes'
      : 'No';
  }

  if (key.includes('status')) {
    const types = ['projecttaskstatus', 'workingstatus'];
    for (const t of types) {
      if (lookups[t]?.[String(v)]) return lookups[t][String(v)];
    }
    return String(v);
  }

  const lookupTypeMap = {
    role: 'roles',
    dept: 'departments',
    depart: 'departments',
    desig: 'designations',
    employ: 'employmenttype',
    work: 'workingstatus',
    client: 'clients',
    team: 'teams',
    report: 'reportingto',
    category: 'categories',
  };

  for (const [prefix, type] of Object.entries(lookupTypeMap)) {
    if (key.includes(prefix)) {
      if (lookups[type]?.[String(v)]) {
        return lookups[type][String(v)];
      }
      if (!lookups[type] || Object.keys(lookups[type]).length === 0) {
        return 'Loading...';
      }
    }
  }

  if (key === 'emp_code' || key === 'employeecode') {
    return `E0${v}`;
  }

  if (key.includes('hour') || key.includes('est')) {
    return `${v}h`;
  }

  return String(v);
};

const getTodayDateString = () => {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const parseUTCDate = (value) => {
  if (!value) return null;
  let dateStr = typeof value === 'string' ? value.replace(' ', 'T') : value;
  if (typeof dateStr === 'string' && !dateStr.endsWith('Z') && !dateStr.includes('+')) {
    dateStr += 'Z';
  }
  const parsedDate = new Date(dateStr);
  return Number.isNaN(parsedDate.getTime()) ? null : parsedDate;
};

const formatAuditDateTime = (value) => {
  const parsedDate = parseUTCDate(value);
  if (!parsedDate) return '';

  const datePart = parsedDate.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'numeric',
    year: 'numeric',
  });
  const timePart = parsedDate
    .toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    })
    .toLowerCase();

  return `${datePart}, ${timePart}`;
};

const AuditLog = () => {
  const [employeeCode, setEmployeeCode] = useState('');
  const [employeeName, setEmployeeName] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [remarks, setRemarks] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [dateInputResetKey, setDateInputResetKey] = useState(0);
  const maxFilterDate = getTodayDateString();

  const [rowData, setRowData] = useState([]);
  const [isGridLoading, setIsGridLoading] = useState(false);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [diffData, setDiffData] = useState({ old: null, new: null, info: {} });

  const [lookups, setLookups] = useState({});
  const [isLookupsLoading, setIsLookupsLoading] = useState(false);

  const diffRows = React.useMemo(() => {
    const rawOld = diffData.old || {};
    const rawNew = diffData.new || {};

    const flatten = (obj) => {
      const flat = {};
      Object.keys(obj).forEach((key) => {
        if (
          obj[key] &&
          typeof obj[key] === 'object' &&
          !Array.isArray(obj[key])
        ) {
          Object.assign(flat, obj[key]);
        } else {
          flat[key] = obj[key];
        }
      });
      return flat;
    };

    const o = flatten(rawOld);
    const n = flatten(rawNew);

    const ignoreKeys = [
      'updated_at',
      'updatedby',
      'createdby',
      'created_at',
      'deletedby',
      'isdelete',
      'isadmin',
      'isloggedin',
      'lastactivity',
    ];

    const changedKeys = getChangedKeys(o, n).filter(
      (k) => !ignoreKeys.includes(k.toLowerCase()),
    );

    return changedKeys.map((k) => ({
      key: k,
      label: formatKeyLabel(k),
      oldVal: formatValue(k, o[k], lookups),
      newVal: formatValue(k, n[k], lookups),
    }));
  }, [diffData, lookups]);

  useEffect(() => {
    loadAuditLogs();
    loadLookups();
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      loadAuditLogs({
        employeeCode,
        employeeName,
        fromDate,
        toDate,
        remarks,
        searchTerm,
      });
    }, 250);

    return () => clearTimeout(timer);
  }, [searchTerm]);

  const loadLookups = async () => {
    setIsLookupsLoading(true);
    const types = [
      'roles',
      'departments',
      'designation',
      'employmenttype',
      'workingstatus',
      'clients',
      'teams',
      'reportingto',
      'Categories',
      'projecttaskstatus',
    ];
    const maps = {};
    for (const type of types) {
      try {
        const data = await fetchDropdownData(type);
        const map = {};
        data.forEach((item) => {
          // Robust ID extraction
          const id =
            item.id ??
            item.Id ??
            item.roleId ??
            item.departmentId ??
            item.designationId ??
            item.clientId ??
            item.teamId ??
            item.emp_code ??
            item.categoryId ??
            item.statusId ??
            item.status_Id;

          // Robust Name extraction
          const name =
            item.name ??
            item.Name ??
            item.roleTitle ??
            item.departmentName ??
            item.designationTitle ??
            item.clientName ??
            item.teamName ??
            item.userName ??
            item.categoryName ??
            item.statusName ??
            item.status_Name;

          if (id !== undefined && id !== null) {
            map[String(id)] = name || `ID: ${id}`;
          }
        });

        // Normalize map key to lowercase for easier matching later
        const mapKey =
          type.toLowerCase() === 'designation'
            ? 'designations'
            : type.toLowerCase();
        maps[mapKey] = map;
      } catch (e) {
        console.error(`Failed to fetch lookup for ${type}`, e);
      }
    }
    setLookups(maps);
    setIsLookupsLoading(false);
    return maps;
  };

  const handleOpenDiff = (data) => {
    console.log('Opening Audit Details:', data);

    if (!lookups.designations || Object.keys(lookups.designations).length === 0) {
      loadLookups();
    }

    setDiffData({
      old: safeParse(data.oldValue),
      new: safeParse(data.newValue),
      info: {
        module: data.moduleName,
        action: data.actionType,
        date: data.actionDate,
      },
    });

    onOpen();
  };

  const loadAuditLogs = async (searchValues = null) => {
    setIsGridLoading(true);
    try {
      // 1. Determine values to use: explicitly passed OR from current state
      const f = searchValues || {
        employeeCode,
        employeeName,
        fromDate,
        toDate,
        remarks,
        searchTerm,
      };

      // 2. Prepare API params
      let searchCode = f.employeeCode;
      if (searchCode && searchCode.toString().toUpperCase().startsWith('E0')) {
        searchCode = searchCode.toString().substring(2);
      }

      const params = {
        empCode: searchCode || undefined,
        startDate: f.fromDate || undefined,
        endDate: f.toDate || undefined,
        remarks: f.remarks || undefined,
        userName: f.employeeName || undefined,
      };

      // Clean undefined keys
      Object.keys(params).forEach(
        (key) => params[key] === undefined && delete params[key],
      );

      console.log('Fetching audit logs with:', params);
      const data = await fetchAuditLogs(params);

      // 3. Sort by Action Date Descending (Most Recent First)
      // Standardize date comparison
      const sorted = [...data].sort((a, b) => {
        const dateA = parseUTCDate(a.actionDate);
        const dateB = parseUTCDate(b.actionDate);
        const timeA = dateA ? dateA.getTime() : 0;
        const timeB = dateB ? dateB.getTime() : 0;
        return timeB - timeA;
      });

      // 4. Local filtering using SAME values to ensure UI sync
      // This is a fail-safe in case the API returns broader results than requested
      const filtered = sorted.filter((item) => {
        // Employee Code Check
        const sCode = searchCode ? searchCode.toString().toUpperCase() : '';
        const matchCode =
          !sCode || item.actorEmpCode?.toString().includes(sCode);

        // Remarks Check
        const sRemarks = (f.remarks || '').toLowerCase();
        const matchRemarks =
          !sRemarks || item.remarks?.toLowerCase().includes(sRemarks);

        // Employee Name Check
        const sName = (f.employeeName || '').toLowerCase();
        const matchName =
          !sName ||
          item.userName?.toLowerCase().includes(sName) ||
          item.actorEmpName?.toLowerCase().includes(sName);

        // Global Search (Module / Action / Remarks / User / Emp Code)
        const sGlobal = (f.searchTerm || '').toLowerCase().trim();
        const searchBlob = [
          item.moduleName,
          item.actionType,
          item.remarks,
          item.userName,
          item.actorEmpName,
          item.actorEmpCode,
          item.targetEmpCode,
        ]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();
        const matchGlobal = !sGlobal || searchBlob.includes(sGlobal);

        // Date Range Check (Robust String Comparison)
        let matchDate = true;
        if (f.fromDate || f.toDate) {
          // Extract YYYY-MM-DD from item action date (Local components)
          const dateObj = parseUTCDate(item.actionDate);
          if (dateObj) {
            const y = dateObj.getFullYear();
            const m = String(dateObj.getMonth() + 1).padStart(2, '0');
            const d = String(dateObj.getDate()).padStart(2, '0');
            const itemDateStr = `${y}-${m}-${d}`;

            if (f.fromDate && itemDateStr < f.fromDate) matchDate = false;
            if (f.toDate && itemDateStr > f.toDate) matchDate = false;
          } else if (f.fromDate || f.toDate) {
            matchDate = false; // No date to compare against filters
          }
        }
        return matchCode && matchRemarks && matchName && matchDate && matchGlobal;
      });

      setRowData(filtered);
    } catch (error) {
      console.error('Failed to load audit logs', error);
      setRowData([]);
    } finally {
      setIsGridLoading(false);
    }
  };

  const [columnDefs] = useState([
    {
      headerName: 'Emp Code',
      field: 'actorEmpCode',
      sortable: true,
      valueFormatter: (params) => (params.value ? `E0${params.value}` : '-'),
    },
    {
      headerName: 'Module',
      field: 'moduleName',
      sortable: true,
    },
    {
      headerName: 'Action',
      field: 'actionType',
      sortable: true,
      valueFormatter: (p) => p.value || '-',
    },
    // {
    //   headerName: 'Entity',
    //   field: 'entityName',
    //   sortable: true,
    // },


    {
      headerName: 'Date & Time',
      field: 'actionDate',
      flex: 2,
      sortable: true,
      valueFormatter: (params) =>
        params.value ? formatAuditDateTime(params.value) : '',
    },

    {
      headerName: 'Remarks',
      field: 'remarks',
      flex: 2,
      cellRenderer: (p) => {
        const val = p.data?.targetEmpCode;
        const isUpdate = p.data?.actionType === 'UPDATE';
        const isEmpCode =
          val && /^\d+$/.test(String(val)) && String(val).length <= 6;
        const detailsValue = isUpdate ? '' : isEmpCode ? `E0${val}` : val || '';
        const remarkText = p.value || '-';
        const hasChanges =
          (p.data?.oldValue !== null &&
            p.data?.oldValue !== undefined &&
            p.data?.oldValue !== '' &&
            String(p.data?.oldValue).toLowerCase() !== 'null') ||
          (p.data?.newValue !== null &&
            p.data?.newValue !== undefined &&
            p.data?.newValue !== '' &&
            String(p.data?.newValue).toLowerCase() !== 'null');
        const displayText = detailsValue
          ? `${remarkText} (${detailsValue})`
          : remarkText;

        if (!isUpdate || !hasChanges) return displayText;

        return (
          <Text
            as="button"
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              handleOpenDiff(p.data);
            }}
            color="blue.600"
            textDecoration="underline"
            cursor="pointer"
            fontSize="sm"
            textAlign="left"
            _hover={{ color: 'blue.700' }}
          >
            {displayText}
          </Text>
        );
      },
    },

  ]);

  const handleSearch = () => {
    loadAuditLogs();
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const handleReset = () => {
    // 1. Clear State
    setEmployeeCode('');
    setEmployeeName('');
    setFromDate('');
    setToDate('');
    setRemarks('');
    setSearchTerm('');
    setDateInputResetKey((prev) => prev + 1);

    // 2. Load data passing EXPLICIT empty values to bypass stale state
    const emptyFilters = {
      employeeCode: '',
      employeeName: '',
      fromDate: '',
      toDate: '',
      remarks: '',
      searchTerm: '',
    };
    loadAuditLogs(emptyFilters);
  };

  const inputBg = useColorModeValue('white', 'navy.900');
  const remarksBg = useColorModeValue('#f4f7fe', 'whiteAlpha.50');
  const labelColor = '#1B2559';

  return (
    <Box className="list-table-page">
      <Heading className="page-title" mb={5}>
        Audit Log
      </Heading>

      {/* Filter Section */}
      <Box mb="20px" px="0">
        <Flex
          direction="row"
          wrap="nowrap"
          gap="10px"
          align="flex-end"
          w="100%"
        >
          <FormControl maxW="140px" flex="1">
            <FormLabel fontSize="14px" fontWeight="bold" mb="10px">
              Employee Code
            </FormLabel>
            <Input
              placeholder="Employee Code"
              value={employeeCode}
              onChange={(e) => setEmployeeCode(e.target.value)}
              onKeyDown={handleKeyDown}
              bg={inputBg}
              border="1px solid"
              borderColor="gray.200"
              height="38px"
              borderRadius="8px"
              fontSize="14px"
              _placeholder={{ color: 'gray.400' }}
            />
          </FormControl>

          {/* <FormControl minW="150px" flex="1.2">
            <FormLabel
              fontSize="14px"
              fontWeight="bold"
              color={labelColor}
              mb="10px"
            >
              Employee Name
            </FormLabel>
            <Input
              placeholder="Employee Name"
              value={employeeName}
              onChange={(e) => setEmployeeName(e.target.value)}
              onKeyDown={handleKeyDown}
              bg={inputBg}
              border="1px solid"
              borderColor="gray.200"
              height="38px"
              borderRadius="8px"
              fontSize="14px"
              _placeholder={{ color: 'gray.400' }}
            />
          </FormControl> */}

          <FormControl maxW="150px" flex="1">
            <FormLabel fontSize="14px" fontWeight="bold" mb="10px">
              From Date
            </FormLabel>
            <Input
              key={`from-date-${dateInputResetKey}`}
              type="date"
              value={fromDate}
              onChange={(e) => {
                const selectedDate = e.target.value;
                setFromDate(selectedDate > maxFilterDate ? maxFilterDate : selectedDate);
              }}
              onKeyDown={handleKeyDown}
              bg={inputBg}
              border="1px solid"
              borderColor="gray.200"
              height="38px"
              borderRadius="8px"
              fontSize="14px"
              max={maxFilterDate}
            />
          </FormControl>

          <FormControl maxW="150px" flex="1">
            <FormLabel fontSize="14px" fontWeight="bold" mb="10px">
              To Date
            </FormLabel>
            <Input
              key={`to-date-${dateInputResetKey}`}
              type="date"
              value={toDate}
              onChange={(e) => {
                const selectedDate = e.target.value;
                setToDate(selectedDate > maxFilterDate ? maxFilterDate : selectedDate);
              }}
              onKeyDown={handleKeyDown}
              bg={inputBg}
              border="1px solid"
              borderColor="gray.200"
              height="38px"
              borderRadius="8px"
              fontSize="14px"
              autoComplete="off"
              max={maxFilterDate}
            />
          </FormControl>

          <FormControl maxW="220px" flex="1.3">
            <InputGroup>
              <InputLeftElement pointerEvents="none">
                <FiSearch color="#9CA3AF" size={15} />
              </InputLeftElement>
              <Input
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={handleKeyDown}
                bg={inputBg}
                border="1px solid"
                borderColor="gray.200"
                height="38px"
                borderRadius="8px"
                fontSize="14px"
                pl="36px"
              />
            </InputGroup>
          </FormControl>

          {/* <FormControl minW="180px" flex="1.5">
            <FormLabel
              fontSize="14px"
              fontWeight="bold"

              mb="10px"
            >
              Remarks
            </FormLabel>
            <Input
              placeholder="Remarks"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              onKeyDown={handleKeyDown}
              bg={remarksBg}
              border="none"
              height="38px"
              borderRadius="8px"
              fontSize="14px"
              _placeholder={{ color: 'gray.500' }}
            />
          </FormControl> */}

          <Flex gap="10px" pb="1px">
            <Button
              bg="#315C8C"
              color="white"
              border="1px solid"
              borderColor="#315C8C"
              _hover={{ bg: '#2A4F7C', borderColor: '#2A4F7C' }}
              onClick={handleSearch}
              height="38px"
              width="50px"
              borderRadius="22px"
              fontSize="18px"
              fontWeight="700"
              p="0"
            >
              <FiSearch />
            </Button>
            <Button
              variant="outline"
              color="#315C8C"
              borderColor="#315C8C"
              _hover={{ bg: '#EEF4FB', color: '#2A4F7C', borderColor: '#2A4F7C' }}
              onClick={handleReset}
              height="38px"
              width="50px"
              borderRadius="22px"
              fontSize="18px"
              fontWeight="700"
              p="0"
              bg="white"
            >
              <FiRotateCcw />
            </Button>
          </Flex>
        </Flex>
      </Box>

      {/* Grid Section */}
      <div
        className="ag-theme-alpine list-table-grid content-surface"
        style={{ width: '100%', position: 'relative' }}
      >
        <AgGridReact
          rowData={rowData}
          suppressNoRowsOverlay={isGridLoading}
          columnDefs={columnDefs}
          defaultColDef={{
            flex: 1,
            minWidth: 100,
            resizable: false,
            suppressMovable: true,
          }}
          suppressDragLeaveHidesColumns={true}
          suppressRowDrag={true}
          suppressMoveWhenRowDragging={true}
          pagination={true}
          paginationPageSize={10}
          paginationPageSizeSelector={[10, 25, 50, 100]}
        />
        {isGridLoading && (
          <Box
            position="absolute"
            top="0"
            left="0"
            right="0"
            bottom="0"
            bg="rgba(31, 58, 95, 0.34)"
            zIndex="10"
            display="flex"
            alignItems="center"
            justifyContent="center"
          >
            <TimeSnapLoader text="Loading audit logs..." />
          </Box>
        )}
      </div>

      <Modal isOpen={isOpen} onClose={onClose} size="xl" isCentered>
        <ModalOverlay backdropFilter="blur(2px)" />
        <ModalContent borderRadius="15px">
          <ModalHeader
            borderBottom="1px solid #eee"
            fontSize="16px"
            color="#1B2559"
          >
            Detailed Changes - {diffData.info.module || 'System'} (
            {diffData.info.date
              ? formatAuditDateTime(diffData.info.date)
              : 'N/A'}
            )
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody p={0}>
            <VStack align="stretch" spacing={0}>
              <HStack bg="gray.50" px={4} py={2} borderBottom="1px solid #eee">
                <Text
                  flex="1"
                  fontSize="12px"
                  fontWeight="bold"
                  color="gray.500"
                >
                  FIELD
                </Text>
                <Text
                  flex="1.5"
                  fontSize="12px"
                  fontWeight="bold"
                  color="gray.500"
                >
                  OLD
                </Text>
                <Text
                  flex="1.5"
                  fontSize="12px"
                  fontWeight="bold"
                  color="gray.500"
                >
                  NEW
                </Text>
              </HStack>
              <Box maxH="400px" overflowY="auto">
                {diffRows.length === 0 ? (
                  <Text p={4} fontSize="13px" color="gray.500">
                    No field-level changes found.
                  </Text>
                ) : (
                  diffRows.map((row) => (
                    <HStack
                      key={row.key}
                      px={4}
                      py={3}
                      borderBottom="1px solid #f9f9f9"
                    >
                      <Text flex="1" fontSize="13px" fontWeight="600">
                        {row.label}
                      </Text>

                      <Text flex="1.5" fontSize="13px" color="red.500">
                        {row.oldVal}
                      </Text>

                      <HStack flex="1.5" spacing={2}>
                        <FiArrowRight size="12" color="gray.300" />
                        <Text
                          flex="1"
                          fontSize="13px"
                          fontWeight="bold"
                          color="green.600"
                        >
                          {row.newVal}
                        </Text>
                      </HStack>
                    </HStack>
                  ))
                )}
              </Box>
            </VStack>
          </ModalBody>
          <Box p={4} textAlign="right">
            <Button
              size="sm"
              bg="#1B2559"
              color="white"
              onClick={onClose}
              _hover={{ bg: '#0b1330' }}
            >
              Close
            </Button>
          </Box>
        </ModalContent>
      </Modal>
    </Box>
  );
};

export default AuditLog;

