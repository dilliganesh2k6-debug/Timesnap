import React, { useEffect, useRef, useState } from 'react';
import {
  fetchEmployeeDetails,
  fetchUserProfilePicture,
  uploadUserProfilePicture,
  deleteUserProfilePicture,
  changeUserPassword,
} from 'utils/api';
import { useLoader } from 'contexts/LoaderContext';
import { useCustomToast } from 'utils/toastUtils';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { LOCAL_STORAGE_KEYS, formatDate } from 'utils/constants';
import {
  Avatar,
  Badge,
  Box,
  Button,
  Flex,
  FormLabel,
  Grid,
  GridItem,
  HStack,
  Icon,
  IconButton,
  Input,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Text,
  VStack,
} from '@chakra-ui/react';
import {
  FaBarcode,
  FaBirthdayCake,
  FaCalendar,
  FaCamera,
  FaEnvelope,
  FaHeart,
  FaIdBadge,
  FaKey,
  FaMapMarkerAlt,
  FaNetworkWired,
  FaTrash,
  FaTransgender,
  FaUserCheck,
  FaUsers,
  FaUserTag,
  FaUserTie,
} from 'react-icons/fa';
import { FiArrowLeft } from 'react-icons/fi';
import {
  MdContactPhone,
  MdPhone,
  MdVisibility,
  MdVisibilityOff,
} from 'react-icons/md';

const naValues = ['NA', '0', '', null, undefined];

const isInvalidValue = (value) => naValues.includes(value);

const resolveDisplayValue = (value) => (isInvalidValue(value) ? null : value);

const getEmergencyContactValue = (details) => {
  const name = resolveDisplayValue(details?.emgContactName) || '';
  const relation = resolveDisplayValue(details?.emgContactRelation) || '';
  const phone = resolveDisplayValue(details?.emgContactPhoneNo) || '';

  if (name && relation && phone) return `${name} (${relation}) - ${phone}`;
  if (name && relation) return `${name} (${relation})`;
  if (name && phone) return `${name} - ${phone}`;
  if (relation && phone) return `${relation} - ${phone}`;
  if (name) return name;
  if (relation) return relation;
  if (phone) return phone;
  return null;
};

const InfoRow = ({ icon: IconComponent, label, value }) => (
  <Flex
    align="center"
    gap={4}
    px={4}
    py={4}
    border="1px solid"
    borderColor="#D9E5F2"
    borderRadius="12px"
    bg="#FFFFFF"
    minH="78px"
  >
    <Flex
      w="34px"
      h="34px"
      borderRadius="10px"
      align="center"
      justify="center"
      bg="linear-gradient(135deg, rgba(167, 199, 236, 0.28), rgba(49, 92, 140, 0.12))"
      color="#2A4F7C"
      flexShrink={0}
    >
      <Icon as={IconComponent} boxSize={4} />
    </Flex>
    <Box minW={0}>
      <Text
        fontSize="11px"
        fontWeight={700}
        textTransform="uppercase"
        letterSpacing="0.08em"
        color="#6F88A8"
        mb={1}
      >
        {label}
      </Text>
      <Text
        fontSize="13px"
        fontWeight={600}
        color={value ? '#1F2F45' : '#8BA1BE'}
        noOfLines={2}
      >
        {value || 'Not available'}
      </Text>
    </Box>
  </Flex>
);

export default function UserDetailsPage() {
  const emp_code = localStorage.getItem('emp_code');
  const showToast = useCustomToast();
  const [activeTab, setActiveTab] = useState(0);
  const [userDetails, setUserDetails] = useState(null);
  const [profilePhoto, setProfilePhoto] = useState(null);
  const [isProfilePhotoModalOpen, setProfilePhotoModalOpen] = useState(false);
  const fileInputRef = useRef(null);
  const { showGlobalLoader, hideGlobalLoader } = useLoader();
  const [isPhotoSubmitting, setIsPhotoSubmitting] = useState(false);

  const [isChangePasswordModalOpen, setChangePasswordModalOpen] =
    useState(false);
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [changingPassword, setChangingPassword] = useState(false);
  const [passwordErrors, setPasswordErrors] = useState({
    oldPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [showOldPassword, setShowOldPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleOpenChangePasswordModal = () => setChangePasswordModalOpen(true);
  const handleCloseChangePasswordModal = () => {
    setOldPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setPasswordErrors({
      oldPassword: '',
      newPassword: '',
      confirmPassword: '',
    });
    setChangePasswordModalOpen(false);
  };

  const validatePassword = (password) => {
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumber = /[0-9]/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    if (password.length < minLength) {
      return 'Password must be at least 8 characters long';
    }
    if (!hasUpperCase) {
      return 'Password must contain at least one uppercase letter';
    }
    if (!hasLowerCase) {
      return 'Password must contain at least one lowercase letter';
    }
    if (!hasNumber) {
      return 'Password must contain at least one number';
    }
    if (!hasSpecialChar) {
      return 'Password must contain at least one special character';
    }
    return '';
  };

  const handleChangePassword = async () => {
    const errors = {
      oldPassword: '',
      newPassword: '',
      confirmPassword: '',
    };

    if (!oldPassword.trim()) {
      errors.oldPassword = 'Current password is required';
    }

    if (!newPassword.trim()) {
      errors.newPassword = 'New password is required';
    } else {
      const passwordError = validatePassword(newPassword);
      if (passwordError) {
        errors.newPassword = passwordError;
      }
    }

    if (!confirmPassword.trim()) {
      errors.confirmPassword = 'Please confirm your new password';
    }

    if (newPassword && confirmPassword && newPassword !== confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }

    if (oldPassword && newPassword && oldPassword === newPassword) {
      errors.newPassword =
        'New password must be different from current password';
    }

    if (errors.oldPassword || errors.newPassword || errors.confirmPassword) {
      setPasswordErrors(errors);
      return;
    }

    setChangingPassword(true);
    try {
      const response = await changeUserPassword(emp_code, oldPassword, newPassword);
      showToast('success', response.message || 'Password changed successfully');
      handleCloseChangePasswordModal();
    } catch (error) {
      showToast('error', error.message || 'Failed to change password');
    } finally {
      setChangingPassword(false);
    }
  };

  const handleOpenProfilePhotoModal = () => setProfilePhotoModalOpen(true);
  const handleCloseProfilePhotoModal = () => setProfilePhotoModalOpen(false);

  useEffect(() => {
    const loadUserDetails = async () => {
      const roleId = localStorage.getItem(LOCAL_STORAGE_KEYS.ROLE_ID);
      if (!emp_code || !roleId) return;

      showGlobalLoader();
      try {
        const response = await fetchEmployeeDetails(emp_code, roleId);
        const { employeeData, roletitle } = response;
        const formattedData = {
          name: employeeData.username,
          emailId: employeeData.email_id,
          phoneNo: employeeData.phoneNo,
          location: employeeData.location,
          dateOfBirth: employeeData.dateofbirth,
          gender: employeeData.gender,
          maritalStatus: employeeData.maritalStatus,
          emgContactName: employeeData.emg_ContactName,
          emgContactPhoneNo: employeeData.emg_ContactPhoneNo,
          emgContactRelation: employeeData.emg_ContactRelation,
          designation: employeeData.designation,
          isBillable: employeeData.isBillable,
          employmentType: employeeData.employmentType,
          employmentType_Id: employeeData.employmentType_Id,
          departmentName: employeeData.departmentName,
          teamName: employeeData.teamName,
          reportingTo: employeeData.reportingTo,
          joiningDate: employeeData.joiningDate,
          emp_code: employeeData.emp_code,
          roleTitle: roletitle,
        };

        setUserDetails(formattedData);
      } catch (error) {
        console.error('Error fetching Employee details:', error);
        showToast(
          'error',
          'Unable to load Employee details. Please try again later.',
        );
      } finally {
        hideGlobalLoader();
      }
    };

    loadUserDetails();
  }, [emp_code]);

  useEffect(() => {
    const loadProfilePicture = async () => {
      if (!userDetails || !userDetails.emp_code) return;
      const imageUrl = await fetchUserProfilePicture(userDetails.emp_code);
      if (imageUrl) setProfilePhoto(imageUrl);
    };

    loadProfilePicture();
  }, [userDetails]);

  const handleProfileUpload = async (event) => {
    if (!userDetails || !userDetails.emp_code) {
      console.error('User details not loaded yet.');
      return;
    }

    const file = event.target.files[0];
    if (!file) return;

    showGlobalLoader();
    try {
      await uploadUserProfilePicture(file, userDetails.emp_code);
      const imageUrl = URL.createObjectURL(file);
      setProfilePhoto(imageUrl);
      showToast('success', 'Profile picture updated successfully!');
      setTimeout(() => {
        window.location.reload();
      }, 2500);
    } catch (error) {
      showToast('error', "Couldn't upload profile picture. Try again.");
    } finally {
      hideGlobalLoader();
    }
  };

  const handleDeleteProfilePhoto = async () => {
    if (!userDetails || !userDetails.emp_code) {
      showToast('error', "Couldn't upload profile picture. Try again.");
      return;
    }

    try {
      setIsPhotoSubmitting(true);
      await deleteUserProfilePicture(userDetails.emp_code);
      setProfilePhoto(null);
      showToast('success', 'profile photo has been deleted successfully!');
      setTimeout(() => {
        window.location.reload();
      }, 2500);
    } catch (error) {
      showToast('warning', "Can't remove the default profile picture.");
    } finally {
      setIsPhotoSubmitting(false);
      handleCloseProfilePhotoModal();
    }
  };

  const openFileInput = () => {
    fileInputRef.current.click();
  };

  const handleBack = () => {
    window.history.back();
  };

  return (
    <Box className="page-content-wrapper">
      <ToastContainer />
      <Box
        border="1px solid"
        borderColor="#D9E5F2"
        borderRadius="18px"
        bg="#FFFFFF"
        boxShadow="0 1px 3px rgba(31, 47, 69, 0.06), 0 6px 16px rgba(42, 79, 124, 0.05)"
        overflow="hidden"
      >
        <Flex
          px={{ base: 5, md: 7 }}
          py={{ base: 5, md: 5 }}
          align={{ base: 'flex-start', md: 'center' }}
          justify="space-between"
          direction={{ base: 'column', md: 'row' }}
          gap={3}
          bg="linear-gradient(90deg, rgba(167, 199, 236, 0.22), rgba(49, 92, 140, 0.1))"
          borderBottom="1px solid"
          borderColor="#D9E5F2"
        >
          <HStack spacing={4} align="center">
            <Box position="relative">
              <Avatar
                size="lg"
                name={userDetails?.name}
                src={profilePhoto || undefined}
                bg="linear-gradient(135deg, #3A699A, #2A4F7C)"
                color="#FFFFFF"
                border="3px solid"
                borderColor="#FFFFFF"
                boxShadow="0 8px 24px rgba(42, 79, 124, 0.24)"
              />
              <IconButton
                size="xs"
                icon={<FaCamera />}
                aria-label="Update profile photo"
                position="absolute"
                right="-1"
                bottom="-1"
                borderRadius="full"
                border="1px solid"
                borderColor="#D9E5F2"
                bg="#FFFFFF"
                color="#2A4F7C"
                onClick={handleOpenProfilePhotoModal}
                _hover={{ bg: '#EEF4FB' }}
              />
              <Input
                type="file"
                ref={fileInputRef}
                display="none"
                accept="image/jpeg,image/png,image/gif"
                onChange={handleProfileUpload}
              />
            </Box>
            <VStack align="flex-start" spacing={1}>
              <Text
                fontSize={{ base: '22px', md: '24px' }}
                lineHeight="1.1"
                fontWeight={800}
                color="#1F2F45"
                letterSpacing="-0.03em"
              >
                {userDetails?.name || 'Loading profile...'}
              </Text>
              <HStack spacing={2} flexWrap="wrap">
                <Badge
                  px={2.5}
                  py={1}
                  borderRadius="full"
                  fontSize="11px"
                  fontWeight={700}
                  textTransform="none"
                  bg="#E7F0FA"
                  color="#2A4F7C"
                  border="1px solid"
                  borderColor="#D9E5F2"
                >
                  {userDetails?.roleTitle || 'Employee'}
                </Badge>
                <Text fontSize="13px" color="#4A617F" noOfLines={1}>
                  {userDetails?.emailId || 'No email available'}
                </Text>
              </HStack>
            </VStack>
          </HStack>
          <HStack spacing={2.5}>
            <Button
              onClick={handleBack}
              leftIcon={<Icon as={FiArrowLeft} boxSize={4} />}
              h="38px"
              px={3.5}
              borderRadius="10px"
              bg="#F2F7FD"
              border="1px solid #C8D9EC"
              color="#2B5383"
              fontSize="14px"
              fontWeight={700}
              lineHeight="1"
              _hover={{
                bg: '#E8F1FB',
                borderColor: '#9FBCE0',
                transform: 'translateY(-1px)',
              }}
              _active={{ bg: '#DFECFA', transform: 'translateY(0)' }}
            >
              Back
            </Button>
            <Button
              className="page-primary-cta"
              leftIcon={<FaKey />}
              h="38px"
              px={4.5}
              borderRadius="10px"
              onClick={handleOpenChangePasswordModal}
            >
              Change Password
            </Button>
          </HStack>
        </Flex>

        <Box px={{ base: 4, md: 6 }} py={{ base: 4, md: 4 }} bg="#F6F9FD">
          <Tabs
            index={activeTab}
            onChange={setActiveTab}
            colorScheme="blue"
            variant="unstyled"
          >
            <TabList
              p={1}
               bg="#EDF4FC"
              border="1px solid"
               borderColor="#D9E5F2"
              borderRadius="12px"
              w="fit-content"
              mb={4}
              gap={1}
            >
              <Tab
                px={4}
                h="36px"
                fontSize="13px"
                fontWeight={700}
                 color="#4A617F"
                borderRadius="9px"
                _selected={{
                  bg: '#FFFFFF',
                   color: '#2A4F7C',
                   boxShadow: '0 1px 2px rgba(31, 58, 95, 0.08)',
                }}
              >
                Professional Details
              </Tab>
              <Tab
                px={4}
                h="36px"
                fontSize="13px"
                fontWeight={700}
                 color="#4A617F"
                borderRadius="9px"
                _selected={{
                  bg: '#FFFFFF',
                   color: '#2A4F7C',
                   boxShadow: '0 1px 2px rgba(31, 58, 95, 0.08)',
                }}
              >
                Personal Details
              </Tab>
            </TabList>

            <TabPanels>
              <TabPanel p={0}>
                <Grid
                  templateColumns={{ base: '1fr', md: '1fr 1fr' }}
                  gap={4}
                >
                  <GridItem>
                    <InfoRow
                      icon={FaBarcode}
                      label="Employee Code"
                      value={userDetails?.emp_code ? `E0${userDetails.emp_code}` : null}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaIdBadge}
                      label="Designation"
                      value={resolveDisplayValue(userDetails?.designation)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaUserCheck}
                      label="Billable"
                      value={
                        userDetails?.isBillable === undefined
                          ? null
                          : userDetails?.isBillable
                            ? 'Yes'
                            : 'No'
                      }
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaUserTag}
                      label="Employment Type"
                      value={resolveDisplayValue(userDetails?.employmentType)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaNetworkWired}
                      label="Department"
                      value={resolveDisplayValue(userDetails?.departmentName)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaUsers}
                      label="Team"
                      value={resolveDisplayValue(userDetails?.teamName)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaUserTie}
                      label="Reporting To"
                      value={resolveDisplayValue(userDetails?.reportingTo)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaCalendar}
                      label="Joining Date"
                      value={userDetails?.joiningDate ? formatDate(userDetails.joiningDate) : null}
                    />
                  </GridItem>
                </Grid>
              </TabPanel>

              <TabPanel p={0}>
                <Grid
                  templateColumns={{ base: '1fr', md: '1fr 1fr' }}
                  gap={4}
                >
                  <GridItem>
                    <InfoRow
                      icon={FaEnvelope}
                      label="Email"
                      value={resolveDisplayValue(userDetails?.emailId)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={MdPhone}
                      label="Phone"
                      value={resolveDisplayValue(userDetails?.phoneNo)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaMapMarkerAlt}
                      label="Location"
                      value={resolveDisplayValue(userDetails?.location)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaBirthdayCake}
                      label="Date of Birth"
                      value={userDetails?.dateOfBirth ? formatDate(userDetails.dateOfBirth) : null}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaTransgender}
                      label="Gender"
                      value={resolveDisplayValue(userDetails?.gender)}
                    />
                  </GridItem>
                  <GridItem>
                    <InfoRow
                      icon={FaHeart}
                      label="Marital Status"
                      value={resolveDisplayValue(userDetails?.maritalStatus)}
                    />
                  </GridItem>
                  <GridItem colSpan={{ base: 1, md: 2 }}>
                    <InfoRow
                      icon={MdContactPhone}
                      label="Emergency Contact"
                      value={getEmergencyContactValue(userDetails)}
                    />
                  </GridItem>
                </Grid>
              </TabPanel>
            </TabPanels>
          </Tabs>
        </Box>
      </Box>

      <Modal
        isOpen={isProfilePhotoModalOpen}
        closeOnOverlayClick={false}
        onClose={handleCloseProfilePhotoModal}
      >
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Profile Picture</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <VStack spacing={5} align="center">
              <Avatar
                size="2xl"
                name={userDetails?.name}
                src={profilePhoto || undefined}
                bg="gray.300"
                color="gray.700"
                borderWidth={3}
                borderColor="gray.500"
              />
              <Text fontWeight="bold" fontSize="lg" color="gray.800">
                {userDetails?.name || 'Your Name'}
              </Text>
              <Text fontSize="sm" color="gray.500">
                {userDetails?.emailId || 'your.email@example.com'}
              </Text>
            </VStack>
          </ModalBody>

          <ModalFooter>
            <HStack spacing={4} width="100%" justifyContent="center">
              <Button
                colorScheme="green"
                onClick={() => {
                  openFileInput();
                  handleCloseProfilePhotoModal();
                }}
                leftIcon={<FaCamera />}
                size="md"
              >
                Change
              </Button>
              <Button
                colorScheme="red"
                variant="outline"
                onClick={handleDeleteProfilePhoto}
                leftIcon={<FaTrash />}
                size="md"
                isLoading={isPhotoSubmitting}
              >
                Remove
              </Button>
            </HStack>
          </ModalFooter>
        </ModalContent>
      </Modal>

      <Modal
        isOpen={isChangePasswordModalOpen}
        closeOnOverlayClick={false}
        onClose={handleCloseChangePasswordModal}
        isCentered
      >
        <ModalOverlay />
        <ModalContent className="profile-change-password-modal">
          <ModalHeader>Change Password</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <VStack spacing={4} align="stretch">
              <Box position="relative">
                <FormLabel htmlFor="old-password">
                  Current Password{' '}
                  <Text as="span" color="red.500">
                    *
                  </Text>
                </FormLabel>
                <Input
                  id="old-password"
                  type={showOldPassword ? 'text' : 'password'}
                  placeholder="Enter your current password"
                  value={oldPassword}
                  onChange={(e) => {
                    setOldPassword(e.target.value);
                    setPasswordErrors((prev) => ({ ...prev, oldPassword: '' }));
                  }}
                  isInvalid={!!passwordErrors.oldPassword}
                  borderColor={passwordErrors.oldPassword ? 'red.500' : undefined}
                  autoComplete="off"
                  pr="2.5rem"
                />
                <Icon
                  as={showOldPassword ? MdVisibilityOff : MdVisibility}
                  position="absolute"
                  right="10px"
                  top="45px"
                  cursor="pointer"
                  onClick={() => setShowOldPassword((prev) => !prev)}
                  zIndex={2}
                />
                {passwordErrors.oldPassword && (
                  <Text color="red.500" fontSize="sm" mt={1}>
                    {passwordErrors.oldPassword}
                  </Text>
                )}
              </Box>

              <Box position="relative">
                <FormLabel htmlFor="new-password">
                  New Password{' '}
                  <Text as="span" color="red.500">
                    *
                  </Text>
                </FormLabel>
                <Input
                  id="new-password"
                  type={showNewPassword ? 'text' : 'password'}
                  placeholder="Enter your new password"
                  value={newPassword}
                  onChange={(e) => {
                    setNewPassword(e.target.value);
                    setPasswordErrors((prev) => ({ ...prev, newPassword: '' }));
                  }}
                  isInvalid={!!passwordErrors.newPassword}
                  borderColor={passwordErrors.newPassword ? 'red.500' : undefined}
                  autoComplete="off"
                  pr="2.5rem"
                />
                <Icon
                  as={showNewPassword ? MdVisibilityOff : MdVisibility}
                  position="absolute"
                  right="10px"
                  top="45px"
                  cursor="pointer"
                  onClick={() => setShowNewPassword((prev) => !prev)}
                  zIndex={2}
                />
                {passwordErrors.newPassword && (
                  <Text color="red.500" fontSize="sm" mt={1}>
                    {passwordErrors.newPassword}
                  </Text>
                )}
                {newPassword &&
                  validatePassword(newPassword) &&
                  !passwordErrors.newPassword && (
                    <Text fontSize="xs" color="gray.600" mt={1}>
                      Must be at least 8 characters with uppercase, lowercase,
                      number, and special character
                    </Text>
                  )}
              </Box>

              <Box position="relative">
                <FormLabel htmlFor="confirm-password">
                  Confirm New Password{' '}
                  <Text as="span" color="red.500">
                    *
                  </Text>
                </FormLabel>
                <Input
                  id="confirm-password"
                  type={showConfirmPassword ? 'text' : 'password'}
                  placeholder="Re-enter your new password"
                  value={confirmPassword}
                  onChange={(e) => {
                    setConfirmPassword(e.target.value);
                    setPasswordErrors((prev) => ({
                      ...prev,
                      confirmPassword: '',
                    }));
                  }}
                  isInvalid={!!passwordErrors.confirmPassword}
                  borderColor={passwordErrors.confirmPassword ? 'red.500' : undefined}
                  autoComplete="off"
                  pr="2.5rem"
                />
                <Icon
                  as={showConfirmPassword ? MdVisibilityOff : MdVisibility}
                  position="absolute"
                  right="10px"
                  top="45px"
                  cursor="pointer"
                  onClick={() => setShowConfirmPassword((prev) => !prev)}
                  zIndex={2}
                />
                {passwordErrors.confirmPassword && (
                  <Text color="red.500" fontSize="sm" mt={1}>
                    {passwordErrors.confirmPassword}
                  </Text>
                )}
              </Box>
            </VStack>
          </ModalBody>
          <ModalFooter>
            <Button
              className="profile-change-password-modal__submit"
              mr={3}
              onClick={handleChangePassword}
              isLoading={changingPassword}
            >
              Change Password
            </Button>
            <Button
              className="profile-change-password-modal__cancel"
              onClick={handleCloseChangePasswordModal}
            >
              Cancel
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Box>
  );
}
