import React, { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import {
  Box,
  Heading,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
  Button,
  Flex,
  Input,
  Select,
  Text,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Badge,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  FormControl,
  FormLabel,
  Checkbox, Icon, IconButton, Tooltip, Stack, Portal,
} from '@chakra-ui/react';
import { FiSearch, FiRotateCcw, FiFilter, FiDownload, FiFileText, FiFile } from 'react-icons/fi';
import { format, parseISO } from 'date-fns';
import {
  fetchTimesheetReportData,
  fetchTimesheetApprovals,
  fetchProjects,
} from 'utils/api';
import { LOCAL_STORAGE_KEYS } from 'utils/constants';
import { useCustomToast } from 'utils/toastUtils';
import { useLoader } from 'contexts/LoaderContext';
import { FiChevronLeft, FiChevronRight } from 'react-icons/fi';
import './Reports.css';
import TimeSnapLoader from '../../../../components/loaders/TimeSnapLoader';

const ReportsTabsScreen = () => {
  const empCode = localStorage.getItem(LOCAL_STORAGE_KEYS.EMP_CODE);
  const roleId = localStorage.getItem(LOCAL_STORAGE_KEYS.ROLE_ID);
  const showToast = useCustomToast();
  const { showGlobalLoader, hideGlobalLoader } = useLoader();
  /* ---------------- STATE ---------------- */
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [pendingReportType, setPendingReportType] = useState('timesheetSummary');
  const [reportType, setReportType] = useState('timesheetSummary');
  const [billableFilter, setBillableFilter] = useState('All');
  const [loading, setLoading] = useState(false);
  const [hasFetched, setHasFetched] = useState(false);
  const [employeeOptions, setEmployeeOptions] = useState([]);
  const [projectOptions, setProjectOptions] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [selectedProjects, setSelectedProjects] = useState([]);
  const [reportData, setReportData] = useState([]);
  const [userSearch, setUserSearch] = useState('');
  const [projectSearch, setProjectSearch] = useState('');
  const [hasSearchedOnce, setHasSearchedOnce] = useState(false);
  const activeReportRequestRef = React.useRef(null);
  /* ---------------- PAGINATION ---------------- */
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  /* ---------------- HELPERS ---------------- */
  const formatHours = (h = 0) => {
    const hrs = Math.floor(h);
    const mins = Math.round((h - hrs) * 60);
    return `${hrs}h ${mins.toString().padStart(2, '0')}m`;
  };
  const formatDecimalHours = formatHours;

  // Excel numeric hours (NO h / m)
  const formatExcelHours = (h = 0) => {
    return Number(h.toFixed(2)); // 8 or 8.5
  };

  /* ---------- GROUP DETAIL DATA (FIX DUPLICATES) ---------- */
  const detailedRowsWithSpan = React.useMemo(() => {
    if (reportType !== 'detailed') return [];

    const groupMap = new Map();
    const rows = [];

    reportData.forEach((item) => {
      const employeeKey = item.empCode ?? item.employeeCode ?? item.employeeName;
      const clientKey = item.clientId ?? item.clientName;
      const groupKey = `${employeeKey}|${item.projectID}|${clientKey}`;

      if (!groupMap.has(groupKey)) {
        groupMap.set(groupKey, {
          employeeName: item.employeeName,
          projectName: item.projectName,
          clientName: item.clientName,
          taskMap: new Map(),
          rows: [],
        });
      }

      const group = groupMap.get(groupKey);
      const categoryKey = item.taskCategoryID ?? item.taskCategoryName;
      const subCategoryKey = item.subCategoryID ?? item.subCategoryName;
      const taskKey = item.taskID ?? item.taskName;
      const detailKey = `${categoryKey}|${subCategoryKey}|${taskKey}|${item.isBillable}`;
      let taskRow = group.taskMap.get(detailKey);

      if (!taskRow) {
        taskRow = {
          employeeName: item.employeeName,
          projectName: item.projectName,
          clientName: item.clientName,
          categoryName: item.taskCategoryName,
          subCategoryName: item.subCategoryName,
          taskName: item.taskName,
          isBillable: item.isBillable,
          dates: {},
          totalHours: 0,
        };
        group.taskMap.set(detailKey, taskRow);
        group.rows.push(taskRow);
      }

      taskRow.dates[item.date] =
        (taskRow.dates[item.date] || 0) + (item.taskHours || 0);

      taskRow.totalHours += item.taskHours || 0;
    });

    // Flatten rows and add rowspan metadata
    groupMap.forEach((group) => {
      group.rows.forEach((row, index) => {
        rows.push({
          ...row,
          isFirstRow: index === 0,
          rowSpan: group.rows.length,
        });
      });
    });
    return rows;
  }, [reportData, reportType]);

  /* ---------- GROUP SUMMARY DATA (FOR PAGINATION) ---------- */
  const uniqueEmployeeNames = React.useMemo(() => {
    if (reportType !== 'timesheetSummary') return [];
    return [...new Set(reportData.map((r) => r.employeeName))];
  }, [reportData, reportType]);

  const summaryRows = React.useMemo(() => {
    if (reportType !== 'timesheetSummary') return [];

    const billTypeGroups = {
      Billable: new Map(),
      'Non-Billable': new Map(),
    };

    reportData.forEach((item) => {
      const billType = item.isBillable ? 'Billable' : 'Non-Billable';
      const categoryKey = item.taskCategoryID ?? item.taskCategoryName;
      const categories = billTypeGroups[billType];

      if (!categories.has(categoryKey)) {
        categories.set(categoryKey, {
          categoryName: item.taskCategoryName,
          tasks: new Map(),
        });
      }

      const category = categories.get(categoryKey);
      const subCategoryKey = item.subCategoryID ?? item.subCategoryName ?? '';
      const taskKey = item.taskID ?? item.taskName;
      const rowKey = `${subCategoryKey}|${taskKey}`;

      if (!category.tasks.has(rowKey)) {
        category.tasks.set(rowKey, {
          billType,
          category: item.taskCategoryName,
          subCategory: item.subCategoryName || '',
          task: item.taskName,
          employeeTotals: {},
          rowTotal: 0,
        });
      }

      const row = category.tasks.get(rowKey);
      const hours = item.taskHours || 0;
      row.employeeTotals[item.employeeName] =
        (row.employeeTotals[item.employeeName] || 0) + hours;
      row.rowTotal += hours;
    });

    const rows = [];
    ['Billable', 'Non-Billable'].forEach((billType) => {
      const categories = billTypeGroups[billType];
      let isFirstInBillType = true;
      categories.forEach((category) => {
        let isFirstInCategory = true;
        category.tasks.forEach((row) => {
          rows.push({
            ...row,
            isFirstInBillType,
            isFirstInCategory,
          });
          isFirstInBillType = false;
          isFirstInCategory = false;
        });
      });
    });
    return rows;
  }, [reportData, reportType]);

  const summaryEmployeeGrandTotals = React.useMemo(() => {
    const totals = {};
    summaryRows.forEach((row) => {
      Object.entries(row.employeeTotals).forEach(([employee, hours]) => {
        totals[employee] = (totals[employee] || 0) + hours;
      });
    });
    return totals;
  }, [summaryRows]);

  const summaryGrandTotal = React.useMemo(
    () => summaryRows.reduce((sum, row) => sum + row.rowTotal, 0),
    [summaryRows]
  );


  const filteredData = reportType === 'detailed' ? detailedRowsWithSpan : summaryRows;
  const totalRecords = filteredData.length;
  const totalPages = Math.max(1, Math.ceil(totalRecords / pageSize));
  const paginatedData = filteredData.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );
  const tableViewportHeight = { base: '320px', md: '430px' };
  const emptyStateContentHeight = { base: '250px', md: '360px' };
  const shouldUseFixedTableHeight =
    !startDate || !endDate || !hasFetched || filteredData.length === 0;

  const isSummary = pendingReportType === 'timesheetSummary';

  /* ---------------- LOADERS ---------------- */
  useEffect(() => {
    const loadProjects = async () => {
      showGlobalLoader();
      try {
        const res = await fetchProjects();
        setProjectOptions(
          res
            .map((p) => ({ value: p.projectID, label: p.projectName }))
            .sort((a, b) =>
              (a.label || "").localeCompare(b.label || "", undefined, {
                sensitivity: "base",
                numeric: true,
              })
            )
        );
      } catch (error) {
        console.error('Error fetching projects:', error);
      } finally {
        hideGlobalLoader();
      }
    };
    loadProjects();
  }, []);

  useEffect(() => {
    if (!empCode) return;
    const loadApprovals = async () => {
      showGlobalLoader();
      try {
        const res = await fetchTimesheetApprovals(empCode);
        const uniqueMap = new Map();
        res.timesheetApprovals
          .filter((a) => a.status === 'Approved' || a.approvedCount > 0)
          .forEach((a) => {
            if (!uniqueMap.has(a.employeeCode)) {
              uniqueMap.set(a.employeeCode, {
                value: a.employeeCode,
                label: a.employeeName,
              });
            }
          });
        setEmployeeOptions(
          Array.from(uniqueMap.values()).sort((a, b) =>
            (a.label || "").localeCompare(b.label || "", undefined, {
              sensitivity: "base",
              numeric: true,
            })
          )
        );
      } catch (error) {
        console.error('Error fetching approvals:', error);
      } finally {
        hideGlobalLoader();
      }
    };
    loadApprovals();
  }, [empCode]);

  /* ---------------- FETCH REPORT ---------------- */
  const fetchReport = React.useCallback(async () => {
    if (!startDate || !endDate) return;

    activeReportRequestRef.current?.abort();
    const requestController = new AbortController();
    activeReportRequestRef.current = requestController;

    setLoading(true);
    // showGlobalLoader();
    setHasFetched(false);
    try {
      let allData = [];
      const empCodes =
        selectedUsers.length > 0
          ? selectedUsers.map((u) => u.value)
          : employeeOptions.map((u) => u.value);

      if (empCodes.length === 0) return;

      // Request the complete selected employee scope once. The API applies
      // authorization first and then applies this employee filter in SQL.
      const res = await fetchTimesheetReportData(
        {
          empCode,
          roleId,
          employeeCodes: empCodes.join(','),
          summaryOnly: reportType === 'timesheetSummary',
          startDate,
          endDate,
        },
        { signal: requestController.signal }
      );

      if (Array.isArray(res)) {
        // Retain a defensive client-side filter for compatibility with older
        // API deployments that may not yet apply employeeCodes server-side.
        const selectedEmployeeCodes = new Set(empCodes.map(String));
        allData = res.filter((item) => {
          const responseEmployeeCode =
            item.employeeCode ??
            item.EmployeeCode ??
            item.empCode ??
            item.EmpCode ??
            item.emp_Code;
          return selectedEmployeeCodes.has(String(responseEmployeeCode));
        });
      }
      let filtered = allData;
      const projectIds = selectedProjects.map((p) => p.value);
      if (projectIds.length) {
        filtered = filtered.filter((i) =>
          projectIds.includes(i.projectID),
        );
      }
      if (reportType === 'detailed') {
        filtered = filtered.filter((i) => {
          if (billableFilter === 'Billable') return i.isBillable;
          if (billableFilter === 'Non-Billable') return !i.isBillable;
          return true;
        });
      }
      setReportData(filtered);
      setHasFetched(true);
      setCurrentPage(1);
    } catch (error) {
      if (error?.code === 'ERR_CANCELED' || error?.name === 'CanceledError') return;
      console.error('Failed to fetch timesheet report:', error);
      setReportData([]);
      const apiMessage = error?.response?.data;
      showToast(
        'error',
        typeof apiMessage === 'string'
          ? apiMessage
          : 'Unable to load the report. Verify that the logged-in employee belongs to the selected database.'
      );
    } finally {
      if (activeReportRequestRef.current === requestController) {
        activeReportRequestRef.current = null;
        setLoading(false);
        hideGlobalLoader();
      }
    }
  }, [
    startDate,
    endDate,
    selectedUsers,
    employeeOptions,
    selectedProjects,
    billableFilter,
    reportType,
    roleId,
    empCode,
    showToast,
  ]);

  useEffect(() => {
    return () => activeReportRequestRef.current?.abort();
  }, []);

  const isAllSelected = (selected, options) =>
    options.length > 0 && selected.length === options.length;

  const toggleSelectAll = (options, selected, setSelected) => {
    if (isAllSelected(selected, options)) {
      setSelected([]);
    } else {
      setSelected(options);
    }
  };

  const filteredUsers = employeeOptions.filter((u) =>
    u.label.toLowerCase().includes(userSearch.toLowerCase())
  );

  const filteredProjects = projectOptions.filter((p) =>
    p.label.toLowerCase().includes(projectSearch.toLowerCase())
  );

  // Auto-fetch when report type or date range changes (if dates set)
  useEffect(() => {
    if (!hasSearchedOnce) return;
    if (!startDate || !endDate) return;

    fetchReport();
  }, [startDate, endDate, fetchReport, hasSearchedOnce]);

  useEffect(() => {
    if (!hasFetched) return;
    if (!startDate || !endDate) return;

    fetchReport();
  }, [
    selectedUsers,
    selectedProjects,
    billableFilter,
  ]);



  /* ---------------- EXPORTS ---------------- */

  const handleExportTableToExcel = () => {
    if (!reportData || reportData.length === 0) {
      showToast('error', 'No data to export');
      return;
    }
    const workbook = XLSX.utils.book_new();
    /* =====================================================
       🔹 DETAILED REPORT
       ===================================================== */
    if (reportType === 'detailed') {
      const allDates = [...new Set(reportData.map(r => r.date))].sort();
      const sheetData = [];
      // HEADER
      sheetData.push([
        'Employee',
        'Project',
        'Client',
        'Task',
        'Billing Type',
        'Total',
        ...allDates.map(d => format(parseISO(d), 'dd/MM/yy')),
      ]);
      let lastGroupKey = null;
      detailedRowsWithSpan.forEach((r) => {
        const groupKey = `${r.employeeName}|${r.projectName}|${r.clientName}`;
        const isFirstRowOfGroup = groupKey !== lastGroupKey;
        lastGroupKey = groupKey;
        const row = [
          isFirstRowOfGroup ? r.employeeName : '',
          isFirstRowOfGroup ? r.projectName : '',
          isFirstRowOfGroup ? r.clientName : '',
          r.taskName,
          r.isBillable ? 'Billable' : 'Non-Billable',
          formatExcelHours(r.totalHours),
        ];
        allDates.forEach((d) => {
          row.push(formatExcelHours(r.dates[d] || 0));
        });
        sheetData.push(row);
      });
      // GRAND TOTAL ROW
      const grandTotalRow = ['Grand Total', '', '', '', ''];
      const totalHours = detailedRowsWithSpan.reduce(
        (sum, r) => sum + r.totalHours, 0
      );
      grandTotalRow.push(formatExcelHours(totalHours));
      allDates.forEach((d) => {
        const dayTotal = detailedRowsWithSpan.reduce(
          (sum, r) => sum + (r.dates[d] || 0), 0
        );
        grandTotalRow.push(formatExcelHours(dayTotal));
      });
      sheetData.push(grandTotalRow);
      const worksheet = XLSX.utils.aoa_to_sheet(sheetData);
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Timesheet Detail');
    }

    /* =====================================================
       🔹 TIMESHEET SUMMARY
       ===================================================== */
    if (reportType === 'timesheetSummary') {
      const employees = [...new Set(reportData.map(r => r.employeeName))];
      const sheetData = [];
      sheetData.push(['Billing Type', 'Task Category', ...employees, 'Total']);
      let grandTotals = Object.fromEntries(employees.map(e => [e, 0]));
      let overallTotal = 0;
      ['Billable', 'Non-Billable'].forEach((billType) => {
        const isBillable = billType === 'Billable';
        const billableData = reportData.filter(r => r.isBillable === isBillable);
        if (!billableData.length) return;
        const categories = [...new Set(billableData.map(r => r.taskCategoryName))];
        categories.forEach((category, index) => {
          const row = [index === 0 ? billType : '', category];
          let rowTotal = 0;
          employees.forEach(emp => {
            const empTotal = billableData
              .filter(
                r =>
                  r.employeeName === emp &&
                  r.taskCategoryName === category
              )
              .reduce((sum, r) => sum + (r.taskHours || 0), 0);
            row.push(formatExcelHours(empTotal));
            rowTotal += empTotal;
            grandTotals[emp] += empTotal;
            overallTotal += empTotal;
          });
          row.push(formatExcelHours(rowTotal));
          sheetData.push(row);
        });
      });
      const grandTotalRow = ['Grand Total', ''];
      employees.forEach(emp => {
        grandTotalRow.push(formatExcelHours(grandTotals[emp]));
      });
      grandTotalRow.push(formatExcelHours(overallTotal));
      sheetData.push(grandTotalRow);
      const worksheet = XLSX.utils.aoa_to_sheet(sheetData);
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Timesheet Summary');
    }
    XLSX.writeFile(
      workbook,
      `Timesheet_Report_${format(new Date(), 'yyyy-MM-dd')}.xlsx`
    );
    showToast('success', 'Excel exported successfully');
  };

  const resetFilters = () => {
    setStartDate('');
    setEndDate('');
    setSelectedUsers([]);
    setSelectedProjects([]);
    setBillableFilter('All');
    setReportData([]);
    setHasFetched(false);
    setHasSearchedOnce(false);
    setCurrentPage(1);
  };

  const allDates = React.useMemo(() => {
    if (reportType !== 'detailed') return [];
    return [...new Set(reportData.map((r) => r.date))].sort();
  }, [reportData, reportType]);

  const detailedGrandTotals = React.useMemo(() => {
    const dateTotals = {};
    let grandTotal = 0;

    detailedRowsWithSpan.forEach((row) => {
      grandTotal += row.totalHours;
      Object.entries(row.dates).forEach(([date, hours]) => {
        dateTotals[date] = (dateTotals[date] || 0) + hours;
      });
    });

    return { grandTotal, dateTotals };
  }, [detailedRowsWithSpan]);


  /* ---------------- UI ---------------- */
  return (
    <Box className="list-table-page timesheet-report-page">
      <Heading className="page-title report-page-title" mb={4}>Timesheet Report</Heading>
      <Tabs variant="unstyled">
        <Flex ml="auto" gap={2} justifyContent="flex-end" mb="1px" className="report-export-row">
          <Menu>
            <Tooltip label="Export Data" placement="top">
              <MenuButton borderColor={'lightgrey'} isDisabled={!hasFetched || reportData.length === 0 || loading}
                as={IconButton}
                icon={<Icon as={FiDownload} />}
                variant="outline"
                className="report-export-btn"
              />
            </Tooltip>
            <MenuList>
              <MenuItem icon={<Icon as={FiFileText} />} onClick={handleExportTableToExcel} isDisabled={!hasFetched || reportData.length === 0}>
                Export as XLSX
              </MenuItem>
            </MenuList>
          </Menu>
        </Flex>
        <TabPanels>
          <TabPanel p={0}>
            {/* TOP FILTER CARD */}
            <Box className="content-surface report-toolbar-card" mb={3} p={4}>
              <Flex wrap="wrap" gap={4} align="flex-end">
                <FormControl maxW="160px" isRequired className="report-control">
                  <FormLabel>Start Date</FormLabel>
                  <Input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                </FormControl>
                <FormControl maxW="160px" isRequired className="report-control">
                  <FormLabel>End Date</FormLabel>
                  <Input
                    type="date"
                    value={endDate}
                    onChange={(e) => {
                      const value = e.target.value;
                      setEndDate(value);
                    }}
                  />
                </FormControl>
                <FormControl maxW="200px" className="report-control">
                  <FormLabel>Report Type</FormLabel>
                  <Select
                    value={pendingReportType}
                    onChange={(e) => {
                      const value = e.target.value;
                      setPendingReportType(value);
                      setReportType(value);
                      setReportData([]);
                      setHasFetched(false);
                      // RESET FILTERS
                      setSelectedUsers([]);
                      setSelectedProjects([]);
                      setBillableFilter('All');
                      setCurrentPage(1);
                    }}
                  >
                    <option value="timesheetSummary">Summary</option>
                    <option value="detailed">Detail</option>
                  </Select>
                </FormControl>
                <Flex gap={2} ml="auto" className="report-action-group">
                  <Tooltip label="Fetch Report" placement="top">
                    <Button
                      leftIcon={<FiSearch />}
                      colorScheme="green"
                      className="report-search-btn"
                      onClick={() => {
                        if (!startDate || !endDate) {
                          showToast('error', 'Please select Start Date and End Date');
                          return;
                        }
                        if (endDate < startDate) {
                          showToast('error', 'End Date must be after Start Date.');
                          return;
                        }
                        fetchReport();
                      }}
                      isLoading={loading}
                    >
                      Search
                    </Button>
                  </Tooltip>
                  <Tooltip label="Reset Filters" placement="top">
                    <Button
                      leftIcon={<FiRotateCcw />}
                      variant="outline"
                      colorScheme="red"
                      className="report-reset-btn"
                      onClick={resetFilters}
                    >
                      Reset
                    </Button>
                  </Tooltip>
                </Flex>
              </Flex>
            </Box>

            {/* DETAIL FILTERS */}
            {/* FILTERS – ALWAYS VISIBLE */}
            <Box className="report-filter-strip" bg="white" mt={6} borderRadius="lg" mb={6}>
              <Flex align="center" gap={4} wrap="wrap">
                <Text fontWeight="bold" fontSize={"16px"} mb={2} whiteSpace="nowrap">
                  Filters
                </Text>
                <Flex gap={4} wrap="wrap">
                  {/* USERS – ALWAYS SHOWN */}
                  <Menu closeOnSelect={false} placement="bottom-start">
                    <MenuButton
                      as={Button}
                      variant="outline"
                      rightIcon={<FiFilter />}
                      minW="200px"
                      className="report-filter-chip"
                    >
                      {selectedUsers.length === 0
                        ? 'All Users'
                        : `${selectedUsers.length} user(s) selected`}
                    </MenuButton>
                    <Portal>
                      <MenuList p={0} minW="280px" height="fit-content" maxH="300px">
                        <Box p={3} borderBottom="1px solid" borderColor="gray.200">
                          <Input
                            size="sm"
                            placeholder="Search users..."
                            value={userSearch}
                            onChange={(e) => setUserSearch(e.target.value)}
                          />
                        </Box>
                        <Box maxH="220px" overflowY="auto" px={3} py={2}>
                          <Stack spacing={2}>
                            <Checkbox
                              isChecked={isAllSelected(selectedUsers, employeeOptions)}
                              onChange={() =>
                                toggleSelectAll(
                                  employeeOptions,
                                  selectedUsers,
                                  setSelectedUsers
                                )
                              }
                            >
                              Select All
                            </Checkbox>
                            {filteredUsers.map((u) => (
                              <Checkbox
                                key={u.value}
                                isChecked={selectedUsers.some(
                                  (s) => s.value === u.value
                                )}
                                onChange={(e) =>
                                  e.target.checked
                                    ? setSelectedUsers([...selectedUsers, u])
                                    : setSelectedUsers(
                                      selectedUsers.filter(
                                        (s) => s.value !== u.value
                                      )
                                    )
                                }
                              >
                                {u.label}
                              </Checkbox>
                            ))}
                            {filteredUsers.length === 0 && (
                              <Text fontSize="sm" color="gray.500">
                                No users found
                              </Text>
                            )}
                          </Stack>
                        </Box>
                      </MenuList>
                    </Portal>
                  </Menu>

                  {/* PROJECTS – DETAIL ONLY */}
                  {/* {pendingReportType === 'detailed' && ( */}
                  <Menu closeOnSelect={false}>
                    <MenuButton
                      as={Button}
                      variant="outline"
                      rightIcon={<FiFilter />}
                      minW="200px"
                      className="report-filter-chip"
                    >
                      {selectedProjects.length === 0
                        ? 'All Projects'
                        : `${selectedProjects.length} project(s) selected`}
                    </MenuButton>
                    <MenuList p={0} minW="280px" maxH="260px" overflowY="auto">
                      {/* Search */}
                      <Box p={3} borderBottom="1px solid" borderColor="gray.200">
                        <Input
                          size="sm"
                          placeholder="Search projects..."
                          value={projectSearch}
                          onChange={(e) =>
                            setProjectSearch(e.target.value)
                          }
                        />
                      </Box>
                      <Box maxH="220px" overflowY="auto" px={3} py={2}>
                        <Stack spacing={2}>
                          <Checkbox
                            isChecked={isAllSelected(
                              projectOptions,
                              selectedProjects
                            )}
                            onChange={() =>
                              toggleSelectAll(
                                projectOptions,
                                selectedProjects,
                                setSelectedProjects
                              )
                            }
                          >
                            Select All
                          </Checkbox>
                          {filteredProjects.map((p) => (
                            <Checkbox
                              key={p.value}
                              isChecked={selectedProjects.some(
                                (s) => s.value === p.value
                              )}
                              onChange={(e) =>
                                e.target.checked
                                  ? setSelectedProjects([
                                    ...selectedProjects,
                                    p,
                                  ])
                                  : setSelectedProjects(
                                    selectedProjects.filter(
                                      (s) => s.value !== p.value
                                    )
                                  )
                              }
                            >
                              {p.label}
                            </Checkbox>
                          ))}
                          {filteredProjects.length === 0 && (
                            <Text fontSize="sm" color="gray.500">
                              No projects found
                            </Text>
                          )}
                        </Stack>
                      </Box>
                    </MenuList>
                  </Menu>
                  {/* )} */}

                  {/* BILLABLE – DETAIL ONLY */}
                  {/* {pendingReportType === 'detailed' && ( */}
                  <Menu>
                    <MenuButton
                      as={Button}
                      variant="outline"
                      rightIcon={<FiFilter />}
                      minW="200px" isDisabled={isSummary}
                      className="report-filter-chip"
                    >
                      Billable: {billableFilter}
                    </MenuButton>
                    {!isSummary && (
                      <MenuList>
                        <MenuItem onClick={() => setBillableFilter('All')}>
                          All
                        </MenuItem>
                        <MenuItem onClick={() => setBillableFilter('Billable')}>
                          Billable
                        </MenuItem>
                        <MenuItem onClick={() => setBillableFilter('Non-Billable')}>
                          Non-Billable
                        </MenuItem>
                      </MenuList>
                    )}
                  </Menu>
                  {/* )} */}
                </Flex>
              </Flex>
            </Box>

            <Box
              className="report-results-section"
              display="flex"
              flexDirection="column"
            >
              {/* TABLE */}
              <Box
                className="content-surface report-table-wrap"
                position="relative"
                h={shouldUseFixedTableHeight ? tableViewportHeight : 'auto'}
                maxH={tableViewportHeight}
                overflowX="auto"
                overflowY="auto"
                width="100%"
                minW="100%"
                sx={{
                  /* Firefox */
                  scrollbarWidth: "auto",
                  scrollbarColor: "#dae2edff #EDF2F7",
                  /* Chrome, Edge, Safari */
                  "&::-webkit-scrollbar": {
                    width: "5px",        // vertical scrollbar thickness
                    height: "5px",       // horizontal scrollbar thickness
                  },
                  "&::-webkit-scrollbar-track": {
                    background: "#EDF2F7",
                    borderRadius: "10px",
                  },
                  "&::-webkit-scrollbar-thumb": {
                    background: "#A0AEC0",
                    borderRadius: "10px",
                  },
                  "&::-webkit-scrollbar-thumb:hover": {
                    background: "#ebeef1ff",
                    scrollbarColor: "#dae2edff #EDF2F7",
                  },
                }}
              >
                {loading && (
                  <Box
                    position="absolute"
                    inset="0"
                    bg="rgba(31, 58, 95, 0.34)"
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                    zIndex={5}
                    px={4}
                  >
                    <TimeSnapLoader text="Loading report..." />
                  </Box>
                )}
                {reportType === 'detailed' && (
                <Table size="sm" border="1px solid"
                  borderColor="gray.200">
                  <Thead position="sticky"
                    top={-1}
                    zIndex={1}
                    bg="var(--chakra-colors-green-100)"
                    height="40px">
                    <Tr>
                      <Th textTransform="camelCase">Employee</Th>
                      <Th textTransform="camelCase">Project</Th>
                      <Th textTransform="camelCase">Client</Th>
                      <Th textTransform="camelCase">Category</Th>
                      <Th textTransform="camelCase">Sub Category</Th>
                      <Th textTransform="camelCase">Task</Th>
                      <Th textTransform="camelCase">Billing Type</Th>
                      <Th textTransform="camelCase">Total</Th>
                      {startDate && endDate ? (
                        allDates.map((d) => (
                            <Th key={d}>
                              {format(parseISO(d), 'dd/MM/yy')}
                            </Th>
                          ))
                      ) : (
                        <Th textTransform="camelCase">No Dates Selected</Th>
                      )}
                    </Tr>
                  </Thead>
                  <Tbody overflowY="scroll">
                    {!startDate || !endDate ? (
                      <Tr>
                        <Td colSpan={9} textAlign="center" verticalAlign="middle" color="gray.500" py={0}>
                          <Box
                            minH={emptyStateContentHeight}
                            display="flex"
                            alignItems="center"
                            justifyContent="center"
                            px={4}
                          >
                            Please select both start date and end date to view the report
                          </Box>
                        </Td>
                      </Tr>
                    ) : !hasFetched ? (
                      <Tr>
                        <Td colSpan={8 + allDates.length} textAlign="center" verticalAlign="middle" color="gray.500" py={0}>
                          <Box
                            minH={emptyStateContentHeight}
                            display="flex"
                            alignItems="center"
                            justifyContent="center"
                            px={4}
                          >
                            Please click "Search" to load the report
                          </Box>
                        </Td>
                      </Tr>
                    ) : filteredData.length === 0 ? (
                      <Tr>
                        <Td colSpan={8 + allDates.length} textAlign="center" verticalAlign="middle" color="gray.500" py={0}>
                          <Box
                            minH={emptyStateContentHeight}
                            display="flex"
                            alignItems="center"
                            justifyContent="center"
                            px={4}
                          >
                            No data available in this table
                          </Box>
                        </Td>
                      </Tr>
                    ) : (
                      <>
                        {paginatedData.map((r, idx) => {
                          const bg = idx % 2 === 0 ? 'gray.100' : 'white';

                          return (
                            <Tr key={idx} bg={bg}>
                              {/* EMPLOYEE */}
                              <Td
                                bg={bg}
                                fontWeight="bold"
                                opacity={r.isFirstRow ? 1 : 0}
                              >
                                {r.employeeName}
                              </Td>
                              {/* PROJECT */}
                              <Td
                                bg={bg} fontWeight="bold"
                                opacity={r.isFirstRow ? 1 : 0}
                              >
                                {r.projectName}
                              </Td>
                              {/* CLIENT */}
                              <Td
                                bg={bg}
                                opacity={r.isFirstRow ? 1 : 0}
                              >
                                {r.clientName}
                              </Td>
                              {/* CATEGORY */}
                              <Td bg={bg}>{r.categoryName}</Td>
                              {/* SUB CATEGORY */}
                              <Td bg={bg}>{r.subCategoryName}</Td>
                              {/* TASK */}
                              <Td bg={bg}>{r.taskName}</Td>
                              {/* BILLING */}
                              <Td bg={bg}>
                                <Badge colorScheme={r.isBillable ? 'green' : 'red'} textTransform="camelCase">
                                  {r.isBillable ? 'Billable' : 'Non-Billable'}
                                </Badge>
                              </Td>
                              {/* TOTAL */}
                              <Td bg={bg}>{formatDecimalHours(r.totalHours)}</Td>
                              {/* DATE COLUMNS */}
                              {allDates.map((d) => (
                                <Td key={d} bg={bg}>
                                  {formatDecimalHours(r.dates[d] || 0)}
                                </Td>
                              ))}
                            </Tr>
                          );
                        })}
                        {/* GRAND TOTAL */}
                        <Tr >
                          <Td colSpan={7} fontWeight="bold">
                            Grand Total
                          </Td>
                          <Td fontWeight="bold">
                            {formatDecimalHours(detailedGrandTotals.grandTotal)}
                          </Td>
                          {allDates.map((d) => (
                            <Td key={d} fontWeight="bold">
                              {formatDecimalHours(detailedGrandTotals.dateTotals[d] || 0)}
                            </Td>
                          ))}
                        </Tr>
                      </>
                    )}
                  </Tbody>
                </Table>
              )}

                {reportType === 'timesheetSummary' && (
                <Table size="sm" border="1px solid"
                  borderColor="gray.200">
                  <Thead position="sticky"
                    top={0}
                    zIndex={1}
                    bg="var(--chakra-colors-green-100)"
                    height="40px">
                    <Tr>
                      <Th textTransform="camelCase">Billing Type</Th>
                      <Th textTransform="camelCase">Category</Th>
                      <Th textTransform="camelCase">Sub Category</Th>
                      <Th textTransform="camelCase">Task</Th>
                      {uniqueEmployeeNames.map(emp => (
                        <Th textTransform="camelCase" key={emp}>{emp}</Th>
                      ))}
                      <Th textTransform="camelCase">Total</Th>
                    </Tr>
                  </Thead>
                  <Tbody overflowY="scroll">
                    {!startDate || !endDate ? (
                      <Tr>
                        <Td colSpan={20} textAlign="center" verticalAlign="middle" color="gray.500" py={0}>
                          <Box
                            minH={emptyStateContentHeight}
                            display="flex"
                            alignItems="center"
                            justifyContent="center"
                            px={4}
                          >
                            Please select both start date and end date
                          </Box>
                        </Td>
                      </Tr>
                    ) : !hasFetched ? (
                      <Tr>
                        <Td colSpan={20} textAlign="center" verticalAlign="middle" color="gray.500" py={0}>
                          <Box
                            minH={emptyStateContentHeight}
                            display="flex"
                            alignItems="center"
                            justifyContent="center"
                            px={4}
                          >
                            Please click "Search" to load the report
                          </Box>
                        </Td>
                      </Tr>
                    ) : reportData.length === 0 ? (
                      <Tr>
                        <Td colSpan={20} textAlign="center" verticalAlign="middle" color="gray.500" py={0}>
                          <Box
                            minH={emptyStateContentHeight}
                            display="flex"
                            alignItems="center"
                            justifyContent="center"
                            px={4}
                          >
                            No data available
                          </Box>
                        </Td>
                      </Tr>
                    ) : (
                      <>
                        {paginatedData.map((r, idx) => {
                          const bg = idx % 2 === 0 ? 'gray.100' : 'white';
                          return (
                            <Tr bg={bg} key={`${r.billType}-${r.category}-${r.task}`}>
                              <Td bg={bg}>
                                {r.isFirstInBillType && (
                                  <Badge
                                    colorScheme={r.billType === 'Billable' ? 'green' : 'red'}
                                    textTransform="camelCase"
                                  >
                                    {r.billType}
                                  </Badge>
                                )}
                              </Td>
                              <Td bg={bg} fontWeight={"bold"}>{r.isFirstInCategory ? r.category : ''}</Td>
                              <Td>{r.subCategory}</Td>
                              <Td bg={bg}>{r.task}</Td>
                              {uniqueEmployeeNames.map((emp) => {
                                const total = r.employeeTotals[emp] || 0;
                                return (
                                  <Td bg={bg} key={emp}>
                                    {total > 0 ? formatDecimalHours(total) : '0h 00m'}
                                  </Td>
                                );
                              })}
                              <Td bg={bg} fontWeight="medium">
                                {formatDecimalHours(r.rowTotal)}
                              </Td>
                            </Tr>
                          );
                        })}
                        {/* GRAND TOTAL */}
                        <Tr>
                          <Td colSpan={4} fontWeight="bold">Grand Total</Td>
                          {uniqueEmployeeNames.map(emp => {
                            const total = summaryEmployeeGrandTotals[emp] || 0;
                            return (
                              <Td key={emp} fontWeight="bold">
                                {formatDecimalHours(total)}
                              </Td>
                            );
                          })}
                          <Td fontWeight="bold">
                            {formatDecimalHours(summaryGrandTotal)}
                          </Td>
                        </Tr>
                      </>
                    )}
                  </Tbody>
                </Table>
                )}
              </Box>
              <Box className="content-surface report-pagination-wrap" mt={3}>
                <Flex
                  justify="flex-end"
                  align="center"
                  px={2}
                  py={3}
                  gap={6}
                  borderTop="1px solid"
                  borderColor="gray.100"
                >
                  <Flex align="center" gap={2}>
                    <Text fontSize="sm">Page size :</Text>
                    <Select
                      size="sm"
                      width="80px"
                      value={pageSize}
                      onChange={(e) => {
                        setPageSize(Number(e.target.value));
                        setCurrentPage(1);
                      }}
                    >
                      {[10, 25, 50, 100].map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </Select>
                  </Flex>
                  <Text fontSize="sm">
                    Page {currentPage} of {totalPages}
                  </Text>
                  <Flex gap={2}>
                    <Tooltip label="Previous page" placement="top">
                      <span>
                        <Button
                          size="sm"
                          leftIcon={<FiChevronLeft />}
                          isDisabled={currentPage === 1}
                          onClick={() => setCurrentPage((p) => p - 1)}
                          className="report-page-nav"
                        >
                        </Button>
                      </span>
                    </Tooltip>
                    <Tooltip label="Next page" placement="top">
                      <span>
                        <Button
                          size="sm"
                          rightIcon={<FiChevronRight />}
                          isDisabled={currentPage === totalPages}
                          onClick={() => setCurrentPage((p) => p + 1)}
                          className="report-page-nav"
                        >
                        </Button>
                      </span>
                    </Tooltip>
                  </Flex>
                </Flex>
              </Box>
            </Box>
          </TabPanel>
        </TabPanels>
      </Tabs>
    </Box>
  );
};

export default ReportsTabsScreen;
