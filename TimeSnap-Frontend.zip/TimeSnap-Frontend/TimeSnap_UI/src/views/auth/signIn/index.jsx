import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { NavLink } from 'react-router-dom';
import { loginUser, changePassword } from 'utils/api';
import { useLocation } from 'react-router-dom';
import { useToast } from '@chakra-ui/react';
import { useCustomToast } from 'utils/toastUtils';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { fetchTimesheetApprovals } from 'utils/api';
import { useLoader } from "../../../contexts/LoaderContext";
import { useAuth } from 'contexts/AuthContext';
import {
  Box,
  Button,
  Checkbox,
  Flex,
  FormControl,
  FormLabel,
  Heading,
  Icon,
  IconButton,
  Input,
  InputGroup,
  InputRightElement,
  Text,
  useColorModeValue,
  FormErrorMessage,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  useDisclosure,
} from '@chakra-ui/react';

import DefaultAuth from 'layouts/auth/Default';
import illustration from 'assets/img/auth/auth.png';
import { MdOutlineRemoveRedEye } from 'react-icons/md';
import { RiEyeCloseLine } from 'react-icons/ri';
import { getTokenExpiry } from 'utils/authUtils';

function SignIn() {
  const textColor = useColorModeValue('navy.700', 'white');
  const textColorSecondary = 'gray.400';
  const textColorBrand = useColorModeValue('brand.500', 'white');
  const brandStars = useColorModeValue('brand.500', 'brand.400');
  const [show, setShow] = React.useState(false);
  const handleClick = () => setShow(!show);
  const navigate = useNavigate();
  const [email_Id, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const location = useLocation();
  const toast = useToast();
  const showToast = useCustomToast();
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [forgotPasswordEmail, setForgotPasswordEmail] = useState('');
  const [forgotPasswordEmailError, setForgotPasswordEmailError] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newPasswordError, setNewPasswordError] = useState('');
  const [showForgotPasswordModal, setShowForgotPasswordModal] = useState(false);
  const { showGlobalLoader, hideGlobalLoader } = useLoader();


  // Modal visibility state
  const { isOpen, onOpen, onClose } = useDisclosure();

  const { setAuth } = useAuth();

  // useEffect(() => {
  //   console.log('AuthContext state:', auth);
  // }, [auth]);

  // Common free email providers to block
  const blockedDomains = [
    'gmail.com',
    'yahoo.com',
    'hotmail.com',
    'outlook.com',
    'aol.com',
    'icloud.com',
    'mail.com',
    'protonmail.com',
    'zoho.com',
    'yandex.com',
    'gmx.com',
    'live.com',
    'inbox.com',
    'me.com',
    'msn.com',
  ];

  // Reset the forgot password form when modal is closed
  const handleModalClose = () => {
    setForgotPasswordEmail('');
    setNewPassword('');
    setForgotPasswordEmailError('');
    setNewPasswordError('');
    onClose();
  };

  const validatePassword = (pass) => {
    if (!pass) {
      setPasswordError('Password is required');
      return false;
    }
    setPasswordError('');
    return true;
  };

  const validateForgotPasswordEmail = (email) => {
    // Basic email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!email) {
      setForgotPasswordEmailError('Email is required');
      return false;
    }

    if (!emailRegex.test(email)) {
      setForgotPasswordEmailError('Please enter a valid email address');
      return false;
    }

    // Extract the domain part of the email
    const emailParts = email.split('@');
    if (emailParts.length !== 2) {
      setForgotPasswordEmailError('Please enter a valid email address');
      return false;
    }

    const domain = emailParts[1].toLowerCase();

    // Check if the email domain is in the blocked list (free email providers)
    if (blockedDomains.includes(domain)) {
      setForgotPasswordEmailError('Please use your company email address');
      return false;
    }

    setForgotPasswordEmailError('');
    return true;
  };

  const validateNewPassword = (pass) => {
    if (!pass) {
      setNewPasswordError('Password is required');
      return false;
    }

    if (pass.length < 6) {
      setNewPasswordError('Password must be at least 6 characters');
      return false;
    }

    setNewPasswordError('');
    return true;
  };

  const handleEmailChange = (e) => {
    const value = e.target.value;
    setUsername(value);
    if (emailError) setEmailError('');
  };

  const validateEmail = (email) => {
    // Basic email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!email) {
      setEmailError('Email is required');
      return false;
    }

    if (!emailRegex.test(email)) {
      setEmailError('Please enter a valid email address');
      return false;
    }

    // Extract the domain part of the email
    const emailParts = email.split('@');
    if (emailParts.length !== 2) {
      setEmailError('Please enter a valid email address');
      return false;
    }

    const domain = emailParts[1].toLowerCase();

    // Check if the email domain is in the blocked list (free email providers)
    if (blockedDomains.includes(domain)) {
      setEmailError('Please use your company email address');
      return false;
    }

    setEmailError('');
    return true;
  };

  const handlePasswordChange = (e) => {
    const value = e.target.value;
    setPassword(value);
    if (passwordError) setPasswordError('');
  };

  const handleForgotPasswordEmailChange = (e) => {
    const value = e.target.value;
    setForgotPasswordEmail(value);
    validateForgotPasswordEmail(value);
  };
  useEffect(() => {
    // Disable scroll on the body
    document.body.style.overflow = 'hidden';

    // Clean up: Restore the scroll when the component unmounts
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, []);
  const handleNewPasswordChange = (e) => {
    const value = e.target.value;
    setNewPassword(value);
    validateNewPassword(value);
  };

  const handleLogin = async () => {
    setError('');
    const isEmailValid = validateEmail(email_Id);
    const isPasswordValid = validatePassword(password);
    if (!isEmailValid || !isPasswordValid) return;
    showGlobalLoader();
    try {
      const loginResponse = await loginUser(email_Id, password);

      if (loginResponse.token) {
        const sessionID = Math.random().toString(36).substring(2);
        const newEmpCode = loginResponse.employeeCode;
        const tokenExpiry = getTokenExpiry(loginResponse.token);

        const existingUser = JSON.parse(localStorage.getItem('activeUser'));
        if (existingUser && existingUser.expiry > Date.now()) {
          const previousEmpCode = existingUser.userId;

          if (previousEmpCode !== newEmpCode) {
            localStorage.clear();
            sessionStorage.clear();
            localStorage.setItem('logout', Date.now());
          }
        }

        // Save the new session
        localStorage.setItem(
          'activeUser',
          JSON.stringify({
            userId: newEmpCode,
            loginTime: Date.now(),
            expiry: tokenExpiry, // ✅ JWT expiry
            sessionID,
          }),
        );

        sessionStorage.setItem('sessionID', sessionID);
        sessionStorage.setItem('sessionActive', 'true');
        sessionStorage.setItem('emp_code', newEmpCode);
        localStorage.setItem('sessionID', sessionID);
        localStorage.setItem('token', loginResponse.token);
        localStorage.setItem('emp_code', newEmpCode);
        const roleIdValue = loginResponse.roleId || loginResponse.role_Id || loginResponse.role;
        localStorage.setItem('roleId', roleIdValue);
        localStorage.setItem('IS_ADMIN', loginResponse.isAdmin ? 'true' : 'false');
        localStorage.setItem(
          'accessDetails',
          JSON.stringify(loginResponse.accessDetails),
        );
        // ✅ UPDATE REACT AUTH STATE (THIS FIXES THE ISSUE)
        setAuth({
          isAuthenticated: true,
          roleId: roleIdValue,
          isAdmin: loginResponse.isAdmin,
          accessDetails: loginResponse.accessDetails,
          user: {
            empCode: loginResponse.employeeCode,
          },
        });

        navigate('/admin', { replace: true });
      } else {
        throw new Error('Invalid credentials');
      }
    } catch (error) {
      let errorMsg = 'Login error. Please try again.';
      if (error.response) {
        if (error.response.status === 409) {
        } else if (error.response.data?.message) {
          errorMsg = error.response.data.message;
        }
      } else if (error.message) {
        errorMsg = error.message;
      }

      showToast('error', errorMsg);
    }
    finally {
      hideGlobalLoader();
    }
  };

  const handleForgotPasswordSubmit = async () => {
    const isEmailValid = validateForgotPasswordEmail(forgotPasswordEmail);
    const isPasswordValid = validateNewPassword(newPassword);

    if (!isEmailValid || !isPasswordValid) return;

    try {
      const response = await changePassword(forgotPasswordEmail, newPassword);

      console.log('API Response:', response);

      if (response?.success) {
        showToast('success', `Password updated successfully`);

        handleModalClose();
      } else if (response?.message === 'User not found') {
        showToast(
          'error',
          `User Not Found ,No account exists with this email address.`,
        );
      } else {
        showToast('error', `Failed to update ,Please try again later.`);
      }
    } catch (error) {
      console.error('Forgot password error:', error);

      const errorMessage =
        error?.response?.data?.message ||
        error?.message ||
        'Error while changing password. Please try again.';

      showToast('error', errorMessage);
    }
  };

  return (
    <DefaultAuth illustrationBackground={illustration} image={illustration}>
      <Flex
        maxW={{ base: '100%', md: 'max-content' }}
        w="100%"
        mx={{ base: 'auto', lg: '0px' }}
        me="auto"
        h="100%"
        alignItems="start"
        justifyContent="center"
        mb={{ base: '30px', md: '60px' }}
        px={{ base: '25px', md: '0px' }}
        mt={{ base: '40px', md: '14vh' }}
        flexDirection="column"
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
          <img src="/CI_Icon.ico" alt="User Icon" width="62" height="32" />
        </div>

        <Box me="auto">
          <Heading color={textColor} fontSize="36px" mb="10px">
            Sign In
          </Heading>
          <Text
            mb="36px"
            ms="4px"
            color={textColorSecondary}
            fontWeight="400"
            fontSize="md"
          >
            Enter your email and password to sign in!
          </Text>
        </Box>
        <Flex
          zIndex="2"
          direction="column"
          w={{ base: '100%', md: '420px' }}
          maxW="100%"
          background="transparent"
          borderRadius="15px"
          mx={{ base: 'auto', lg: 'unset' }}
          me="auto"
          mb={{ base: '20px', md: 'auto' }}
        >
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleLogin();
            }}
            autoComplete="off"
            noValidate
          >
            <FormControl isInvalid={!!emailError}>
              <FormLabel
                display="flex"
                ms="4px"
                fontSize="sm"
                fontWeight="500"
                color={textColor}
                mb="8px"
              >
                Email<Text color={brandStars}>*</Text>
              </FormLabel>
              <Input
                isRequired={true}
                variant="auth"
                fontSize="sm"
                ms={{ base: '0px', md: '0px' }}
                type="email"
                value={email_Id}
                onChange={handleEmailChange}
                placeholder="your-email@company.com"
                mb="24px"
                fontWeight="500"
                size="lg"
              />
              <FormErrorMessage position="absolute" mt="-20px" mb="12px">
                {emailError}
              </FormErrorMessage>
            </FormControl>

            <FormControl isInvalid={!!passwordError}>
              <FormLabel
                ms="4px"
                fontSize="sm"
                fontWeight="500"
                color={textColor}
                display="flex"
              >
                Password<Text color={brandStars}>*</Text>
              </FormLabel>
              <InputGroup size="md">
                <Input
                  isRequired={true}
                  fontSize="sm"
                  placeholder="Password"
                  value={password}
                  onChange={handlePasswordChange}
                  mb="24px"
                  size="lg"
                  type={show ? 'text' : 'password'}
                  variant="auth"
                />
                <InputRightElement
                  display="flex"
                  alignItems="center"
                  mt="4px"
                  pointerEvents="auto"
                >
                  <IconButton
                    type="button"
                    aria-label={show ? 'Hide password' : 'Show password'}
                    icon={
                      <Icon
                        as={show ? RiEyeCloseLine : MdOutlineRemoveRedEye}
                        color={textColorSecondary}
                      />
                    }
                    variant="ghost"
                    size="sm"
                    minW="auto"
                    h="auto"
                    p="4px"
                    _hover={{ bg: 'transparent' }}
                    _active={{ bg: 'transparent' }}
                    _focusVisible={{ boxShadow: 'none' }}
                    onClick={handleClick}
                  />
                </InputRightElement>
              </InputGroup>
              <FormErrorMessage position="absolute" mt="-20px" mb="12px">
                {passwordError}
              </FormErrorMessage>
            </FormControl>

            <Button
              variant="brand"
              fontSize="16px"
              fontWeight="500"
              w="100%"
              h="50"
              mb="24px"
              mt="24px"
              type="submit"
            >
              Sign In
            </Button>
          </form>
        </Flex>
        <Modal isOpen={isOpen} onClose={handleModalClose}>
          <ModalOverlay />
          <ModalContent>
            <ModalHeader>Forgot Password</ModalHeader>
            <ModalCloseButton />
            <ModalBody>
              <FormControl isInvalid={forgotPasswordEmailError}>
                <FormLabel>
                  Email
                  <Text color={brandStars} as="span">
                    *
                  </Text>
                </FormLabel>
                <Input
                  type="email"
                  value={forgotPasswordEmail}
                  onChange={handleForgotPasswordEmailChange}
                  placeholder="Enter your company email address"
                />
                <FormErrorMessage>{forgotPasswordEmailError}</FormErrorMessage>
              </FormControl>
              <FormControl mt={4} isInvalid={newPasswordError}>
                <FormLabel>
                  New Password
                  <Text color={brandStars} as="span">
                    *
                  </Text>
                </FormLabel>
                <InputGroup>
                  <Input
                    type={show ? 'text' : 'password'}
                    value={newPassword}
                    onChange={handleNewPasswordChange}
                    placeholder="Minimum 6 characters"
                  />
                  <InputRightElement pointerEvents="auto">
                    <IconButton
                      type="button"
                      aria-label={show ? 'Hide password' : 'Show password'}
                      icon={
                        <Icon
                          color={textColorSecondary}
                          as={show ? RiEyeCloseLine : MdOutlineRemoveRedEye}
                        />
                      }
                      variant="ghost"
                      size="sm"
                      minW="auto"
                      h="auto"
                      p="4px"
                      _hover={{ bg: 'transparent' }}
                      _active={{ bg: 'transparent' }}
                      _focusVisible={{ boxShadow: 'none' }}
                      onClick={handleClick}
                    />
                  </InputRightElement>
                </InputGroup>
                <FormErrorMessage>{newPasswordError}</FormErrorMessage>
              </FormControl>
            </ModalBody>
            <ModalFooter>
              <Button
                colorScheme="blue"
                mr={3}
                onClick={handleForgotPasswordSubmit}
              >
                Submit
              </Button>
              <Button variant="ghost" onClick={handleModalClose}>
                Cancel
              </Button>
            </ModalFooter>
          </ModalContent>
        </Modal>
      </Flex>
    </DefaultAuth>
  );
}

export default SignIn;
