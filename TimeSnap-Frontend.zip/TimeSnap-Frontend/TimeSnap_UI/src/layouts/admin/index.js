// React
import React, { useMemo, useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

// Chakra
import { Box } from '@chakra-ui/react';

// Contexts
import { SidebarContext } from 'contexts/SidebarContext';
import { useAuth } from 'contexts/AuthContext';

// Layout components
import MainLayout from 'components/sidebar/Sidebar';
import GlobalLoader from 'components/loaders/GlobalLoader';

// Routes builder
import { getRoutes } from 'routes';

export default function AdminLayout() {
  const { auth } = useAuth();

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [toggleSidebar, setToggleSidebar] = useState(false);

  const routes = useMemo(() => {
    return getRoutes(auth.accessDetails || [], auth.isAdmin);
  }, [auth.accessDetails, auth.isAdmin]);

  return (
    <SidebarContext.Provider
      value={{ toggleSidebar, setToggleSidebar, isMenuOpen, setIsMenuOpen }}
    >
      <MainLayout routes={routes}>
        <GlobalLoader />

        <Box w="100%" minW={0}>
          <Routes>
            {routes.map((route, index) => (
              <Route key={index} path={route.path} element={route.component} />
            ))}

            <Route index element={<Navigate to="Timesheet" replace />} />
          </Routes>
        </Box>
      </MainLayout>
    </SidebarContext.Provider>
  );
}
