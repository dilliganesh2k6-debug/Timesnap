// React
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

// Chakra
import { Box, useColorModeValue } from '@chakra-ui/react';

// Context
import { SidebarContext } from 'contexts/SidebarContext';

// Auth pages
import SignIn from 'views/auth/signIn/index';

export default function AuthLayout() {
  const authBg = useColorModeValue('white', 'navy.900');

  // This layout NEVER depends on role
  // It is always static
  return (
    <SidebarContext.Provider
      value={{
        toggleSidebar: false,
        setToggleSidebar: () => {},
      }}
    >
      <Box
        bg={authBg}
        minHeight="100vh"
        width="100%"
        position="relative"
      >
        <Routes>
          {/* Login */}
          <Route path="signin" element={<SignIn />} />

          {/* Default redirect */}
          <Route
            path="/"
            element={<Navigate to="/auth/signin" replace />}
          />

          {/* Catch-all */}
          <Route
            path="*"
            element={<Navigate to="/auth/signin" replace />}
          />
        </Routes>
      </Box>
    </SidebarContext.Provider>
  );
}
