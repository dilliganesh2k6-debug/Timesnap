﻿using LoginAppApi.Data;
using LoginAppApi.Models;
using LoginAppApi.Models.Dto;
using Microsoft.EntityFrameworkCore;

namespace LoginAppApi.Services
{
    public class AuditLogService : IAuditLogService
    {
        private readonly LoginAppDbContext _context;

        public AuditLogService(LoginAppDbContext context)
        {
            _context = context;
        }

        public async Task LogAsync(AuditLog log)
        {
            log.ActionDate = DateTime.Now;

            _context.AuditLogs.Add(log);
            await _context.SaveChangesAsync();
        }

        // WITHOUT parameters
        //public async Task<List<AuditLog>> GetAllAuditLogsAsync()
        //{
        //    return await _context.AuditLogs
        //        .AsNoTracking()
        //        .OrderByDescending(x => x.ActionDate)
        //        .ToListAsync();
        //}

        public async Task<List<AuditLogDto>> GetAllAuditLogsAsync()
        {
            return await _context.AuditLogs
                .AsNoTracking()
                .OrderByDescending(x => x.ActionDate)
                .Select(x => new AuditLogDto
                {
                    AuditId = x.AuditId,
                    ActorEmpCode = x.ActorEmpCode,
                    TargetEmpCode = x.TargetEmpCode,
                    ModuleName = x.ModuleName,
                    ActionType = x.ActionType,
                    EntityName = x.EntityName,
                    OldValue = x.OldValue,
                    NewValue = x.NewValue,
                    ActionDate = x.ActionDate.ToString("yyyy-MM-dd HH:mm:ss"),
                    Remarks = x.Remarks
                })
                .ToListAsync();
        }


        // WITH parameters
        public async Task<(List<AuditLogDto> Logs, int TotalCount)> GetAuditLogsAsync(
            int page,
            int pageSize,
            string? moduleName,
            string? actionType,
            int? actorEmpCode,
            int? targetEmpCode,
            DateTime? fromDate,
            DateTime? toDate)
        {
            var query = _context.AuditLogs
                .AsNoTracking()
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(moduleName))
                query = query.Where(x => x.ModuleName == moduleName);

            if (!string.IsNullOrWhiteSpace(actionType))
                query = query.Where(x => x.ActionType == actionType);

            if (actorEmpCode.HasValue)
                query = query.Where(x => x.ActorEmpCode == actorEmpCode);

            if (targetEmpCode.HasValue)
                query = query.Where(x => x.TargetEmpCode == targetEmpCode);

            if (fromDate.HasValue)
                query = query.Where(x => x.ActionDate >= fromDate.Value);

            if (toDate.HasValue)
                query = query.Where(x => x.ActionDate <= toDate.Value);

            int totalCount = await query.CountAsync();

            var logs = await query
                .OrderByDescending(x => x.ActionDate)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(x => new AuditLogDto
                {
                    AuditId = x.AuditId,
                    ActorEmpCode = x.ActorEmpCode,
                    TargetEmpCode = x.TargetEmpCode,
                    ModuleName = x.ModuleName,
                    ActionType = x.ActionType,
                    EntityName = x.EntityName,
                    OldValue = x.OldValue,
                    NewValue = x.NewValue,
                    //ActionDate = x.ActionDate,
                    ActionDate = x.ActionDate.ToString("yyyy-MM-dd HH:mm:ss"),
                    Remarks = x.Remarks
                })
                .ToListAsync();

            return (logs, totalCount);
        }

    }
}
