﻿using LoginAppApi.Models.Dto;

namespace LoginAppApi.Services
{
    public interface IEmailService
    {
        Task SendEmailAsync(EmailRequestDto request);
    }

}
