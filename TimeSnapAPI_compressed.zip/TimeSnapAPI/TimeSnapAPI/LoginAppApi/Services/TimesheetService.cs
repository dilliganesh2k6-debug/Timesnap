﻿using System.Data;
using System.Data.SqlClient;
using Dapper;
using TimeTrackerApplication.Models.DTOs;
using Microsoft.Extensions.Configuration;

namespace TimeTrackerApplication.Services
{
    public class TimesheetService : ITimesheetService
    {
        private readonly string _connectionString;

        public TimesheetService(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<int> SaveTimesheetAsync(TimesheetSubmissionRequest request)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        //  Insert or Update Timesheet Header
                        var parameters = new DynamicParameters();
                        parameters.Add("@Emp_code", request.Header.EmpCode);
                        parameters.Add("@Start_Date", request.Header.StartDate);
                        parameters.Add("@End_Date", request.Header.EndDate);
                        parameters.Add("@Timesheet_Id", dbType: DbType.Int32, direction: ParameterDirection.Output);

                        await connection.ExecuteAsync("InsertOrUpdateTimesheetHeader", parameters, transaction, commandType: CommandType.StoredProcedure);
                        int timesheetId = parameters.Get<int>("@Timesheet_Id");

                        //   Insert or Update Timesheet Details
                        foreach (var detail in request.Details)
                        {
                            var detailParams = new DynamicParameters();
                            detailParams.Add("@Timesheet_Id", timesheetId);
                            detailParams.Add("@Emp_code", detail.EmpCode);
                            detailParams.Add("@Task_Id", detail.TaskId);
                            detailParams.Add("@Project_Id", detail.ProjectId);
                            detailParams.Add("@Date", detail.Date);
                            detailParams.Add("@Hours", detail.Hours);
                            detailParams.Add("@Category_Id", detail.CategoryId);
                            detailParams.Add("@Sub_Category_Id", detail.SubCategoryId);

                            // Pass the IsDraftSubmission flag from the header (Option A: do not revert existing statuses)
                            detailParams.Add("@IsDraftSubmission", request.Header.IsDraftSubmission ? 1 : 0, DbType.Boolean);
                            await connection.ExecuteAsync("InsertOrUpdateTimesheetDetails", detailParams, transaction, commandType: CommandType.StoredProcedure);
                        }

                        //   Update Overall Hours in Timesheet Header
                        var updateParams = new DynamicParameters();
                        updateParams.Add("@Timesheet_Id", timesheetId);

                        await connection.ExecuteAsync("UpdateOverallHours", updateParams, transaction, commandType: CommandType.StoredProcedure);

                        // Commit the transaction
                        transaction.Commit();

                        return timesheetId;
                    }
                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }
    }
}