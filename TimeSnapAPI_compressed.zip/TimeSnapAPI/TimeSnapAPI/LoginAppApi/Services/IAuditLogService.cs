﻿using LoginAppApi.Models;
using LoginAppApi.Models.Dto;

namespace LoginAppApi.Services
{
    public interface IAuditLogService
    {
        Task LogAsync(AuditLog log);

        // WITHOUT parameters
        //Task<List<AuditLog>> GetAllAuditLogsAsync();
        Task<List<AuditLogDto>> GetAllAuditLogsAsync();


        // WITH parameters
        Task<(List<AuditLogDto> Logs, int TotalCount)> GetAuditLogsAsync(
            int page,
            int pageSize,
            string? moduleName,
            string? actionType,
            int? actorEmpCode,
            int? targetEmpCode,
            DateTime? fromDate,
            DateTime? toDate
        );

    }
}
