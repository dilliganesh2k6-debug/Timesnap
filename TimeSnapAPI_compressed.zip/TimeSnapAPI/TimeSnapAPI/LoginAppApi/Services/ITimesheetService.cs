﻿using TimeTrackerApplication.Models.DTOs;

namespace TimeTrackerApplication.Services
{
    public interface ITimesheetService
    {
        Task<int> SaveTimesheetAsync(TimesheetSubmissionRequest request);
    }
}