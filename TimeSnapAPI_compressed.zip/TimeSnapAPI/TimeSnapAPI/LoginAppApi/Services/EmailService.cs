﻿using LoginAppApi.Models.Dto;
using Microsoft.Extensions.Options;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace LoginAppApi.Services
{
    public class EmailService : IEmailService
    {
        private readonly SmtpSettings _smtp;

        public EmailService(IOptions<SmtpSettings> smtpOptions)
        {
            _smtp = smtpOptions.Value;
        }

        public async Task SendEmailAsync(EmailRequestDto request)
        {
            try
            {
                using var smtpClient = new SmtpClient(_smtp.Host)
                {
                    Port = _smtp.Port,
                    Credentials = new NetworkCredential(
                        _smtp.Username,
                        _smtp.Password
                    ),
                    EnableSsl = _smtp.EnableSsl,
                };

                using var mailMessage = new MailMessage
                {
                    From = new MailAddress(_smtp.FromEmail),
                    Subject = request.Subject,
                    Body = request.HtmlBody,
                    IsBodyHtml = true,
                    SubjectEncoding = Encoding.UTF8,
                    BodyEncoding = Encoding.UTF8,
                };

                mailMessage.To.Add(request.To);

                await smtpClient.SendMailAsync(mailMessage);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(
                    $"Error sending email to {request.To}: {ex.Message}", ex
                );
            }
        }
    }
}
