﻿using Microsoft.EntityFrameworkCore;
using LoginAppApi.Models;
using System.Globalization;
using TimeTrackerApplication.Models;
using Microsoft.EntityFrameworkCore.Metadata.Internal;



namespace LoginAppApi.Data
{
    public class LoginAppDbContext : DbContext
    {
        public LoginAppDbContext(DbContextOptions<LoginAppDbContext> options) : base(options)
        {
        }
        public DbSet<User> Users { get; set; }
        public DbSet<Access> Access { get; set; }
        public DbSet<ScreenRights> ScreenRights { get; set; }
        public DbSet<ScreenRightsView> ScreenRightsView { get; set; }
        public DbSet<WorkingstatusInfo> WorkingstatusInfo { get; set; }
        public DbSet<statusinfo> statusinfo { get; set; }
        public DbSet<Designation> Designations { get; set; }
        public DbSet<EmploymentType> employmentTypes { get; set; }
        public DbSet<Screen> screens { get; set; }
        public DbSet<Client> Clients { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<TaskCategories> Categories { get; set; }
        public DbSet<CategoryViewDto> CategoriesView { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<UserDetails> UserDetails { get; set; }
        public DbSet<UsersInfo> UsersInfo { get; set; }
        public DbSet<ProjectOverview> ProjectOverviews { get; set; }
        public DbSet<ProjectCategories> ProjectCategories { get; set; }
        public DbSet<UserManagementViewModel> UserManagementView { get; set; }
        public DbSet<EmployeeViewModel> EmployeeViewModels { get; set; }
        public DbSet<ProjectInfo> ProjectInfo { get; set; }
        public DbSet<ProjectManagers> ProjectManagers { get; set; }
        public DbSet<EditProject> ProjectEditView { get; set; }
        public DbSet<ProjectTask> ProjectTasks { get; set; }
        public DbSet<ProjectView> projectViews { get; set; }
        public DbSet<TeamInfo> Teaminfo { get; set; }
        public DbSet<ProjectMember> ProjectMembers { get; set; }
        public DbSet<ProjectMembersView> ProjectMembersView { get; set; }
        public DbSet<TeamManagementView> TeamManagementView { get; set; }
        public DbSet<Models.TaskEntity> Tasks { get; set; }
        public DbSet<TimesheetHeaderModel> TimesheetHeader { get; set; }
        public DbSet<TimesheetDetailsModel> TimesheetDetails { get; set; }
        public DbSet<TimesheetApproval> TimesheetApproval { get; set; }
        public DbSet<TimesheetDetailReport> TimesheetDetailReport { get; set; }
        public DbSet<TimesheetNotes> TimesheetNotes { get; set; }
        public DbSet<ProjectTaskResourceAnalytics> ProjectTaskResourceAnalytics { get; set; }
        public DbSet<AuditLog> AuditLogs { get; set; }






        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure User table
            modelBuilder.Entity<User>()
                .HasKey(u => u.UserId);
            modelBuilder.Entity<User>()
                .Property(u => u.Email_Id)
                .IsRequired()
                .HasMaxLength(100);
            modelBuilder.Entity<User>()
                .Property(u => u.Password)
                .IsRequired()
                .HasMaxLength(100);
            modelBuilder.Entity<ProjectOverview>().HasNoKey();
            modelBuilder.Entity<ProjectOverview>().ToView("project_overview");

            // Configure Access table
            modelBuilder.Entity<Access>()
                .HasKey(a => a.AccessId);
            modelBuilder.Entity<Access>()
                .Property(a => a.ScreenName)
                .IsRequired()
                .HasMaxLength(100);
            modelBuilder.Entity<Access>()
                .HasOne(a => a.Role)
                .WithMany()
                .HasForeignKey(a => a.RoleId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure WorkingstatusInfo table
            modelBuilder.Entity<WorkingstatusInfo>()
                .HasNoKey();

            // Configure statusInfo table
            modelBuilder.Entity<statusinfo>()
                .HasKey(t => t.status_id);

            // Configure Designation table
            modelBuilder.Entity<Designation>(entity =>
            {
                entity.ToTable("Designation");
                entity.HasKey(d => d.designationId);
                entity.Property(d => d.designationId).HasColumnName("designation_Id");
                entity.Property(d => d.designationname).HasColumnName("designation_name").HasMaxLength(50).IsRequired();
                entity.Property(d => d.createdAt).HasColumnName("created_at").HasDefaultValueSql("GETDATE()");
            });

            // Configure EmploymentType table
            modelBuilder.Entity<EmploymentType>(entity =>
            {
                entity.ToTable("EmploymentType");
                entity.HasKey(e => e.EmploymentTypeId);
                entity.Property(e => e.EmploymentTypeId).HasColumnName("employmentType_Id");
                entity.Property(e => e.EmploymentTypeName).HasColumnName("employmentType_name").HasMaxLength(50).IsRequired();
            });
            modelBuilder.Entity<ProjectOverview>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("project_overview");
            });

            // Configure Screen table
            modelBuilder.Entity<Screen>()
                 .HasKey(s => new { s.ScreenId, s.Role });
            modelBuilder.Entity<Screen>()
                 .Property(s => s.ScreenName)
                 .IsRequired()
                 .HasMaxLength(100);


            // Configure Role table
            modelBuilder.Entity<Role>()
                .HasKey(r => r.RoleId);
            modelBuilder.Entity<Role>()
                .Property(r => r.RoleTitle)
                .IsRequired()
                .HasMaxLength(255);
            modelBuilder.Entity<Role>()
                .Property(r => r.CreatedAt)
                .HasDefaultValueSql("GETDATE()");
            modelBuilder.Entity<Role>()
                .Property(r => r.IsDeleted)
                .HasDefaultValue(false);

            modelBuilder.Entity<ProjectOverview>().ToView("project_overview");

            // Configure UserDetails table
            modelBuilder.Entity<UserDetails>()
                .HasKey(u => u.Emp_code);
            modelBuilder.Entity<UserDetails>();
            modelBuilder.Entity<UserDetails>()
               .HasKey(u => u.Emp_code);
            modelBuilder.Entity<UserDetails>()
                  .Property(u => u.Joining_Date)
                  .HasColumnType("date");
            modelBuilder.Entity<UserDetails>()
                .HasQueryFilter(u => !u.IsDelete);

            // Configure UsersInfo table
            modelBuilder.Entity<UsersInfo>()
                .Property(u => u.DOB)
                .HasColumnType("date");

            // Configure UserManagementViewModel table
            modelBuilder.Entity<UserManagementViewModel>()
              .Property(u => u.JoiningDate)
              .HasColumnType("date");
            modelBuilder.Entity<UserManagementViewModel>()
                .HasNoKey()
                .ToView("UserManagementView");

            // Configure EmployeeDetailsView table
            modelBuilder.Entity<EmployeeViewModel>()
                .ToView("EmployeeDetailsView")
                .HasNoKey();

            // Configure ProjectInfo table
            modelBuilder.Entity<ProjectInfo>().HasKey(p => p.Project_id);
            modelBuilder.Entity<ProjectInfo>()
                .Property(p => p.isDelete)
                .HasDefaultValue(false);
            modelBuilder.Entity<ProjectInfo>()
                .Property(p => p.created_at)
                .HasDefaultValueSql("GETDATE()");
            modelBuilder.Entity<ProjectInfo>()
                .Property(p => p.updated_at)
                .HasDefaultValueSql("GETDATE()");

            //Configure EditProject table
            modelBuilder.Entity<EditProject>()
               .ToView("ProjectEditView")
               .HasNoKey();

            //Configure ProjectTask table
            modelBuilder.Entity<ProjectTask>()
                .HasKey(pt => new { pt.Project_Id, pt.Task_Id });
            modelBuilder.Entity<ProjectTask>()
                 .Property(pt => pt.created_at)
                 .HasDefaultValueSql("getdate()");
            modelBuilder.Entity<ProjectTask>()
                 .Property(pt => pt.updated_at)
                 .HasDefaultValueSql("getdate()");

            // Configure ProjectView table
            modelBuilder.Entity<ProjectView>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("ProjectView");
            });

            modelBuilder.Entity<ProjectCategories>(entity =>
            {
                entity.ToTable("ProjectCategories");
                entity.HasKey(p => p.ProjectCategoryId);
                entity.Property(p => p.ProjectCategoryId).HasColumnName("ProjectCategoryId");
                entity.Property(d => d.projectCategoryName).HasColumnName("projectCategoryName").HasMaxLength(50).IsRequired();
                entity.Property(d => d.CreatedDate).HasColumnName("CreatedDate").HasDefaultValueSql("GETDATE()");
            });

            //Configure TeamInfo table
            modelBuilder.Entity<TeamInfo>()
                .ToTable("teamInfo")
                .HasKey(t => t.Team_id);
            modelBuilder.Entity<TeamInfo>()
                .HasKey(t => t.Team_id);

            //Configure TeamMember table
            modelBuilder.Entity<ProjectMember>()
                .HasKey(tm => new { tm.Emp_code, tm.projectid, tm.Index_id });

            // Configure ProjectMembersView table
            modelBuilder.Entity<ProjectMembersView>()
               .HasNoKey()
               .ToView("ProjectMembersView");

            //Configure TeamManagementView table
            modelBuilder.Entity<TeamManagementView>()
                .ToView("TeamManagementView")
                .HasNoKey();
            modelBuilder.Entity<ProjectOverview>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("project_overview");
            });

            modelBuilder.Entity<TimesheetHeaderModel>()
                .HasKey(th => th.Timesheet_Id);

            modelBuilder.Entity<TimesheetDetailsModel>()
.HasKey(td => new {
td.Timesheet_Id,
td.Task_Id,
td.Date,
td.CategoryId,     // Add this 
td.SubCategoryId  // Add this
});

            modelBuilder.Entity<TimesheetHeaderModel>()
                .HasMany(th => th.TimesheetDetails)
                .WithOne()
                .HasForeignKey(td => td.Timesheet_Id);

            modelBuilder.Entity<TimesheetHeaderModel>()
                .Property(th => th.Computed_Timesheet_Id)
                .HasComputedColumnSql("('TS' + RIGHT('0000' + CAST(Emp_Code AS VARCHAR(4)), 4) + RIGHT('0000' + CAST(Timesheet_Id AS VARCHAR(10)), 4))");

            modelBuilder.Entity<TimesheetDetailsModel>()
                .Property(td => td.Computed_Timesheet_Id)
                .HasComputedColumnSql("('TS' + RIGHT('0000' + CAST(Emp_Code AS VARCHAR(4)), 4) + RIGHT('0000' + CAST(Timesheet_Id AS VARCHAR(10)), 4))");

            //Configure TimesheetApproval table
            modelBuilder.Entity<TimesheetApproval>()
                 .HasNoKey()
                 .ToView("TimesheetApproval");

            modelBuilder.Entity<TimesheetDetailReport>().HasNoKey().ToView("TimesheetDetailReport");

            modelBuilder.Entity<CategoryViewDto>().ToView("CategoriesView").HasNoKey();
            modelBuilder.Entity<TimesheetNotes>().HasKey(tn => tn.Note_Id);

            // Configure ProjectManagers table
            modelBuilder.Entity<ProjectManagers>(entity =>
            {
                entity.ToTable("ProjectManagers");     
                entity.HasKey(pm => pm.Id);           

                // Optional but recommended: foreign key relation with projectInfo
                entity.HasOne<ProjectInfo>()
                      .WithMany()
                      .HasForeignKey(pm => pm.ProjectId)
                      .OnDelete(DeleteBehavior.Cascade);

                // Optional: relation with UserDetails table
                entity.HasOne<UserDetails>()
                      .WithMany()
                      .HasForeignKey(pm => pm.ManagerId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder
               .Entity<ProjectTaskResourceAnalytics>()
               .HasNoKey()
               .ToView("ProjectTaskResourceAnalytics");
                }
    }
}
