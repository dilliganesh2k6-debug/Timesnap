﻿namespace LoginAppApi.Models 
{ 
    public class AccessRequest

    { 
        public int Role_Id { get; set; } 
        public List<AccessData> AccessData { get; set; } 
    } 
}

