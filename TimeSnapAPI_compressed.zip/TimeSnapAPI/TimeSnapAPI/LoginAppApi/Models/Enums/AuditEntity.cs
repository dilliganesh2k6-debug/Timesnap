﻿namespace LoginAppApi.Models.Enums
{
    public enum AuditEntity
    {
        Users,
        Access,
        Screens,
        UserDetails,
        TeamInfo,
        ProjectInfo,
        ProjectMember,
        ProjectTask,
        Tasks,
        Departments,
        Categories,
        ProjectCategories,
        Roles,
        Clients,
    }
}
