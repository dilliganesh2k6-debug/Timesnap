﻿namespace LoginAppApi.Models.Enums
{
    public enum AuditAction
    {
        INSERT,
        CREATE,
        UPDATE,
        DELETE,
        SUBMIT,
        APPROVE,
        DECLINE,
        LOGIN,
        LOGOUT,
        LOGIN_FAILED,
        PASSWORD_CHANGE,
        PASSWORD_RESET,
        SAVE
    }
}
