﻿using System.Runtime.Serialization;

namespace LoginAppApi.Models.Enums
{

    public enum AuditModule
    {
        [EnumMember(Value = "Timesheet")]
        Timesheet,
        [EnumMember(Value = "Project")]
        Project,
        [EnumMember(Value = "Project Task Allocation")]
        ProjectTaskAllocation,
        [EnumMember(Value = "Task")]
        Task,
        [EnumMember(Value = "Task SubCategory")]
        TaskSubCategory,
        [EnumMember(Value = "Team")]
        Team,
        [EnumMember(Value = "User")]
        User,
        [EnumMember(Value = "User Management")]
        UserManagement,
        [EnumMember(Value = "Access")]
        Access,
        [EnumMember(Value = "System")]
        System,
        [EnumMember(Value = "Authentication")]
        Authentication,
        [EnumMember(Value = "Access Control")]
        AccessControl,
        [EnumMember(Value = "Screen Access")]
        ScreenAccess,
        [EnumMember(Value = "Department")]
        Department,
        [EnumMember(Value = "Task Category")]
        TaskCategory,
        [EnumMember(Value = "Project Category")]
        ProjectCategory,
        [EnumMember(Value = "Role")]
        Role,
        [EnumMember(Value = "Client")]
        Client,
        [EnumMember(Value = "Resource Allocation")]
        ResourceAllocation,
    }
}
