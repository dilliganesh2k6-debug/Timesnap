﻿using System.Text.Json.Serialization;

namespace LoginAppApi.Models.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))] // Converts JSON strings to enum
    public enum CategoryType
    {
        TaskCategories,
        ProjectCategories
    }
}
