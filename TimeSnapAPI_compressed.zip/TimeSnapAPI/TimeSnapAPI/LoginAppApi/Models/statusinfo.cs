﻿namespace LoginAppApi.Models
{
    public class statusinfo
    {
        public int status_id { get; set; }
        public string status_name { get; set; } 
        public DateTime created_at { get; set; }
    }
}
