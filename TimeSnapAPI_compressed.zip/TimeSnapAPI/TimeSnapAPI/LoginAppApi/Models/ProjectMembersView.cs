﻿namespace LoginAppApi.Models

{
    public class ProjectMembersView
    {
        public int Index_id { get; set; }   
        public int Projectid { get; set; }
        public string ProjectName { get; set; }
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string ProjectStatus { get; set; }
        public int EmpCode { get; set; }
        public string UserName { get; set; }
        public string Designation { get; set; }
        public bool IsDelete { get; set; }
    }
}

