﻿namespace LoginAppApi.Models 
{ 
    public class AccessData
    { 
        public string ScreenName { get; set; } 
        public string ScreenId { get; set; }   
        public bool HideShow { get; set; } 
        public bool FullAccess { get; set; } 
        public bool ReadOnly { get; set; } 
    } 
}

