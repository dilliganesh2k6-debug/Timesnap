﻿namespace LoginAppApi.Models
{
    public class UserProfilePicture
    {
        public int Id { get; set; }
        public string EmpCode { get; set; }
        public string ProfilePhoto { get; set; }  
        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}

