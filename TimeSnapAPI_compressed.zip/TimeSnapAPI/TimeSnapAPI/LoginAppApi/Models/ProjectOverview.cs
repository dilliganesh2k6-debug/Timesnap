﻿namespace LoginAppApi.Models
{
    public class ProjectOverview
    {
        public int ProjectID { get; set; }
        public string ProjectName { get; set; }
        public string TeamID { get; set; }   
        public string TeamName { get; set; }
        public int ProjectCategoryId { get; set; }
        public string projectCategoryName { get; set; }
        public int TaskID { get; set; }
        public string TaskName { get; set; }
        public decimal ActualHours { get; set; }
        public int StatusID { get; set; }
        public DateTime StartDate { get; set; }
        public string StatusName { get; set; }
        public int TotalTaskCount { get; set; }
    }
}