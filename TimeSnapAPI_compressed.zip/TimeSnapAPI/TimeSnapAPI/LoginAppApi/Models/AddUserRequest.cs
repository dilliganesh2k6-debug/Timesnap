﻿using System.Text.Json.Serialization;

namespace LoginAppApi.Models
{
    public class AddUserRequest
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public int Emp_code { get; set; }
        public DateTime JoiningDate { get; set; }
        public int Department_Id { get; set; }
        public int Designation_Id { get; set; }
        public int TeamId { get; set; }
        public int StatusId { get; set; }
        public bool IsBillable { get; set; }
        public bool ReportingRights { get; set; }
        public int employmentType_ID { get; set; }
        public int WorkingStatusId { get; set; }
        public DateTime DOB { get; set; }
        public string Location { get; set; }
        public string Marital_status { get; set; }
        public string Gender { get; set; }
        public long? Phone_no { get; set; }
        public string Emg_ContactName { get; set; }
        public string Emg_ContactRelation { get; set; }
        public long Emg_ContactPhoneNo { get; set; }
        public int Role_Id { get; set; }
        public int ReportingId { get; set; }
        public bool IsAdmin { get; set; } = false;
    }
    public class UpdateUserRequest
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public int Emp_code { get; set; }
        public DateTime JoiningDate { get; set; }
        public int Department_Id { get; set; }
        public int Designation_Id { get; set; }
        public int TeamId { get; set; }
        public int StatusId { get; set; }
        public bool IsBillable { get; set; }
        public bool Reportingrights { get; set; }
        public int employmentType_ID { get; set; }
        public int WorkingStatusId { get; set; }
        public DateTime DOB { get; set; }
        public string Location { get; set; }
        public string Marital_status { get; set; }
        public string Gender { get; set; }
        public long? Phone_no { get; set; }
        public string Emg_ContactName { get; set; }
        public string Emg_ContactRelation { get; set; }
        public long Emg_ContactPhoneNo { get; set; }
        public int Role_Id { get; set; }
        public int? ReportingId { get; set; }
        public bool IsAdmin { get; set; } = false;
    }
}

