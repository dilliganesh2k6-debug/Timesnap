﻿namespace LoginAppApi.Models

{ 
    public class ProjectCategories

    { 
        public int ProjectCategoryId { get; set; } 
        public string projectCategoryName { get; set; } 
        public string ProjectCategoryDescription { get; set; } 
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow; 
        public Boolean IsDeleted { get; set; } = false; 
    } 
}

