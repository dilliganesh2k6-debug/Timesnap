﻿namespace LoginAppApi.Models
{
    public class ChangePassword
    {
        public int EmpCode { get; set; }
        public string CurrentPassword { get; set; }
        public string NewPassword { get; set; }
    }
}

