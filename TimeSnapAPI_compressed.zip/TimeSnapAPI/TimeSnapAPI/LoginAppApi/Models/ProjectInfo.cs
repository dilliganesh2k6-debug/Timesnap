﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LoginAppApi.Models
{
    [Table("projectInfo")]
    public class ProjectInfo
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Project_id { get; set; }
        [Required]
        public string Project_name { get; set; }
        [Required]
        public int Client_Id { get; set; }
        [Required]
        public int ProjectCategoryId { get; set; }
        [Required]
        public DateTime Start_date { get; set; }
        public DateTime? Due_date { get; set; }
        [Required]
        public int Department_Id { get; set; }
        [Required]
        public int Status_Id { get; set; }
        [Required]
        public string? Color_Code { get; set; }
        public Boolean isDelete { get; set; } = false;
        public DateTime created_at { get; set; } = DateTime.UtcNow;
        public DateTime updated_at { get; set; } = DateTime.UtcNow;
        //public int? CreatedBy { get; set; }
        //public int? UpdatedBy { get; set; }
        //public int? DeletedBy { get; set; }
    }

    public class ProjectInfoDto
    {
        public int ProjectId { get; set; }
        public string ProjectName { get; set; } = string.Empty;
        public string ColorCode { get; set; } = string.Empty;
    }
}
