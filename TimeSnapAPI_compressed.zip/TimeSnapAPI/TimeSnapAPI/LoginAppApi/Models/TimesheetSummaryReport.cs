﻿namespace LoginAppApi.Models

{

    public class TimesheetSummaryReport 
    { 
        public int EmpCode { get; set; } 
        public string EmployeeName { get; set; }
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public int ProjectCategoryId { get; set; }
        public string projectCategoryName { get; set; }
        public int ProjectID { get; set; } 
        public string ProjectName { get; set; }
        public int TaskCategoryID { get; set; }
        public string TaskCategoryName { get; set; }
        public int TaskID { get; set; } 
        public string TaskName { get; set; }
        public Boolean  IsBillable { get; set; }
        public DateTime Date { get; set; } 
        public decimal TaskHours { get; set; }   
    } 
}

