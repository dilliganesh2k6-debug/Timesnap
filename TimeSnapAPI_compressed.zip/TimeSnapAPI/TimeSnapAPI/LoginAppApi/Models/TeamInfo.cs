﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LoginAppApi.Models
{
    [Table("teamInfo")]
    public class TeamInfo
    {
        [Key] 
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Team_id { get; set; } 
        [Required]
        [StringLength(20)]
        public string Team_name { get; set; }
        [Required]
        public int Manager_id { get; set; } 
        [Required]
        public int Status_Id { get; set; } 
        public Boolean IsDelete { get; set; }
        public DateTime Created_at { get; set; } 
    }  
}

