﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace TimeTrackerApplication.Models
{
    [Table("TimesheetHeader")]
    public class TimesheetHeaderModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Timesheet_Id { get; set; }
        [Required]
        public int Emp_code { get; set; }
        [Required]
        public DateTime Start_Date { get; set; }
        [Required]
        public DateTime End_Date { get; set; }
        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal Overall_Hours { get; set; }
        [MaxLength(20)]
        public string? Status { get; set; } = "Draft";
        public string? Notes { get; set; }
        public int? Reporting_To_Id { get; set; }
        public DateTime? created_at { get; set; } = DateTime.UtcNow;
        public DateTime? updated_at { get; set; }
        [NotMapped]
        public string Computed_Timesheet_Id { get; set; }
        public ICollection<TimesheetDetailsModel> TimesheetDetails { get; set; }
    }

    public class TimesheetNotesUpdateDto
    {
        public string Status { get; set; }
        public string? Notes { get; set; }
    }
}

