﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace LoginAppApi.Models
{
    public class EditProject
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TaskId { get; set; }
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
        //public int CategoryId { get; set; }
        //public string CategoryName { get; set; }
        //public int SubCategoryId { get; set; }
        //public string SubCategoryName { get; set; }
        public string TaskName { get; set; }
        public string TaskDescription { get; set; }
        public decimal EstimatedHoures { get; set; }
        public decimal ActualHours { get; set; }
        public decimal OverheadHours { get; set; }
        public string StatusName { get; set; }
        public int? Status_Id { get; set; }
    }
}

