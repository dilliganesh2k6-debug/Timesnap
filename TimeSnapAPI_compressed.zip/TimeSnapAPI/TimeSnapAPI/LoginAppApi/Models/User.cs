﻿namespace LoginAppApi.Models
{
    public class User
    {
        public int UserId { get; set; }
        public int Emp_code { get; set; }
        public string Email_Id { get; set; }
        public string Password { get; set; }
        public int Role_Id { get; set; }
    }

    public class ChangePasswordRequest
    {
        public string Email_Id { get; set; }
        public string NewPassword { get; set; }
    }
}

