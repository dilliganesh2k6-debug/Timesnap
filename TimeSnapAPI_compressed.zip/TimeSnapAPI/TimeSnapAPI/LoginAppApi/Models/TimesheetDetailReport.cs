﻿namespace LoginAppApi.Models
{
    public class TimesheetDetailReport
    {
        public int EmpCode { get; set; }
        public string EmployeeName { get; set; }
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public int ProjectCategoryId { get; set; }
        public string projectCategoryName { get; set; }
        public int ProjectID { get; set; }
        public string ProjectName { get; set; }
        public int TaskCategoryID { get; set; }
        public string TaskCategoryName { get; set; }
        public int SubCategoryID { get; set; }
        public string SubCategoryName { get; set; }
        public int TaskID { get; set; }
        public string TaskName { get; set; }
        public Boolean IsBillable { get; set; }
        public DateTime Date { get; set; }
        public decimal TaskHours { get; set; }
        public int ReportingtoId { get; set; }
    }
}
