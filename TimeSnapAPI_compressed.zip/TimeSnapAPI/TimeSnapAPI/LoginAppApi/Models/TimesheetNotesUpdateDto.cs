﻿namespace LoginAppApi.Models

{

    public class TimesheetNotesUpdateDto
    {
        public int UserId { get; set; }

        public List<TaskStatusUpdate> TaskUpdates { get; set; } = new();

        public string? Status { get; set; }  
        public string? Notes { get; set; }   
    }

}

