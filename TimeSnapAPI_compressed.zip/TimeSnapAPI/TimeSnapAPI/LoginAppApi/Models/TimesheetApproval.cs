﻿namespace LoginAppApi.Models

{
    public class TimesheetApproval

    {
        public int TimesheetId { get; set; }
        public string ComputedTimesheetId { get; set; }
        public int EmployeeCode { get; set; }
        public string EmployeeName { get; set; }
        public DateTime WeekStartDate { get; set; }
        public string WeekRange { get; set; }
        public string TotalHours { get; set; }         
        public string ProjectTotalHours { get; set; }  
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
        public string Status { get; set; }
        public string ProjectStatus { get; set; }
        public string Notes { get; set; }
        public int? ReportingId { get; set; }
        public string ReportingToName { get; set; }
        public int ApprovedCount { get; set; }
        //public int TotalTask { get; set; }
    }
}

