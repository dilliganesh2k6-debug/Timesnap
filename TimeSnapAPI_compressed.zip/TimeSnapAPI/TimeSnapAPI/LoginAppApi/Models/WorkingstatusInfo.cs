﻿namespace LoginAppApi.Models
{
    public class WorkingstatusInfo
    {
        public int working_status_Id { get; set; }
        public string working_status_name { get; set; }
        public DateTime created_at { get; set; }
    }
}
