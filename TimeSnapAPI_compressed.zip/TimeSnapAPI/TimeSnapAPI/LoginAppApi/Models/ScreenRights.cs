﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LoginAppApi.Models
{
    public class ScreenRights
    {
        [Key]
        public int ScreenRightId { get; set; } 
        [Required]
        public int ScreenId { get; set; } 
        [Required]
        public int RoleId { get; set; } 
        [Required]
        public bool IsEditable { get; set; } 
        [Required]
        [StringLength(100)]
        public string AccessFieldName { get; set; }
    }
}