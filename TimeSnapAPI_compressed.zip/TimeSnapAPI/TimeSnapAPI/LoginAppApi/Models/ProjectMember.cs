﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LoginAppApi.Models

{
    public class ProjectMember
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Index_id { get; set; } 
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Emp_code { get; set; }
        public string User_name { get; set; }
        public bool IsDeleted { get; set; }
        public int? projectid { get; set; }
        //public int? CreatedBy { get; set; }
        //public int? UpdatedBy { get; set; }
        //public int? DeletedBy { get; set; }
    }

    public class ProjectMemberRequest
    {
        public int projectid { get; set; }
        public int Emp_code { get; set; }
        public string User_name { get; set; }
        //public int? CreatedBy { get; set; }
        //public int? UpdatedBy { get; set; }
        //public int? DeletedBy { get; set; }
    }
}

