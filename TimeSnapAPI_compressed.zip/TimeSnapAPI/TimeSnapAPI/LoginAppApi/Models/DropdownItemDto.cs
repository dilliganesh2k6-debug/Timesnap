﻿namespace LoginAppApi.Models
{
    public class DropdownItemDto
    {
        public string Id { get; set; } 
        public string Name { get; set; }
        public string Location { get; set; }
    }
}
