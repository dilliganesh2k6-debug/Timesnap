namespace LoginAppApi.Models
{
    public sealed class TimesheetReportDetailRow
    {
        public int Emp_code { get; set; }
        public int Project_Id { get; set; }
        public int Task_Id { get; set; }
        public int CategoryId { get; set; }
        public int SubCategoryId { get; set; }
        public DateTime Date { get; set; }
        public decimal Hours { get; set; }
        public int? ReportingToId { get; set; }
    }
}
