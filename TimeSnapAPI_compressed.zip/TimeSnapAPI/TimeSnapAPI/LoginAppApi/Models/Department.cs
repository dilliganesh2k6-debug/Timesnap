﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LoginAppApi.Models
{
    public class Department
    {
        [Key]  
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int DepartmentId { get; set; } 
        [Required]
        [StringLength(100, ErrorMessage = "Name cannot be longer than 100 characters.")]
        public string DepartmentName { get; set; } 
        public string DepartmentDescription { get; set; } 
        [Required]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public Boolean IsDeleted { get; set; }
    }
}
