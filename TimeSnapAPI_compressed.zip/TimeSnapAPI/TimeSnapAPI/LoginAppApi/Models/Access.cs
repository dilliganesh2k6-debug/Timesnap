﻿namespace LoginAppApi.Models

{ 
    public class Access 
    { 
        public int AccessId { get; set; } 
        public int ScreenId { get; set; }
        public string ScreenName { get; set; }
        public int RoleId { get; set; } 
        public bool FullAccess { get; set; } 
        public bool ReadOnly { get; set; } 
        public bool HideShow { get; set; }
        public bool ShowAllUser { get; set; }
        public bool IsDefault { get; set; }
        public Role Role { get; set; } 
    } 
}

