﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace LoginAppApi.Models
{
    public class Client
    {
        [Key]  
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string ClientLocation { get; set; }
        public Boolean IsDeleted { get; set; } = false;    
        public DateTime CreatedDate { get; set; } = DateTime.Now;
    }
}
