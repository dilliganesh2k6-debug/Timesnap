﻿using System.ComponentModel.DataAnnotations;

namespace LoginAppApi.Models
{
    public class Role
    { 
        public int RoleId { get; set; }    
        [Required]
        [StringLength(255)]
        public string RoleTitle { get; set; }   
        public string RolePermissions { get; set; }    
        public DateTime CreatedAt { get; set; }
        public Boolean IsDeleted { get; set; } = false;

    }
}
