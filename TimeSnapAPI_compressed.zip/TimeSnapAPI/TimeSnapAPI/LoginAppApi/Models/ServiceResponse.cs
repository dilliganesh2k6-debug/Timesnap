﻿namespace LoginAppApi.Models
{
    public class ServiceResponse
    {
        public bool Success { get; internal set; }
        public string Message { get; internal set; }
    }
}
