﻿using System.ComponentModel.DataAnnotations;

namespace LoginAppApi.Models
{
    public class TimesheetNotes
    {
        [Key]
        public int Note_Id { get; set; } 
        public int Timesheet_Id { get; set; }
        public int Emp_code { get; set; } 
        public int Manager_Emp_code { get; set; } 
        public string Note { get; set; }
        public DateTime Note_DateTime { get; set; } = DateTime.UtcNow;
    }
}
