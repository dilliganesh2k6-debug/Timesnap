﻿using System.ComponentModel.DataAnnotations;

namespace TimeTrackerApplication.Models.DTOs
{
    public class TimesheetDetailsRequest
    {
        [Required]
        public int TimesheetId { get; set; }
        [Required]
        public int EmpCode { get; set; }
        [Required]
        public int TaskId { get; set; }
        [Required]
        public int ProjectId { get; set; }
        [Required]
        public DateTime Date { get; set; }
        [Required]
        [Range(0, 24)]
        public decimal Hours { get; set; }
        public int CategoryId { get; set; }    // Add this
        public int SubCategoryId { get; set; }
    }
}