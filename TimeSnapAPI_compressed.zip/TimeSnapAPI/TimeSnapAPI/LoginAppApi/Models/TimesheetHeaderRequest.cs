﻿using System.ComponentModel.DataAnnotations;

namespace TimeTrackerApplication.Models.DTOs

{
    public class TimesheetHeaderRequest
    {
        [Required]
        public int EmpCode { get; set; }
        [Required]
        public DateTime StartDate { get; set; }
        [Required]
        public DateTime EndDate { get; set; }

        public bool IsDraftSubmission { get; set; } 
    }
}

