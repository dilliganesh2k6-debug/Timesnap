﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
namespace LoginAppApi.Models
{
    public class UserManagementViewModel
    {
        public int EmployeeCode { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public int RoleId { get; set; }
        public string Role { get; set; }
        public int EmploymentTypeId { get; set; }
        public string EmploymentType { get; set; }
        public int Designation_Id { get; set; }
        public string Designation { get; set; }
        public int DepartmentId { get; set; }
        public string Department { get; set; }
        public int working_status_Id { get; set; }
        public string WorkingStatus { get; set; }
        public int? Team_id { get; set; }  // Nullable if a user might not have a team
        public string TeamName { get; set; }
        public int? ReportingId { get; set; }  // Nullable if a user might not have a reporting manager
        public string ReportingToName { get; set; }
        public bool Reportingrights { get; set; }
        public long PhoneNo { get; set; }  
        public string Location { get; set; }
        public string MaritalStatus { get; set; }
        public string Gender { get; set; }
        public long EmgContactPhoneno { get; set; }
        public string EmgContactName { get; set; }
        public string EmgContactRelation { get; set; }
        public int status_Id { get; set; }
        public string status { get; set; }
        public DateTime DOB { get; set; }
        public bool IsBillable { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsAdmin { get; set; }
        public DateTime Created_At { get; set; }
        [JsonIgnore]
        public DateTime JoiningDate { get; set; }
        [JsonPropertyName("joiningDate")]
        public string JoiningDateFormatted => JoiningDate.ToString("yyyy-MM-dd");
    }

}


