﻿using System.ComponentModel.DataAnnotations;

namespace LoginAppApi.Models.Dto

{
    public class AddRoleRequestDto
    {
        [Required(ErrorMessage = "Role name is required.")]
        public string RoleName { get; set; }

        public string RolePermissions { get; set; }

        [Required(ErrorMessage = "At least one permission must be selected.")]
        public List<int> PermissionIds { get; set; } = new List<int>();
    }
}
