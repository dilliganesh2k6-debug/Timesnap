﻿namespace LoginAppApi.Models.Dto
{
    public class TimesheetApprovalDTO
    {
        public int TimesheetId { get; set; }
        public string ComputedTimesheetId { get; set; }
        public int EmployeeCode { get; set; }
        public string EmployeeName { get; set; }
        public string WeekRange { get; set; }
        public string Hours { get; set; } 
        public string Status { get; set; }
        public string Notes { get; set; }
        public int? ReportingId { get; set; }
        public string ReportingToName { get; set; }
        public int ApprovedCount { get; set; }
        public int TotalTask { get; set; }
    }

}
