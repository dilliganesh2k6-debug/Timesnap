﻿namespace LoginAppApi.Models.Dto
{
    public class EmailRequestDto
    {
        public string To { get; set; }
        public string Subject { get; set; }
        public string HtmlBody { get; set; }
    }

}
