﻿namespace LoginAppApi.Models.Dto
{
    public class CreateProjectDto
    {
        public string Project_name { get; set; }
        public int Client_Id { get; set; }
        public int ProjectCategoryId { get; set; }
        public DateTime Start_date { get; set; }
        public DateTime? Due_date { get; set; }
        public int Department_Id { get; set; }
        public int Status_Id { get; set; }
        public string Color_Code { get; set; }

        public List<int> Managers { get; set; }
    }
}
