﻿using LoginAppApi.Models.Enums; 

namespace LoginAppApi.Models.Dto
{
    public class CategoryDto
    {
        public int Id { get; set; }
        public CategoryType Type { get; set; } 
        public string Name { get; set; }
        public string Description { get; set; }
    }
}