﻿namespace LoginAppApi.Models.Dto
{
    public class ProjectViewDto
    {
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string ProjectManagers { get; set; }
        public string DepartmentName { get; set; }
        public int DepartmentId { get; set; }
        public string ProjectStatus { get; set; }
        public int Status_Id { get; set; }
        public bool IsDelete { get; set; }

        // NEW FIELD → Not tracked by EF
        public List<int> ManagerIds { get; set; }
    }

}
