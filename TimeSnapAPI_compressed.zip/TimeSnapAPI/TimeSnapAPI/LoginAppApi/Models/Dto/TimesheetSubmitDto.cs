﻿namespace LoginAppApi.Models.Dto
{
    public class TimesheetSubmitDto
    {
        public int EmpCode { get; set; }
        public string StartDate { get; set; }  
        public string EndDate { get; set; }
    }
}
