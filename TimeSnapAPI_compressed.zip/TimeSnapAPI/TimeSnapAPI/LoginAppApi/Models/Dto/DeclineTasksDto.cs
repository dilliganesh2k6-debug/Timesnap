﻿namespace LoginAppApi.Models.Dto
{

    public class DeclineTasksRequestDto
    {
        public int? ProjectId { get; set; }
        public int TimesheetId { get; set; }
        public string? Notes { get; set; }
        public string HeaderStatus { get; set; }
        public int ManagerEmpCode { get; set; }
        public List<DeclineTaskDto> Tasks { get; set; }
    }

    public class DeclineTaskDto
    {
        public int EmpCode { get; set; }
        public int ProjectId { get; set; }
        public int TaskId { get; set; }
        public DateTime Date { get; set; }
        public string TaskStatus { get; set; }
        public int CategoryId { get; set; }    // Add this
        public int SubCategoryId { get; set; }
    }
}
