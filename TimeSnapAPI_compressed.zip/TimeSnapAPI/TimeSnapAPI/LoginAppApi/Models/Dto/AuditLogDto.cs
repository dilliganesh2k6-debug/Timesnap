﻿namespace LoginAppApi.Models.Dto
{
    public class AuditLogDto
    {
        public long AuditId { get; set; }
        public int? ActorEmpCode { get; set; }
        public int? TargetEmpCode { get; set; }
        public string? ModuleName { get; set; }
        public string? ActionType { get; set; }
        public string? EntityName { get; set; }
        public string? OldValue { get; set; }
        public string? NewValue { get; set; }
        //public DateTime ActionDate { get; set; }
        public string? ActionDate { get; set; }
        public string? Remarks { get; set; }
    }
}
