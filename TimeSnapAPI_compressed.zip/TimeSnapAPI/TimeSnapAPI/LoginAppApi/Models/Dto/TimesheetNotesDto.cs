﻿namespace LoginAppApi.Models.Dto
{
    public class TimesheetNotesDto
    {
        public int Note_Id { get; set; }
        public string Note { get; set; }
        public DateTime Note_DateTime { get; set; }
        public int Manager_Emp_code { get; set; }
    }

}
