﻿namespace LoginAppApi.Models.Dto
{
    // Represents one task being approved (inside a project)
    public class ApproveTaskDto
    {
        public int ProjectId { get; set; }      
        public int TaskId { get; set; }          
        public int EmpCode { get; set; }         
        public DateTime Date { get; set; }       
        public string TaskStatus { get; set; }
        public int CategoryId { get; set; }    // Add this
        public int SubCategoryId { get; set; }
    }

    // Represents the full request (sent once per approval action)
    public class ApproveTasksRequestDto
    {
        public int TimesheetId { get; set; }         
        public string? Notes { get; set; }           
        public string HeaderStatus { get; set; }     
        public int ManagerEmpCode { get; set; }      
        public List<ApproveTaskDto> Tasks { get; set; } = new(); 
    }
}
