﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using static LoginAppApi.Models.UserManagementService;
using System.Text.Json.Serialization;

public class UserDetails

{
    [Key]
    public int Emp_code { get; set; }
    [Required]
    [MaxLength(50)]
    public string User_name { get; set; }
    [Required]
    [MaxLength(100)]
    public string Email_Id { get; set; }
    public string? TeamName { get; set; }
    public int? Designation_Id { get; set; }
    [JsonConverter(typeof(DateOnlyJsonConverter))]
    public DateTime? Joining_Date { get; set; }
    [Required]
    public int? Department_Id { get; set; }
    [Required]
    public int? Status_Id { get; set; }
    [Required]
    public int? Working_Status_Id { get; set; }
    [Required]
    public int? Role_Id { get; set; }
    public bool? IsBillable { get; set; }
    public int? employmentType_ID { get; set; }
    public DateTime Created_At { get; set; } = DateTime.UtcNow;
    public DateTime Updated_At { get; set; } = DateTime.UtcNow;
    public int? team_id { get; internal set; }
    public bool IsDelete { get; internal set; }
    public int? Projectid { get; internal set; }
    public bool IsLoggedIn { get; set; } = false;
    public DateTime? LastActivity { get; set; }
    public bool IsAdmin { get; set; } = false;
}

public class UsersInfo

{
    [Key]
    [ForeignKey("UserDetails")]
    public int Emp_code { get; set; }
    [Required]
    [MaxLength(50)]
    public string User_name { get; set; }
    [Required]
    [MaxLength(100)]
    public string Email_Id { get; set; }
    [JsonConverter(typeof(DateOnlyJsonConverter))]
    public DateTime? DOB { get; set; }
    [MaxLength(20)]
    public string? Gender { get; set; }
    public long? Phone_no { get; set; }
    [MaxLength(20)]
    public string? Marital_status { get; set; }
    [MaxLength(50)]
    public string? Location { get; set; }
    [MaxLength(20)]
    public string? Role_name { get; set; }
    public string? Emg_ContactName { get; set; }
    public long? Emg_ContactPhoneNo { get; set; }
    public string? Emg_ContactRelation { get; set; }
    public bool? Reportingrights { get; set; }

    public int ReportingId { get; set; }
    public DateTime Created_At { get; set; } = DateTime.UtcNow;
    public DateTime Updated_At { get; set; } = DateTime.UtcNow;
    public string? ReportingToName { get; set; }
    //public int? CreatedBy { get; set; }
    //public int? UpdatedBy { get; set; }
    //public int? DeletedBy { get; set; }


}


public class profileInfoDto

{
    public int Emp_code { get; set; }
    public string User_name { get; set; }
    public string Email_Id { get; set; }
}

