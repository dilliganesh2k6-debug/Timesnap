﻿namespace LoginAppApi.Models
{
    public class CategoryViewDto
    {
        public int Id { get; set; }
        public string CategoryName { get; set; }
        public string CategoryDescription { get; set; }
        public string TypeOfCategory { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreatedDate { get; set; } 
    }
}
