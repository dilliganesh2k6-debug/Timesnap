﻿namespace LoginAppApi.Models
{
    public class Designation
    {
        public int designationId { get; set; }
        public string designationname {  get; set; }
        public DateTime createdAt { get; set; }
    } 
}
