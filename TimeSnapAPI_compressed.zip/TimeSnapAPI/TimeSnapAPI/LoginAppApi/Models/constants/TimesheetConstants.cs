﻿namespace LoginAppApi.Models.constants
{
    public static class TimesheetConstants
    {
        public static class Status
        {
            public const string Pending = "Pending";
            public const string Approved = "Approved";
            public const string Declined = "Declined";
            public const string Submitted = "Submitted";
            public const string DefaultHashedPassword = "8C23DA0E5E9C6F8D786DC1444D25AE6B9A2A455CE22002DB53EB1D6461D573E6";
        }
    }
}
