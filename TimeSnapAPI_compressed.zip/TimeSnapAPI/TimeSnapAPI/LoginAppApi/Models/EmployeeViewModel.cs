﻿using LoginAppApi.Models;

namespace LoginAppApi.Models
{
    public class EmployeeViewModel
    {
        public string Username { get; set; }
        public int Emp_code { get; set; }
        public int employmentType_Id { get; set; }
        public string email_id { get; set; }
        public long PhoneNo { get; set; }
        public string location { get; set; }
        public DateTime dateofbirth { get; set; }
        public string Gender { get; set; }
        public string MaritalStatus { get; set; }
        public string Emg_ContactName { get; set; }
        public long Emg_ContactPhoneNo { get; set; }
        public string Emg_ContactRelation { get; set; }
        public string Designation { get; set; }
        public string DepartmentName { get; set; }
        public string TeamName { get; set; }
        public string ReportingTo { get; set; }
        public bool IsBillable { get; set; }
        public string EmploymentType { get; set; }
        public DateTime JoiningDate { get; set; }
    }
}
public class EmployeeResponseModel
{
    public EmployeeViewModel EmployeeData { get; set; }
    public FieldAccessModel FieldAccess { get; set; }
    public string Roletitle { get; internal set; }
}

public class FieldAccessModel
{
    public bool IsResourceTypeEditable { get; set; }
    public bool IsEmploymentTypeEditable { get; set; }
}