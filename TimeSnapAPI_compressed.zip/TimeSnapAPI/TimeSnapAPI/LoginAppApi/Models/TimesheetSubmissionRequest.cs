﻿using System.ComponentModel.DataAnnotations;

namespace TimeTrackerApplication.Models.DTOs
{
    public class TimesheetSubmissionRequest
    {
        [Required]
        public TimesheetHeaderRequest Header { get; set; }

        [Required]
        public List<TimesheetDetailsRequest> Details { get; set; } = new List<TimesheetDetailsRequest>();
    }
}