﻿using LoginAppApi.Data;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace LoginAppApi.Models
{
    public class UserManagementService
    {
        private readonly LoginAppDbContext _context;
        public UserManagementService(LoginAppDbContext context)
        {
            _context = context;
        }

        // add user
        public async Task<ServiceResponse> AddUserAsync(AddUserRequest request)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Check if Emp_code or Email_Id already exist
                if (await _context.UserDetails.AnyAsync(u => u.Emp_code == request.Emp_code))
                {
                    return new ServiceResponse { Success = false, Message = "Employee code already exists." };
                }

                if (await _context.UserDetails.AnyAsync(u => u.Email_Id == request.Email) ||
    await _context.UsersInfo.AnyAsync(u => u.Email_Id == request.Email))
                {
                    return new ServiceResponse { Success = false, Message = "Email ID already exists." };
                }

                // Fetch Department
                var department = await _context.Departments
                    .FirstOrDefaultAsync(d => d.DepartmentId == request.Department_Id);
                if (department == null)
                {
                    return new ServiceResponse { Success = false, Message = "Department not found." };
                }

                // Fetch Working Status
                var workingStatus = await _context.WorkingstatusInfo
                    .FirstOrDefaultAsync(ws => ws.working_status_Id == request.WorkingStatusId);
                if (workingStatus == null)
                {
                    return new ServiceResponse { Success = false, Message = "Working status not found." };
                }

                // Fetch Role
                var role = await _context.Roles
                    .Where(r => r.RoleId == request.Role_Id)
                    .Select(r => new { r.RoleId, r.RoleTitle })
                    .FirstOrDefaultAsync();
                if (role == null)
                {
                    return new ServiceResponse { Success = false, Message = "Role not found." };
                }

                // Determine ReportingToName
                var ReportingUser = await _context.UsersInfo
                    .Where(u => u.Emp_code == request.ReportingId)
                    .Select(u => u.User_name)
                    .FirstOrDefaultAsync();

                if (string.IsNullOrEmpty(ReportingUser))
                {
                    return new ServiceResponse { Success = false, Message = "ReportingTo user not found." };
                }

                string ReportingToName = ReportingUser;

                // Determine TeamName

                string TeamName = "Unassigned"; // Default value

                if (request.TeamId != 0)
                {
                    var team = await _context.Teaminfo
                        .Where(t => t.Team_id == request.TeamId)
                        .Select(t => t.Team_name)
                        .FirstOrDefaultAsync();
                    if (!string.IsNullOrEmpty(team))
                    {
                        TeamName = team;
                    }
                }

                // Insert into UserDetails
                var userDetails = new UserDetails
                {
                    Emp_code = request.Emp_code,
                    User_name = request.UserName,
                    Email_Id = request.Email,
                    Joining_Date = request.JoiningDate,
                    Department_Id = department.DepartmentId,
                    team_id = request.TeamId,
                    Designation_Id = request.Designation_Id,
                    Status_Id = request.StatusId,
                    Working_Status_Id = workingStatus.working_status_Id,
                    Role_Id = role.RoleId,
                    IsBillable = request.IsBillable,
                    employmentType_ID = request.employmentType_ID,
                    TeamName = TeamName,
                    Created_At = DateTime.Now,
                    Updated_At = DateTime.Now,
                    IsDelete = false,
                    IsAdmin = request.IsAdmin

                };

                _context.UserDetails.Add(userDetails);
                await _context.SaveChangesAsync();

                // Insert into UsersInfo
                var usersInfo = new UsersInfo
                {
                    Emp_code = request.Emp_code,
                    User_name = request.UserName,
                    Email_Id = request.Email,
                    DOB = request.DOB,
                    Gender = request.Gender,
                    Location = request.Location,
                    Marital_status = request.Marital_status,
                    Emg_ContactName = request.Emg_ContactName,
                    Emg_ContactRelation = request.Emg_ContactRelation,
                    Phone_no = request.Phone_no,
                    Role_name = role.RoleTitle,
                    ReportingId = request.ReportingId,
                    ReportingToName = ReportingToName,
                    Reportingrights = request.ReportingRights,
                    Emg_ContactPhoneNo = request.Emg_ContactPhoneNo,
                    Created_At = DateTime.Now,
                    Updated_At = DateTime.Now,
                    //CreatedBy = createdBy,
                    //UpdatedBy = createdBy
                };

                _context.UsersInfo.Add(usersInfo);
                await _context.SaveChangesAsync();

                await transaction.CommitAsync();

                return new ServiceResponse { Success = true, Message = "User added successfully." };
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return new ServiceResponse { Success = false, Message = $"Error: {ex.Message}" };
            }
        }


        //public async Task<List<UserManagementViewModel>> GetAllUsersAsync(int loggedInEmpCode, bool isAdmin)
        //{
        //    try
        //    {
        //        var users = await _context.UserManagementView
        //            .Where(u => !u.IsDeleted) // Filter out deleted records
        //            .OrderByDescending(u => u.Created_At) // LIFO ordering
        //            .Select(u => new UserManagementViewModel
        //            {
        //                EmployeeCode = u.EmployeeCode,
        //                UserName = u.UserName,
        //                Email = u.Email,
        //                JoiningDate = u.JoiningDate,
        //                RoleId = u.RoleId,
        //                Role = u.Role,
        //                EmploymentTypeId = u.EmploymentTypeId,
        //                EmploymentType = u.EmploymentType,
        //                Designation_Id = u.Designation_Id,
        //                Designation = u.Designation,
        //                DepartmentId = u.DepartmentId,
        //                Department = u.Department,
        //                working_status_Id = u.working_status_Id,
        //                WorkingStatus = u.WorkingStatus,
        //                Team_id = u.Team_id,
        //                TeamName = u.TeamName,
        //                ReportingId = u.ReportingId,
        //                ReportingToName = u.ReportingToName,
        //                Reportingrights = u.Reportingrights,
        //                PhoneNo = u.PhoneNo,
        //                Location = u.Location,
        //                MaritalStatus = u.MaritalStatus,
        //                Gender = u.Gender,
        //                EmgContactPhoneno = u.EmgContactPhoneno,
        //                EmgContactName = u.EmgContactName,
        //                EmgContactRelation = u.EmgContactRelation,
        //                status_Id = u.status_Id,
        //                status = u.status,
        //                DOB = u.DOB,
        //                IsBillable = u.IsBillable,
        //                IsDeleted = u.IsDeleted,
        //            })
        //            .ToListAsync();

        //        return users;
        //    }
        //    catch (Exception ex)
        //    {
        //        // You can log it here using any logging framework
        //        Console.WriteLine($"Error fetching user list: {ex.Message}");
        //        throw; // rethrow to maintain stack trace
        //    }
        //}

        public async Task<List<UserManagementViewModel>> GetAllUsersAsync(int loggedInEmpCode, bool isAdmin)
        {
            try
            {
                var query = _context.UserManagementView
                    .Where(u => !u.IsDeleted);

                // 🔐 Apply Reporting filter ONLY if not admin
                if (!isAdmin)
                {
                    query = query.Where(u => u.ReportingId == loggedInEmpCode);
                }

                var users = await query
                    .OrderByDescending(u => u.Created_At)
                    .Select(u => new UserManagementViewModel
                    {
                        EmployeeCode = u.EmployeeCode,
                        UserName = u.UserName,
                        Email = u.Email,
                        JoiningDate = u.JoiningDate,
                        RoleId = u.RoleId,
                        Role = u.Role,
                        EmploymentTypeId = u.EmploymentTypeId,
                        EmploymentType = u.EmploymentType,
                        Designation_Id = u.Designation_Id,
                        Designation = u.Designation,
                        DepartmentId = u.DepartmentId,
                        Department = u.Department,
                        working_status_Id = u.working_status_Id,
                        WorkingStatus = u.WorkingStatus,
                        Team_id = u.Team_id,
                        TeamName = u.TeamName,
                        ReportingId = u.ReportingId,
                        ReportingToName = u.ReportingToName,
                        Reportingrights = u.Reportingrights,
                        PhoneNo = u.PhoneNo,
                        Location = u.Location,
                        MaritalStatus = u.MaritalStatus,
                        Gender = u.Gender,
                        EmgContactPhoneno = u.EmgContactPhoneno,
                        EmgContactName = u.EmgContactName,
                        EmgContactRelation = u.EmgContactRelation,
                        status_Id = u.status_Id,
                        status = u.status,
                        DOB = u.DOB,
                        IsBillable = u.IsBillable,
                        IsDeleted = u.IsDeleted,
                        IsAdmin = u.IsAdmin
                    })
                    .ToListAsync();

                return users;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching user list: {ex.Message}");
                throw;
            }
        }


        // Custom DateOnly JSON Converter
        public class DateOnlyJsonConverter : JsonConverter<DateTime>
        {
            private const string DateFormat = "yyyy-MM-dd"; // Standard Date-Only Format

            //private const string DateFormat = "yyyy-MM-dd HH:mm:ss"; // Date + Time

            public override DateTime Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
            {
                var rawValue = reader.GetString(); // Read the string value from JSON
                if (DateTime.TryParse(rawValue, null, System.Globalization.DateTimeStyles.RoundtripKind, out var parsedDateTime))
                {
                    return parsedDateTime.Date; // Return only the Date part
                }

                throw new JsonException($"Invalid date format: {rawValue}");
            }

            public override void Write(Utf8JsonWriter writer, DateTime value, JsonSerializerOptions options)
            {
                writer.WriteStringValue(value.ToString(DateFormat)); // Serialize as "yyyy-MM-dd"
            }
        }

        // Edit 
        public async Task UpdateUserAsync(UpdateUserRequest request)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Fetch the existing UserDetails record
                var userDetails = await _context.UserDetails.FirstOrDefaultAsync(u => u.Emp_code == request.Emp_code);
                if (userDetails == null)
                {
                    throw new Exception("User not found.");
                }

                // Fetch the existing UsersInfo record
                var usersInfo = await _context.UsersInfo.FirstOrDefaultAsync(u => u.Emp_code == request.Emp_code);
                if (usersInfo == null)
                {
                    throw new Exception("User information not found.");
                }

                // Validate and fetch related entities
                var department = await _context.Departments.FirstOrDefaultAsync(d => d.DepartmentId == request.Department_Id);
                if (department == null)
                {
                    throw new Exception($"Department '{request.Department_Id}' not found.");
                }

                var workingStatus = await _context.WorkingstatusInfo.FirstOrDefaultAsync(ws => ws.working_status_Id == request.WorkingStatusId);
                if (workingStatus == null)
                {
                    throw new Exception($"Working Status '{request.WorkingStatusId}' not found.");
                }

                var status = await _context.statusinfo.FirstOrDefaultAsync(s => s.status_id == request.StatusId);
                if (status == null)
                {
                    throw new Exception($"Status '{request.StatusId}' not found.");
                }

                var role = await _context.Roles.FirstOrDefaultAsync(r => r.RoleId == request.Role_Id);
                if (role == null)
                {
                    throw new Exception($"Role '{request.Role_Id}' not found.");
                }

                var user = await _context.Users.FirstOrDefaultAsync(u => u.Emp_code == request.Emp_code);
                if (user == null)
                {
                    throw new Exception("User record not found.");
                }

                string TeamName = "Unassigned"; // Default value
                if (request.TeamId != 0)
                {
                    var team = await _context.Teaminfo
                        .Where(t => t.Team_id == request.TeamId)
                        .Select(t => t.Team_name)
                        .FirstOrDefaultAsync();
                    if (!string.IsNullOrEmpty(team))
                    {
                        TeamName = team;
                    }
                }

                // **Fetch the reporting manager's name**
                string ReportingToName = "Unassigned";
                if (request.ReportingId.HasValue)
                {
                    var ReportingUser = await _context.UsersInfo
                        .FirstOrDefaultAsync(u => u.Emp_code == request.ReportingId.Value);
                    if (ReportingUser != null)
                    {
                        ReportingToName = ReportingUser.User_name;
                    }
                }


                // Check if user is part of any active team
                //bool isInTeam = await _context.Teaminfo
                //    .AnyAsync(t => t.Manager_id == userDetails.Emp_code && !t.IsDelete);

                //// Check if user is managing or assigned to any active project
                //bool isInProject = await _context.ProjectInfo
                //    .AnyAsync(p => p.Manager_id == userDetails.Emp_code && !p.isDelete);

                // If user is in team or project, restrict role editing
                //if ((isInTeam || isInProject) && userDetails.Role_Id != request.Role_Id)
                //{
                //    throw new Exception("Role cannot be changed because the employee is assigned to a team or project.");
                //}

                // Check if user is managing or assigned to any active project
                //bool isInProject = await _context.ProjectInfo
                //    .AnyAsync(p => p.Manager_id == userDetails.Emp_code && !p.isDelete);

                //// If user is in team or project, restrict role editing
                //if ((isInTeam || isInProject) && userDetails.Role_Id != request.Role_Id)
                //{
                //    throw new Exception("Role cannot be changed because the employee is assigned to a team or project.");
                //}

                // Update UserDetails fields
                userDetails.User_name = request.UserName;
                userDetails.Email_Id = request.Email;
                userDetails.Designation_Id = request.Designation_Id;
                userDetails.Department_Id = department.DepartmentId;
                userDetails.Status_Id = status.status_id;
                userDetails.Working_Status_Id = workingStatus.working_status_Id;
                userDetails.IsBillable = request.IsBillable;
                userDetails.employmentType_ID = request.employmentType_ID;
                userDetails.Updated_At = DateTime.Now;
                userDetails.Joining_Date = request.JoiningDate;
                userDetails.team_id = request.TeamId;
                userDetails.TeamName = TeamName;
                userDetails.Role_Id = request.Role_Id;
                userDetails.IsAdmin = request.IsAdmin;
                //if (!(isInTeam || isInProject))
                //{
                //    userDetails.Role_Id = role.RoleId;
                //    user.Role_Id = role.RoleId;
                //}

                // Update UsersInfo fields
                usersInfo.Reportingrights = request.Reportingrights;
                usersInfo.ReportingId = request.ReportingId ?? 0;
                usersInfo.ReportingToName = ReportingToName;
                usersInfo.DOB = request.DOB;
                usersInfo.Location = request.Location;
                usersInfo.Marital_status = request.Marital_status;
                usersInfo.Gender = request.Gender;
                usersInfo.Phone_no = request.Phone_no;
                usersInfo.Role_name = role.RoleTitle;
                usersInfo.Emg_ContactName = request.Emg_ContactName;
                usersInfo.Emg_ContactRelation = request.Emg_ContactRelation;
                usersInfo.Emg_ContactPhoneNo = request.Emg_ContactPhoneNo;
                usersInfo.Updated_At = DateTime.Now;
                user.Role_Id = role.RoleId;


                // Save changes
                await _context.SaveChangesAsync();

                // Commit the transaction
                await transaction.CommitAsync();
            }
            catch
            {
                await transaction.RollbackAsync();
                throw;
            }
        }


        // delete user( soft delete)
        public async Task<bool> DeleteUserAsync(int emp_code)
        {
            var user = await _context.UserDetails
                .FirstOrDefaultAsync(u => u.Emp_code == emp_code && u.Status_Id == 2 && !u.IsDelete);

            var usersInfo = await _context.UsersInfo.FirstOrDefaultAsync(u => u.Emp_code == emp_code);
           

            if (user == null)
                return false; // User not found, not inactive, or already deleted
            // Proceed with soft delete
            user.IsDelete = true;
            user.Updated_At = DateTime.Now;

            await _context.SaveChangesAsync();
            return true;
        }
    }
}
