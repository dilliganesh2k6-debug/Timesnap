﻿namespace LoginAppApi.Models 
{ 
    public class Screen 
    { 
        public int ScreenId { get; set; } 
        public string ScreenName { get; set; }   
        public string Role { get; set; }    
        public bool IsVisible { get; set; }   
    } 
}

