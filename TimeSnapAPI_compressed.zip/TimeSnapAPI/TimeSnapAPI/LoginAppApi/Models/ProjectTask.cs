﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
namespace LoginAppApi.Models
{
    public class ProjectTask
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Task_Id { get; set; }
        public int Project_Id { get; set; }
        //public int category_Id { get; set; }
        //public int sub_category_Id { get; set; }
        public string Task_Name { get; set; }
        public string? Task_Desc { get; set; }
        public decimal? Estimated_hours { get; set; }
        public decimal Actual_hours { get; set; } = 0;
        public decimal Overhead_hours { get; set; } = 0;
        public int Status_id { get; set; }
        public DateTime created_at { get; set; }
        public DateTime updated_at { get; set; }
        public bool IsBillable { get; set; } = false;
        //public int? CreatedBy { get; set; }
        //public int? UpdatedBy { get; set; }
        //public int? DeletedBy { get; set; }

    }

}
public class UpdateProjectTaskRequest
{
    public decimal Estimated_hours { get; set; }
    public int Status_id { get; set; }
    public bool Billable { get; set; }
    //public int? UpdatedBy { get; set; }

}
public class CreateProjectTaskDto
{
    public int Project_Id { get; set; }
    //public int category_Id { get; set; }
    //public int sub_category_Id { get; set; }
    public string Task_Name { get; set; } = string.Empty; 

    public bool IsBillable { get; set; } = false;
    public string? Task_Desc { get; set; }
    public decimal? Estimated_hours { get; set; }
    //public int? CreatedBy { get; set; }
    //public int? UpdatedBy { get; set; }
}

public class CreateProjectTaskItemDto
{
    public string Task_Name { get; set; }
    public string? Task_Desc { get; set; }
    public decimal? Estimated_hours { get; set; }
    public bool IsBillable { get; set; }
}

public enum ConflictResolutionStrategy
{
    Skip = 0,
    Overwrite = 1,
    AddAsCopy = 2
}

public class BulkCreateProjectTaskDto
{
    public int Project_Id { get; set; }
    public List<CreateProjectTaskItemDto> Tasks { get; set; }
    public ConflictResolutionStrategy Strategy { get; set; } = ConflictResolutionStrategy.Skip;
}

public class BulkCreateResultDto
{
    public string Message { get; set; }
    public int AddedCount { get; set; }
    public int UpdatedCount { get; set; }
    public int SkippedCount { get; set; }
    public List<BulkTaskErrorDto> Errors { get; set; } = new List<BulkTaskErrorDto>();
}

public class BulkTaskErrorDto
{
    public string TaskName { get; set; }
    public string Error { get; set; }
}





