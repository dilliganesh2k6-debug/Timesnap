﻿namespace LoginAppApi.Models
{
    public class EmploymentType
    {
        public int EmploymentTypeId { get; set; }
        public string EmploymentTypeName { get; set; }
   }
}
