﻿namespace LoginAppApi.Models
{
    public class ProjectView
    {
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string DepartmentName { get; set; }
        public string ProjectStatus { get; set; }
        public int DepartmentId { get; set; }
        public int status_Id { get; set; }
        public Boolean IsDelete { get; set; }
        public string ProjectManagers { get; set; }

    }
}