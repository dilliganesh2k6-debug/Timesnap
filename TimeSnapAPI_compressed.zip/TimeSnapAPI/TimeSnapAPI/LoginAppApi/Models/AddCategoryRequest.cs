﻿using LoginAppApi.Models.Enums;

namespace LoginAppApi.Models
{
    public class AddCategoryRequest
    {
        public string CategoryName { get; set; }
        public string CategoryDescription { get; set; }
        public CategoryType Type { get; set; } //  Enum instead of string
    }
}
