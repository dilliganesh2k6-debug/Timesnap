﻿using System.ComponentModel.DataAnnotations;

namespace LoginAppApi.Models

{ 
    public class TeamManagementView

    {
        public int TeamId { get; set; } 
        public string TeamName { get; set; } 
        public string ManagerName { get; set; }
        public int Manager_id { get; set; } 
        public int Status_Id { get; set; } 
        public string TeamStatus { get; set; } 
        public Boolean IsDelete { get; set; }

    }

}
