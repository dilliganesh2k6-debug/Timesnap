﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LoginAppApi.Models
{
    [Table("ProjectManagers")]
    public class ProjectManagers
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Column("Project_id")]
        public int ProjectId { get; set; }

        [Column("Manager_id")]
        public int ManagerId { get; set; }
        public bool IsActive { get; set; } = true;
        public DateTime? Assigned_Date { get; set; }
    }
}
