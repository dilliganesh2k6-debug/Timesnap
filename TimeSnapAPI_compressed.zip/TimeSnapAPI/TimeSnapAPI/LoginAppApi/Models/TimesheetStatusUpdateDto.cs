﻿namespace LoginAppApi.Models
{
    public class TimesheetStatusUpdateDto
    {
        public int EmpCode { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string Status { get; set; }
    }
}