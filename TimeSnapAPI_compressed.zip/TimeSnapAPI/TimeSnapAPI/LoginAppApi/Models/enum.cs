﻿namespace LoginAppApi.Models
{
    public enum statusrole
    {
        Employee ,
        Manager ,
        Admin ,
        SuperAdmin 
    } 
}