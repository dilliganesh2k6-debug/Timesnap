﻿namespace LoginAppApi.Models

{
    public class TaskEntity

    {
        public int Id { get; set; }
        public string TaskName { get; set; }
        public string Description { get; set; }
        public int CategoryId { get; set; }
        public DateTime CreatedAt { get; set; }
        public bool IsDeleted { get; set; } = false;
    }
    public class TaskDto
    {
        public int sub_category_Id { get; set; }
        public string TaskName { get; set; }
        public string Description { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public bool Billable { get; set; }
    }
}
