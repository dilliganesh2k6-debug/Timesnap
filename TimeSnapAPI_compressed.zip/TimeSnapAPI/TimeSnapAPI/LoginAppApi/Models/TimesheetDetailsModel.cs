﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using LoginAppApi.Models;
namespace TimeTrackerApplication.Models
{
    [Table("TimesheetDetails")]
    public class TimesheetDetailsModel
    {
        [Key]
        [Column(Order = 1)]
        public int Timesheet_Id { get; set; }
        [Required]
        public int Emp_code { get; set; }
        [Key]
        [Column(Order = 2)]
        public int Task_Id { get; set; }
        [Required]
        public int Project_Id { get; set; }
        [Key]
        [Column(Order = 3)]
        public DateTime Date { get; set; }
        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal Hours { get; set; }
        [NotMapped]
        public string Computed_Timesheet_Id { get; set; }
        [Column("Reporting_To_Id")]
        public int? ReportingToId { get; set; }
        public string Status { get; set; }
        [Column("category_Id")]
        public int CategoryId { get; set; }
        [Column("sub_category_Id")]
        public int SubCategoryId { get; set; }
        [Required]
        [Column("IsDeleted")]
        public int IsDeleted { get; set; } = 0;

    }
}

