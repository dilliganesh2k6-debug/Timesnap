﻿using System.ComponentModel.DataAnnotations;

namespace LoginAppApi.Models
{
    public class ScreenRightsView
    {
        [Key]
        public int ScreenRightId { get; set; }
        public int ScreenId { get; set; }
        public string ScreenName { get; set; }
        public int RoleId { get; set; }
        public string RoleTitle { get; set; }
        public bool IsEditable { get; set; }
        public string AccessFieldName { get; set; }
    }
}