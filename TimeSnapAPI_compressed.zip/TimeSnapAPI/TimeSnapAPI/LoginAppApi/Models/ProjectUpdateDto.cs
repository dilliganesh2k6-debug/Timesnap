﻿namespace LoginAppApi.Models
{
    public class ProjectUpdateDto
    {
        public int Department_Id { get; set; }
        public int Status_Id { get; set; }
        public List<int> Managers { get; set; }
    }
}
