﻿namespace LoginAppApi.Models
{
    public class TaskStatusUpdate
    {
        public int TaskId { get; set; }
        public DateTime Date { get; set; }
        public string? Status { get; set; }
        public string? Notes { get; set; }
    }
}
