﻿namespace LoginAppApi.Models
{
    public class ProjectTaskResourceAnalytics
    {
        public int ProjectID { get; set; }
        public string ProjectName { get; set; }

        public int TaskID { get; set; }
        public string TaskName { get; set; }
        public decimal EstimatedHours { get; set; }
        public decimal ActualHours { get; set; }
        //public decimal OverheadHours { get; set; }
        public int TaskStatusId { get; set; }
        public string StatusName { get; set; }
        public int EmpCode { get; set; }
        public string EmployeeName { get; set; }
        public decimal ProductivityPercent { get; set; }
        public bool IsIdleResource { get; set; }
    }
}
