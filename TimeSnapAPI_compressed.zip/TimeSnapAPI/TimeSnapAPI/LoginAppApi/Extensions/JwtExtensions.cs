﻿using System.Security.Claims;

namespace LoginAppApi.Extensions
{
    public static class JwtExtensions
    {
        public static int GetEmpCode(this ClaimsPrincipal user)
        {
            var empCodeClaim = user.Claims.FirstOrDefault(c => c.Type == "empCode");
            return empCodeClaim != null && int.TryParse(empCodeClaim.Value, out int empCode)
                ? empCode
                : 0;
        }
    }
}
