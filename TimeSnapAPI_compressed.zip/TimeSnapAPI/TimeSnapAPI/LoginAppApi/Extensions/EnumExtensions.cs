using System.Reflection;
using System.Runtime.Serialization;

namespace LoginAppApi.Extensions
{
    public static class EnumExtensions
    {
        /// <summary>
        /// Returns the [EnumMember(Value = "...")] string for an enum value.
        /// Falls back to the enum name if no attribute is present.
        /// </summary>
        public static string GetDisplayName(this Enum value)
        {
            var field = value.GetType().GetField(value.ToString());
            if (field == null) return value.ToString();

            var attribute = field.GetCustomAttribute<EnumMemberAttribute>();
            return attribute?.Value ?? value.ToString();
        }
    }
}
