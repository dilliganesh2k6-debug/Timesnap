﻿using LoginAppApi.Data;
using LoginAppApi.Extensions;
using LoginAppApi.Models;
using LoginAppApi.Models.Enums;
using LoginAppApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;


namespace LoginAppApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class UserManagementController : ControllerBase
    {
        private readonly UserManagementService _service;
        private readonly LoginAppDbContext _context;
        private readonly IAuditLogService _auditLogService;
        public UserManagementController(UserManagementService service, LoginAppDbContext context, IAuditLogService auditLogService) 
        {
            _service = service;
            _context = context;
            _auditLogService = auditLogService;
        }

        //GET
        //[HttpGet]
        //public async Task<IActionResult> GetAllUsers()
        //{
        //    int empCode = User.GetEmpCode();

        //    var users = await _service.GetAllUsersAsync();
        //    // Custom sort order: Active (1), then Break (12), then the rest
        //    var sortedUsers = users
        //        .OrderBy(u => u.status_Id == 1 ? 0 : u.status_Id == 12 ? 1 : 2)
        //        .ThenByDescending(u => u.Created_At); 
        //    return Ok(sortedUsers);

        //}

        [HttpGet]
        public async Task<IActionResult> GetAllUsers()
        {
            int empCode = User.GetEmpCode();

            // 🔹 Get logged-in user details
            var loggedInUser = await _context.UserDetails
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.Emp_code == empCode && !u.IsDelete);

            if (loggedInUser == null)
                return Unauthorized("Invalid user");

            bool isAdmin = loggedInUser.IsAdmin;

            var users = await _service.GetAllUsersAsync(empCode, isAdmin);

            // 🔹 Custom sort order
            var sortedUsers = users
                .OrderBy(u => u.status_Id == 1 ? 0 : u.status_Id == 12 ? 1 : 2)
                .ThenByDescending(u => u.Created_At);

            return Ok(sortedUsers);
        }


        //ADD
        //[HttpPost]
        //[Authorize]
        //public async Task<IActionResult> AddUser([FromBody] AddUserRequest request)
        //{
        //    int loggedInEmpCode = User.GetEmpCode();

        //    if (!ModelState.IsValid)
        //    {
        //        var errors = ModelState.Values.SelectMany(v => v.Errors)
        //                                    .Select(e => e.ErrorMessage)
        //                                    .ToList();
        //        return BadRequest(new { success = false, message = "Validation failed", errors });
        //    }
        //    try
        //    {
        //        var response = await _service.AddUserAsync(request, loggedInEmpCode);
        //        if (!response.Success)
        //        {
        //            return BadRequest(new { success = false, message = response.Message });
        //        }
        //        return StatusCode(StatusCodes.Status201Created, new { success = true, message = "User added successfully." });
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(StatusCodes.Status500InternalServerError, new { success = false, message = "An error occurred.", error = ex.Message });
        //    }
        //}

        [HttpPost]
        //[Authorize]
        public async Task<IActionResult> AddUser([FromBody] AddUserRequest request)
        {
            int loggedInEmpCode = User.GetEmpCode();

            //if (!ModelState.IsValid)
            //    return BadRequest(ModelState);

            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors)
                                            .Select(e => e.ErrorMessage)
                                            .ToList();
                return BadRequest(new { success = false, message = "Validation failed", errors });
            }

            try
                {
                var response = await _service.AddUserAsync(request);

                //if (!response.Success)
                //    return BadRequest(response.Message);
                if (!response.Success)
                {
                    return BadRequest(new { success = false, message = response.Message });
                }

                // 🔹 AUDIT (CREATE USER)
                try
                    {
                    var auditValue = new
                    {
                        request.Emp_code,
                        request.UserName,
                        request.Email,
                        request.Role_Id,
                        request.Department_Id,
                        request.TeamId,
                        request.IsAdmin
                    };

                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = loggedInEmpCode,
                        TargetEmpCode = request.Emp_code,
                        ModuleName = AuditModule.UserManagement.GetDisplayName(),
                        ActionType = AuditAction.CREATE.ToString(),
                        EntityName = AuditEntity.UserDetails.ToString(),
                        NewValue = JsonSerializer.Serialize(auditValue),
                        Remarks = "New user created"
                    });
                }
                catch { }

                //return StatusCode(201, "User added successfully.");
                return StatusCode(StatusCodes.Status201Created, new { success = true, message = "User added successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { success = false, message = "An error occurred.", error = ex.Message });
            }
        }


        //UPDATE
        //[HttpPost("update/{emp_code}")]
        //public async Task<IActionResult> UpdateUser(string emp_code, [FromBody] UpdateUserRequest request)
        //{
        //    int loggedInEmpCode = User.GetEmpCode();

        //    if (!int.TryParse(emp_code, out int emp_codeInt))
        //    {
        //        return BadRequest("Invalid employee code in the URL.");
        //    }

        //    if (emp_codeInt != request.Emp_code)
        //    {
        //        return BadRequest("Employee code in the URL does not match the request body.");
        //    }

        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    try
        //    {
        //        var user = await _context.UserDetails
        //            .FirstOrDefaultAsync(u => u.Emp_code == request.Emp_code);

        //        if (user == null)
        //        {
        //            return NotFound("User not found.");
        //        }

        //        // Check if ReportingRights is being set to false 
        //        var userInfo = await _context.UsersInfo
        //            .FirstOrDefaultAsync(u => u.Emp_code == request.Emp_code);

        //        if (userInfo?.Reportingrights == true && request.Reportingrights == false)
        //        {
        //            var hasReportees = await _context.UsersInfo  // Check if any reportees are assigned to this user
        //                .AnyAsync(u => u.ReportingId == request.Emp_code);

        //            if (hasReportees)
        //            {
        //                return BadRequest(new
        //                {
        //                    message = $"{user.User_name}'s reporting rights cannot be removed because employees are reporting to them."
        //                });
        //            }
        //        }

        //        // Check for Inactive or Break status changes
        //        if (request.StatusId == 2 || request.StatusId == 11)
        //        {
        //            // For Inactive: Check if assigned to a project
        //            if (request.StatusId == 2)
        //            {
        //                var isAssigned = await _context.ProjectMembers
        //                    .AnyAsync(p => p.Emp_code == request.Emp_code && !p.IsDeleted && p.projectid != 0);

        //                if (isAssigned)
        //                {
        //                    return BadRequest(new
        //                    {
        //                        message = $"{user.User_name} is assigned to a project and cannot be inactivated."
        //                    });
        //                }
        //            }

        //            // Admin fallback for reportees reassignments
        //            if (userInfo?.Reportingrights == true)
        //            {
        //                var reportees = await _context.UsersInfo
        //                    .Where(u => u.ReportingId == request.Emp_code)
        //                    .ToListAsync();

        //                if (reportees.Any())
        //                {
        //                    const int adminId = 461;  // Admin ID

        //                    // Fetch admin's name from UserDetails
        //                    var admin = await _context.UserDetails
        //                        .Where(u => u.Emp_code == adminId)
        //                        .Select(u => u.User_name)
        //                        .FirstOrDefaultAsync();

        //                    if (string.IsNullOrEmpty(admin))
        //                    {
        //                        return BadRequest("Default admin user not found. Cannot reassign reportees.");
        //                    }

        //                    foreach (var reportee in reportees)
        //                    {
        //                        reportee.ReportingId = adminId;
        //                        reportee.ReportingToName = admin;
        //                        reportee.Updated_At = DateTime.Now;
        //                    }

        //                    // Save changes
        //                    await _context.SaveChangesAsync();
        //                }
        //            }
        //        }
        //        await _service.UpdateUserAsync(request, loggedInEmpCode);

        //        return Ok("User updated successfully.");
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
        //    }
        //}

        [HttpPost("update/{emp_code}")]
        public async Task<IActionResult> UpdateUser(string emp_code, [FromBody] UpdateUserRequest request)
        {
            int loggedInEmpCode = User.GetEmpCode();

            if (!int.TryParse(emp_code, out int empCodeInt))
                return BadRequest("Invalid employee code.");

            if (empCodeInt != request.Emp_code)
                return BadRequest("Employee code mismatch.");

            // 🔹 FETCH OLD DATA FOR AUDIT
            var oldUser = await _context.UserDetails
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.Emp_code == request.Emp_code);

            if (oldUser == null)
                return NotFound("User not found.");

            try
            {
                await _service.UpdateUserAsync(request);
                var user = await _context.UserDetails
                    .FirstOrDefaultAsync(u => u.Emp_code == request.Emp_code);

                if (user == null)
                {
                    return NotFound("User not found.");
                }

                // Check if ReportingRights is being set to false 
                var userInfo = await _context.UsersInfo
                    .FirstOrDefaultAsync(u => u.Emp_code == request.Emp_code);

                if (userInfo?.Reportingrights == true && request.Reportingrights == false)
                {
                    var hasReportees = await _context.UsersInfo  // Check if any reportees are assigned to this user
                        .AnyAsync(u => u.ReportingId == request.Emp_code);

                    if (hasReportees)
                    {
                        return BadRequest(new
                        {
                            message = $"{user.User_name}'s reporting rights cannot be removed because employees are reporting to them."
                        });
                    }
                }

                // Check for Inactive or Break status changes
                if (request.StatusId == 2 || request.StatusId == 11)
                {
                    // For Inactive: Check if assigned to a project
                    if (request.StatusId == 2)
                    {
                        var isAssigned = await _context.ProjectMembers
                            .AnyAsync(p => p.Emp_code == request.Emp_code && !p.IsDeleted && p.projectid != 0);

                        if (isAssigned)
                        {
                            return BadRequest(new
                            {
                                message = $"{user.User_name} is assigned to a project and cannot be inactivated."
                            });
                        }
                    }

                    // Admin fallback for reportees reassignments
                    if (userInfo?.Reportingrights == true)
                    {
                        var reportees = await _context.UsersInfo
                            .Where(u => u.ReportingId == request.Emp_code)
                            .ToListAsync();

                        if (reportees.Any())
                        {
                            const int adminId = 461;  // Admin ID

                            // Fetch admin's name from UserDetails
                            var admin = await _context.UserDetails
                                .Where(u => u.Emp_code == adminId)
                                .Select(u => u.User_name)
                                .FirstOrDefaultAsync();

                            if (string.IsNullOrEmpty(admin))
                            {
                                return BadRequest("Default admin user not found. Cannot reassign reportees.");
                            }

                            foreach (var reportee in reportees)
                            {
                                reportee.ReportingId = adminId;
                                reportee.ReportingToName = admin;
                                reportee.Updated_At = DateTime.Now;
                            }

                            // Save changes
                            await _context.SaveChangesAsync();
                        }
                    }
                }
                await _service.UpdateUserAsync(request);

                // 🔹 FETCH NEW DATA
                var newUser = await _context.UserDetails
                    .AsNoTracking()
                    .FirstOrDefaultAsync(u => u.Emp_code == request.Emp_code);

                // 🔹 AUDIT (UPDATE USER)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = loggedInEmpCode,
                        TargetEmpCode = request.Emp_code,
                        ModuleName = AuditModule.UserManagement.GetDisplayName(),
                        ActionType = AuditAction.UPDATE.ToString(),
                        EntityName = AuditEntity.UserDetails.ToString(),
                        OldValue = JsonSerializer.Serialize(oldUser),
                        NewValue = JsonSerializer.Serialize(newUser),
                        Remarks = "User details updated"
                    });
                }
                catch { }

                return Ok("User updated successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        //DELETE
        //[HttpPost("delete/{emp_code}")]
        //public async Task<IActionResult> DeleteUser(string emp_code)
        //{
        //    int loggedInEmpCode = User.GetEmpCode();

        //    // Validate emp_code input
        //    if (!int.TryParse(emp_code, out int emp_codeInt))
        //    {
        //        return BadRequest("Invalid employee code in the URL.");
        //    }
        //    try
        //    {
        //        var result = await _service.DeleteUserAsync(emp_codeInt, loggedInEmpCode);
        //        if (!result)
        //        {
        //            return NotFound("User not found, not inactive, or already deleted.");
        //        }
        //        return Ok("User deleted successfully.");
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
        //    }
        //}

        [HttpPost("delete/{emp_code}")]
        public async Task<IActionResult> DeleteUser(string emp_code)
        {
            int loggedInEmpCode = User.GetEmpCode();

            if (!int.TryParse(emp_code, out int empCodeInt))
                return BadRequest("Invalid employee code.");

            // 🔹 FETCH OLD DATA
            var oldUser = await _context.UserDetails
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.Emp_code == empCodeInt);

            if (oldUser == null)
                return NotFound("User not found.");

            try
            {
                var result = await _service.DeleteUserAsync(empCodeInt);

                if (!result)
                    return BadRequest("User cannot be deleted.");

                // 🔹 AUDIT (DELETE USER)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = loggedInEmpCode,
                        TargetEmpCode = empCodeInt,
                        ModuleName = AuditModule.UserManagement.GetDisplayName(),
                        ActionType = AuditAction.DELETE.ToString(),
                        EntityName = AuditEntity.UserDetails.ToString(),
                        OldValue = JsonSerializer.Serialize(oldUser),
                        Remarks = "User soft deleted"
                    });
                }
                catch { }

                return Ok("User deleted successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


    }
}
