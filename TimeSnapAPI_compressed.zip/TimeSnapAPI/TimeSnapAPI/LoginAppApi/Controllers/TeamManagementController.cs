﻿using LoginAppApi.Data;
using LoginAppApi.Extensions;
using LoginAppApi.Models;
using LoginAppApi.Models.Enums;
using LoginAppApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.Json;
using System.Threading.Tasks;

namespace LoginApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeamManagementController : ControllerBase
    {
        private readonly LoginAppDbContext _context;
        private readonly IAuditLogService _auditLogService;
        public TeamManagementController(LoginAppDbContext context, IAuditLogService auditLogService)
        {
            _context = context;
            _auditLogService = auditLogService;
        }

        // GET
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TeamManagementView>>> GetTeamManagementView()
        {
            // Filter the data where IsDelete is false and Team_id is greater than 0
            var teamManagementData = await _context.TeamManagementView
                .Where(t => t.IsDelete == false && t.TeamId > 0)
                .ToListAsync();

            return Ok(teamManagementData);
        }
        //ADD
        [HttpPost]
        public async Task<ActionResult<TeamInfo>> CreateTeamInfo([FromBody] TeamInfo teamInfo)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            int empCode = User.GetEmpCode();
            //Check if team already exists
            var teamExists = await _context.Teaminfo
                .FirstOrDefaultAsync(t => t.Team_name == teamInfo.Team_name);

            if (teamExists != null)
            {
                //Reactivate if it was soft-deleted
                if (teamExists.IsDelete)
                {
                    teamExists.IsDelete = false;

                    _context.Teaminfo.Update(teamExists);
                    await _context.SaveChangesAsync();

                    return Ok(new { message = "Soft-deleted team reactivated successfully." });
                }
                else
                {
                    //Block duplicate active team
                    return Conflict(new { message = "A team with the same name already exists." });
                }
            }

            // Create new team
            teamInfo.IsDelete = false;
            teamInfo.Created_at = DateTime.Now;

            try
            {
                _context.Teaminfo.Add(teamInfo);
                await _context.SaveChangesAsync();
                // 🔹 AUDIT (CREATE TEAM)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = empCode,
                        TargetEmpCode = null,
                        ModuleName = AuditModule.Team.GetDisplayName(),
                        ActionType = AuditAction.CREATE.ToString(),
                        EntityName = AuditEntity.TeamInfo.ToString(),
                        NewValue = JsonSerializer.Serialize(teamInfo),
                        Remarks = "Team created successfully"
                    });
                }
                catch { }
                return CreatedAtAction(nameof(GetTeamInfoById), new { id = teamInfo.Team_id }, teamInfo);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        //GET by ID
        [HttpGet("{id}")]
        public async Task<ActionResult<TeamInfo>> GetTeamInfoById(int id)
        {
            var teamInfo = await _context.Teaminfo
        .Where(t => t.Team_id == id && t.IsDelete == false)
        .FirstOrDefaultAsync();

            if (teamInfo == null)
            {
                return NotFound();
            }

            return Ok(teamInfo);
        }
        // EDIT
        [HttpPost("update/{id}")]

        public async Task<IActionResult> UpdateTeamInfo(int id, [FromBody] TeamInfo updatedTeamInfo)
        {
            int empCode = User.GetEmpCode();

            var oldTeam = await _context.Teaminfo
           .AsNoTracking()
           .FirstOrDefaultAsync(t => t.Team_id  == id );

            if (id != updatedTeamInfo.Team_id)
                return BadRequest("Team ID mismatch.");

            var existingTeam = await _context.Teaminfo.FindAsync(id);

            if (existingTeam == null)
                return NotFound(new { message = "Team not found." });

            const int InactiveStatusId = 2;
            // Prevent Active → Inactive if assigned to a user
            if (updatedTeamInfo.Status_Id == InactiveStatusId)
            {
                bool isAssignedToUser = await _context.UserDetails
                    .AnyAsync(u => u.team_id == id);  

                if (isAssignedToUser)
                {
                    return BadRequest(new
                    {
                        message = "Team cannot be deactivated because it is assigned to one or more users."
                    });
                }
            }

            // Update team details
            existingTeam.Team_name = updatedTeamInfo.Team_name;
            existingTeam.Status_Id = updatedTeamInfo.Status_Id;

            await _context.SaveChangesAsync();
            var newTeam= await _context.Teaminfo
               .AsNoTracking()
               .FirstOrDefaultAsync(t => t.Team_id == id);

            // 🔹 AUDIT (UPDATE TEAM)
            try
            {
                await _auditLogService.LogAsync(new AuditLog
                {
                    ActorEmpCode = empCode,
                    ModuleName = AuditModule.Team.GetDisplayName(),
                    ActionType = AuditAction.UPDATE.ToString(),
                    EntityName = AuditEntity.TeamInfo.ToString(),
                    OldValue = JsonSerializer.Serialize(oldTeam),
                    NewValue = JsonSerializer.Serialize(newTeam),
                    Remarks = "Team updated"
                });
            }
            catch { }
            return Ok(new { message = "Team updated successfully." });
        }

        // DELETE
        [HttpPost("delete/{id}")]
        public async Task<IActionResult> DeleteTeamInfo(int id)
        {
            int empCode = User.GetEmpCode();
            var teamInfo = await _context.Teaminfo.FindAsync(id);
            if (teamInfo == null)
            {
                return NotFound(new { message = $"TeamInfo with ID {id} not found." });
            }
            
            // Prevent deletion for active teams (status_id == 1)
            if (teamInfo.Status_Id == 1)
            {
                // Clear message about why it can't be deleted
                return BadRequest(new { message = "Active teams cannot be marked as deleted." });
            }

            // If the team has already been marked as deleted, prevent further deletion
            if (teamInfo.IsDelete)
            {
                return BadRequest(new { message = "TeamInfo is already marked as deleted." });
            }
            var oldTeam = JsonSerializer.Serialize(teamInfo);
            teamInfo.IsDelete = true;
            try
            {
                await _context.SaveChangesAsync();
                // 🔹 AUDIT (DELETE TEAM)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = empCode,
                        ModuleName = AuditModule.Team.GetDisplayName(),
                        ActionType = AuditAction.DELETE.ToString(),
                        EntityName = AuditEntity.TeamInfo.ToString(),
                        OldValue = oldTeam,
                        Remarks = $"Team '{teamInfo.Team_name}' deleted"
                    });
                }
                catch { }
                return Ok(new { message = $"Team with ID {id} has been marked as deleted." });
            }
            catch (Exception ex)
            {
                // Return a generic error message to the client
                return StatusCode(500, new { message = "An unexpected error occurred while deleting the team." });
            }
        }
    }
}

