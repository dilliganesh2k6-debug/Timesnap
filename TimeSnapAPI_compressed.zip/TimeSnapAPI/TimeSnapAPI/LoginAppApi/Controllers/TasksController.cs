﻿using LoginAppApi.Data;
using LoginAppApi.Extensions;
using LoginAppApi.Models;
using LoginAppApi.Models.Enums;
using LoginAppApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginAppApi.Controllers

{
    [ApiController]
    [Route("api/[controller]")]
    public class TasksController : ControllerBase
    {
        private readonly LoginAppDbContext _context;
        private readonly IAuditLogService _auditLogService;
        public TasksController(LoginAppDbContext context, IAuditLogService auditLogService)
        {
            _context = context;
            _auditLogService = auditLogService;
        }

        // GET: api/tasks
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TaskDto>>> GetTasks()
        {
            // Only fetch non-deleted tasks
            var tasks = await _context.Tasks
                .Where(t => !t.IsDeleted)
                .OrderByDescending(t => t.CreatedAt)
                 .Join(_context.Categories,

                       task => task.CategoryId,
                       Category => Category.CategoryId,
                       (task, Category) => new TaskDto

                       {
                           sub_category_Id = task.Id,
                           TaskName = task.TaskName,
                           Description = task.Description,
                           CategoryId = task.CategoryId,
                           CategoryName = Category.CategoryName,
                       })
                 .ToListAsync();
            return Ok(tasks);
        }

        // POST: api/tasks
        [HttpPost]
        public async Task<ActionResult<TaskEntity>> CreateTask(TaskEntity taskEntity)
        {
            if (string.IsNullOrEmpty(taskEntity.TaskName) || string.IsNullOrEmpty(taskEntity.Description) || taskEntity.CategoryId <= 0)
            {
                return BadRequest("Task Name and Description are required.");
            }

            // Check for duplicate task name in same category
            var isDuplicate = await _context.Tasks
                .AnyAsync(t => t.TaskName == taskEntity.TaskName && t.CategoryId == taskEntity.CategoryId && !t.IsDeleted);

            if (isDuplicate)
            {
                return BadRequest(new { message = "A task with the same name already exists in this category." });
            }

            var newTaskEntity = new TaskEntity
            {
                TaskName = taskEntity.TaskName,
                Description = taskEntity.Description,
                CategoryId = taskEntity.CategoryId,
                CreatedAt = DateTime.UtcNow
            };

            _context.Tasks.Add(newTaskEntity);
            await _context.SaveChangesAsync();

            // 🔹 AUDIT LOG (CREATE)
            try
            {
                await _auditLogService.LogAsync(new AuditLog
                {
                    ActorEmpCode = User.GetEmpCode(),
                    ModuleName = AuditModule.TaskSubCategory.GetDisplayName(),
                    ActionType = AuditAction.CREATE.ToString(),
                    EntityName = AuditEntity.Tasks.ToString(),
                    NewValue = System.Text.Json.JsonSerializer.Serialize(newTaskEntity),
                    Remarks = $"Task '{newTaskEntity.TaskName}' created"
                });
            }
            catch { }

            return Ok(new TaskEntity
            {
                Id = newTaskEntity.Id,
                TaskName = newTaskEntity.TaskName,
                Description = newTaskEntity.Description,
                CategoryId = newTaskEntity.CategoryId,
            });
        }

        //EDIT
        [HttpPost("update/{id}")]
        public async Task<ActionResult<TaskEntity>> UpdateTaskById(int id, TaskEntity taskEntity)
        {
            var existingTask = await _context.Tasks.FindAsync(id);
            if (existingTask == null)
            {
                return NotFound(new { message = $"Task with ID {id} not found" });
            }
            if (string.IsNullOrWhiteSpace(taskEntity.TaskName) || string.IsNullOrWhiteSpace(taskEntity.Description) || taskEntity.CategoryId <= 0)
            {
                return BadRequest(new { message = "Task Name, Description, and valid Category ID are required." });
            }

            var oldValue = System.Text.Json.JsonSerializer.Serialize(existingTask);

            var normalizedName = taskEntity.TaskName.Trim().ToLower();
            var isDuplicate = await _context.Tasks
                .AnyAsync(t => t.Id != id &&
                               t.CategoryId == taskEntity.CategoryId &&
                               !t.IsDeleted &&
                               t.TaskName.ToLower().Trim() == normalizedName);
            if (isDuplicate)
            {
                return BadRequest(new { message = "A task with the same name already exists in this category." });
            }
            existingTask.TaskName = taskEntity.TaskName;
            existingTask.Description = taskEntity.Description;
            existingTask.CategoryId = taskEntity.CategoryId;

            _context.Entry(existingTask).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();

                // 🔹 AUDIT LOG (UPDATE)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = User.GetEmpCode(),
                        ModuleName = AuditModule.TaskSubCategory.GetDisplayName(),
                        ActionType = AuditAction.UPDATE.ToString(),
                        EntityName = AuditEntity.Tasks.ToString(),
                        OldValue = oldValue,
                        NewValue = System.Text.Json.JsonSerializer.Serialize(existingTask),
                        Remarks = $"Task '{existingTask.TaskName}' updated"
                    });
                }
                catch { }

                return Ok(new TaskEntity
                {
                    Id = existingTask.Id,
                    TaskName = existingTask.TaskName,
                    Description = existingTask.Description,
                    CategoryId = existingTask.CategoryId,
                    CreatedAt = existingTask.CreatedAt,
                    IsDeleted = existingTask.IsDeleted
                });
            }
            catch (DbUpdateConcurrencyException)
            {
                return StatusCode(500, new { message = "Error updating the task. Please try again later." });
            }
        }

        //DELETE
        [HttpPost("delete/{id}")]
        public async Task<ActionResult> DeleteTaskById(int id)
        {
            // Check if the task is assigned to any project
            bool isTaskAssigned = await _context.ProjectTasks.AnyAsync(pt => pt.Task_Id == id);

            if (isTaskAssigned)
            {
                return BadRequest(new { message = $"Cannot delete: Task is assigned to one or more projects." });
            }

            // Find the task
            var task = await _context.Tasks.FindAsync(id);
            if (task == null)
            {
                return NotFound(new { message = $"Task with ID {id} not found." });
            }

            var oldValue = System.Text.Json.JsonSerializer.Serialize(task);

            // Mark the task as deleted (soft delete)
            task.IsDeleted = true;
            _context.Tasks.Update(task);
            await _context.SaveChangesAsync();

            // 🔹 AUDIT LOG (DELETE)
            try
            {
                await _auditLogService.LogAsync(new AuditLog
                {
                    ActorEmpCode = User.GetEmpCode(),
                    ModuleName = AuditModule.TaskSubCategory.GetDisplayName(),
                    ActionType = AuditAction.DELETE.ToString(),
                    EntityName = AuditEntity.Tasks.ToString(),
                    OldValue = oldValue,
                    Remarks = $"Task '{task.TaskName}' deleted"
                });
            }
            catch { }

            return Ok(new { message = $"Task with ID {id} has been marked as deleted." });
        }

        //GET
        [HttpGet("GetCategories")]
        public async Task<IActionResult> GetCategories()
        {
            var categories = await _context.Categories
                .Where(c => !c.IsDeleted)
                .Select(c => new
                {
                    c.CategoryId,
                    c.CategoryName
                })
                .ToListAsync();

            return Ok(categories);
        }

        //GET by ID
        [HttpGet("GetTasksByCategory/{categoryId}")]
        public async Task<IActionResult> GetTasksByCategory(int categoryId)
        {
            var tasks = await _context.Tasks
                .Where(t => t.CategoryId == categoryId && !t.IsDeleted)
                .Join(_context.Categories,
                 task => task.CategoryId,
                       Category => Category.CategoryId,
                       (task, Category) => new TaskDto

                       {
                           sub_category_Id = task.Id,
                           TaskName = task.TaskName,
                           Description = task.Description,
                           CategoryId = task.CategoryId,
                           CategoryName = Category.CategoryName,
                       })
                 .ToListAsync();
            return Ok(tasks);
        }
    }
}

