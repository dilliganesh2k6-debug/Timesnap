﻿using LoginAppApi.Data;
using LoginAppApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LoginAppApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeeController : ControllerBase
    {
        private readonly LoginAppDbContext _context;

        public EmployeeController(LoginAppDbContext context)
        {
            _context = context;
        }

        //GET by ID
        [HttpGet("{employeeCode}/{roleId}")]
        public async Task<ActionResult<EmployeeResponseModel>> GetEmployeeDetails(int employeeCode, int roleId)
        {
            var roleName = await _context.Roles
                .Where(r => r.RoleId == roleId)
                .Select(r => r.RoleTitle)
                .FirstOrDefaultAsync();

            if (roleName == null)
            {
                return NotFound($"Role with ID {roleId} not found.");
            }

            var employee = await _context.EmployeeViewModels
                .Where(e => e.Emp_code == employeeCode)
                .Select(e => new EmployeeViewModel
                {
                    Username = e.Username,
                    Emp_code = e.Emp_code,
                    email_id = e.email_id,
                    PhoneNo = e.PhoneNo,
                    location = e.location,
                    dateofbirth = e.dateofbirth,
                    Gender = e.Gender,
                    MaritalStatus = e.MaritalStatus,
                    Emg_ContactName = e.Emg_ContactName,
                    Emg_ContactPhoneNo = e.Emg_ContactPhoneNo,
                    Emg_ContactRelation = e.Emg_ContactRelation,
                    Designation = e.Designation,
                    DepartmentName = e.DepartmentName,
                    TeamName = e.TeamName,
                    ReportingTo = e.ReportingTo,
                    IsBillable = e.IsBillable,
                    EmploymentType = e.EmploymentType,
                    JoiningDate = e.JoiningDate,
                    employmentType_Id = e.employmentType_Id
                })
                .FirstOrDefaultAsync();

            if (employee == null)
            {
                return NotFound($"Employee with code {employeeCode} not found.");
            }

            var response = new EmployeeResponseModel
            {
                EmployeeData = employee,
                Roletitle = roleName
            };

            return Ok(response);
        }
    }
}
