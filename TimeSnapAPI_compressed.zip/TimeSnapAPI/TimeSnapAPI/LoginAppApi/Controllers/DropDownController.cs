﻿using LoginAppApi.Data;
using LoginAppApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginAppApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DropDownController : ControllerBase
    {
        private readonly LoginAppDbContext _context;

        public DropDownController(LoginAppDbContext context)
        {
            _context = context;
        }

        //GET
        [HttpGet("dropdown")]
        public async Task<ActionResult<IEnumerable<DropdownItemDto>>> GetDropdownData([FromQuery] string type, [FromQuery] int? empCode)
        {
            if (string.IsNullOrWhiteSpace(type))
            {
                return BadRequest(new { message = "Dropdown type is required." });
            }

            IEnumerable<DropdownItemDto> dropdownItems;

            try
            {
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
                dropdownItems = type.ToLower() switch
                {
                    "managers" => _context.UserDetails
                    .Where(u => u.Role_Id == 7001 && u.Status_Id != 2)
                    .Select(u => new DropdownItemDto
                    {
                        Id = u.Emp_code.ToString(),
                        Name = u.User_name
                    }),

                    "projects" => _context.ProjectInfo
      .Where(p => p.isDelete == false)
      .Select(p => new DropdownItemDto
      {
          Id = p.Project_id.ToString(),
          Name = p.Project_name
      }),

                    "projectsbyempcode" when empCode.HasValue =>
                    await (from pm in _context.ProjectMembersView
                           join pi in _context.ProjectInfo on pm.Projectid equals pi.Project_id
                           where pm.EmpCode == empCode.Value
                           select new DropdownItemDto
                           {
                               Id = pi.Project_id.ToString(),
                               Name = pi.Project_name
                           }).ToListAsync(),

                    "reportingto" => await (
                          from ui in _context.UsersInfo
                          join ud in _context.UserDetails on ui.Emp_code equals ud.Emp_code
                          where ui.Reportingrights == true
                        && ud.IsDelete == false
                        && ud.Status_Id == 1
                        && (!empCode.HasValue || ui.Emp_code != empCode.Value)
                          select new DropdownItemDto
                          {
                              Id = ui.Emp_code.ToString(),
                              Name = ui.User_name
                          }
                        ).ToListAsync(),
                    "departments" => _context.Departments
                     .Where(d => d.IsDeleted == false)
                        .Select(d => new DropdownItemDto
                        {
                            Id = d.DepartmentId.ToString(),
                            Name = d.DepartmentName
                        }),

                    "clients" => _context.Clients
                    .Where(c => c.IsDeleted == false)
                        .Select(c => new DropdownItemDto
                        {
                            Id = c.ClientId.ToString(),
                            Name = c.ClientName,
                            Location = c.ClientLocation

                        }),

                    "categories" => _context.Categories
                    .Where(c => c.IsDeleted == false)
                        .Select(cat => new DropdownItemDto
                        {
                            Id = cat.CategoryId.ToString(),
                            Name = cat.CategoryName
                        }),

                    "roles" => _context.Roles
                    .Where(c => c.IsDeleted == false)
                        .Select(r => new DropdownItemDto
                        {
                            Id = r.RoleId.ToString(),
                            Name = r.RoleTitle
                        }),

                    "status" => _context.statusinfo
                        .Select(s => new DropdownItemDto
                        {
                            Id = s.status_id.ToString(),
                            Name = s.status_name
                        }),

                    "activeinactivestatus" => _context.statusinfo
                   .Where(s => s.status_id == 1 || s.status_id == 2 || s.status_id == 11) // Filter statuses

                        .Select(s => new DropdownItemDto
                        {
                            Id = s.status_id.ToString(),
                            Name = s.status_name
                        }),



                    "approvelstatus" => _context.statusinfo
                       .Where(s => s.status_id == 8 || s.status_id == 9 || s.status_id == 10)
                       .Select(s => new DropdownItemDto
                       {
                           Id = s.status_id.ToString(),
                           Name = s.status_name
                       }),

                    "projectstatus" => _context.statusinfo
                    .Where(s => s.status_id == 1 || s.status_id == 2)
                    .Select(s => new DropdownItemDto
                    {
                        Id = s.status_id.ToString(),
                        Name = s.status_name
                    }),

                    "projecttaskstatus" => _context.statusinfo
                       .Where(s => s.status_id == 4 || s.status_id == 5 || s.status_id == 6 || s.status_id == 7)
                       .Select(s => new DropdownItemDto
                       {
                           Id = s.status_id.ToString(),
                           Name = s.status_name
                       }),

                    "tasks" => _context.Tasks
                    .Where(c => c.IsDeleted == false)
                        .Select(t => new DropdownItemDto
                        {
                            Id = t.Id.ToString(),
                            Name = t.TaskName
                        }),

                    "designation" => _context.Designations
                 .Select(d => new DropdownItemDto
                 {
                     Id = d.designationId.ToString(),
                     Name = d.designationname
                 }),

                    "workingstatus" => _context.WorkingstatusInfo
                    .Select(w => new DropdownItemDto
                    {
                        Id = w.working_status_Id.ToString(),
                        Name = w.working_status_name
                    }),

                    "teams" => _context.Teaminfo
                    .Where(t => t.IsDelete == false)
                    .Where(t => t.Status_Id == 1)
                    .Select(t => new DropdownItemDto
                    {
                        Id = t.Team_id.ToString(),
                        Name = t.Team_name
                    }),

                    "employmenttype" => _context.employmentTypes
                    .Select(e => new DropdownItemDto
                    {
                        Id = e.EmploymentTypeId.ToString(),
                        Name = e.EmploymentTypeName
                    }),

                    "users" => _context.UsersInfo
                    .Select(u => new DropdownItemDto
                    {
                        Id = u.Emp_code.ToString(),
                        Name = u.User_name
                    }),

                    "projectcategories" => _context.ProjectCategories

                    .Where(p => p.IsDeleted == false)

                    .Select(p => new DropdownItemDto

                    {

                        Id = p.ProjectCategoryId.ToString(),

                        Name = p.projectCategoryName

                    }),


                    "teamactiveinactivestatus" => _context.statusinfo
                    .Where(s => s.status_id == 1 || s.status_id == 2)
                    .Select(s => new DropdownItemDto
                    {
                        Id = s.status_id.ToString(),
                        Name = s.status_name
                    }),


                    _ => null
                };
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.

                if (dropdownItems == null)
                {
                    return BadRequest(new { message = $"Invalid dropdown type specified: {type}" });
                }

                return Ok(await Task.FromResult(dropdownItems.ToList()));
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred.", details = ex.Message });
            }
        }

        //GET
        [HttpGet("types")]
        public ActionResult<IEnumerable<string>> GetSupportedDropdownTypes()
        {
            // Return a list of supported dropdown types
            var supportedTypes = new List<string> { "managers", "projects", "reportingto", "departments", "clients", "categories", "roles", "status", "tasks", "designation", "workingstatus", "teams", "employmenttype", "users", "projectcategories", "activeinactivestatus", "approvelstatus", "projectstatus", "projecttaskstatus", "projectsbyempcode", "teamactiveinactivestatus" };
            return Ok(supportedTypes);
        }
    }
}
