﻿using LoginAppApi.Data;
using LoginAppApi.Extensions;
using LoginAppApi.Models;
using LoginAppApi.Models.Dto;
using LoginAppApi.Models.Enums;
using LoginAppApi.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection.Emit;
using System.Text.Json;
using System.Threading.Tasks;

namespace LoginAppApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SettingsController : ControllerBase
    {
        private readonly LoginAppDbContext _context;
        private readonly IAuditLogService _auditLogService;
        // Constructor to inject the DbContext
        public SettingsController(LoginAppDbContext context, IAuditLogService auditLogService)
        {
            _context = context;
            _auditLogService = auditLogService;
        }

        // --------------------------- Department APIs --------------------------

        // GET: api/settings/departments
        [HttpGet("departments")]
        public async Task<IActionResult> GetDepartments()
        {
            try
            {
                var departments = await _context.Departments
                    .Where(d => !d.IsDeleted)
                    .OrderByDescending(d => d.CreatedAt)
                    .Select(d => new
                    {
                        d.DepartmentId,
                        d.DepartmentName,
                        d.DepartmentDescription,
                        d.CreatedAt
                    })
                    .ToListAsync();

                return Ok(departments);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error retrieving departments: {ex.Message}" });
            }
        }


        // GET: api/settings/departments/{id}
        [HttpGet("departments/{id}")]
        public async Task<IActionResult> GetDepartment(int id)
        {
            try
            {
                var department = await _context.Departments
                                               .Where(d => d.DepartmentId == id)
                                               .Select(d => new
                                               {
                                                   d.DepartmentId,
                                                   d.DepartmentName,
                                                   d.DepartmentDescription
                                               })
                                               .FirstOrDefaultAsync();

                // Return NotFound if department doesn't exist
                if (department == null)
                {
                    return NotFound($"Department with ID {id} not found.");
                }

                return Ok(department);
            }
            catch (Exception ex)
            {
                return BadRequest($"Error retrieving department with ID {id}: {ex.Message}");
            }
        }

        // POST: api/settings/departments
        [HttpPost("departments/create")]
        public async Task<IActionResult> PostDepartment([FromBody] Department department)
        {

            int empCode = User.GetEmpCode();
            try
            {
                if (department == null)
                {
                    return BadRequest(new { message = "Department data is null." });
                }

                // Check if department name already exists
                department.DepartmentName = department.DepartmentName.Trim();

                var normalizedName = department.DepartmentName.ToLower();

                var existingDepartment = await _context.Departments
                    .FirstOrDefaultAsync(d =>
                        d.DepartmentName.Trim().ToLower() == normalizedName
                    );
                if (existingDepartment != null)
                {
                    if (existingDepartment.IsDeleted)
                    {
                        existingDepartment.IsDeleted = false;
                        existingDepartment.CreatedAt = DateTime.UtcNow;
                        _context.Departments.Update(existingDepartment);
                        await _context.SaveChangesAsync();
                        return Ok(new { message = "Soft-deleted department reactivated successfully." });
                    }
                    else
                    {
                        return Conflict(new { message = "A department with the same name already exists." });
                    }
                }

                department.CreatedAt = DateTime.UtcNow;

                _context.Departments.Add(department);
                await _context.SaveChangesAsync();

                // 🔹 AUDIT (CREATE DEPARTMENT)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = empCode,
                        TargetEmpCode = null,
                        ModuleName = AuditModule.Department.ToString(),
                        ActionType = AuditAction.CREATE.ToString(),
                        EntityName = AuditEntity.Departments.ToString(),
                        NewValue = JsonSerializer.Serialize(department),
                        Remarks = "Department created successfully"
                    });
                }
                catch { }
                return Ok(new { message = "Department created successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error creating department: {ex.Message}" });
            }
        }



        //Edit Department
        [HttpPost("departments/update/{departmentId}")]
        public async Task<IActionResult> UpdateDepartment(int departmentId, [FromBody] Department UpdateDepartment)
        {
            int empCode = User.GetEmpCode();

            var oldDepartment = await _context.Departments
            .AsNoTracking()
            .FirstOrDefaultAsync(dt => dt.DepartmentId == departmentId);

            if (departmentId != UpdateDepartment.DepartmentId)
            {
                return BadRequest("Department ID in the URL does not match the ID in the body.");
            }
            var existingDepartment = await _context.Departments
           .FirstOrDefaultAsync(d => d.DepartmentName == UpdateDepartment.DepartmentName && d.DepartmentId != departmentId);

            if (existingDepartment != null)
            {
                return Conflict(new { message = "A department with the same name already exists." });
            }

            var existingDepartmentInfo = await _context.Departments.FindAsync(departmentId);
            if (existingDepartmentInfo == null)
            {
                return NotFound($"Departments with ID {departmentId} not found.");
            }
            existingDepartmentInfo.DepartmentName = UpdateDepartment.DepartmentName;
            existingDepartmentInfo.DepartmentDescription = UpdateDepartment.DepartmentDescription;
            try
            {
                await _context.SaveChangesAsync();
                var newDepartment = await _context.Departments
                .AsNoTracking()
                .FirstOrDefaultAsync(dt => dt.DepartmentId == departmentId);

                // 🔹 AUDIT (UPDATE DEPARTMENT)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = empCode,
                        ModuleName = AuditModule.Department.ToString(),
                        ActionType = AuditAction.UPDATE.ToString(),
                        EntityName = AuditEntity.Departments.ToString(),
                        OldValue = JsonSerializer.Serialize(oldDepartment),
                        NewValue = JsonSerializer.Serialize(newDepartment),
                        Remarks = "Department updated"
                    });
                }
                catch { }
                return Ok("Department updated successfully.");
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return StatusCode(500, $" error: {ex.Message}");
            }
        }

        // Delete Department
        [HttpPost("departments/delete/{id}")]
        public async Task<IActionResult> DeleteDepartment(int id)
        {
            int empCode = User.GetEmpCode();
            var department = await _context.Departments.FindAsync(id);

            if (department == null)
            {
                return NotFound(new { message = $"Department with ID {id} not found." });
            }

            // Check references in other tables before deleting
            bool isInUse = await _context.UserDetails.AnyAsync(u => u.Department_Id == id)
                        || await _context.ProjectInfo.AnyAsync(p => p.Department_Id == id);

            if (isInUse)
            {
                return BadRequest(new { message = $"Cannot delete {department.DepartmentName} because it is assigned to users or projects." });
            }

            try
            {
                var oldDepartment = JsonSerializer.Serialize(department);
                _context.Departments.Remove(department);   // HARD DELETE
                await _context.SaveChangesAsync();
                // 🔹 AUDIT (DELETE DEPARTMENT)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = empCode,
                        ModuleName = AuditModule.Department.ToString(),
                        ActionType = AuditAction.DELETE.ToString(),
                        EntityName = AuditEntity.Departments.ToString(),
                        OldValue = oldDepartment,
                        Remarks = $"Department '{department.DepartmentName}' deleted"
                    });
                }
                catch { }
                return Ok(new { message = $"Department {department.DepartmentName} has been permanently deleted." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error deleting Department with ID {id}", details = ex.Message });
            }
        }


        //[HttpDelete("departments/{id}")]
        //public async Task<IActionResult> DeleteDepartment(int id)
        //{
        //    var department = await _context.Departments.FindAsync(id);

        //    if (department == null)
        //    {
        //        return NotFound($"Department with ID {id} not found.");
        //    }

        //    // Check references in other tables before deleting
        //    bool isInUse = await _context.UserDetails.AnyAsync(u => u.Department_Id == id)
        //                || await _context.ProjectInfo.AnyAsync(p => p.Department_Id == id);

        //    if (isInUse)
        //    {
        //        return BadRequest(new { message = $"Cannot delete {department.DepartmentName} Department is assigned to users or projects " });
        //    }

        //    // Proceed with soft delete
        //    department.IsDeleted = true;
        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //        return Ok(new { message = $"Department {department.DepartmentName} has been successfully deleted." });
        //    }

        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, $"Error deleting Department with ID {id}: {ex.Message}");
        //    }
        //}

        // --------------------------- Category APIs --------------------------

        //Get category
        [HttpGet("GetAllCategories")]
        public async Task<IActionResult> GetAllCategories()
        {
            var categories = await _context.CategoriesView
                .Where(cat => cat.IsDeleted == false)
                .OrderByDescending(cat => cat.CreatedDate)
                .ToListAsync();

            return Ok(categories);
        }

        //Add Category
        [HttpPost("AddCategory")]
        public async Task<IActionResult> AddCategory([FromBody] AddCategoryRequest request)
        {
            int empCode = User.GetEmpCode();
            if (request == null || string.IsNullOrWhiteSpace(request.CategoryName))
                return BadRequest(new { message = "Invalid request data." });

            request.CategoryName = request.CategoryName.Trim();
            var normalizedName = request.CategoryName.ToLower();
            if (request.Type == CategoryType.TaskCategories)
            {
                var existingCategory = await _context.Categories
                    .FirstOrDefaultAsync(c =>
                    c.CategoryName.Trim().ToLower() == normalizedName
                     );
                if (existingCategory != null)
                {
                    if (existingCategory.IsDeleted)
                    {
                        existingCategory.IsDeleted = false;
                        existingCategory.CategoryDescription = request.CategoryDescription;
                        existingCategory.CreatedDate = DateTime.UtcNow;
                        _context.Categories.Update(existingCategory);
                        await _context.SaveChangesAsync();

                        return Ok(new { message = "Soft-deleted task category reactivated and updated successfully." });
                    }

                    return Conflict(new { message = "A task category with the same name already exists." });
                }

                _context.Categories.Add(new TaskCategories
                {
                    CategoryName = request.CategoryName,
                    CategoryDescription = request.CategoryDescription,
                    CreatedDate = DateTime.UtcNow
                });
            }
            else if (request.Type == CategoryType.ProjectCategories)
            {
                var existingProjectCategory = await _context.ProjectCategories
                    .FirstOrDefaultAsync(pc =>
                    pc.projectCategoryName.Trim().ToLower() == normalizedName
                    );
                if (existingProjectCategory != null)
                {
                    if (existingProjectCategory.IsDeleted)
                    {
                        existingProjectCategory.IsDeleted = false;
                        existingProjectCategory.ProjectCategoryDescription = request.CategoryDescription; // ✅ Update description
                        existingProjectCategory.CreatedDate = DateTime.UtcNow;
                        _context.ProjectCategories.Update(existingProjectCategory);
                        await _context.SaveChangesAsync();

                        return Ok(new { message = "Soft-deleted project category reactivated and updated successfully." });
                    }

                    return Conflict(new { message = "A project category with the same name already exists." });
                }

                _context.ProjectCategories.Add(new ProjectCategories
                {
                    projectCategoryName = request.CategoryName,
                    ProjectCategoryDescription = request.CategoryDescription,
                    CreatedDate = DateTime.UtcNow
                });
            }
            else
            {
                return BadRequest(new { message = "Invalid category type." });
            }

            await _context.SaveChangesAsync();
            try
            {
                await _auditLogService.LogAsync(new AuditLog
                {
                    ActorEmpCode = empCode,
                    TargetEmpCode = null,
                    ModuleName = AuditModule.TaskCategory.GetDisplayName(),
                    ActionType = AuditAction.CREATE.ToString(),
                    EntityName = AuditEntity.Categories.ToString(),
                    NewValue = JsonSerializer.Serialize(request),
                    Remarks = $"{request.Type} created successfully."
                });
            }
            catch { }
            return Ok(new { message = $"{request.Type} added successfully." });
        }

        //Edit category
        [HttpPost("UpdateCategory/{id}")]
        public async Task<IActionResult> UpdateCategory(int id, [FromBody] CategoryDto categoryDto)
        {
            int empCode = User.GetEmpCode();
            if (categoryDto == null || id <= 0 || string.IsNullOrWhiteSpace(categoryDto.Name))
                return BadRequest(new { message = "Invalid request data." });

            if (categoryDto.Type == CategoryType.TaskCategories)
            {
                var oldvalue = await _context.Categories
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.CategoryId == id);

                var existingTaskCategory = await _context.Categories.FirstOrDefaultAsync(c => c.CategoryId == id);
                if (existingTaskCategory == null)
                    return NotFound(new { message = "Category not found." });
                bool categoryExists = await _context.Categories.AnyAsync(c => c.CategoryName == categoryDto.Name && c.CategoryId != categoryDto.Id);
                if (categoryExists)
                {
                    return BadRequest(new { message = "Category already exists." });
                }
                existingTaskCategory.CategoryName = categoryDto.Name;
                existingTaskCategory.CategoryDescription = categoryDto.Description;
                await _context.SaveChangesAsync();

                var newValue = await _context.Categories
                    .AsNoTracking()
                    .FirstOrDefaultAsync(c => c.CategoryId == id);
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = empCode,
                        ModuleName = AuditModule.TaskCategory.GetDisplayName(),
                        ActionType = AuditAction.UPDATE.ToString(),
                        EntityName = AuditEntity.Categories.ToString(),
                        OldValue = JsonSerializer.Serialize(oldvalue),
                        NewValue = JsonSerializer.Serialize(newValue),
                        Remarks = $"{categoryDto.Type} updated"
                    });
                }
                catch { }
            }
            else if (categoryDto.Type == CategoryType.ProjectCategories)
            {
                 var oldvalue = await _context.ProjectCategories
                .AsNoTracking()
                .FirstOrDefaultAsync(pc => pc.ProjectCategoryId == id);

                var existingProjectCategory = await _context.ProjectCategories.FirstOrDefaultAsync(pc => pc.ProjectCategoryId == id);
                if (existingProjectCategory == null)
                    return NotFound(new { message = "Project Category not found." });

                bool projectCategoryExists = await _context.ProjectCategories.AnyAsync(pc => pc.projectCategoryName == categoryDto.Name && pc.ProjectCategoryId != categoryDto.Id);
                if (projectCategoryExists)
                {
                    return BadRequest(new { message = "Project Category already exists." });
                }

                existingProjectCategory.projectCategoryName = categoryDto.Name;
                existingProjectCategory.ProjectCategoryDescription = categoryDto.Description;
                await _context.SaveChangesAsync();

                var newValue = await _context.ProjectCategories
                    .AsNoTracking()
                    .FirstOrDefaultAsync(pc => pc.ProjectCategoryId == id);
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = empCode,
                        ModuleName = AuditModule.TaskCategory.GetDisplayName(),
                        ActionType = AuditAction.UPDATE.ToString(),
                        EntityName = AuditEntity.Categories.ToString(),
                        OldValue = JsonSerializer.Serialize(oldvalue),
                        NewValue = JsonSerializer.Serialize(newValue),
                        Remarks = $"{categoryDto.Type} updated"
                    });
                }
                catch { }
            }
          
            return Ok(new { message = $"{categoryDto.Type} updated successfully." });
        }

        //Delete category
        [HttpPost("DeleteCategory/{id}")]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            int empCode = User.GetEmpCode();
            if (id <= 0)
                return BadRequest(new { message = "Invalid category ID." });
            // Check if the category is referenced in Tasks
            bool isTaskCategoryUsed = await _context.Tasks.AnyAsync(t => t.CategoryId == id);
            bool isProjectCategoryUsed = await _context.ProjectInfo.AnyAsync(p => p.ProjectCategoryId == id);

            if (isTaskCategoryUsed || isProjectCategoryUsed)
            {
                return BadRequest(new { message = $"Cannot delete category because they are assigned to one or more active projects." });
            }

            var existingTaskCategory = await _context.Categories.FirstOrDefaultAsync(c => c.CategoryId == id);
            if (existingTaskCategory != null)
            {
                var oldTaskCategory = JsonSerializer.Serialize(existingTaskCategory);
                existingTaskCategory.IsDeleted = true;
                await _context.SaveChangesAsync();
                // 🔹 AUDIT (DELETE TASK CATEGORY)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = empCode,
                        ModuleName = AuditModule.TaskCategory.GetDisplayName(),
                        ActionType = AuditAction.DELETE.ToString(),
                        EntityName = AuditEntity.Categories.ToString(),
                        OldValue = oldTaskCategory,
                        Remarks = $"Category '{existingTaskCategory.CategoryName}' deleted"
                    });
                }
                catch { }
                return Ok(new { message = "Category marked as deleted." });
            }

            var existingProjectCategory = await _context.ProjectCategories.FirstOrDefaultAsync(pc => pc.ProjectCategoryId == id);
            if (existingProjectCategory != null)
            {
                var oldProjectCategory = JsonSerializer.Serialize(existingProjectCategory);
                existingProjectCategory.IsDeleted = true; // Soft delete
                await _context.SaveChangesAsync();
                // 🔹 AUDIT (DELETE PROJECT CATEGORY)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = empCode,
                        ModuleName = AuditModule.ProjectCategory.GetDisplayName(),
                        ActionType = AuditAction.DELETE.ToString(),
                        EntityName = AuditEntity.ProjectCategories.ToString(),
                        OldValue = oldProjectCategory,
                        Remarks = $"Category '{existingProjectCategory.projectCategoryName}' deleted"
                    });
                }
                catch { }

                return Ok(new { message = "Project Category marked as deleted." });
            }
            return NotFound(new { message = "Category not found." });
        }


        // --------------------------- roles APIs --------------------------
        // GET: api/settings/roles
        [HttpGet("roles")]
        public async Task<IActionResult> GetRoles()
        {
            try
            {
                // Retrieve all active roles in LIFO order
                var roles = await _context.Roles
                    .Where(r => r.IsDeleted == false)
                    .OrderByDescending(r => r.CreatedAt) // ✅ LIFO: newest first
                    .ToListAsync();

                return Ok(roles);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Error = "Error retrieving roles.", Details = ex.Message });
            }
        }

        // GET: api/roles/{id}
        [HttpGet("roles/{id}")]
        public async Task<IActionResult> GetRole(int id)
        {
            try
            {
                var role = await _context.Roles
                                         .Where(r => r.RoleId == id)
                                         .Select(r => new
                                         {
                                             r.RoleId,
                                             r.RoleTitle,
                                             r.RolePermissions
                                         })
                                         .FirstOrDefaultAsync();

                // Return NotFound if role doesn't exist
                if (role == null)
                {
                    return NotFound(new { Message = $"Role with ID {id} not found." });
                }

                return Ok(role);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Error = "An error occurred while retrieving the role.", Details = ex.Message });
            }
        }


        // POST: api/roles
        [HttpPost("roles/create")]
        public async Task<IActionResult> PostRole([FromBody] Role role)
        {
            int empCode = User.GetEmpCode();
            try
            {
                if (role == null)
                {
                    return BadRequest(new { Message = "Role data cannot be null." });
                }
                if (!ModelState.IsValid)
                {
                    return BadRequest(new { Message = "Invalid role data." });
                }
                role.RoleTitle = role.RoleTitle.Trim();
                var normalizedRoleTitle = role.RoleTitle.ToLower();

                var existingRole = await _context.Roles
                    .FirstOrDefaultAsync(r =>
                        r.RoleTitle.Trim().ToLower() == normalizedRoleTitle
                    );
                if (existingRole != null)
                {
                    if (existingRole.IsDeleted)
                    {
                        existingRole.IsDeleted = false;
                        existingRole.CreatedAt = DateTime.UtcNow;
                        _context.Roles.Update(existingRole);
                        await _context.SaveChangesAsync();
                        return Ok(new { message = "Soft-deleted Role reactivated successfully." });
                    }
                    else
                    {
                        return Conflict(new { message = "A Role with the same name already exists." });
                    }
                }
                role.CreatedAt = DateTime.UtcNow;
                _context.Roles.Add(role);
                await _context.SaveChangesAsync();
                // 🔹 AUDIT (CREATE ROLE)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = empCode,
                        TargetEmpCode = null,
                        ModuleName = AuditModule.Role.ToString(),
                        ActionType = AuditAction.CREATE.ToString(),
                        EntityName = AuditEntity.Roles.ToString(),
                        NewValue = JsonSerializer.Serialize(role),
                        Remarks = "Role created successfully"
                    });
                }
                catch { }
                // Return only a success message
                return Ok(new { Message = "Role created successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Error = "Error creating role.", Details = ex.Message });
            }
        }

        [HttpPost("roles/update/{RoleId}")]
        public async Task<IActionResult> UpdateRole(int RoleId, [FromBody] Role UpdateRole)
        {
            int empCode = User.GetEmpCode();

            var oldRole = await _context.Roles
            .AsNoTracking()
            .FirstOrDefaultAsync(r => r.RoleId == RoleId);

            if (RoleId != UpdateRole.RoleId)
            {
                return BadRequest("Role ID in the URL does not match the ID in the body.");
            }

            var existingRoleInfo = await _context.Roles.FindAsync(RoleId);
            if (existingRoleInfo == null)
            {
                return NotFound($"Roles with ID {RoleId} not found.");
            }
            var existingRole = await _context.Roles.FirstOrDefaultAsync(r => r.RoleTitle == UpdateRole.RoleTitle && r.RoleId != RoleId);

            if (existingRole != null)

            {
                return Conflict(new { message = "A Role with the same name already exists." });
            }
            existingRoleInfo.RoleTitle = UpdateRole.RoleTitle;
            existingRoleInfo.RolePermissions = UpdateRole.RolePermissions;
            try
            {
                await _context.SaveChangesAsync();
                var newRole = await _context.Roles
                   .AsNoTracking()
                   .FirstOrDefaultAsync(r => r.RoleId == RoleId);

                // 🔹 AUDIT (UPDATE ROLE)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = empCode,
                        ModuleName = AuditModule.Role.ToString(),
                        ActionType = AuditAction.UPDATE.ToString(),
                        EntityName = AuditEntity.Roles.ToString(),
                        OldValue = JsonSerializer.Serialize(oldRole),
                        NewValue = JsonSerializer.Serialize(newRole),
                        Remarks = "Role updated"
                    });
                }
                catch { }
                return Ok("Role updated successfully.");
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return StatusCode(500, $" error: {ex.Message}");
            }
        }


        //[HttpDelete("roles/{id}")]
        //public async Task<IActionResult> DeleteRole(int id)
        //{
        //    var role = await _context.Roles.FindAsync(id);

        //    if (role == null)
        //    {
        //        return NotFound(new { message = $"Role with ID {id} not found." });
        //    }

        //    // Check if the role has access rights
        //    bool hasActiveAccessRights = await _context.Access.AnyAsync(a =>
        //        a.RoleId == id && (a.FullAccess == true || a.ReadOnly == true || a.HideShow == true));

        //    if (hasActiveAccessRights)
        //    {
        //        return BadRequest(new { message = $"Role '{role.RoleTitle}' cannot be deleted because it has active access rights." });
        //    }

        //    try
        //    {
        //        _context.Roles.Remove(role);  // <-- Hard delete
        //        await _context.SaveChangesAsync();

        //        return Ok(new { message = $"Role '{role.RoleTitle}' has been successfully deleted (hard delete)." });
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, new { message = $"Error deleting role '{role.RoleTitle}': {ex.Message}" });
        //    }
        //}

        [HttpPost("roles/delete/{id}")]
        public async Task<IActionResult> DeleteRole(int id)
        {
            int empCode = User.GetEmpCode();
            var role = await _context.Roles.FindAsync(id);

            if (role == null)
            {
                return NotFound(new { message = $"Role with ID {id} not found." });
            }

            // ✅ Check if role is assigned to any user in UserDetails table
            bool isRoleAssignedToUser = await _context.UserDetails
                .AnyAsync(u => u.Role_Id == id && u.IsDelete == false); // only active users

            if (isRoleAssignedToUser)
            {
                return BadRequest(new { message = $"Role '{role.RoleTitle}' cannot be deleted because it is assigned to a user." });
            }

            // ✅ Check if the role has access rights
            bool hasActiveAccessRights = await _context.Access.AnyAsync(a =>
                a.RoleId == id && (a.FullAccess == true || a.ReadOnly == true || a.HideShow == true));

            if (hasActiveAccessRights)
            {
                return BadRequest(new { message = $"Role '{role.RoleTitle}' cannot be deleted because it has active access rights." });
            }

            try
            {
                var oldRole = JsonSerializer.Serialize(role);
                _context.Roles.Remove(role);  // Hard delete
                await _context.SaveChangesAsync();

                // 🔹 AUDIT (DELETE ROLE)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = empCode,
                        ModuleName = AuditModule.Role.ToString(),
                        ActionType = AuditAction.DELETE.ToString(),
                        EntityName = AuditEntity.Roles.ToString(),
                        OldValue = oldRole,
                        Remarks = $"Role '{role.RoleTitle}' deleted"
                    });
                }
                catch { }
                return Ok(new { message = $"Role '{role.RoleTitle}' has been successfully deleted." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error deleting role '{role.RoleTitle}': {ex.Message}" });
            }
        }

        // --------------------------- clients APIs --------------------------

        // GET: api/settings/clients
        [HttpGet("clients")]
        public async Task<IActionResult> GetClients()
        {
            try
            {
                // Retrieve active clients in LIFO order
                var clients = await _context.Clients
                    .Where(c => c.IsDeleted == false)
                    .OrderByDescending(c => c.CreatedDate) // ✅ newest first
                    .ToListAsync();

                return Ok(clients);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error retrieving clients: {ex.Message}" });
            }
        }

        // POST: api/settings/clients
        [HttpPost("clients/create")]
        public async Task<IActionResult> CreateClient([FromBody] Client client)
        {
            int empCode = User.GetEmpCode();
            try
            {
                if (client == null)
                {
                    return BadRequest(new { message = "Invalid client data." });
                }

                // Check if a client with the same name and location exists
                var existingClient = await _context.Clients
                    .FirstOrDefaultAsync(c =>
                        c.ClientName == client.ClientName &&
                        c.ClientLocation == client.ClientLocation);

                if (existingClient != null)
                {
                    if (existingClient.IsDeleted)
                    {
                        // Reactivate soft-deleted client and update timestamp
                        existingClient.IsDeleted = false;
                        existingClient.CreatedDate = DateTime.UtcNow; // ✅ LIFO
                        _context.Clients.Update(existingClient);
                        await _context.SaveChangesAsync();

                        return Ok(new { message = "Soft-deleted client reactivated successfully." });
                    }
                    else
                    {
                        return Conflict(new { message = "A client with the same name and location already exists." });
                    }
                }

                // ✅ Allow same name with different location
                client.CreatedDate = DateTime.UtcNow; // ✅ LIFO
                _context.Clients.Add(client);
                await _context.SaveChangesAsync();

                // 🔹 AUDIT (CREATE CLIENT)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = empCode,
                        TargetEmpCode = null,
                        ModuleName = AuditModule.Client.ToString(),
                        ActionType = AuditAction.CREATE.ToString(),
                        EntityName = AuditEntity.Clients.ToString(),
                        NewValue = JsonSerializer.Serialize(client),
                        Remarks = "Client created successfully"
                    });
                }
                catch { }
                return Ok(new { message = "Client created successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error creating client: {ex.Message}" });
            }
        }

        [HttpPost("clients/update/{clientId}")]
        public async Task<IActionResult> UpdateClient(int clientId, [FromBody] Client UpdateClient)

        {
            int empCode = User.GetEmpCode();

            var oldClient = await _context.Clients
            .AsNoTracking()
            .FirstOrDefaultAsync(c => c.ClientId == clientId);

            if (clientId != UpdateClient.ClientId)
            {
                return BadRequest("Client ID in the URL does not match the ID in the body.");
            }

            var existingClientInfo = await _context.Clients.FindAsync(clientId);
            if (existingClientInfo == null)
            {
                return NotFound($"Client with ID {clientId} not found.");
            }

            // ✅ Check if another client exists with the same name & location (excluding current one)
            var duplicateClient = await _context.Clients
                .FirstOrDefaultAsync(c =>
                    c.ClientId != clientId &&
                    c.ClientName == UpdateClient.ClientName &&
                    c.ClientLocation == UpdateClient.ClientLocation);

            if (duplicateClient != null)
            {
                if (duplicateClient.IsDeleted)
                {
                    // ✅ Reactivate the soft-deleted client
                    duplicateClient.IsDeleted = false;
                    duplicateClient.CreatedDate = DateTime.UtcNow;

                    _context.Clients.Update(duplicateClient);
                    await _context.SaveChangesAsync();

                    return Ok(new { message = "Soft-deleted client reactivated successfully." });
                }
                else
                {
                    return Conflict(new { message = "A client with the same name and location already exists." });
                }
            }

            // ✅ Update current client info
            existingClientInfo.ClientName = UpdateClient.ClientName;
            existingClientInfo.ClientLocation = UpdateClient.ClientLocation;
            existingClientInfo.CreatedDate = DateTime.UtcNow; // Optional: refresh LIFO timestamp

            try
            {
                await _context.SaveChangesAsync();

                var newClient = await _context.Clients
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.ClientId == clientId);

                // 🔹 AUDIT (UPDATE CLIENT)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = empCode,
                        ModuleName = AuditModule.Client.ToString(),
                        ActionType = AuditAction.UPDATE.ToString(),
                        EntityName = AuditEntity.Clients.ToString(),
                        OldValue = JsonSerializer.Serialize(oldClient),
                        NewValue = JsonSerializer.Serialize(newClient),
                        Remarks = "Client updated"
                    });
                }
                catch { }
                return Ok(new { message = "Client updated successfully." });
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return StatusCode(500, new { message = $"Error updating client: {ex.Message}" });
            }
        }

        [HttpPost("clients/delete/{id}")]
        public async Task<IActionResult> DeleteClient(int id)
        {
            int empCode = User.GetEmpCode();
            try
            {

                // Find the client by ID
                var client = await _context.Clients.FirstOrDefaultAsync(c => c.ClientId == id);
                if (client == null)
                {
                    return NotFound(new { Message = "Client not found." });
                }
                // Check if client is assigned to any non-deleted projects
                bool isClientInProjects = await _context.ProjectInfo
                    .AnyAsync(p => p.Client_Id == id && p.isDelete == false);
                if (isClientInProjects)
                {
                    return BadRequest(new { Message = $"Cannot delete client '{client.ClientName}' because they are assigned to one or more active projects." });
                }

                var oldClient = JsonSerializer.Serialize(client);
                // Soft delete the client
                client.IsDeleted = true;
                _context.Clients.Update(client);
                await _context.SaveChangesAsync();
                // 🔹 AUDIT (DELETE CLIENT)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = empCode,
                        ModuleName = AuditModule.Client.ToString(),
                        ActionType = AuditAction.DELETE.ToString(),
                        EntityName = AuditEntity.Clients.ToString(),
                        OldValue = oldClient,
                        Remarks = $"Client '{client.ClientName}' deleted"
                    });
                }
                catch { }
                return Ok(new { Message = $"Client '{client.ClientName}' deleted successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error deleting client: {ex.Message}");
            }
        }
    }
}
