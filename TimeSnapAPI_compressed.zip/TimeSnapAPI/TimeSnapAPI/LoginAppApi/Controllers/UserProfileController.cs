﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;
using System.IO;
using Microsoft.AspNetCore.Hosting;

[ApiController]
[Route("api/userprofilepicture")]
public class UserProfileController : ControllerBase
{ 
    private readonly IConfiguration _configuration; 
    private readonly IWebHostEnvironment _environment; 
    public UserProfileController(IConfiguration configuration, IWebHostEnvironment environment)

    { 
        _configuration = configuration; 
        _environment = environment; 
    }
    private string GetConnectionString()
    { 
        return _configuration.GetConnectionString("DefaultConnection");
    }

    // Post Method for Employee Profile
    [HttpPost("upload")]
    public async Task<IActionResult> UploadProfilePicture([FromForm] IFormFile file, [FromForm] string empCode)
    {
        if (file == null || file.Length == 0)
            return BadRequest("No file uploaded.");

        var baseDirectory = _environment.ContentRootPath;
        var uploadsFolder = Path.Combine(baseDirectory, "Uploads", "profile_pictures");
        if (!Directory.Exists(uploadsFolder))
            Directory.CreateDirectory(uploadsFolder);
        var fileName = $"{empCode}{Path.GetExtension(file.FileName)}";
        var filePath = Path.Combine(uploadsFolder, fileName);
        using (var stream = new FileStream(filePath, FileMode.Create))
        {
            await file.CopyToAsync(stream);
        }
        // Update the path to reflect the new location
        var profilePhotoUrl = $"/Uploads/profile_pictures/{fileName}";
        using (SqlConnection conn = new SqlConnection(GetConnectionString()))
        {
            conn.Open();
            // Check if a record already exists for this employee
            string checkQuery = "SELECT COUNT(*) FROM UserProfilePictures WHERE EmpCode = @EmpCode";
            bool recordExists = false;
            using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
            {
                checkCmd.Parameters.AddWithValue("@EmpCode", empCode);
                int count = (int)checkCmd.ExecuteScalar();
                recordExists = count > 0;
            }
            string query;
            if (recordExists)
            {
                // Update existing record 
                query = "UPDATE UserProfilePictures SET ProfilePhoto = @ProfilePhoto WHERE EmpCode = @EmpCode";
            }
            else
            {
                // Insert new record 
                query = "INSERT INTO UserProfilePictures (EmpCode, ProfilePhoto) VALUES (@EmpCode, @ProfilePhoto)";
            }
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@EmpCode", empCode);
                cmd.Parameters.AddWithValue("@ProfilePhoto", profilePhotoUrl);
                cmd.ExecuteNonQuery();
            }
        }
        return Ok(new { profilePhoto = profilePhotoUrl });
    }

    //GET
    [HttpGet("get/{empCode}")]
    public IActionResult GetProfilePicture(string empCode)
    {
        if (string.IsNullOrWhiteSpace(empCode))
            return BadRequest("Invalid employee code.");

        try
        {
            string profilePhoto = null;

            using (SqlConnection conn = new SqlConnection(GetConnectionString()))
            {
                conn.Open();

                string query = @"
                SELECT TOP 1 ProfilePhoto 
                FROM UserProfilePictures 
                WHERE EmpCode = @EmpCode 
                ORDER BY CreatedAt DESC";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EmpCode", empCode);

                    var result = cmd.ExecuteScalar();

                    // Check for null or DBNull
                    if (result != DBNull.Value && result != null)
                        profilePhoto = result.ToString();
                }
            }

            // If DB returned null, empty or whitespace
            if (string.IsNullOrWhiteSpace(profilePhoto))
                return Ok("No profile picture found for this employee.");

            // Build file path safely
            var baseDirectory = _environment.ContentRootPath;
            var sanitizedPath = profilePhoto.TrimStart('/', '\\');
            var imagePath = Path.Combine(baseDirectory, sanitizedPath);

            // Validate file existence
            if (!System.IO.File.Exists(imagePath))
                return NotFound("Profile picture file does not exist on the server.");

            // Detect content type
            var extension = Path.GetExtension(imagePath)?.ToLower();
            var contentType = extension switch
            {
                ".png" => "image/png",
                ".gif" => "image/gif",
                ".jpeg" => "image/jpeg",
                ".jpg" => "image/jpeg",
                _ => "application/octet-stream"
            };

            var imageFileStream = System.IO.File.OpenRead(imagePath);
            return File(imageFileStream, contentType);
        }
        catch (Exception ex)
        {
            // Log error if you want
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }


    // Delete Method for Employee Profile
    [HttpPost("delete/{empCode}")]
    public IActionResult DeleteProfilePicture(string empCode)
    {
        string profilePhoto = null;
        using (SqlConnection conn = new SqlConnection(GetConnectionString()))
        {
            conn.Open(); 
            // Get the profile picture path
            string query = "SELECT ProfilePhoto FROM UserProfilePictures WHERE EmpCode = @EmpCode";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@EmpCode", empCode); 
                var result = cmd.ExecuteScalar();
                if (result != null)
                { 
                    profilePhoto = result.ToString(); 
                }
            }
            if (string.IsNullOrEmpty(profilePhoto))
                return NotFound("No profile picture found."); 
            // Delete the profile picture record from the database
            string deleteQuery = "DELETE FROM UserProfilePictures WHERE EmpCode = @EmpCode";
            using (SqlCommand deleteCmd = new SqlCommand(deleteQuery, conn))
            {
                deleteCmd.Parameters.AddWithValue("@EmpCode", empCode); 
                deleteCmd.ExecuteNonQuery();
            } 
        }
        // Delete the file from the server
        var baseDirectory = _environment.ContentRootPath; 
        var imagePath = Path.Combine(baseDirectory, profilePhoto.TrimStart('/'));
        if (System.IO.File.Exists(imagePath))
        { 
            System.IO.File.Delete(imagePath);
        } 
        return Ok("Profile picture deleted successfully.");
    } 
}

