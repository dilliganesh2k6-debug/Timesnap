﻿using LoginAppApi.Data;
using Microsoft.AspNetCore.Mvc;
using LoginAppApi.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginAppApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserDetailsController : ControllerBase
    {
        private readonly LoginAppDbContext _context;

        public UserDetailsController(LoginAppDbContext context)
        {
            _context = context;
        }

        // GET: api/UserDetails
        [HttpGet]
        public async Task<ActionResult<IEnumerable<UserDetails>>> GetUserDetails()
        {
            var users = await _context.UserDetails.ToListAsync();

            if (users == null || users.Count == 0)
            {
                return NotFound("No users found.");
            }

            return Ok(users);
        }

        // POST: api/UserDetails
        [HttpPost]
        public async Task<ActionResult<UserDetails>> PostUserDetails(UserDetails userDetails)
        {
            // Validate if userDetails is null
            if (userDetails == null)
            {
                return BadRequest("User details are required.");
            }

            // Validate required fields (e.g., Emp_code, Name)
            if (string.IsNullOrEmpty(userDetails.User_name))
            {
                return BadRequest("Name is required.");
            }

            if (userDetails.Emp_code <= 0)
            {
                return BadRequest("Valid Emp_code is required.");
            }

            // Add the new user details to the context
            _context.UserDetails.Add(userDetails);
            await _context.SaveChangesAsync();

            return Ok(new { message = "User details added successfully!" });
        }

        // PUT: api/UserDetails/5
        [HttpPost("{id}")]
        public async Task<IActionResult> PutUserDetails(int id, UserDetails userDetails)
        {
            // Validate if the user details are null or invalid
            if (userDetails == null)
            {
                return BadRequest("User details are required.");
            }

            // Check if the ID in the URL matches the ID in the body
            if (id != userDetails.Emp_code)
            {
                return BadRequest("ID mismatch.");
            }

            // Validate required fields (e.g., Name)
            if (string.IsNullOrEmpty(userDetails.User_name))
            {
                return BadRequest("Name is required.");
            }

            // Update the user details
            _context.Entry(userDetails).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserDetailsExists(id))
                {
                    return NotFound($"User with ID {id} not found.");
                }
                else
                {
                    throw;
                }
            }

            return NoContent(); 
        } 
        private bool UserDetailsExists(int id)
        {
            return _context.UserDetails.Any(e => e.Emp_code == id);
        }
    }
}
