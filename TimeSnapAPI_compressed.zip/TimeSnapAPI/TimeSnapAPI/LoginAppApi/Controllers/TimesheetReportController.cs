﻿using LoginAppApi.Data;
using LoginAppApi.Models;
using Microsoft.AspNetCore.Mvc; 
using Microsoft.EntityFrameworkCore; 
using System; 
using System.Linq; 
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading.Tasks;
using TimeTrackerApplication.Services;
using Microsoft.Extensions.Logging;

namespace LoginAppApi.Controllers
{
    [Route("api/[controller]")] 
    [ApiController]
    public class TimesheetReportController : ControllerBase
    {
        private readonly LoginAppDbContext _context;
        private readonly ILogger<TimesheetReportController> _logger;

        public TimesheetReportController(
            LoginAppDbContext context,
            ILogger<TimesheetReportController> logger)
        { 
            _context = context;
            _logger = logger;
        }

        //GET
        [HttpGet("summary")] 
        public async Task<IActionResult> GetTimesheetSummaryReport() 
        {
            var data = await _context.TimesheetDetailReport.ToListAsync(); 
            return Ok(data);
        }

        //GET with FILTER
        //[HttpGet("summary/filter")]
        //public async Task<IActionResult> GetFilteredSummary(
        //    [FromQuery] int? empCode, 
        //    [FromQuery] int? roleId,
        //    [FromQuery] int? projectID,
        //    [FromQuery] DateTime? startDate,
        //    [FromQuery] DateTime? endDate,
        //    [FromQuery] int? reportingToId,
        //    [FromQuery] int? projectManagerId)
        //{
        //    if (!empCode.HasValue || !roleId.HasValue)
        //    {
        //        return BadRequest("EmpCode and RoleId are required.");
        //    }

        //    // Fetch user details
        //    var user = await _context.UserDetails
        //        .FirstOrDefaultAsync(u => u.Emp_code == empCode.Value);
        //    if (user == null)
        //    {
        //        return NotFound("User not found.");
        //    }

        //    // Check if user has FullAccess for the "Report" screen
        //    var access = await _context.Access
        //        .FirstOrDefaultAsync(a => a.RoleId == roleId.Value && a.ScreenId == 109 && a.FullAccess == true);
        //    if (access == null)
        //    {
        //        return Forbid("You do not have permission to access the report.");
        //    }

        //    var query = _context.TimesheetDetailReport.AsQueryable();

        //    if (!access.ShowAllUser)
        //    {
        //        var managedProjectIds = await _context.ProjectManagers
        //            .Where(pm => pm.ManagerId == empCode && pm.IsActive)
        //            .Select(pm => pm.ProjectId)
        //            .ToListAsync();

        //        query = query.Where(x =>
        //            x.EmpCode == empCode ||             
        //            x.ReportingtoId == empCode ||        
        //            managedProjectIds.Contains(x.ProjectID) 
        //        );
        //    }

        //    if (empCode.HasValue)
        //    {
        //        query = query.Where(x => x.EmpCode == empCode.Value);
        //    }

        //    // Apply additional filters
        //    if (projectID.HasValue)
        //    {
        //        query = query.Where(x => x.ProjectID == projectID.Value);
        //    }

        //    if (startDate.HasValue)
        //    {
        //        query = query.Where(x => x.Date >= startDate.Value);
        //    }

        //    if (endDate.HasValue)
        //    {
        //        query = query.Where(x => x.Date <= endDate.Value);
        //    }

        //    var data = await query.ToListAsync();
        //    return Ok(data);
        //}

        [HttpGet("summary/filter")]
        public async Task<IActionResult> GetFilteredSummary(
    [FromQuery] int? empCode,
    [FromQuery] int? roleId,
    [FromQuery] int? projectID,
    [FromQuery] DateTime? startDate,
    [FromQuery] DateTime? endDate,
    [FromQuery] int? reportingToId,
    [FromQuery] int? projectManagerId,
    [FromQuery(Name = "employeeCodes")] string employeeCodes = null,
    [FromQuery] bool summaryOnly = false)
        {
            var stopwatch = Stopwatch.StartNew();

            if (!empCode.HasValue || !roleId.HasValue)
                return BadRequest("EmpCode and RoleId are required.");

            if (startDate.HasValue && endDate.HasValue && startDate.Value.Date > endDate.Value.Date)
                return BadRequest("Start date cannot be after end date.");

            var requestedEmpCode = empCode.Value;
            var requestedRoleId = roleId.Value;
            var normalizedStartDate = startDate?.Date;
            var exclusiveEndDate = endDate?.Date.AddDays(1);
            List<int> requestedEmployeeCodes = null;

            if (!string.IsNullOrWhiteSpace(employeeCodes))
            {
                requestedEmployeeCodes = employeeCodes
                    .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                    .Select(value => int.TryParse(value, out var parsed) ? (int?)parsed : null)
                    .Where(value => value.HasValue)
                    .Select(value => value.Value)
                    .Distinct()
                    .ToList();

                if (requestedEmployeeCodes.Count == 0)
                    return BadRequest("employeeCodes must contain at least one valid employee code.");
            }

            _logger.LogInformation(
                "Timesheet summary request started. empCode={EmpCode}, roleId={RoleId}, projectId={ProjectId}, reportingToId={ReportingToId}, projectManagerId={ProjectManagerId}, startDate={StartDate}, endDate={EndDate}",
                requestedEmpCode,
                requestedRoleId,
                projectID,
                reportingToId,
                projectManagerId,
                normalizedStartDate,
                endDate?.Date);

            // Fetch only the admin flag needed for access validation.
            var userAccessInfo = await _context.UserDetails
                .AsNoTracking()
                .Where(u => u.Emp_code == requestedEmpCode)
                .Select(u => new { u.IsAdmin })
                .FirstOrDefaultAsync();

            _logger.LogInformation(
                "Timesheet summary user lookup completed in {ElapsedMs} ms for empCode={EmpCode}",
                stopwatch.ElapsedMilliseconds,
                requestedEmpCode);

            if (userAccessInfo == null)
                return NotFound("User not found.");

            // Fetch only the access flags used in this endpoint.
            var access = await _context.Access
                .AsNoTracking()
                .FirstOrDefaultAsync(a =>
                    a.RoleId == requestedRoleId &&
                    a.ScreenId == 109
                );

            _logger.LogInformation(
                "Timesheet summary access lookup completed in {ElapsedMs} ms for empCode={EmpCode}, roleId={RoleId}",
                stopwatch.ElapsedMilliseconds,
                requestedEmpCode,
                requestedRoleId);

            if (access == null)
                return Forbid("You do not have permission to access the report.");

            bool hasFullAccess = userAccessInfo.IsAdmin || access.FullAccess;

            var filteredDetails = _context.TimesheetDetails
                .AsNoTracking()
                .Where(td => td.IsDeleted == 0);

            if (projectID.HasValue)
                filteredDetails = filteredDetails.Where(td => td.Project_Id == projectID.Value);

            if (normalizedStartDate.HasValue)
                filteredDetails = filteredDetails.Where(td => td.Date >= normalizedStartDate.Value);

            if (exclusiveEndDate.HasValue)
                filteredDetails = filteredDetails.Where(td => td.Date < exclusiveEndDate.Value);

            if (reportingToId.HasValue)
                filteredDetails = filteredDetails.Where(td => td.ReportingToId == reportingToId.Value);

            if (!hasFullAccess)
            {
                var managedProjectIds = _context.ProjectManagers
                    .AsNoTracking()
                    .Where(pm => pm.ManagerId == requestedEmpCode && pm.IsActive)
                    .Select(pm => pm.ProjectId);

                filteredDetails = filteredDetails.Where(td =>
                    td.Emp_code == requestedEmpCode ||
                    td.ReportingToId == requestedEmpCode ||
                    managedProjectIds.Contains(td.Project_Id)
                );
            }

            if (projectManagerId.HasValue)
            {
                var managerProjectIds = _context.ProjectManagers
                    .AsNoTracking()
                    .Where(pm => pm.ManagerId == projectManagerId.Value && pm.IsActive)
                    .Select(pm => pm.ProjectId);

                filteredDetails = filteredDetails.Where(td => managerProjectIds.Contains(td.Project_Id));
            }

            // Optional batch filter used by the Reports screen. This is applied
            // after the authorization scope so selected employees can never
            // expand the data visible to the requesting user.
            if (requestedEmployeeCodes != null)
                filteredDetails = filteredDetails.Where(td => requestedEmployeeCodes.Contains(td.Emp_code));

            _logger.LogInformation(
                "Timesheet summary query shape prepared in {ElapsedMs} ms for empCode={EmpCode}",
                stopwatch.ElapsedMilliseconds,
                requestedEmpCode);

            List<TimesheetReportDetailRow> detailRows;

            if (summaryOnly)
            {
                // Summary reports do not need one row per day. Aggregate in
                // SQL before loading data into the API process or serializing
                // it for the browser.
                detailRows = await filteredDetails
                    .GroupBy(td => new
                    {
                        td.Emp_code,
                        td.Project_Id,
                        td.Task_Id,
                        td.CategoryId,
                        td.SubCategoryId,
                        td.ReportingToId
                    })
                    .Select(group => new TimesheetReportDetailRow
                    {
                        Emp_code = group.Key.Emp_code,
                        Project_Id = group.Key.Project_Id,
                        Task_Id = group.Key.Task_Id,
                        CategoryId = group.Key.CategoryId,
                        SubCategoryId = group.Key.SubCategoryId,
                        Date = group.Min(td => td.Date),
                        Hours = group.Sum(td => td.Hours),
                        ReportingToId = group.Key.ReportingToId
                    })
                    .ToListAsync();
            }
            else
            {
                detailRows = await filteredDetails
                    .Select(td => new TimesheetReportDetailRow
                    {
                        Emp_code = td.Emp_code,
                        Project_Id = td.Project_Id,
                        Task_Id = td.Task_Id,
                        CategoryId = td.CategoryId,
                        SubCategoryId = td.SubCategoryId,
                        Date = td.Date,
                        Hours = td.Hours,
                        ReportingToId = td.ReportingToId
                    })
                    .ToListAsync();
            }

            _logger.LogInformation(
                "Timesheet summary base detail query completed in {ElapsedMs} ms with {RowCount} rows for empCode={EmpCode}",
                stopwatch.ElapsedMilliseconds,
                detailRows.Count,
                requestedEmpCode);

            if (detailRows.Count == 0)
            {
                _logger.LogInformation(
                    "Timesheet summary finished in {ElapsedMs} ms with 0 rows for empCode={EmpCode}",
                    stopwatch.ElapsedMilliseconds,
                    requestedEmpCode);
                return Ok(new List<TimesheetDetailReport>());
            }

            var detailEmployeeCodes = detailRows.Select(x => x.Emp_code).Distinct().ToList();
            var projectIds = detailRows.Select(x => x.Project_Id).Distinct().ToList();
            var categoryIds = detailRows.Select(x => x.CategoryId).Distinct().ToList();
            var subCategoryIds = detailRows.Select(x => x.SubCategoryId).Distinct().ToList();
            var taskKeys = detailRows
                .Select(x => new { x.Project_Id, x.Task_Id })
                .Distinct()
                .ToList();
            var taskIds = taskKeys.Select(x => x.Task_Id).Distinct().ToList();

            var employees = await _context.UserDetails
                .AsNoTracking()
                .Where(x => detailEmployeeCodes.Contains(x.Emp_code))
                .Select(x => new { x.Emp_code, x.User_name })
                .ToDictionaryAsync(x => x.Emp_code, x => x.User_name);

            var projects = await _context.ProjectInfo
                .AsNoTracking()
                .Where(x => projectIds.Contains(x.Project_id))
                .Select(x => new
                {
                    x.Project_id,
                    x.Project_name,
                    x.Client_Id,
                    x.ProjectCategoryId
                })
                .ToListAsync();

            var clientIds = projects.Select(x => x.Client_Id).Distinct().ToList();
            var projectCategoryIds = projects.Select(x => x.ProjectCategoryId).Distinct().ToList();

            var clients = await _context.Clients
                .AsNoTracking()
                .Where(x => clientIds.Contains(x.ClientId))
                .Select(x => new { x.ClientId, x.ClientName })
                .ToDictionaryAsync(x => x.ClientId, x => x.ClientName);

            var projectCategories = await _context.ProjectCategories
                .AsNoTracking()
                .Where(x => projectCategoryIds.Contains(x.ProjectCategoryId))
                .Select(x => new { x.ProjectCategoryId, x.projectCategoryName })
                .ToDictionaryAsync(x => x.ProjectCategoryId, x => x.projectCategoryName);

            var taskCategories = await _context.Categories
                .AsNoTracking()
                .Where(x => categoryIds.Contains(x.CategoryId))
                .Select(x => new { x.CategoryId, x.CategoryName })
                .ToDictionaryAsync(x => x.CategoryId, x => x.CategoryName);

            var subCategories = await _context.Tasks
                .AsNoTracking()
                .Where(x => subCategoryIds.Contains(x.Id))
                .Select(x => new { x.Id, x.TaskName })
                .ToDictionaryAsync(x => x.Id, x => x.TaskName);

            var projectTasks = await _context.ProjectTasks
                .AsNoTracking()
                .Where(x => projectIds.Contains(x.Project_Id) && taskIds.Contains(x.Task_Id))
                .Select(x => new
                {
                    x.Project_Id,
                    x.Task_Id,
                    x.Task_Name,
                    x.IsBillable
                })
                .ToListAsync();

            var projectLookup = projects.ToDictionary(x => x.Project_id);
            var projectTaskLookup = projectTasks.ToDictionary(
                x => $"{x.Project_Id}_{x.Task_Id}",
                x => new { x.Task_Name, x.IsBillable });

            var data = detailRows
                .Select(row =>
                {
                    projectLookup.TryGetValue(row.Project_Id, out var project);
                    var clientName = project != null && clients.TryGetValue(project.Client_Id, out var resolvedClientName)
                        ? resolvedClientName
                        : string.Empty;
                    var projectCategoryName = project != null && projectCategories.TryGetValue(project.ProjectCategoryId, out var resolvedProjectCategoryName)
                        ? resolvedProjectCategoryName
                        : string.Empty;
                    var employeeName = employees.TryGetValue(row.Emp_code, out var resolvedEmployeeName)
                        ? resolvedEmployeeName
                        : string.Empty;
                    var taskCategoryName = taskCategories.TryGetValue(row.CategoryId, out var resolvedTaskCategoryName)
                        ? resolvedTaskCategoryName
                        : string.Empty;
                    var subCategoryName = subCategories.TryGetValue(row.SubCategoryId, out var resolvedSubCategoryName)
                        ? resolvedSubCategoryName
                        : string.Empty;

                    projectTaskLookup.TryGetValue($"{row.Project_Id}_{row.Task_Id}", out var projectTask);

                    return new TimesheetDetailReport
                    {
                        EmpCode = row.Emp_code,
                        EmployeeName = employeeName,
                        ClientId = project?.Client_Id ?? 0,
                        ClientName = clientName,
                        ProjectCategoryId = project?.ProjectCategoryId ?? 0,
                        projectCategoryName = projectCategoryName,
                        ProjectID = row.Project_Id,
                        ProjectName = project?.Project_name ?? string.Empty,
                        TaskCategoryID = row.CategoryId,
                        TaskCategoryName = taskCategoryName,
                        SubCategoryID = row.SubCategoryId,
                        SubCategoryName = subCategoryName,
                        TaskID = row.Task_Id,
                        TaskName = projectTask?.Task_Name ?? string.Empty,
                        IsBillable = projectTask?.IsBillable ?? false,
                        Date = row.Date,
                        TaskHours = row.Hours,
                        ReportingtoId = row.ReportingToId ?? 0
                    };
                })
                .ToList();

            _logger.LogInformation(
                "Timesheet summary query completed in {ElapsedMs} ms with {RowCount} rows for empCode={EmpCode}",
                stopwatch.ElapsedMilliseconds,
                data.Count,
                requestedEmpCode);

            return Ok(data);
        }


        //GET
        [HttpGet("report/projects")]
        public async Task<IActionResult> GetProjectDropdown()
        {
            var projects = await _context.TimesheetDetailReport
                .Select(p => new
                {
                    projectID = p.ProjectID,
                    projectName = p.ProjectName
                })
                .Distinct()
                .OrderBy(p => p.projectName)
                .ToListAsync();
            return Ok(projects);
        }

        [HttpGet("{projectId}")]
        public async Task<IActionResult> GetProjectAnalytics(int projectId)
        {
            var rows = await _context
                .Set<ProjectTaskResourceAnalytics>()
                .Where(x => x.ProjectID == projectId)
                .ToListAsync();

            if (!rows.Any())
                return NotFound();

            var tasks = rows
                .GroupBy(t => new { t.TaskID, t.TaskName, t.EstimatedHours,t.TaskStatusId,t.StatusName })
                .Select(t => new
                {
                    t.Key.TaskID,
                    t.Key.TaskName,
                    t.Key.EstimatedHours,
                    t.Key.TaskStatusId,
                    TaskStatusName = t.Key.StatusName,
                    ActualHours = t.Sum(x => x.ActualHours),

                    Resources = t
                        .Where(x => x.ActualHours > 0)
                        .Select(x => new
                        {
                            x.EmpCode,
                            x.EmployeeName,
                            x.ActualHours,
                            x.ProductivityPercent
                        })
                        .ToList()
                })
                .ToList();

            var employees = rows
                .GroupBy(e => new { e.EmpCode, e.EmployeeName, e.IsIdleResource })
                .Select(e => new
                {
                    e.Key.EmpCode,
                    e.Key.EmployeeName,
                    IsIdle = e.Key.IsIdleResource
                })
                .ToList();

            return Ok(new
            {
                ProjectID = projectId,
                Tasks = tasks,
                Employees = employees
            });
        }



    }
}


