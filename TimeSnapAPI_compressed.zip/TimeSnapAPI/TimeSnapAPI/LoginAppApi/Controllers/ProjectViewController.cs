﻿using LoginAppApi.Data;
using LoginAppApi.Models;
using LoginAppApi.Models.Dto;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using LoginAppApi.Extensions;
using LoginAppApi.Services;
using System.Text.Json;
using LoginAppApi.Models.Enums;


[Authorize]
[Route("api/[controller]")]
[ApiController]
public class ProjectViewController : ControllerBase
{
    private readonly LoginAppDbContext _context;
    private readonly IAuditLogService _auditLogService;
    public ProjectViewController(LoginAppDbContext context, IAuditLogService auditLogService)
    {
        _context = context;
        _auditLogService = auditLogService;
    }

    // GET: api/projectview
    //[HttpGet]
    //public async Task<IActionResult> GetProjectViews()
    //{
    //    int empCode = User.GetEmpCode();

    //    var projectViews = await _context.projectViews
    //        .Where(p => p.IsDelete == false)
    //        .Select(p => new ProjectViewDto
    //        {
    //            ProjectId = p.ProjectId,
    //            ProjectName = p.ProjectName,
    //            ClientId = p.ClientId,
    //            ClientName = p.ClientName,
    //            ProjectStatus = p.ProjectStatus,
    //            DepartmentName = p.DepartmentName,
    //            DepartmentId = p.DepartmentId,
    //            Status_Id = p.status_Id,
    //            ProjectManagers = p.ProjectManagers,
    //            IsDelete = p.IsDelete,
    //            ManagerIds = new List<int>()
    //        })
    //        .ToListAsync();

    //    var managerLookup = await _context.ProjectManagers
    //.GroupBy(pm => pm.ProjectId)
    //.Select(g => new
    //{
    //    ProjectId = g.Key,
    //    ManagerIds = g.Select(pm => pm.ManagerId).ToList()
    //})
    //.ToDictionaryAsync(x => x.ProjectId, x => x.ManagerIds);
    //    foreach (var project in projectViews)
    //    {
    //        if (managerLookup.TryGetValue(project.ProjectId, out var managerIds))
    //            project.ManagerIds = managerIds;
    //    }


    //    return Ok(projectViews);
    //}

    [HttpGet]
    public async Task<IActionResult> GetProjectViews()
    {
        int empCode = User.GetEmpCode();

        // 🔹 Get logged-in user role
        var user = await _context.UserDetails
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.Emp_code == empCode && !u.IsDelete);

        if (user == null)
            return Unauthorized("Invalid user");

        bool isAdmin = user.IsAdmin;

        // 🔹 Get project-manager mapping for this user (if not admin)
        var assignedProjectIds = new List<int>();

        if (!isAdmin)
        {
            assignedProjectIds = await _context.ProjectManagers
                .Where(pm => pm.ManagerId == empCode && pm.IsActive)
                .Select(pm => pm.ProjectId)
                .Distinct()
                .ToListAsync();
        }

        // 🔹 Main project query
        var projectViewsQuery = _context.projectViews
            .Where(p => !p.IsDelete);

        // 🔐 Filter only if NOT admin
        if (!isAdmin)
        {
            projectViewsQuery = projectViewsQuery
                .Where(p => assignedProjectIds.Contains(p.ProjectId));
        }

        var projectViews = await projectViewsQuery
            .Select(p => new ProjectViewDto
            {
                ProjectId = p.ProjectId,
                ProjectName = p.ProjectName,
                ClientId = p.ClientId,
                ClientName = p.ClientName,
                ProjectStatus = p.ProjectStatus,
                DepartmentName = p.DepartmentName,
                DepartmentId = p.DepartmentId,
                Status_Id = p.status_Id,
                ProjectManagers = p.ProjectManagers,
                IsDelete = p.IsDelete,
                ManagerIds = new List<int>()
            })
            .ToListAsync();

        // 🔹 Populate manager IDs per project
        var managerLookup = await _context.ProjectManagers
            .GroupBy(pm => pm.ProjectId)
            .Select(g => new
            {
                ProjectId = g.Key,
                ManagerIds = g.Select(pm => pm.ManagerId).ToList()
            })
            .ToDictionaryAsync(x => x.ProjectId, x => x.ManagerIds);

        foreach (var project in projectViews)
        {
            if (managerLookup.TryGetValue(project.ProjectId, out var managerIds))
            {
                project.ManagerIds = managerIds;
            }
        }

        return Ok(projectViews);
    }



    // POST: api/projectview
    [HttpPost]
    public async Task<IActionResult> CreateProject([FromBody] CreateProjectDto dto)
    {
        if (dto == null)
        {
            return BadRequest("Project information is required.");
        }

        int empCode = User.GetEmpCode();

        try
        {
            // Check if project name already exists
            var existingProject = await _context.ProjectInfo
                .FirstOrDefaultAsync(p => p.Project_name == dto.Project_name);

            if (existingProject != null)
            {
                if (existingProject.isDelete)
                {
                    // reactivate soft-deleted project
                    existingProject.isDelete = false;
                    existingProject.Status_Id = 1;

                    _context.ProjectInfo.Update(existingProject);
                    await _context.SaveChangesAsync();

                    return Ok(new { message = "Soft-deleted Project reactivated successfully." });
                }
                else
                {
                    return Conflict(new { message = $"A '{existingProject.Project_name}' Project with the same name already exists." });
                }
            }

            //// Check color code already exists
            bool colorExists = await _context.ProjectInfo
                .AnyAsync(p => p.Color_Code == dto.Color_Code);

            if (colorExists)
            {
                return Conflict(new { message = "Color code already exists. Please choose another color." });
            }

            // Set default status if missing
            if (dto.Status_Id == 0)
            {
                dto.Status_Id = 1;
            }

            // Create main project record
            var projectInfo = new ProjectInfo
            {
                Project_name = dto.Project_name,
                Client_Id = dto.Client_Id,
                ProjectCategoryId = dto.ProjectCategoryId,
                Start_date = dto.Start_date,
                Due_date = dto.Due_date,
                Department_Id = dto.Department_Id,
                Status_Id = dto.Status_Id,
                Color_Code = dto.Color_Code,
                isDelete = false,

                //CreatedBy = empCode,
                //UpdatedBy = empCode,
            };

            _context.ProjectInfo.Add(projectInfo);
            await _context.SaveChangesAsync();

            // Insert managers (NEW LOGIC)
            if (dto.Managers != null && dto.Managers.Any())
            {
                foreach (var managerId in dto.Managers)
                {
                    _context.ProjectManagers.Add(new ProjectManagers
                    {
                        ProjectId = projectInfo.Project_id,
                        ManagerId = managerId
                    });
                }

                await _context.SaveChangesAsync();
            }

            // 🔹 AUDIT (CREATE PROJECT)
            try
            {
                await _auditLogService.LogAsync(new AuditLog
                {
                    ActorEmpCode = empCode,
                    TargetEmpCode = null,
                    ModuleName = AuditModule.Project.ToString(),
                    ActionType = AuditAction.CREATE.ToString(),
                    EntityName = AuditEntity.ProjectInfo.ToString(),
                    NewValue = JsonSerializer.Serialize(projectInfo),
                    Remarks = "Project created"
                });
            }
            catch { }

            return CreatedAtAction(nameof(GetProjectById),
                new { id = projectInfo.Project_id },
                new { message = "Project created successfully.", project = projectInfo });
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }

    [HttpPost("update/{id}")]
    public async Task<IActionResult> UpdateProject(int id, [FromBody] ProjectUpdateDto dto)
    {
        int empCode = User.GetEmpCode();

        var oldProject = await _context.projectViews
        .AsNoTracking()
        .FirstOrDefaultAsync(p => p.ProjectId == id);

        if (oldProject == null)
            return NotFound("Project not found.");  

        // Inactivate check stays same
        const int InactiveStatusId = 2;

        if (dto.Status_Id == InactiveStatusId)
        {
            bool hasMembers = await _context.ProjectMembers
                .AnyAsync(pm => pm.projectid == id && pm.IsDeleted == false);

            bool hasTasks = await _context.ProjectTasks
                .AnyAsync(pt => pt.Project_Id == id);

            if (hasMembers || hasTasks)
            {
                return BadRequest(new { message = "Cannot set project to inactive because project has assigned members or tasks." });
            }
        }

        var project = await _context.ProjectInfo.FindAsync(id);
        if (project == null)
            return NotFound($"Project with id {id} not found.");

        // update project basic fields
        project.Department_Id = dto.Department_Id;
        project.Status_Id = dto.Status_Id;
        //project.UpdatedBy = empCode;

        _context.ProjectInfo.Update(project);

        // update managers (delete old → insert new)
        var oldManagers = _context.ProjectManagers.Where(pm => pm.ProjectId == id);
        _context.ProjectManagers.RemoveRange(oldManagers);

        if (dto.Managers != null && dto.Managers.Any())
        {
            foreach (var managerId in dto.Managers)
            {
                _context.ProjectManagers.Add(new ProjectManagers
                {
                    ProjectId = id,
                    ManagerId = managerId
                });
            }
        }

        await _context.SaveChangesAsync();

        var newProject = await _context.projectViews
        .AsNoTracking()
        .FirstOrDefaultAsync(p => p.ProjectId == id);

        // 🔹 AUDIT (UPDATE PROJECT)
        try
        {
            await _auditLogService.LogAsync(new AuditLog
            {
                ActorEmpCode = empCode,
                ModuleName = AuditModule.Project.ToString(),
                ActionType = AuditAction.UPDATE.ToString(),
                EntityName = AuditEntity.ProjectInfo.ToString(),
                OldValue = JsonSerializer.Serialize(oldProject),
                NewValue = JsonSerializer.Serialize(newProject),
                Remarks = "Project updated"
            });
        }
        catch { }

        return Ok(new { message = "Project updated successfully." });
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetProjectById(int id)
    {
        var project = await _context.ProjectInfo.FindAsync(id);
        if (project == null)
        {
            return NotFound();
        }
        return Ok(project);
    }

    [HttpPost("delete/{id}")]
    public async Task<IActionResult> DeleteProjectInfo(int id)
    {
        int empCode = User.GetEmpCode();

        var projectInfo = await _context.ProjectInfo.FindAsync(id);
        if (projectInfo == null)
        {
            return NotFound($"ProjectInfo with id {id} not found.");
        }

        // Check if the statusId is 1 (active). If so, don't allow deletion.
        if (projectInfo.Status_Id == 1)
        {
            return BadRequest(new { message = $"You cannot delete the Active Project" });
        }

        var oldProject = JsonSerializer.Serialize(projectInfo);

        // Proceed with deletion for statusId 2 (inactive).
        projectInfo.isDelete = true;
        //projectInfo.DeletedBy = empCode;
        //projectInfo.UpdatedBy = empCode;

        try
        {
            await _context.SaveChangesAsync();

            // 🔹 AUDIT (DELETE PROJECT)
            try
            {
                await _auditLogService.LogAsync(new AuditLog
                {
                    ActorEmpCode = empCode,
                    ModuleName = AuditModule.Project.ToString(),
                    ActionType = AuditAction.DELETE.ToString(),
                    EntityName = AuditEntity.ProjectInfo.ToString(),
                    OldValue = oldProject,
                    Remarks = $"Project '{projectInfo.Project_name}' deleted"
                });
            }
            catch { }

            return Ok(new { message = $"Project {projectInfo.Project_name} has been deleted." });
        }

        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }

    // GET: api/ProjectView/GetProjectDetails
    [HttpGet("project-name-color")]
    public async Task<ActionResult<IEnumerable<ProjectInfoDto>>> GetProjectDetails()
    {
        var projects = await _context.ProjectInfo
            .Where(p => p.isDelete == false)
            .Select(p => new ProjectInfoDto
            {
                ProjectId = p.Project_id,
                ProjectName = p.Project_name,
                ColorCode = p.Color_Code
            })
            .ToListAsync();
        if (projects == null || !projects.Any())
        {
            return NotFound("No project details found.");
        }
        return Ok(projects);
    }
}

