﻿using LoginAppApi.Data;
using LoginAppApi.Extensions;
using LoginAppApi.Models;
using LoginAppApi.Models.Enums;
using LoginAppApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Text.Json;


namespace LoginAppApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class EditProjectController : ControllerBase
    {
        private readonly LoginAppDbContext _context;
        private readonly IAuditLogService _auditLogService;

        [ActivatorUtilitiesConstructor]
        public EditProjectController(LoginAppDbContext context, IAuditLogService auditLogService)
        {
            _context = context;
            _auditLogService = auditLogService;
        }

        //GET
        [HttpGet("{projectId}")]
        public async Task<ActionResult<IEnumerable<EditProject>>> GetProjectInfoById(int projectId)
        {
            var taskHours = await (
            from pt in _context.ProjectTasks
            where pt.Project_Id == projectId
            join td in _context.TimesheetDetails
                on new { pt.Project_Id, pt.Task_Id }
                equals new { td.Project_Id, td.Task_Id } into taskDetails
            from td in taskDetails
                .Where(x => x.Status == "Approved")
                .DefaultIfEmpty()
            group td by new
            {
                pt.Project_Id,
                pt.Task_Id,
                pt.Estimated_hours
            }
            into g
            select new
            {
                TaskId = g.Key.Task_Id,
                ActualHours = g.Sum(x => x != null ? x.Hours : 0),    // Only approved hours counted
                OverheadHours = g.Sum(x => x != null ? x.Hours : 0) - g.Key.Estimated_hours
            }
        ).ToListAsync();
            foreach (var taskHour in taskHours)
            {
                var projectTask = await _context.ProjectTasks
                    .FirstOrDefaultAsync(pt => pt.Project_Id == projectId &&
                                               pt.Task_Id == taskHour.TaskId);

                if (projectTask != null)
                {
                    projectTask.Actual_hours = taskHour.ActualHours;
                    projectTask.Overhead_hours = Math.Max(0, (decimal)taskHour.OverheadHours);

                    // ✅ AUTO STATUS UPDATE
                    if (projectTask.Actual_hours > 0 && projectTask.Status_id == 5) // Todo
                    {
                        projectTask.Status_id = 6; // InProgress
                        projectTask.updated_at = DateTime.UtcNow;
                    }
                }
            }

            await _context.SaveChangesAsync();
            var tasks = await _context.ProjectTasks
            .Where(pt => pt.Project_Id == projectId)
            .Join(
                _context.statusinfo,
                pt => pt.Status_id,
                si => si.status_id,
                (pt, si) => new { pt, si }
            )

            //.Join(
            //    _context.Categories,
            //    x => x.pt.category_Id,
            //    c => c.CategoryId,
            //    (x, c) => new { x.pt, x.si, c }
            //)
            //.Join(
            //    _context.Tasks,
            //    x => x.pt.sub_category_Id,
            //    sc => sc.Id,
            //    (x, sc) => new { x.pt, x.si, x.c, sc }
            //)
            .OrderByDescending(x => x.pt.created_at)
            .Select(result => new
            {
                result.pt.Task_Id,
                result.pt.Project_Id,
                //result.pt.category_Id,
                //Category_Name = result.c.CategoryName,
                //result.pt.sub_category_Id,
                //Sub_Category_Name = result.sc.TaskName,
                result.pt.Task_Name,
                result.pt.Task_Desc,
                result.pt.Estimated_hours,
                result.pt.Actual_hours,
                result.pt.Overhead_hours,
                result.pt.Status_id,
                Status_Name = result.si.status_name,
                result.pt.IsBillable,
                result.pt.created_at,
                result.pt.updated_at
            })
            .ToListAsync();
            return Ok(tasks);
        }

        //POST

        [HttpPost]
        public async Task<IActionResult> CreateProjectTask([FromBody] CreateProjectTaskDto dto)
        {

            if (dto == null)
                return BadRequest("Invalid data.");

            int loggedInEmpCode = User.GetEmpCode();


            if (dto.Project_Id == 0)
                return BadRequest("Project_Id is required.");

            if (string.IsNullOrWhiteSpace(dto.Task_Name))
                return BadRequest("Task name is required.");

            //if (dto.Estimated_hours.HasValue && (dto.Estimated_hours < 1 || dto.Estimated_hours > 500))
            //    return BadRequest("Estimated hours must be between 1 and 500.");

            //if (!await _context.Categories.AnyAsync(c => c.CategoryId == dto.category_Id && !c.IsDeleted))
            //    return BadRequest(new { message = $"Category {dto.category_Id} not found." });

            //if (!await _context.Tasks.AnyAsync(t => t.Id == dto.sub_category_Id && !t.IsDeleted))
            //    return BadRequest(new { message = $"Sub category (task) {dto.sub_category_Id} not found." });

            // Duplicate check (same project + category + sub-category + task name)
            bool isTaskExists = await _context.ProjectTasks.AnyAsync(pt =>
                pt.Project_Id == dto.Project_Id &&
                //pt.category_Id == dto.category_Id &&
                //pt.sub_category_Id == dto.sub_category_Id &&
                pt.Task_Name.ToLower() == dto.Task_Name.Trim().ToLower()
            );

            if (isTaskExists)
                return Conflict(new { message = "This task is already assigned to this project." });

            try
            {

                var projectTask = new ProjectTask
                {
                    Project_Id = dto.Project_Id,
                    //category_Id = dto.category_Id,
                    //sub_category_Id = dto.sub_category_Id,
                    Task_Name = dto.Task_Name.Trim(),
                    Task_Desc = string.IsNullOrWhiteSpace(dto.Task_Desc) ? null : dto.Task_Desc.Trim(),
                    Estimated_hours = dto.Estimated_hours,
                    IsBillable = dto.IsBillable,
                    Actual_hours = 0,
                    Overhead_hours = 0,
                    Status_id = 5,
                    created_at = DateTime.Now,
                    updated_at = DateTime.Now,
                    //CreatedBy = loggedInEmpCode,
                    //UpdatedBy = loggedInEmpCode
                };

                _context.ProjectTasks.Add(projectTask);
                await _context.SaveChangesAsync(); // <-- If this still fails, inner exception is key

                // 🔹 AUDIT LOG (CREATE TASK)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = loggedInEmpCode,
                        ModuleName = AuditModule.ProjectTaskAllocation.GetDisplayName(),
                        ActionType = AuditAction.CREATE.ToString(),
                        EntityName = AuditEntity.ProjectTask.ToString(),
                        NewValue = System.Text.Json.JsonSerializer.Serialize(projectTask),
                        Remarks = "Task created"
                    });
                }
                catch { }

                return Ok(new
                {
                    message = "Task assigned successfully.",
                    taskId = projectTask.Task_Id
                });
            }
            catch (DbUpdateException dbEx)
            {
                var inner = dbEx.InnerException?.Message ?? dbEx.Message;
                // Log the exception with your logger (not shown here)
                return StatusCode(500, new { message = "Database error while saving project task.", detail = inner });
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, new { message = "Internal server error.", detail = ex.Message });
            }
        }

        [HttpPost("bulk")]
        public async Task<IActionResult> BulkCreateProjectTasks([FromBody] BulkCreateProjectTaskDto dto)
        {
            if (dto == null || dto.Tasks == null || !dto.Tasks.Any())
                return BadRequest("Invalid data or empty task list.");

            if (dto.Project_Id == 0)
                return BadRequest("Project_Id is required.");

            var result = new BulkCreateResultDto();

            try
            {
                var existingTasks = await _context.ProjectTasks
                    .Where(pt => pt.Project_Id == dto.Project_Id)
                    .ToListAsync();

                foreach (var taskDto in dto.Tasks)
                {
                    if (string.IsNullOrWhiteSpace(taskDto.Task_Name))
                    {
                        result.Errors.Add(new BulkTaskErrorDto { TaskName = "Unnamed Task", Error = "Task Name is required." });
                        continue;
                    }

                    var existingTask = existingTasks.FirstOrDefault(t => t.Task_Name.Equals(taskDto.Task_Name.Trim(), StringComparison.OrdinalIgnoreCase));

                    if (existingTask != null)
                    {
                        if (dto.Strategy == ConflictResolutionStrategy.Skip)
                        {
                            result.SkippedCount++;
                            continue;
                        }
                        else if (dto.Strategy == ConflictResolutionStrategy.Overwrite)
                        {
                            existingTask.Task_Desc = string.IsNullOrWhiteSpace(taskDto.Task_Desc) ? existingTask.Task_Desc : taskDto.Task_Desc.Trim();
                            existingTask.Estimated_hours = taskDto.Estimated_hours ?? existingTask.Estimated_hours;
                            existingTask.IsBillable = taskDto.IsBillable;
                            existingTask.updated_at = DateTime.Now;
                            _context.Entry(existingTask).State = EntityState.Modified;
                            result.UpdatedCount++;
                        }
                        else if (dto.Strategy == ConflictResolutionStrategy.AddAsCopy)
                        {
                            string baseName = taskDto.Task_Name.Trim();
                            int counter = 1;
                            string newName;
                            do
                            {
                                newName = $"{baseName} ({counter++})";
                            } while (existingTasks.Any(t => t.Task_Name.Equals(newName, StringComparison.OrdinalIgnoreCase)));

                            var newTask = new ProjectTask
                            {
                                Project_Id = dto.Project_Id,
                                Task_Name = newName,
                                Task_Desc = string.IsNullOrWhiteSpace(taskDto.Task_Desc) ? null : taskDto.Task_Desc.Trim(),
                                Estimated_hours = taskDto.Estimated_hours,
                                IsBillable = taskDto.IsBillable,
                                Actual_hours = 0,
                                Overhead_hours = 0,
                                Status_id = 5,
                                created_at = DateTime.Now,
                                updated_at = DateTime.Now
                            };
                            _context.ProjectTasks.Add(newTask);
                            existingTasks.Add(newTask);
                            result.AddedCount++;
                        }
                    }
                    else
                    {
                        var newTask = new ProjectTask
                        {
                            Project_Id = dto.Project_Id,
                            Task_Name = taskDto.Task_Name.Trim(),
                            Task_Desc = string.IsNullOrWhiteSpace(taskDto.Task_Desc) ? null : taskDto.Task_Desc.Trim(),
                            Estimated_hours = taskDto.Estimated_hours,
                            IsBillable = taskDto.IsBillable,
                            Actual_hours = 0,
                            Overhead_hours = 0,
                            Status_id = 5,
                            created_at = DateTime.Now,
                            updated_at = DateTime.Now
                        };
                        _context.ProjectTasks.Add(newTask);
                        existingTasks.Add(newTask);
                        result.AddedCount++;
                    }
                }

                await _context.SaveChangesAsync();

                result.Message = $"Processed {dto.Tasks.Count} tasks: {result.AddedCount} added, {result.UpdatedCount} updated, {result.SkippedCount} skipped.";
                if (result.Errors.Any())
                {
                    result.Message += $" {result.Errors.Count} tasks had errors.";
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Internal server error.", detail = ex.Message });
            }
        }


        //EDIT
        [HttpPost("update/{task_id}")]
        public async Task<IActionResult> UpdateProjectTask(int task_id, [FromBody] UpdateProjectTaskRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request data is missing");
            }
            int loggedInEmpCode = User.GetEmpCode();
            var projectTaskview = await _context.ProjectEditView.FirstOrDefaultAsync(pt => pt.TaskId == task_id);

            var oldValue = JsonSerializer.Serialize(projectTaskview);
            try
            {
                var projectTask = await _context.ProjectTasks.FirstOrDefaultAsync(pt => pt.Task_Id == task_id);
                if (projectTask == null)
                {
                    return NotFound($"Task with Id {task_id} was not found");
                }
                projectTask.Estimated_hours = request.Estimated_hours;
                projectTask.Status_id = request.Status_id;
                projectTask.IsBillable = request.Billable;
                projectTask.updated_at = DateTime.UtcNow;
                //projectTask.UpdatedBy = User.GetEmpCode();

                _context.ProjectTasks.Update(projectTask);
                await _context.SaveChangesAsync();

                // 🔹 AUDIT LOG (UPDATE TASK)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = loggedInEmpCode,
                        ModuleName = AuditModule.ProjectTaskAllocation.GetDisplayName(),
                        ActionType = AuditAction.UPDATE.ToString(),
                        EntityName = AuditEntity.ProjectTask.ToString(),
                        OldValue = oldValue,
                        NewValue = JsonSerializer.Serialize(projectTaskview),
                        Remarks = "Task updated"
                    });
                }
                catch { }
                return Ok("Task updated successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        //DELETE
        [HttpPost("delete/{task_id}")]
        public async Task<IActionResult> DeleteTaskByIndexId(int task_id)
        {
            int loggedInEmpCode = User.GetEmpCode();
            // 1️⃣ Check if task exists
            var task = await _context.ProjectTasks
                .AsNoTracking()
                .FirstOrDefaultAsync(t => t.Task_Id == task_id);

            if (task == null)
                return NotFound(new { message = "Task not found." });

            // 2️⃣ Check if task is already logged in timesheet
            bool isTaskLogged = await _context.TimesheetDetails
                .AnyAsync(td => td.Task_Id == task_id);

            if (isTaskLogged)
            {
                return BadRequest(new { message = "Cannot delete the task. Hours are already logged for this task." });
            }

            // 3️⃣ Allow delete only if status is Todo (5)
            if (task.Status_id != 5)
            {
                return BadRequest(new { message = "Task can be deleted only when its status is Todo." });
            }
            var oldValue = System.Text.Json.JsonSerializer.Serialize(task);
            // 🔹 AUDIT LOG (DELETE TASK)
            try
            {
                await _auditLogService.LogAsync(new AuditLog
                {
                    ActorEmpCode = loggedInEmpCode,
                    ModuleName = AuditModule.ProjectTaskAllocation.GetDisplayName(),
                    ActionType = AuditAction.DELETE.ToString(),
                    EntityName = AuditEntity.ProjectTask.ToString(),
                    OldValue = oldValue,
                    Remarks = $"Task '{task.Task_Name}' deleted"
                });
            }
            catch { }
            // 4️⃣ Delete task
            _context.ProjectTasks.Remove(task);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Task deleted successfully." });
        }


        [HttpGet("filter")]
        public async Task<IActionResult> GetFilteredTasks(int projectId)
        {
            var result = await _context.ProjectTasks
                .Where(t => t.Project_Id == projectId)
                .OrderByDescending(t => t.Task_Id)
                .Select(t => new
                {
                    t.Task_Id,
                    t.Project_Id,
                    t.Task_Name,
                    t.Task_Desc,
                    t.Estimated_hours,
                    t.Actual_hours,
                    t.Overhead_hours,
                    t.Status_id,
                    t.IsBillable,
                    t.created_at,
                    t.updated_at
                })
                .ToListAsync();

            return Ok(result);
        }



    }
}

