﻿using LoginAppApi.Data;
using LoginAppApi.Extensions;
using LoginAppApi.Models;
using LoginAppApi.Models.Enums;
using LoginAppApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LoginAppApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectMembersController : ControllerBase
    {
        private readonly LoginAppDbContext _context;
        private readonly IAuditLogService _auditLogService;

        public ProjectMembersController(LoginAppDbContext context, IAuditLogService auditLogService)
        {
            _context = context;
            _auditLogService = auditLogService;
        }

        //GET by ID
        [HttpGet("{projectid}")]
        public async Task<ActionResult<IEnumerable<ProjectMembersView>>> GetProjectMembersByProjectId(int projectid)
        {
            var ProjectMembers = await _context.ProjectMembersView
                                            .Where(tm => tm.Projectid == projectid && !tm.IsDelete)
                                            .OrderByDescending(pm => pm.Index_id)
                                            .ToListAsync();

            if (!ProjectMembers.Any())
            {
                return NotFound(new { Message = $"No members found for projectid {projectid}" });

            }

            return Ok(ProjectMembers);
        }


        // GET
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProjectMembersView>>> GetProjectMembersView()
        {
            var ProjectMembers = await _context.ProjectMembersView.ToListAsync();
            return Ok(ProjectMembers);
        }
        //POST
        [HttpPost]
        public async Task<ActionResult> PostTeamMember(ProjectMemberRequest request)
        {
            int loggedInEmpCode = User.GetEmpCode();

            // Check if the member is already added to the same project (even if soft deleted)
            var existingMember = await _context.ProjectMembers
                .IgnoreQueryFilters()
                .FirstOrDefaultAsync(pm => pm.Emp_code == request.Emp_code && pm.projectid == request.projectid);

            ProjectMember auditEntity;

            if (existingMember != null)
            {
                if (existingMember.IsDeleted)
                {
                    // Reactivate soft-deleted entry
                    existingMember.IsDeleted = false;
                    existingMember.User_name = request.User_name;
                    auditEntity = existingMember;
                }
                else
                {
                    // Already assigned and active
                    return BadRequest(new
                    {
                        field = "Emp_code",
                        message = $"Employee '{request.User_name}' is already assigned to this project."
                    });
                }
            }
            else
            {
                // No existing assignment, create new one
                 auditEntity = new ProjectMember
                {
                    Emp_code = request.Emp_code,
                    User_name = request.User_name,
                    projectid = request.projectid,
                    IsDeleted = false
                };

                _context.ProjectMembers.Add(auditEntity);
            }

            await _context.SaveChangesAsync();

            // 🔹 AUDIT LOG (ADD MEMBER)
            try
            {
                await _auditLogService.LogAsync(new AuditLog
                {
                    ActorEmpCode = loggedInEmpCode,
                    TargetEmpCode = request.Emp_code,
                    ModuleName = AuditModule.ResourceAllocation.GetDisplayName(),
                    ActionType = AuditAction.CREATE.ToString(),
                    EntityName = AuditEntity.ProjectMember.ToString(),
                    NewValue = System.Text.Json.JsonSerializer.Serialize(auditEntity),
                    Remarks = $"Employee {request.User_name} assigned to project {request.projectid}"
                });
            }
            catch
            {
                // never block main flow
            }

            return Ok(new { message = "Project member assigned successfully." });
        }

        //DELETE
        [HttpPost("{projectId}/{empCode}")]
        public async Task<IActionResult> DeleteTeamMember(int projectId, int empCode)
        {
            int loggedInEmpCode = User.GetEmpCode();

            // Fetch existing record for audit
            var existingMember = await _context.ProjectMembers
                .AsNoTracking()
                .FirstOrDefaultAsync(pm =>
                    pm.projectid == projectId &&
                    pm.Emp_code == empCode &&
                    !pm.IsDeleted);

            if (existingMember == null)
            {
                return NotFound(new
                {
                    message = $"Employee {empCode} not found in project {projectId}."
                });
            }

            var oldValue = System.Text.Json.JsonSerializer.Serialize(existingMember);

            try
            {
                // Execute the stored procedure
                await _context.Database.ExecuteSqlRawAsync("EXEC DeleteTeamMemberFromProject @p0, @p1",
                    parameters: new object[] { projectId, empCode });

                // 🔹 AUDIT LOG (REMOVE MEMBER)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = loggedInEmpCode,
                        TargetEmpCode = empCode,
                        ModuleName = AuditModule.ResourceAllocation.GetDisplayName(),
                        ActionType = AuditAction.DELETE.ToString(),
                        EntityName = AuditEntity.ProjectMember.ToString(),
                        OldValue = oldValue,
                        Remarks = $"Employee {empCode} removed from project {projectId}"
                    });
                }
                catch
                {
                    // ignore audit failure
                }

                return Ok(new { message = $"Employee {empCode} removed from Project {projectId}." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting the team member.", error = ex.Message });
            }
        }

        //  GET
        [HttpGet("role")]
        public async Task<ActionResult<IEnumerable<object>>> GetUserDetailsByRoleId()
        {

            var userDetails = await _context.UserDetails
                .Where(u => u.Status_Id == 1)
                .Select(u => new
                {
                    u.Emp_code,
                    u.User_name,
                    u.Email_Id,
                    u.Designation_Id,
                })
                .ToListAsync();

            if (!userDetails.Any())
            {
                return NotFound(new { message = $"No users found ." });
            }

            return Ok(userDetails);
        }
    }
}
