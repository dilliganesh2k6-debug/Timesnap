﻿using LoginAppApi.Data;
using LoginAppApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LoginAppApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ScreenRightsController : ControllerBase
    {
        private readonly LoginAppDbContext _context;

        public ScreenRightsController(LoginAppDbContext context)
        {
            _context = context;
        }

        [HttpGet("view")]
        public async Task<ActionResult<IEnumerable<ScreenRightsView>>> GetScreenRightsView()
        {
            var screenRights = await _context.ScreenRightsView.ToListAsync();
            return Ok(screenRights);
        }
        [HttpGet("view/{roleId}")]
        public async Task<ActionResult<IEnumerable<ScreenRightsView>>> GetScreenRightsViewByRole(int roleId)
        {
            var screenRights = await _context.ScreenRightsView
                .Where(sr => sr.RoleId == roleId)
                .ToListAsync();

            if (screenRights.Count == 0)
                return NotFound("No screen rights found for this role.");

            return Ok(screenRights);
        }
        // GET: api/ScreenRights
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ScreenRights>>> GetScreenRights()
        {
            return await _context.ScreenRights.ToListAsync();
        }

        // GET: api/ScreenRights/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<ScreenRights>> GetScreenRight(int id)
        {
            var screenRight = await _context.ScreenRights.FindAsync(id);
            if (screenRight == null)
                return NotFound();

            return screenRight;
        }

        [HttpPost("save")]
        public async Task<IActionResult> SaveScreenRights([FromBody] List<ScreenRights> screenRights)
        {
            foreach (var right in screenRights)
            {
                _context.Entry(right).State = right.ScreenRightId == 0 ? EntityState.Added : EntityState.Modified;
            }
            await _context.SaveChangesAsync();
            return Ok();
        }


        // PUT: api/ScreenRights/{id}
        [HttpPost("{id}")]
        public async Task<IActionResult> PutScreenRight(int id, ScreenRights screenRight)
        {
            if (id != screenRight.ScreenRightId)
                return BadRequest();

            _context.Entry(screenRight).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.ScreenRights.Any(e => e.ScreenRightId == id))
                    return NotFound();
                else
                    throw;
            }

            return NoContent();
        } 
    }
}