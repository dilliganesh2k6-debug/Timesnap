﻿using LoginAppApi.Data;
using LoginAppApi.Extensions;
using LoginAppApi.Models;
using LoginAppApi.Models.constants;
using LoginAppApi.Models.Enums;
using LoginAppApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.AccessControl;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;


namespace LoginAppApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly LoginAppDbContext _context;
        private readonly IAuditLogService _auditLogService;
        private readonly IConfiguration _configuration;
        public UsersController(LoginAppDbContext context, IAuditLogService auditLogService, IConfiguration configuration)
        {
            _context = context;
            _auditLogService = auditLogService;
            _configuration = configuration;
        }

        //GET
        [HttpGet]
        public async Task<IActionResult> GetUsers()
        {
            var users = await _context.Users
                                      .Join(_context.UserDetails,
                                            u => u.Emp_code,
                                            ud => ud.Emp_code,
                                            (u, ud) => new { User = u, UserDetails = ud })
                                      .Where(joined => joined.UserDetails.Status_Id != 2 && !joined.UserDetails.IsDelete)
                                      .Select(joined => new
                                      {
                                          joined.User.UserId,
                                          joined.User.Email_Id,
                                          joined.User.Password,
                                          joined.User.Role_Id
                                      })
                                      .ToListAsync();

            return Ok(users);
        }

        // POST
        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<ActionResult> Login([FromBody] User loginRequest)
        {
            try
            {
                // 1. Validate request
                if (loginRequest == null ||
                    string.IsNullOrWhiteSpace(loginRequest.Email_Id) ||
                    string.IsNullOrWhiteSpace(loginRequest.Password))
                {
                    return BadRequest(new { message = "Email and password are required." });
                }

                // 2. Fetch user with details
                var userWithDetails = await _context.Users
                    .Join(_context.UserDetails,
                          u => u.Emp_code,
                          ud => ud.Emp_code,
                          (u, ud) => new { User = u, UserDetails = ud })
                    .FirstOrDefaultAsync(x => x.User.Email_Id == loginRequest.Email_Id);

                // 3. User not found
                if (userWithDetails == null)
                {
                    await SafeAuditAsync(
                        null,
                        AuditAction.LOGIN_FAILED.ToString(),
                        "User not found"
                    );

                    return Unauthorized(new
                    {
                        message = "Invalid email. Please check your email or contact the administrator."
                    });
                }

                int empCode = userWithDetails.User.Emp_code;

                // 4. Deleted user
                if (userWithDetails.UserDetails.IsDelete)
                {
                    await SafeAuditAsync(
                        empCode,
                        AuditAction.LOGIN_FAILED.ToString(),
                        "Account deleted"
                    );

                    return Unauthorized(new
                    {
                        message = "This account has been deleted. Please contact the administrator."
                    });
                }

                // 5. Inactive user
                if (userWithDetails.UserDetails.Status_Id == 2)
                {
                    await SafeAuditAsync(
                        empCode,
                        AuditAction.LOGIN_FAILED.ToString(),
                        "Account inactive"
                    );

                    return Unauthorized(new
                    {
                        message = "Your account is inactive. Please contact the administrator."
                    });
                }

                // 6. Password validation
                string encryptedInputPassword = ComputeSha256Hash(loginRequest.Password);

                if (!string.Equals(
                        userWithDetails.User.Password,
                        encryptedInputPassword,
                        StringComparison.OrdinalIgnoreCase))
                {
                    await SafeAuditAsync(
                        empCode,
                        AuditAction.LOGIN_FAILED.ToString(),
                        "Incorrect password"
                    );

                    return Unauthorized(new
                    {
                        message = "Incorrect password. Please try again."
                    });
                }

                // 7. Update login status
                userWithDetails.UserDetails.IsLoggedIn = true;
                userWithDetails.UserDetails.LastActivity = DateTime.UtcNow;
                await _context.SaveChangesAsync();

                bool isAdmin = userWithDetails.UserDetails.IsAdmin;
                List<object> accessDetails;
                // 8. Fetch access details
                if (isAdmin)
                {
                    accessDetails = await _context.screens
                     .GroupBy(s => new { s.ScreenId, s.ScreenName })
                     .Select(g => new
                     {
                         ScreenId = g.Key.ScreenId,
                         screenname = g.Key.ScreenName,
                         FullAccess = 1,
                         ReadOnly = 0
                     })
                     .ToListAsync<object>();
                }
                else
                {
                    // 🔒 Existing role-based access (UNCHANGED)
                    accessDetails = await _context.Access
                        .Where(a => a.RoleId == userWithDetails.User.Role_Id && a.HideShow)
                        .Select(a => new
                        {
                            a.ScreenId,
                            screenname = a.ScreenName,
                            FullAccess = a.FullAccess ? 1 : 0,
                            ReadOnly = a.ReadOnly ? 1 : 0
                        })
                        .ToListAsync<object>();
                }
                // 10. Token 
                var token = GenerateJwtToken(
                            userWithDetails.User.Emp_code,
                            userWithDetails.User.Role_Id,
                            userWithDetails.UserDetails.User_name
                        );
                await SafeAuditAsync(
                        empCode,
                        AuditAction.LOGIN.ToString(),
                        "User LoggedIn successful"
                    );
                return Ok(new
                {
                    message = "Login successful",
                    employeeCode = userWithDetails.User.Emp_code,
                    email = userWithDetails.User.Email_Id,
                    roleId = userWithDetails.User.Role_Id,
                    isAdmin = isAdmin,               // ⭐ VERY IMPORTANT FOR FRONTEND
                    token,
                    accessDetails
                });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new
                {
                    message = "An unexpected error occurred while processing your request.",
                    error = ex.Message
                });
            }
        }

        //UPDATE
        [HttpPost("ChangePassword")]
        public async Task<IActionResult> ChangePassword([FromBody] ChangePassword request)
        {
            int? loggedEmpCode = User.GetEmpCode();
            if (request == null || request.EmpCode <= 0)
                return BadRequest(new { message = "EmpCode is required." });

            // Get the user record
            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Emp_code == request.EmpCode);

            if (user == null)
                return NotFound(new { message = "User not found." });

            // 🔹 ADMIN RESET (default password)
            if (!string.IsNullOrEmpty(request.NewPassword) &&
                request.NewPassword.Equals("reset", StringComparison.OrdinalIgnoreCase))
            {
                string defaultHash = ComputeSha256Hash("ciglobal123");
                user.Password = defaultHash;
                await _context.SaveChangesAsync();

                // 🔹 AUDIT (PASSWORD RESET)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = loggedEmpCode,
                        ModuleName = AuditModule.Authentication.ToString(),
                        ActionType = AuditAction.PASSWORD_CHANGE.ToString(),
                        EntityName = AuditEntity.Users.ToString(),
                        Remarks = "Password reset to default by admin"
                    });
                }
                catch
                {
                    // Never block password reset
                }

                return Ok(new { message = "Password reset to default successfully (ciglobal123)." });
            }

            // Ensure both current and new passwords are provided
            if (string.IsNullOrEmpty(request.CurrentPassword) ||
                string.IsNullOrEmpty(request.NewPassword))
                return BadRequest(new
                {
                    message = "Current password and new password are required."
                });

            // Verify the current password
            string currentPasswordHash = ComputeSha256Hash(request.CurrentPassword);

            if (!string.Equals(user.Password, currentPasswordHash, StringComparison.OrdinalIgnoreCase))
            {
                // 🔹 AUDIT (FAILED CHANGE)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = loggedEmpCode,
                        ModuleName = AuditModule.Authentication.ToString(),
                        ActionType = AuditAction.PASSWORD_CHANGE.ToString(),
                        EntityName = AuditEntity.Users.ToString(),
                        Remarks = "Incorrect current password"
                    });
                }
                catch
                {
                    // ignore
                }

                return Unauthorized(new { message = "Current password is incorrect." });
            }

            // Prevent setting same password
            if (string.Equals(
                request.CurrentPassword,
                request.NewPassword,
                StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest(new
                {
                    message = "New password cannot be same as current password."
                });
            }

            // Hash and update new password
            string newPasswordHash = ComputeSha256Hash(request.NewPassword);
            user.Password = newPasswordHash;

            await _context.SaveChangesAsync();

            // 🔹 AUDIT (SUCCESSFUL CHANGE)
            try
            {
                await _auditLogService.LogAsync(new AuditLog
                {
                    ActorEmpCode = loggedEmpCode,
                    ModuleName = AuditModule.Authentication.ToString(),
                    ActionType = AuditAction.PASSWORD_CHANGE.ToString(),
                    EntityName = AuditEntity.Users.ToString(),
                    Remarks = "Password changed successfully"
                });
            }
            catch
            {
                // Never block password change
            }

            return Ok(new { message = "Password changed successfully." });
        }


        private string ComputeSha256Hash(string rawData)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        //RESET
        [HttpPost("ResetToDefaultPassword/{empCode}")]
        public async Task<IActionResult> ResetToDefaultPassword(int empCode)
        {
            try
            {
                int loggedEmpCode = User.GetEmpCode();

                // Find the user by Emp_code
                var user = await _context.Users.FirstOrDefaultAsync(u => u.Emp_code == empCode);

                if (user == null)
                {
                    return NotFound(new { message = "User not found for the given employee code." });
                }

                // Default password hash for 'ciglobal123' (uppercase SHA256)
                string defaultHashedPassword = TimesheetConstants.Status.DefaultHashedPassword;

                // Update password
                user.Password = defaultHashedPassword;
                await _context.SaveChangesAsync();

                // AUDIT LOG (non-blocking)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = loggedEmpCode,
                        TargetEmpCode = empCode,
                        ModuleName = AuditModule.Authentication.ToString(),
                        ActionType = AuditAction.PASSWORD_RESET.ToString(),
                        EntityName = AuditEntity.Users.ToString(),
                        Remarks = "Password reset to default"
                    });
                }
                catch
                {
                    // Never block password reset if audit fails
                }

                return Ok(new
                {
                    message = "Password has been reset to the default value successfully.",
                    empCode = empCode
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while resetting the password.", error = ex.Message });
            }
        }

        //POST
        [HttpPost("logout")]
        public async Task<IActionResult> Logout([FromBody] int empCode)
        {
            var userDetails = await _context.UserDetails.FirstOrDefaultAsync(u => u.Emp_code == empCode);
            if (userDetails == null) return NotFound("User not found");

            // Update logout state
            userDetails.IsLoggedIn = false;
            userDetails.LastActivity = null;
            await _context.SaveChangesAsync();

            // AUDIT LOG (non-blocking)
            try
            {
                await _auditLogService.LogAsync(new AuditLog
                {
                    ActorEmpCode = empCode,
                    ModuleName = AuditModule.Authentication.ToString(),
                    ActionType = AuditAction.LOGOUT.ToString(),
                    EntityName = AuditEntity.Users.ToString(),
                    Remarks = "User logged out successfully"
                });
            }
            catch
            {
                // Never block logout if audit fails
            }

            return Ok("Logout successful");
        }

        //POST
        [HttpPost("updateactivity")]
        public async Task<IActionResult> UpdateLastActivity([FromBody] int empCode)
        {
            var userDetails = await _context.UserDetails.FirstOrDefaultAsync(u => u.Emp_code == empCode);
            if (userDetails == null) return NotFound("User not found");

            userDetails.LastActivity = DateTime.UtcNow;
            await _context.SaveChangesAsync();

            return Ok("Activity updated");
        }

        //GET
        [HttpGet("get-role")]
        public async Task<ActionResult> GetRole([FromQuery] string EmailId, [FromQuery] string password)
        {
            if (string.IsNullOrEmpty(EmailId) || string.IsNullOrEmpty(password))
            {
                return BadRequest("Username and password are required");
            }

            var user = await _context.Users
                                     .FirstOrDefaultAsync(u => u.Email_Id == EmailId && u.Password == password);

            if (user == null)
            {
                return NotFound("User not found or invalid credentials");
            }

            var response = new
            {
                EmailId = user.Email_Id,
                role = user.Role_Id
            };

            return Ok(response);
        }

        //POST
        [HttpPost("saveaccessbyrole")]
        public async Task<IActionResult> SaveAccessPermissionsByRole([FromBody] AccessRequest accessRequest)
        {
            int empCode = User.GetEmpCode();
            var auditLogs = new List<AuditLog>();

            if (accessRequest?.AccessData == null || accessRequest.AccessData.Count == 0)
                return BadRequest("No access data provided.");

            try
            {
                // Get RoleName based on RoleId
                var role = await _context.Roles
                    .FirstOrDefaultAsync(r => r.RoleId == accessRequest.Role_Id);

                if (role == null)
                    return BadRequest("Invalid RoleId.");

                string roleName = role.RoleTitle; // fetch role name

                foreach (var access in accessRequest.AccessData)
                {
                    int screenId = int.Parse(access.ScreenId);

                    if (!access.HideShow) // Apply business rule
                    {
                        access.FullAccess = false;
                        access.ReadOnly = false;
                    }

                    // --- Access Table Insert/Update ---
                    var existingAccess = await _context.Access
                        .FirstOrDefaultAsync(a => a.ScreenId == screenId && a.RoleId == accessRequest.Role_Id);

                    if (existingAccess != null)
                    {
                        var oldValue = JsonSerializer.Serialize(existingAccess);
                        existingAccess.HideShow = access.HideShow;
                        existingAccess.FullAccess = access.FullAccess;
                        existingAccess.ReadOnly = access.ReadOnly;

                        var newValue = JsonSerializer.Serialize(existingAccess);
                        auditLogs.Add(new AuditLog
                        {
                            ActorEmpCode = empCode,
                            ModuleName = "Access Management",
                            ActionType = AuditAction.UPDATE.ToString(),
                            EntityName = AuditEntity.Access.ToString(),
                            OldValue = oldValue,
                            NewValue = newValue,
                            Remarks = $"Updated access for RoleId {accessRequest.Role_Id}, ScreenId {screenId}"
                        });
                    }
                    else
                    {
                        var newAccess = new Access
                        {
                            ScreenId = screenId,
                            ScreenName = access.ScreenName,
                            RoleId = accessRequest.Role_Id,
                            HideShow = access.HideShow,
                            FullAccess = access.FullAccess,
                            ReadOnly = access.ReadOnly
                        };

                        _context.Access.Add(newAccess);
                        auditLogs.Add(new AuditLog
                        {
                            ActorEmpCode = empCode,
                            ModuleName = AuditModule.AccessControl.GetDisplayName(),
                            ActionType = AuditAction.CREATE.ToString(),
                            EntityName = AuditEntity.Access.ToString(),
                            NewValue = JsonSerializer.Serialize(newAccess),
                            Remarks = $"Created access for RoleId {accessRequest.Role_Id}, ScreenId {screenId}"
                        });
                    }

                    // --- Screens Table Insert/Update (with Role name) ---
                    var screenRecord = await _context.screens
                        .FirstOrDefaultAsync(s => s.ScreenId == screenId && s.Role == roleName);

                    if (screenRecord != null)
                    {
                        var oldValue = JsonSerializer.Serialize(screenRecord);
                        screenRecord.IsVisible = access.HideShow;

                        var newValue = JsonSerializer.Serialize(screenRecord);
                        auditLogs.Add(new AuditLog
                        {
                            ActorEmpCode = empCode,
                            ModuleName = AuditModule.ScreenAccess.GetDisplayName(),
                            ActionType = AuditAction.UPDATE.ToString(),
                            EntityName = AuditEntity.Screens.ToString(),
                            OldValue = oldValue,
                            NewValue = newValue,
                            Remarks = $"Updated screen visibility for Role {roleName}, ScreenId {screenId}"
                        });
                    }
                    else
                    {
                        var newScreen = new Screen
                        {
                            ScreenId = screenId,
                            ScreenName = access.ScreenName,
                            Role = roleName,
                            IsVisible = access.HideShow
                        };

                        _context.screens.Add(newScreen);
                        auditLogs.Add(new AuditLog
                        {
                            ActorEmpCode = empCode,
                            ModuleName = AuditModule.ScreenAccess.GetDisplayName(),
                            ActionType = AuditAction.CREATE.ToString(),
                            EntityName = AuditEntity.Screens.ToString(),
                            NewValue = JsonSerializer.Serialize(newScreen),
                            Remarks = $"Created screen visibility for Role {roleName}, ScreenId {screenId}"
                        });
                    }
                }

                await _context.SaveChangesAsync();
                foreach (var log in auditLogs)
                {
                    try
                    {
                        await _auditLogService.LogAsync(log);
                    }
                    catch { }
                }
                return Ok(new { message = "Access & Screen Role mapping saved successfully!" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }

        //GET
        [HttpGet("getaccessbyrole/{RoleId}")]
        public async Task<IActionResult> GetAccessPermissionsByRole(int RoleId)
        {
            try
            {
                // Retrieve distinct access data for the specified role
                var accessData = await _context.Access
                                               .Where(a => a.RoleId == RoleId)
                                               .Join(_context.screens,
                                                     a => a.ScreenId,
                                                     s => s.ScreenId,
                                                     (a, s) => new
                                                     {
                                                         a.ScreenId,
                                                         screenName = a.ScreenName, // Changed to screenname
                                                         a.HideShow,
                                                         a.FullAccess,
                                                         a.ReadOnly,
                                                         s.IsVisible
                                                     })
                                               .GroupBy(x => new { x.ScreenId, x.screenName }) // Group by ScreenId and screenname
                                               .Select(g => g.First()) // Select only the first record from each group
                                               .ToListAsync();

                if (accessData == null || accessData.Count == 0)
                {
                    return NotFound("No access data found for the specified role.");
                }

                return Ok(accessData);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        //POST
        [HttpPost]
        public async Task<IActionResult> CreateUser([FromBody] User newUser)
        {
            int? loggedEmpCode = User.GetEmpCode();

            if (newUser == null || string.IsNullOrEmpty(newUser.Email_Id) || string.IsNullOrEmpty(newUser.Password))
            {
                return BadRequest("Email Id, password, and role are required.");
            }

            // Check if the username already exists
            var existingUser = await _context.Users.FirstOrDefaultAsync(u => u.Email_Id == newUser.Email_Id);
            if (existingUser != null)
            {
                return Conflict("A user with the same Email Id already exists.");
            }

            try
            {
                // Add the new user to the database
                _context.Users.Add(newUser);
                await _context.SaveChangesAsync();

                // Prepare safe audit data (NO password)
                var auditNewValue = new
                {
                    newUser.Emp_code,
                    newUser.Email_Id,
                    newUser.Role_Id
                };

                //  AUDIT LOG (inline, no helper)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = loggedEmpCode,
                        ModuleName = AuditModule.User.ToString(),
                        ActionType = AuditAction.CREATE.ToString(),
                        EntityName = AuditEntity.Users.ToString(),
                        OldValue = null,
                        NewValue = System.Text.Json.JsonSerializer.Serialize(auditNewValue),
                        Remarks = "New user created"
                    });
                }
                catch
                {
                    // Never break user creation because of audit failure
                }

                return CreatedAtAction(nameof(GetUsers), new { id = newUser.Email_Id }, newUser);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        //GET
        [HttpGet("profileInfo")]
        public async Task<ActionResult<profileInfoDto>> GetProfileValues(int EmployeeCode)
        {
            var profileValues = await _context.UserDetails
                .Where(u => u.IsDelete == false && u.Emp_code == EmployeeCode)
                .Select(u => new profileInfoDto
                {
                    Emp_code = u.Emp_code,
                    User_name = u.User_name,
                    Email_Id = u.Email_Id,
                })
                .FirstOrDefaultAsync();
            if (profileValues == null)
            {
                return NotFound("No Employee found.");
            }
            return Ok(profileValues);
        }

        private async Task SafeAuditAsync(
        int? loggedEmpCode,
        string actionType,
        string remarks)
        {
            try
            {
                await _auditLogService.LogAsync(new AuditLog
                {
                    ActorEmpCode = loggedEmpCode,
                    ModuleName = AuditModule.Authentication.ToString(),
                    ActionType = actionType,
                    EntityName = AuditEntity.Users.ToString(),
                    Remarks = remarks
                });
            }
            catch
            {
                // Never break login flow
            }
        }


        private string GenerateJwtToken(int empCode, int roleId, string userName)
        {
            var claims = new List<Claim>
            {
                new Claim("empCode", empCode.ToString()),
                new Claim("roleId", roleId.ToString()),
                new Claim("userName", userName),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var key = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(_configuration["Jwt:Key"])
            );

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(
                    int.Parse(_configuration["Jwt:ExpireMinutes"])
                ),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }


    }
}
