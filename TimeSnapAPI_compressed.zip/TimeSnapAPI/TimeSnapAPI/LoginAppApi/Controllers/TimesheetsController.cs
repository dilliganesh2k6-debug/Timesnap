﻿using LoginAppApi.Data;
using LoginAppApi.Models;
using LoginAppApi.Models.constants;
using LoginAppApi.Models.Dto;
using LoginAppApi.Models.Enums;
using LoginAppApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Text.Json;
using TimeTrackerApplication.Models;
using TimeTrackerApplication.Models.DTOs;
using TimeTrackerApplication.Services;
using Microsoft.AspNetCore.Authorization;
using LoginAppApi.Extensions;
using System.Threading.Tasks;

namespace LoginAppApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class TimesheetsController : ControllerBase
    {
        private readonly ITimesheetService _timesheetService;
        private readonly LoginAppDbContext _context;
        private readonly IEmailService _emailService;
        private readonly IAuditLogService _auditLogService;
        public TimesheetsController(LoginAppDbContext context, ITimesheetService timesheetService, IEmailService emailService, IAuditLogService auditLogService)
        {
            _context = context;
            _timesheetService = timesheetService;
            _emailService = emailService;
            _auditLogService = auditLogService;
        }

        //GET
        [HttpGet("timesheetdetails")]
        public async Task<ActionResult<IEnumerable<object>>> GetTimesheetDetails(int empCode, DateTime startDate, DateTime endDate)
        {
            try
            {
                var details = await (
                    from td in _context.TimesheetDetails
                    join th in _context.TimesheetHeader
                        on td.Timesheet_Id equals th.Timesheet_Id
                    join task in _context.ProjectTasks
                        on td.Task_Id equals task.Task_Id
                    join project in _context.ProjectInfo
                        on td.Project_Id equals project.Project_id
                    join cat in _context.Categories
                         on td.CategoryId equals cat.CategoryId
                    join sub in _context.Tasks
                         on td.SubCategoryId equals sub.Id
                    where td.Emp_code == empCode
                       && td.Date >= startDate
                       && td.Date <= endDate
                       && td.IsDeleted == 0
                    select new
                    {
                        td.Timesheet_Id,
                        td.Emp_code,
                        td.Project_Id,
                        td.Task_Id,
                        td.CategoryId,
                        td.SubCategoryId,
                        CategoryName = cat.CategoryName,
                        SubCategoryName = sub.TaskName,
                        td.Date,
                        td.Hours,
                        td.Status,
                        TaskName = task.Task_Name,
                        ProjectName = project.Project_name,
                        ProjectColor = project.Color_Code,
                    }
                ).ToListAsync();

                if (!details.Any())
                {
                    return Ok(new
                    {
                        message = "No timesheet details found for the specified criteria."
                    });
                }

                var header = await _context.TimesheetHeader
                    .Where(th => th.Emp_code == empCode && th.Start_Date == startDate && th.End_Date == endDate)
                    .Select(th => new { th.Notes, th.Status })
                    .FirstOrDefaultAsync();

                var result = new
                {
                    Notes = header?.Notes,
                    Status = header?.Status,
                    TimesheetDetails = details.Select(d => new
                    {
                        d.Timesheet_Id,
                        d.Emp_code,
                        d.Project_Id,
                        d.Task_Id,
                        Category_Id = d.CategoryId,
                        Sub_Category_Id = d.SubCategoryId,
                        CategoryName = d.CategoryName,
                        SubCategoryName = d.SubCategoryName,
                        d.Date,
                        d.Hours,
                        d.Status,
                        d.TaskName,
                        d.ProjectName,
                        d.ProjectColor
                    })
                };
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    message = "An error occurred while fetching timesheet details.",
                    error = ex.Message
                });
            }
        }



        //POST
        [HttpPost("save")]
        public async Task<IActionResult> SaveTimesheet([FromBody] TimesheetSubmissionRequest request)
        {
            try
            {
                int? loggedEmpCode = User.GetEmpCode();

                int timesheetId = await _timesheetService.SaveTimesheetAsync(request);

                // 🔹 Load header AFTER save
                var header = await _context.TimesheetHeader
                    .FirstOrDefaultAsync(t => t.Timesheet_Id == timesheetId);

                if (header != null)
                {
                    try
                    {
                        await _auditLogService.LogAsync(new AuditLog
                        {
                            ActorEmpCode = loggedEmpCode,
                            TargetEmpCode = header.Emp_code,
                            ModuleName = AuditModule.Timesheet.ToString(),
                            ActionType = AuditAction.SAVE.ToString(),
                            EntityName = nameof(TimesheetHeaderModel),
                            NewValue = JsonSerializer.Serialize(new
                            {
                                header.Timesheet_Id,
                                header.Status,
                                header.Start_Date,
                                header.End_Date
                            }),
                            Remarks = "Timesheet saved (Draft)"
                        });
                    }
                    catch { }
                }

                return Ok(new { TimesheetId = timesheetId });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        
        [HttpPost("SubmitWeek")]
        public async Task<IActionResult> SubmitWeek([FromBody] TimesheetSubmitDto request)
        {
            int? loggedEmpCode = User.GetEmpCode();

            if (request == null || request.EmpCode == 0 ||
                string.IsNullOrEmpty(request.StartDate) ||
                string.IsNullOrEmpty(request.EndDate))
                return BadRequest("Invalid request.");

            if (!DateTime.TryParse(request.StartDate, out var startDate) ||
                !DateTime.TryParse(request.EndDate, out var endDate))
                return BadRequest("Invalid date format.");

            var header = await _context.TimesheetHeader
                .FirstOrDefaultAsync(th =>
                    th.Emp_code == request.EmpCode &&
                    th.Start_Date == startDate &&
                    th.End_Date == endDate);

            if (header == null)
                return NotFound("Timesheet header not found.");

            if (string.Equals(header.Status, "Approved", StringComparison.OrdinalIgnoreCase))
                return BadRequest("Cannot submit. Timesheet already approved.");

            // 🔹 Capture OLD state
            var oldHeaderState = new
            {
                header.Status,
                header.Notes
            };

            // 🔹 Update
            header.Status = "Posted";
            header.Notes = "Timesheet Posted Successfully";
            header.updated_at = DateTime.UtcNow;

            var detailsToUpdate = await _context.TimesheetDetails
                .Where(td => td.Timesheet_Id == header.Timesheet_Id &&
                             td.Emp_code == request.EmpCode &&
                             td.Status != "Approved" && td.IsDeleted == 0)
                .ToListAsync();

            foreach (var detail in detailsToUpdate)
            {
                detail.Status = "Pending";
            }

            // 🔹 Save once
            await _context.SaveChangesAsync();
            await _context.Database.ExecuteSqlRawAsync(
                "EXEC UpdateOverallHours @Timesheet_Id",
                new SqlParameter("@Timesheet_Id", header.Timesheet_Id));

            // =====================================================
            // 🔔 EMAIL NOTIFICATION TO REPORTING MANAGER
            // =====================================================

            // 🔹 Get employee info (submitted employee)
            var employee = await _context.UsersInfo
                .Where(u => u.Emp_code == request.EmpCode)
                .Select(u => new
                {
                    u.User_name,
                    u.Email_Id,
                    u.ReportingId
                })
                .FirstOrDefaultAsync();

            if (employee == null || employee.ReportingId == null)
            {
                // No reporting manager → skip email silently
                return Ok(new
                {
                    message = "Timesheet submitted successfully (no reporting manager found)."
                });
            }

            // 🔹 Get reporting manager info
            var manager = await _context.UsersInfo
                .Where(u => u.Emp_code == employee.ReportingId)
                .Select(u => new
                {
                    u.User_name,
                    u.Email_Id
                })
                .FirstOrDefaultAsync();

            if (manager != null && !string.IsNullOrWhiteSpace(manager.Email_Id))
            {
                await _emailService.SendEmailAsync(new EmailRequestDto
                {
                    To = manager.Email_Id,
                    Subject = $"Timesheet Submitted – {employee.User_name}",
                    HtmlBody = $@"
                <p>Hello <b>{manager.User_name}</b>,</p>

                <p><b>{employee.User_name}</b> has submitted their timesheet for the week 
                <b>{header.Start_Date:dd MMM yyyy} – {header.End_Date:dd MMM yyyy}</b>.</p>

                <p>Please review and approve it in the system.</p>

                <br/>
                <p>Regards,<br/>
                <b>CI-TimeSnap</b></p>
                "
                });
            }
            // 🔹 AUDIT (correct place)
            await LogAuditAsync(
                request.EmpCode,
                AuditModule.Timesheet.ToString(),
                AuditAction.SUBMIT.ToString(),
                nameof(TimesheetHeaderModel),
                header.Timesheet_Id.ToString(),
                oldHeaderState,
                new { header.Status, header.Notes },
                "Timesheet submitted (Posted)"
            );

            return Ok(new { message = "Timesheet submitted (Posted) successfully." });
        }


        //UPDATE
        [HttpPost("UpdateTimesheetStatus")]
        public async Task<IActionResult> UpdateTimesheetStatus([FromBody] TimesheetStatusUpdateDto request)
        {
            if (request.StartDate == null || request.EndDate == null)
            {
                return BadRequest("Start date and end date are required.");
            }

            if (request.EmpCode == 0)
            {
                return BadRequest("Employee code is required");
            }

            if (!DateTime.TryParse(request.StartDate, out DateTime parsedStartDate) ||
            !DateTime.TryParse(request.EndDate, out DateTime parsedEndDate))
            {
                return BadRequest("Invalid date format.");
            }

            var timesheets = await _context.TimesheetHeader
            .Where(t => t.Emp_code == request.EmpCode && t.Start_Date >= parsedStartDate && t.End_Date <= parsedEndDate)
            .ToListAsync();

            if (timesheets.Count == 0)
            {
                return NotFound("No timesheets found for the given date range.");
            }

            var oldSnapshot = timesheets.Select(t => new
            {
                t.Timesheet_Id,
                t.Status,
                t.Notes
            }).ToList();

            foreach (var timesheet in timesheets)
            {
                timesheet.Status = request.Status;
                timesheet.Notes = "Timesheet Posted Successfully";
                timesheet.updated_at = DateTime.UtcNow;
                var declinedTasks = await _context.TimesheetDetails
                .Where(td => td.Timesheet_Id == timesheet.Timesheet_Id &&
                         td.Emp_code == request.EmpCode &&
                         td.Status == TimesheetConstants.Status.Declined && td.IsDeleted == 0)
            .ToListAsync();

                foreach (var task in declinedTasks)
                {
                    task.Status = TimesheetConstants.Status.Pending;
                    _context.TimesheetDetails.Update(task);
                }
            }

            await _context.SaveChangesAsync();

            // 🔹 AUDIT
            try
            {
                await _auditLogService.LogAsync(new AuditLog
                {
                    ActorEmpCode = User.GetEmpCode(),
                    TargetEmpCode = request.EmpCode,
                    ModuleName = AuditModule.Timesheet.ToString(),
                    ActionType = AuditAction.UPDATE.ToString(),
                    EntityName = nameof(TimesheetHeaderModel),
                    OldValue = JsonSerializer.Serialize(oldSnapshot),
                    NewValue = JsonSerializer.Serialize(timesheets.Select(t => new
                    {
                        t.Timesheet_Id,
                        t.Status,
                        t.Notes
                    })),
                    Remarks = "Timesheet status updated (date range)"
                });
            }
            catch { }

            return Ok(new { message = "Timesheets updated successfully" });
        }

        //GET
        [HttpGet("checktaskstatus")]
        public async Task<IActionResult> CheckTaskStatus(int empCode, DateTime startDate, DateTime endDate)
        {
            try
            {
                var timesheetHeader = await _context.TimesheetHeader
                    .Where(th => th.Emp_code == empCode
                        && th.Start_Date == startDate
                        && th.End_Date == endDate)
                    .FirstOrDefaultAsync();

                if (timesheetHeader == null)
                {
                    return Ok(new { canDelete = true, hasApprovedTasks = false });
                }

                var hasApprovedTasks = await _context.TimesheetDetails
             .AnyAsync(td => td.Timesheet_Id == timesheetHeader.Timesheet_Id
                 && td.Status == "Approved" && td.IsDeleted == 0);
                return Ok(new
                {
                    canDelete = !hasApprovedTasks,
                    hasApprovedTasks = hasApprovedTasks,
                    headerStatus = timesheetHeader.Status
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        //DELETE
        [HttpPost("deletetask")]
        public async Task<IActionResult> DeleteTask(int empCode, int taskId, int projectId, int categoryId, int subCategoryId, DateTime startDate, DateTime endDate)
        {
            try
            {
                int? loggedEmpCode = User.GetEmpCode();
                var timesheetHeader = await _context.TimesheetHeader
                    .Where(th => th.Emp_code == empCode
                            && th.Start_Date == startDate
                            && th.End_Date == endDate)
                    .FirstOrDefaultAsync();

                // If no timesheet header found → allow frontend delete only
                if (timesheetHeader == null)
                {
                    return Ok(new { message = "True", canDelete = true });
                }

                // Only allow delete for Draft or Pending Timesheets
                if (!(string.Equals(timesheetHeader.Status, "Draft") ||
                      string.Equals(timesheetHeader.Status, "Pending")))
                {
                    return BadRequest(new
                    {
                        message = "Only Draft or Pending timesheets allow task deletion.",
                        canDelete = false
                    });
                }

                // Fetch all task entries related to this task under same timesheet
                var allEntries = await _context.TimesheetDetails
                    .Where(td => td.Timesheet_Id == timesheetHeader.Timesheet_Id
                            && td.Task_Id == taskId
                            && td.Project_Id == projectId
                            && td.CategoryId == categoryId
                            && td.SubCategoryId == subCategoryId
                            && td.IsDeleted == 0)
                    .ToListAsync();

                if (!allEntries.Any())
                {
                    return Ok(new { message = "True", canDelete = true });
                }

                // 🔹 Capture OLD state BEFORE delete
                var deletedSnapshot = allEntries.Select(e => new
                {
                    e.Timesheet_Id,
                    e.Task_Id,
                    e.Project_Id,
                    e.Date,
                    e.Hours,
                    e.Status
                }).ToList();

                var approvedCount = allEntries.Count(td => td.Status == "Approved");
                var declinedCount = allEntries.Count(td => td.Status == "Declined");
                var pendingCount = allEntries.Count(td => td.Status == "Pending");
                var draftCount = allEntries.Count(td => td.Status == "Draft");
                var total = allEntries.Count;

                // Case 1: All Approved
                if (approvedCount == total)
                {
                    return BadRequest(new
                    {
                        message = "All tasks are fully Approved.",
                        canDelete = false
                    });
                }

                // Case 2: All Pending
                if (pendingCount == total)
                {
                    return BadRequest(new
                    {
                        message = "Tasks are not yet Approved or Declined.",
                        canDelete = false
                    });
                }

                // Case 3: Mixed ANY Status → BLOCK (Fix for Case 6)
                if ((approvedCount > 0 && declinedCount > 0) ||
                    (approvedCount > 0 && pendingCount > 0) ||
                    (declinedCount > 0 && pendingCount > 0))
                {
                    return BadRequest(new
                    {
                        message = "Some tasks are Approved or Declined.",
                        canDelete = false
                    });
                }

                // Check if all tasks are in Draft status
                bool allDraft = draftCount == total;
                int rowsAffected = 0;
                if (allDraft)
                {
                    // Hard delete for Draft tasks
                    _context.TimesheetDetails.RemoveRange(allEntries);
                    rowsAffected = await _context.SaveChangesAsync();
                }
                else
                {
                    // Soft delete for non-Draft tasks using stored procedure
                    var rowsAffectedParam = new SqlParameter("@RowsAffected", SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };
                    var deleteParameters = new[]
                    {
                        new SqlParameter("@TimesheetId", timesheetHeader.Timesheet_Id),
                        new SqlParameter("@TaskId", taskId),
                        new SqlParameter("@ProjectId", projectId),
                        new SqlParameter("@CategoryId", categoryId),
                        new SqlParameter("@SubCategoryId", subCategoryId),
                        rowsAffectedParam
                    };

                    await _context.Database.ExecuteSqlRawAsync(
                        "EXEC DeleteTimesheetTask @TimesheetId, @TaskId, @ProjectId, @CategoryId, @SubCategoryId, @RowsAffected OUTPUT",
                        deleteParameters);
                    rowsAffected = (int)rowsAffectedParam.Value;
                }

                if (rowsAffected > 0)
                {
                    // 1. Update Hours via SP
                    await _context.Database.ExecuteSqlRawAsync(
                        "EXEC UpdateOverallHours @Timesheet_Id",
                        new SqlParameter("@Timesheet_Id", timesheetHeader.Timesheet_Id));
                    // 2. Refresh Header from DB to get updated Overall_Hours
                    await _context.Entry(timesheetHeader).ReloadAsync();
                    // 3. Fetch all remaining active tasks
                    var activeDetails = await _context.TimesheetDetails
                        .Where(td => td.Timesheet_Id == timesheetHeader.Timesheet_Id && td.IsDeleted == 0)
                        .ToListAsync();
                    string userMessage = "Task deleted successfully.";
                    bool statusChanged = false;
                    // 4. Synchronization Logic
                    if (activeDetails.Any())
                    {
                        // Removed auto-approve logic as per request.
                        // Timesheet remains in current status (Pending/Draft)
                    }
                    else
                    {
                        // No tasks left? Reset total hours and move to Draft
                        timesheetHeader.Status = "Draft";
                        timesheetHeader.Overall_Hours = 0;
                        userMessage = "Last task deleted. Timesheet reverted to Draft.";
                        statusChanged = true;
                    }
                    if (statusChanged)
                    {
                        timesheetHeader.updated_at = DateTime.Now;
                        _context.Entry(timesheetHeader).Property(x => x.Computed_Timesheet_Id).IsModified = false;
                        await _context.SaveChangesAsync();
                    }
                    try
                    {
                        await _auditLogService.LogAsync(new AuditLog
                        {
                            ActorEmpCode = loggedEmpCode,
                            TargetEmpCode = empCode,    
                            ModuleName = AuditModule.Timesheet.ToString(),
                            ActionType = AuditAction.DELETE.ToString(),
                            EntityName = nameof(TimesheetDetailsModel),
                            OldValue = JsonSerializer.Serialize(deletedSnapshot),
                            NewValue = null,
                            Remarks = "Task deleted from timesheet"
                        });
                    }
                    catch
                    {
                        // Ignore audit log failures
                    }

                    return Ok(new
                    {
                        message = userMessage,
                        canDelete = true,
                        currentStatus = timesheetHeader.Status,
                        totalHours = timesheetHeader.Overall_Hours
                    });
                }
                return Ok(new { message = "True", canDelete = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        //GET
        [HttpGet("MyTimesheet")]
        public async Task<IActionResult> MyTimesheet(int empCode, int roleId)
        {
            // Get role name for reference
            var roleName = await _context.Roles
                .Where(r => r.RoleId == roleId)
                .Select(r => r.RoleTitle)
                .FirstOrDefaultAsync();

            // STEP 1: Remove manager duplicates (Project-wise MAX)
            var projectWise = await _context.TimesheetApproval
                .Where(t => t.EmployeeCode == empCode)
                .GroupBy(t => new { t.TimesheetId, t.ProjectId })
                .Select(g => new
                {
                    g.Key.TimesheetId,
                    ProjectTotalHours = g.Max(x =>
                        Convert.ToDecimal(x.ProjectTotalHours))
                })
                .ToListAsync();

            // STEP 2: Combine project totals into timesheet total
            var timesheetTotals = projectWise
                .GroupBy(x => x.TimesheetId)
                .Select(g => new
                {
                    TimesheetId = g.Key,
                    TotalHours = g.Sum(x => x.ProjectTotalHours)
                })
                .ToList();

            // STEP 3: Join back with one representative row per timesheet
            var finalResult = await _context.TimesheetApproval
                .Where(t => t.EmployeeCode == empCode)
                .GroupBy(t => new
                {
                    t.TimesheetId,
                    t.ComputedTimesheetId,
                    t.EmployeeCode,
                    t.EmployeeName,
                    t.WeekRange,
                    t.Status,
                    t.Notes,
                    t.ReportingId,
                    t.ReportingToName
                })
                .Select(g => new
                {
                    g.Key.TimesheetId,
                    g.Key.ComputedTimesheetId,
                    g.Key.EmployeeCode,
                    g.Key.EmployeeName,
                    g.Key.WeekRange,
                    g.Key.Status,
                    g.Key.Notes,
                    g.Key.ReportingId,
                    g.Key.ReportingToName
                })
                .ToListAsync();
            var result = finalResult
                  .Join(timesheetTotals,
                        t => t.TimesheetId,
                        h => h.TimesheetId,
                        (t, h) => new
                        {
                            t.TimesheetId,
                            t.ComputedTimesheetId,
                            t.EmployeeCode,
                            t.EmployeeName,
                            t.WeekRange,
                            TotalHours = h.TotalHours.ToString("0.00"),
                            t.Status,
                            t.Notes,
                            t.ReportingId,
                            t.ReportingToName
                        })
                  .OrderBy(t => t.Status == "Posted" ? 0 :
                                t.Status == "Pending" ? 1 :
                                t.Status == "Approved" ? 2 : 3)
                  .ThenByDescending(t => t.TimesheetId)
                  .ToList();

            return Ok(result);
        }

        //GET
        [HttpGet("GetTimesheetApprovals")]
        public async Task<IActionResult> GetTimesheetApprovals()
        {
            int empCode = User.GetEmpCode();
            // step:1 Get user info
            var user = await _context.UsersInfo
                .Where(u => u.Emp_code == empCode)
                .Select(u => new { u.Reportingrights })
                .FirstOrDefaultAsync();

            if (user == null)
                return NotFound("User not found.");

            var userdetails = await _context.UserDetails
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.Emp_code == empCode && !u.IsDelete);

            if (userdetails == null)
                return NotFound("User not found.");

            bool isAdmin = userdetails.IsAdmin;
            bool hasReportingRights = user.Reportingrights == true;

            // step:2 Get project IDs managed by this user
            var managedProjectIds = await _context.ProjectManagers
                .Where(pm => pm.ManagerId == empCode && pm.IsActive)
                .Select(pm => pm.ProjectId)
                .ToListAsync();

            bool isProjectManager = managedProjectIds.Any();

            // Common projection
            var baseQuery = _context.TimesheetApproval
                .Select(t => new
                {
                    t.TimesheetId,
                    t.ComputedTimesheetId,
                    t.EmployeeCode,
                    t.EmployeeName,
                    t.WeekStartDate,
                    t.WeekRange,
                    t.ProjectId,
                    t.ProjectName,
                    Hours = t.ProjectTotalHours,
                    t.Status,
                    t.ProjectStatus,
                    t.Notes,
                    t.ReportingId,
                    t.ReportingToName,
                    t.ApprovedCount
                });

            // ================= ADMIN =================
            if (isAdmin)
            {
                var raw = await baseQuery.ToListAsync();

                var deduped = GroupByTimesheetAndProject(
                    raw,
                    x => x.TimesheetId,
                    x => x.ProjectId
                );

                var ordered = deduped
                    .OrderBy(x => x.ProjectStatus == "Posted" ? 0 :
                                  x.ProjectStatus == "Pending" ? 1 :
                                  x.ProjectStatus == "Approved" ? 2 : 3)
                    .ThenByDescending(x => x.WeekStartDate)
                    .ThenBy(x => x.EmployeeCode)
                    .ThenBy(x => x.ProjectName)
                    .ToList();

                return Ok(new
                {
                    hasApprovalAccess = true,
                    isAdmin = true,
                    isReportingManager = false,
                    isProjectManager = false,
                    timesheetApprovals = ordered
                });
            }

            // ================= REPORTING + PROJECT MANAGER =================
            if (hasReportingRights && isProjectManager)
            {
                var reportingData = await baseQuery
                    .Where(t => t.ReportingId == empCode)
                    .ToListAsync();

                var projectData = await baseQuery
                    .Where(t => managedProjectIds.Contains(t.ProjectId))
                    .ToListAsync();

                var combined = GroupByTimesheetAndProject(
                    reportingData.Union(projectData),
                    x => x.TimesheetId,
                    x => x.ProjectId
                );

                var ordered = combined
                    .OrderBy(x => x.ProjectStatus == "Posted" ? 0 :
                                  x.ProjectStatus == "Pending" ? 1 :
                                  x.ProjectStatus == "Approved" ? 2 : 3)
                    .ThenByDescending(x => x.WeekStartDate)
                    .ThenBy(x => x.EmployeeCode)
                    .ThenBy(x => x.ProjectName)
                    .ToList();

                return Ok(new
                {
                    hasApprovalAccess = true,
                    isAdmin = false,
                    isReportingManager = true,
                    isProjectManager = true,
                    timesheetApprovals = ordered
                });
            }

            // ================= REPORTING MANAGER ONLY =================
            if (hasReportingRights)
            {
                var raw = await baseQuery
                    .Where(t => t.ReportingId == empCode)
                    .ToListAsync();

                var deduped = GroupByTimesheetAndProject(
                    raw,
                    x => x.TimesheetId,
                    x => x.ProjectId
                );

                return Ok(new
                {
                    hasApprovalAccess = true,
                    isAdmin = false,
                    isReportingManager = true,
                    isProjectManager = false,
                    timesheetApprovals = deduped
                });
            }

            // ================= PROJECT MANAGER ONLY =================
            if (isProjectManager)
            {
                var raw = await baseQuery
                    .Where(t => managedProjectIds.Contains(t.ProjectId))
                    .ToListAsync();

                var deduped = GroupByTimesheetAndProject(
                    raw,
                    x => x.TimesheetId,
                    x => x.ProjectId
                );

                return Ok(new
                {
                    hasApprovalAccess = true,
                    isAdmin = false,
                    isReportingManager = false,
                    isProjectManager = true,
                    timesheetApprovals = deduped
                });
            }

            // ================= NO ACCESS =================
            return Ok(new
            {
                hasApprovalAccess = false,
                message = "User does not have reporting or project manager approval rights."
            });
        }

        //UPDATE
        [HttpPost("UpdateTimesheetStatus/{timesheetId}")]
        public async Task<IActionResult> UpdateTimesheetStatus(int timesheetId, [FromBody] LoginAppApi.Models.TimesheetNotesUpdateDto request)
        {
            var header = await _context.TimesheetHeader.FindAsync(timesheetId);
            if (header == null)
                return NotFound($"Timesheet with ID {timesheetId} not found.");

            var details = await _context.TimesheetDetails
                .Where(d => d.Timesheet_Id == timesheetId && d.IsDeleted == 0 && d.Status != "Draft")
                .ToListAsync();

            var oldHeader = JsonSerializer.Serialize(new
            {
                header.Status,
                header.Notes
            });

            var oldDetails = JsonSerializer.Serialize(details.Select(d => new
            {
                d.Task_Id,
                d.Project_Id,
                d.Date,
                d.Status
            }));

            int updatedCount = 0;

            bool isReportingManager = header.Reporting_To_Id == request.UserId;
            var managedProjectIds = await _context.ProjectManagers
                .Where(pm => pm.ManagerId == request.UserId && pm.IsActive)
                .Select(pm => pm.ProjectId)
                .ToListAsync();

            var userTasks = details
                .Where(d => managedProjectIds.Contains(d.Project_Id))
                .ToList();

            bool isProjectManager = userTasks.Any();

            int updatedTaskCount = 0;

            if (isProjectManager && request.TaskUpdates?.Any() == true)
            {
                foreach (var update in request.TaskUpdates)
                {
                    var taskToUpdate = userTasks.FirstOrDefault(t =>
                        t.Task_Id == update.TaskId && t.Date.Date == update.Date.Date);

                    if (taskToUpdate != null)
                    {
                        taskToUpdate.Status = update.Status;
                        updatedTaskCount++;
                    }
                }
            }

            if (isReportingManager)
            {
                bool allTasksReviewed = details.All(d => !string.IsNullOrEmpty(d.Status));

                if (!allTasksReviewed)
                {
                    await _context.SaveChangesAsync();
                    return Ok(new
                    {
                        Message = $"{updatedTaskCount} task(s) updated. Header not updated because not all tasks are reviewed."
                    });
                }

                header.Status = request.Status;
                header.Notes = request.Notes;
            }

            if (!isProjectManager && !isReportingManager)
            {
                return Forbid("You are not authorized to update this timesheet.");
            }

            await _context.SaveChangesAsync();

            // 🔹 AUDIT
            try
            {
                await _auditLogService.LogAsync(new AuditLog
                {
                    ActorEmpCode = request.UserId,
                    TargetEmpCode = header.Emp_code,
                    ModuleName = AuditModule.Timesheet.ToString(),
                    ActionType = request.Status,
                    EntityName = nameof(TimesheetHeaderModel),
                    OldValue = oldHeader,
                    NewValue = JsonSerializer.Serialize(new
                    {
                        header.Status,
                        header.Notes
                    }),
                    Remarks = $"{updatedCount} task(s) updated, timesheet {request.Status}"
                });
            }
            catch { }

            return Ok(new
            {
                Message = $"{updatedTaskCount} task(s) updated.{(isReportingManager ? " Timesheet header updated." : "")}"
            });
        }

        //GET
        [HttpGet("GetTimesheetDetails/{timesheetId}/{projectId?}")]
        public async Task<IActionResult> GetTimesheetDetails(int timesheetId, int? projectId = null)
        {
            var query =
                from td in _context.TimesheetDetails

                // Project
                join pi in _context.ProjectInfo on td.Project_Id equals pi.Project_id into projectGroup
                from pi in projectGroup.DefaultIfEmpty()

                // Task
                join t in _context.ProjectTasks on td.Task_Id equals t.Task_Id into taskGroup
                from t in taskGroup.DefaultIfEmpty()

                 // Category
                join c in _context.Categories
                    on td.CategoryId equals c.CategoryId into categoryGroup
                from c in categoryGroup.DefaultIfEmpty()

                 // SubCategory
                join s in _context.Tasks
                    on td.SubCategoryId equals s.Id into subCategoryGroup
                from s in subCategoryGroup.DefaultIfEmpty()

                // User
                join ud in _context.UserDetails on td.Emp_code equals ud.Emp_code into userGroup
                from ud in userGroup.DefaultIfEmpty()

                where td.Timesheet_Id == timesheetId && td.IsDeleted ==0
                select new
                {
                    TimesheetId = td.Timesheet_Id,
                    ProjectId = td.Project_Id,
                    ProjectName = pi != null ? pi.Project_name : null,
                    TaskId = td.Task_Id,
                    TaskName = t != null ? t.Task_Name : null,
                    CategoryId = td.CategoryId,
                    CategoryName = c != null ? c.CategoryName : null,
                    SubCategoryId = td.SubCategoryId,
                    SubCategoryName = s != null ? s.TaskName : null,
                    td.Date,
                    EmployeeCode = td.Emp_code,
                    EmployeeName = ud != null ? ud.User_name : null,
                    td.Hours,
                    td.Status,
                    IsDeleted = td.IsDeleted,  
                };

            // Optional filter by projectId
            if (projectId.HasValue && projectId.Value > 0)
            {
                query = query.Where(td => td.ProjectId == projectId.Value);
            }

            var details = await query
                .OrderBy(d => d.ProjectName)
                .ThenBy(d => d.Date)
                .ToListAsync();

            if (!details.Any())
                return NotFound(new { message = $"No details found for Timesheet ID {timesheetId}" });

            return Ok(details);
        }

        //GET
        [HttpGet("GetApprovalStatusCountsByEmployee")]
        public async Task<IActionResult> GetApprovalStatusCounts(int empCode)
        {
            var statusCounts = await _context.TimesheetHeader
                .Where(t => t.Emp_code == empCode)
                .GroupBy(t => t.Status)
                .Select(g => new { Status = g.Key, Count = g.Count() })
                .ToListAsync();
            if (!statusCounts.Any())
            {
                return Ok("No status records found for this employee.");
            }
            return Ok(new { EmpCode = empCode, StatusCounts = statusCounts });
        }

        //GET
        [HttpGet("GetApprovalStatusCounts")]
        public async Task<IActionResult> GetTimesheetStatusCounts(int empCode)
        {
            var user = await _context.UsersInfo
                .Where(u => u.Emp_code == empCode)
                .Select(u => new { u.Role_name, u.Reportingrights })
                .FirstOrDefaultAsync();

            if (user == null)
                return NotFound("User not found.");

            var userdetails = await _context.UserDetails
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.Emp_code == empCode && !u.IsDelete);

            if (userdetails == null)
                return NotFound("User not found.");

            bool isAdmin = userdetails.IsAdmin;

            List<TimesheetApproval> raw;

            if (isAdmin)
            {
                raw = await _context.TimesheetApproval.ToListAsync();
            }
            else
            {
                var projectIds = await _context.ProjectManagers
                    .Where(pm => pm.ManagerId == empCode && pm.IsActive)
                    .Select(pm => pm.ProjectId)
                    .ToListAsync();

                raw = await _context.TimesheetApproval
                    .Where(t => t.ReportingId == empCode || projectIds.Contains(t.ProjectId))
                    .ToListAsync();
            }
            // remove duplicates
            var distinct = GroupByTimesheetAndProject(
                raw,
                x => x.TimesheetId,
                x => x.ProjectId
            );

            // count correctly
            var statusCounts = distinct
                .GroupBy(x => x.ProjectStatus)
                .Select(g => new
                {
                    Status = g.Key,
                    Count = g.Count()
                })
                .ToList();

            return Ok(new
            {
                IsAdmin = isAdmin,
                StatusCounts = statusCounts
            });
        }

        //GET
        [HttpGet("GetProjectsByEmpCode")]
        public async Task<IActionResult> GetProjectsByEmpCode([FromQuery] int empCode)
        {
            if (empCode <= 0)
            {
                return BadRequest("Invalid employee code.");
            }
            var projects = await (from pm in _context.ProjectMembersView
                                  join pi in _context.ProjectInfo on pm.Projectid equals pi.Project_id
                                  where pm.EmpCode == empCode && !pm.IsDelete
                                  where pm.EmpCode == empCode && !pm.IsDelete && pi.Status_Id == 1
                                  select new
                                  {
                                      pi.Project_id,
                                      pi.Project_name,
                                      pi.Color_Code
                                  })
                                 .ToListAsync();
            return Ok(projects);
        }

       
        //POST

        [HttpPost("DeclineTasks")]
        public async Task<IActionResult> DeclineTasks([FromBody] DeclineTasksRequestDto request)
        {
            if (request == null || request.Tasks == null || request.Tasks.Count == 0)
                return BadRequest("Invalid task decline request.");
            try
            {
                int actorEmpCode = request.ManagerEmpCode;
                int? loggedEmpCode = User.GetEmpCode();
                int targetEmpCode = request.Tasks
                    .Select(t => t.EmpCode)
                    .Distinct()
                    .Single();

                // 🔹 Identify actor role
                var user = await _context.UsersInfo
                    .Where(u => u.Emp_code == actorEmpCode)
                    .Select(u => new { u.Role_name, u.Reportingrights })
                    .FirstOrDefaultAsync();

                if (user == null)
                    return BadRequest("User not found.");

                var userdetails = await _context.UserDetails
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.Emp_code == loggedEmpCode && !u.IsDelete);

                if (userdetails == null)
                    return NotFound("User not found.");

                bool isAdmin = userdetails.IsAdmin;

                bool isReportingManager = user.Reportingrights == true;
                // 🔹 Load all details
                var allDetails = await _context.TimesheetDetails
                    .Where(td => td.Timesheet_Id == request.TimesheetId && td.IsDeleted == 0 && td.Status != "Draft")
                    .ToListAsync();

                if (!allDetails.Any())
                    return BadRequest("No timesheet details found.");

                // 🔹 CAPTURE OLD STATE (before decline)
                var oldSnapshot = allDetails.Select(d => new
                {
                    d.Task_Id,
                    d.Project_Id,
                    d.Date,
                    d.Status
                }).ToList();

                // 🔹 Determine allowed tasks
                List<TimesheetDetailsModel> allowedTasks = new();

                if (isAdmin)
                {
                    allowedTasks = allDetails;
                }
                else
                {
                    bool isReportingManagerForThisTimesheet = await _context.TimesheetHeader
                        .AnyAsync(th =>
                            th.Timesheet_Id == request.TimesheetId &&
                            th.Reporting_To_Id == actorEmpCode);

                    if (isReportingManagerForThisTimesheet)
                    {
                        allowedTasks = allDetails;
                    }
                    else
                    {
                        var managedProjectIds = await _context.ProjectManagers
                            .Where(pm => pm.ManagerId == actorEmpCode && pm.IsActive)
                            .Select(pm => pm.ProjectId)
                            .ToListAsync();

                        if (managedProjectIds.Any())
                        {
                            allowedTasks = allDetails
                                .Where(td => managedProjectIds.Contains(td.Project_Id))
                                .ToList();
                        }
                    }
                }

                if (!allowedTasks.Any())
                    return BadRequest("You are not authorized to decline this timesheet.");

                // 🔹 Decline allowed tasks
                foreach (var task in request.Tasks)
                {
                    var detail = allowedTasks.FirstOrDefault(t =>
                        t.Task_Id == task.TaskId &&
                        t.Project_Id == task.ProjectId &&
                        t.CategoryId == task.CategoryId && 
                        t.SubCategoryId == task.SubCategoryId &&
                        t.Date.Date == task.Date.Date);
                        
                    if (detail != null)
                        detail.Status = "Declined";
                }

                await _context.SaveChangesAsync();

                bool allApproved = await _context.TimesheetDetails
                    .Where(td => td.Timesheet_Id == request.TimesheetId && td.IsDeleted == 0 && td.Status != "Draft")
                    .AllAsync(td => td.Status == "Approved");

                // 🔹 Update header
                int empCode = request.Tasks.First().EmpCode;

                var header = await _context.TimesheetHeader
                    .FirstOrDefaultAsync(th =>
                        th.Timesheet_Id == request.TimesheetId &&
                        th.Emp_code == empCode);

                if (header != null)
                {
                    header.Status = allApproved ? "Approved" : "Pending";
                    header.Notes = request.Notes;
                    header.updated_at = DateTime.Now;

                    _context.Entry(header)
                        .Property(x => x.Computed_Timesheet_Id)
                        .IsModified = false;
                }

                // 🔹 Insert decline note
                if (!string.IsNullOrWhiteSpace(request.Notes))
                {
                    await _context.TimesheetNotes.AddAsync(new TimesheetNotes
                    {
                        Timesheet_Id = request.TimesheetId,
                        Emp_code = empCode,
                        Manager_Emp_code = actorEmpCode,
                        Note = request.Notes,
                        Note_DateTime = DateTime.Now
                    });
                }

                await _context.SaveChangesAsync();



                // ================= EMAIL NOTIFICATION =================

                // Get employee info
                var employee = await _context.UsersInfo
                    .Where(u => u.Emp_code == empCode)
                    .Select(u => new
                    {
                        u.User_name,
                        u.Email_Id
                    })
                    .FirstOrDefaultAsync();

                // Get manager info
                var manager = await _context.UsersInfo
                    .Where(u => u.Emp_code == loggedEmpCode)
                    .Select(u => new
                    {
                        u.User_name,
                        u.Email_Id
                    })
                    .FirstOrDefaultAsync();

                // Fetch updated timesheet entries with project & task
                // 🔹 Fetch only Approved / Declined entries for this timesheet
                var tasks = await (
                     from t in _context.TimesheetDetails
                     join p in _context.ProjectInfo
                         on t.Project_Id equals p.Project_id
                     join pt in _context.ProjectTasks
                         on new { t.Project_Id, t.Task_Id }
                         equals new { pt.Project_Id, pt.Task_Id }
                     where t.Timesheet_Id == header.Timesheet_Id
                           && t.Status == "Declined"
                     select new
                     {
                         t.Date,
                         t.Hours,
                         ProjectName = p.Project_name,
                         TaskName = pt.Task_Name
                     }
                 ).ToListAsync();


                if (employee != null && !string.IsNullOrWhiteSpace(employee.Email_Id))
                {
                    string subject = "Timesheet Declined";

                    string body = $@"<p>Hello <b>{employee.User_name}</b>,</p>

                    <p>Your timesheet for the week 
                    <b>{header.Start_Date:dd MMM yyyy} – {header.End_Date:dd MMM yyyy}</b> 
                    has been <b>declined</b>.</p>";


                    body += $@"
                    <table style='width:100%; border-collapse:collapse; margin-bottom:5px;'>
                    <tr>
                    <td style='text-align:left; font-weight:bold;'>
                    Declined Entries:
                    </td>
                    <td style='text-align:right;'>
                    <b>Reviewed by:</b> {manager.User_name}
                    </td>
                    </tr>
                    </table>";
                    body += @"
                    <table border='1' cellpadding='8' cellspacing='0' 
                    style='border-collapse:collapse; width:100%; font-family:Segoe UI, Arial, sans-serif; font-size:14px;'>
                    <tr style='background-color:#f2f2f2;'>
                    <th>Date</th>
                    <th>Project</th>
                    <th>Task</th>
                    <th>Hours</th>
                    </tr>";

                    body += string.Join("", tasks.Select(t => $@"
                    <tr>
                    <td>{t.Date:dd MMM yyyy}</td>
                    <td>{t.ProjectName}</td>
                    <td>{t.TaskName}</td>
                    <td>{t.Hours}</td>
                    </tr>
                    "));

                    body += "</table>";

                    body += $@"
                    <p><b>Reason:</b><br/>
                    {request.Notes}</p>

                    <p>Please update and resubmit your timesheet.</p>

                    <br/>
                    <p>Regards,<br/>
                    <b>CI-TimeSnap</b></p>";

                    await _emailService.SendEmailAsync(new EmailRequestDto
                    {
                        To = employee.Email_Id,
                        Subject = subject,
                        HtmlBody = body
                    });
                }


                // 🔹 CAPTURE NEW STATE (after decline)
                var newSnapshot = await _context.TimesheetDetails
                    .Where(td => td.Timesheet_Id == request.TimesheetId && td.IsDeleted == 0 && td.Status != "Draft")
                    .Select(d => new
                    {
                        d.Task_Id,
                        d.Project_Id,
                        d.Date,
                        d.Status
                    })
                    .ToListAsync();

                // 🔹 AUDIT LOG (safe)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = actorEmpCode,
                        TargetEmpCode = targetEmpCode,
                        ModuleName = AuditModule.Timesheet.ToString(),
                        ActionType = AuditAction.DECLINE.ToString(),
                        EntityName = nameof(TimesheetHeaderModel),
                        OldValue = JsonSerializer.Serialize(oldSnapshot),
                        NewValue = JsonSerializer.Serialize(newSnapshot),
                        Remarks = "Tasks declined"
                    });
                }
                catch
                {
                    // 🔕 Never block decline flow if audit fails
                }

                return Ok(new
                {
                    message = "Tasks declined successfully.",
                    headerStatus = allApproved ? "Approved" : "Pending"
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        //POST
        [HttpPost("ApproveTasks")]
        public async Task<IActionResult> ApproveTasks([FromBody] ApproveTasksRequestDto request)
        {
            if (request == null || request.Tasks == null || !request.Tasks.Any())
                return BadRequest("Invalid task approve request.");

            try
            {
                int actorEmpCode = request.ManagerEmpCode;
                int? loggedEmpCode = User.GetEmpCode();
                int targetEmpCode = request.Tasks
                    .Select(t => t.EmpCode)
                    .Distinct()
                    .Single();

                // 🔹 Load header FIRST
                var header = await _context.TimesheetHeader
                    .FirstOrDefaultAsync(th => th.Timesheet_Id == request.TimesheetId);

                if (header == null)
                    return BadRequest("Timesheet not found.");

                // 🔹 Identify actor role
                var user = await _context.UsersInfo
                    .Where(u => u.Emp_code == actorEmpCode)
                    .Select(u => new { u.Role_name, u.Reportingrights })
                    .FirstOrDefaultAsync();

                if (user == null)
                    return BadRequest("User not found.");

                var userdetails = await _context.UserDetails
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.Emp_code == loggedEmpCode && !u.IsDelete);

                if (userdetails == null)
                    return NotFound("User not found.");

                bool isAdmin = userdetails.IsAdmin;

                // 🔹 Load all details
                var allDetails = await _context.TimesheetDetails
                    .Where(td => td.Timesheet_Id == request.TimesheetId && td.IsDeleted == 0 && td.Status != "Draft")
                    .ToListAsync();

                if (!allDetails.Any())
                    return BadRequest("No tasks found.");

                // 🔹 CAPTURE OLD STATE (before approval)
                var oldSnapshot = allDetails.Select(d => new
                {
                    d.Task_Id,
                    d.Project_Id,
                    d.Date,
                    d.Status
                }).ToList();

                // 🔹 Determine allowed tasks
                List<TimesheetDetailsModel> allowedTasks;

                if (isAdmin)
                {
                    allowedTasks = allDetails;
                }
                else
                {
                    // RM check (for this timesheet only)
                    bool isRMForThisTimesheet =
                        header.Reporting_To_Id == actorEmpCode;

                    if (isRMForThisTimesheet)
                    {
                        allowedTasks = allDetails;
                    }
                    else
                    {
                        // PM check
                        var managedProjectIds = await _context.ProjectManagers
                            .Where(pm => pm.ManagerId == actorEmpCode && pm.IsActive)
                            .Select(pm => pm.ProjectId)
                            .ToListAsync();

                        allowedTasks = allDetails
                            .Where(td => managedProjectIds.Contains(td.Project_Id))
                            .ToList();
                    }
                }

                if (!allowedTasks.Any())
                    return BadRequest("You are not authorized to approve this timesheet.");

                // 🔹 Approve ONLY selected tasks
                foreach (var task in request.Tasks)
                {
                    var detail = allowedTasks.FirstOrDefault(t =>
                        t.Task_Id == task.TaskId &&
                        t.Project_Id == task.ProjectId &&
                        t.CategoryId == task.CategoryId &&
                        t.SubCategoryId == task.SubCategoryId &&
                        t.Date == task.Date);

                    if (detail != null && detail.Status != "Approved")
                    {
                        detail.Status = "Approved";
                    }
                }

                await _context.SaveChangesAsync();

                // 🔹 Re-check final status AFTER update
                bool allApproved = await _context.TimesheetDetails
                    .Where(td => td.Timesheet_Id == request.TimesheetId && td.IsDeleted == 0 && td.Status != "Draft")
                    .AllAsync(td => td.Status == "Approved");

                if (allApproved)
                {
                    header.Status = "Approved";
                    header.Notes = "Timesheet Approved Successfully.";
                    header.updated_at = DateTime.Now;

                    await _context.TimesheetNotes.AddAsync(new TimesheetNotes
                    {
                        Timesheet_Id = request.TimesheetId,
                        Emp_code = header.Emp_code,
                        Manager_Emp_code = actorEmpCode,
                        Note = "Timesheet Approved Successfully.",
                        Note_DateTime = DateTime.Now
                    });
                }
                else
                {
                    // Partial approval → Pending (only if not already Approved)
                    header.Status = "Pending";
                    header.updated_at = DateTime.Now;
                }

                await _context.SaveChangesAsync();

                // ================= EMAIL NOTIFICATION =================

                // Get employee info
                var employee = await _context.UsersInfo
                    .Where(u => u.Emp_code == header.Emp_code)
                    .Select(u => new
                    {
                        u.User_name,
                        u.Email_Id
                    })
                    .FirstOrDefaultAsync();

                // Get manager info
                var manager = await _context.UsersInfo
                    .Where(u => u.Emp_code == actorEmpCode)
                    .Select(u => new
                    {
                        u.User_name,
                        u.Email_Id
                    })
                    .FirstOrDefaultAsync();

                if (employee != null && !string.IsNullOrWhiteSpace(employee.Email_Id))
                {
                    string subject = allApproved
                        ? "Timesheet Approved"
                        : "Timesheet Partially Approved";

                    string body = $@"
                    <p>Hello <b>{employee.User_name}</b>,</p>

                    <p>Your timesheet for the week 
                    <b>{header.Start_Date:dd MMM yyyy} – {header.End_Date:dd MMM yyyy}</b> 
                    has been <b>{(allApproved ? "approved" : "partially approved")}</b>.</p>

                    <p><b>Reviewed by:</b> {manager.User_name}</p>

                    <br/>
                    <p>Regards,<br/>
                    <b>CI-TimeSnap</b></p>
                    ";

                    await _emailService.SendEmailAsync(new EmailRequestDto
                    {
                        To = employee.Email_Id,
                        Subject = subject,
                        HtmlBody = body
                    });
                }


                // 🔹 CAPTURE NEW STATE (after approval)
                var newSnapshot = await _context.TimesheetDetails
                    .Where(td => td.Timesheet_Id == request.TimesheetId)
                    .Select(d => new
                    {
                        d.Task_Id,
                        d.Project_Id,
                        d.Date,
                        d.Status
                    })
                    .ToListAsync();

                // 🔹 AUDIT LOG (safe)
                try
                {
                    await _auditLogService.LogAsync(new AuditLog
                    {
                        ActorEmpCode = loggedEmpCode,
                        TargetEmpCode = targetEmpCode,
                        ModuleName = AuditModule.Timesheet.ToString(),
                        ActionType = AuditAction.APPROVE.ToString(),
                        EntityName = nameof(TimesheetHeaderModel),
                        OldValue = JsonSerializer.Serialize(oldSnapshot),
                        NewValue = JsonSerializer.Serialize(newSnapshot),
                        Remarks = allApproved
                            ? "Timesheet fully approved"
                            : "Tasks partially approved"
                    });
                }
                catch
                {
                    // 🔕 Never block approval if audit fails
                }

                return Ok(new
                {
                    message = allApproved
                        ? "Timesheet fully approved."
                        : "Tasks approved successfully.",
                    allApproved
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        //GET
        [HttpGet("GetNotes")]
        public async Task<IActionResult> GetNotes(int timesheetId, int empCode)
        {
            var notes = await _context.TimesheetNotes
                .Where(n => n.Timesheet_Id == timesheetId && n.Emp_code == empCode)
                .OrderByDescending(n => n.Note_DateTime)
                .Select(n => new TimesheetNotesDto
                {
                    Note_Id = n.Note_Id,
                    Note = n.Note,
                    Note_DateTime = n.Note_DateTime,
                    Manager_Emp_code = n.Manager_Emp_code
                })
                .ToListAsync();

            if (notes == null || !notes.Any())
                return NotFound("No notes found for this timesheet.");

            return Ok(notes);
        }

        //GET
        [HttpGet("usersbyreportingid")]
        public async Task<ActionResult<IEnumerable<DropdownItemDto>>> GetUsersByReportingId([FromQuery] int? empCode)
        {
            if (!empCode.HasValue)
            {
                return BadRequest(new { message = "empCode is required." });
            }

            var users = await _context.UsersInfo
                .Where(u => u.ReportingId == empCode.Value)
                .Select(u => new DropdownItemDto
                {
                    Id = u.Emp_code.ToString(),
                    Name = u.User_name
                })
                .ToListAsync();

            return Ok(users);
        }

        private async Task LogAuditAsync(
            int loggedEmpCode,
            
            string module,
            string action,
            string entity,
            string entityId,
            object? oldValue,
            object? newValue,
            string remarks)
        {
            await _auditLogService.LogAsync(new AuditLog
            {
                ActorEmpCode = loggedEmpCode,
                TargetEmpCode = loggedEmpCode,
                ModuleName = module,
                ActionType = action,
                EntityName = entity,
                OldValue = oldValue == null ? null : System.Text.Json.JsonSerializer.Serialize(oldValue),
                NewValue = newValue == null ? null : System.Text.Json.JsonSerializer.Serialize(newValue),
                Remarks = remarks
            });
        }

        [HttpPost("test-mail")]
        [AllowAnonymous] // optional – remove in prod
        public async Task<IActionResult> SendTestMail([FromQuery] string toEmail)
        {
            if (string.IsNullOrWhiteSpace(toEmail))
                return BadRequest("Email address is required.");

            try
            {
                await _emailService.SendEmailAsync(new EmailRequestDto
                {
                    To = toEmail,
                    Subject = "SMTP Test Email",
                    HtmlBody = @"
                <h3>SMTP Test Successful ✅</h3>
                <p>This email confirms that Office365 SMTP is working.</p>
                <p><b>Time:</b> " + DateTime.Now.ToString("dd MMM yyyy HH:mm") + @"</p>"
                });

                return Ok(new
                {
                    message = "Test email sent successfully.",
                    to = toEmail
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    message = "Failed to send test email.",
                    error = ex.Message
                });
            }
        }


        // collapse duplicate rows caused by multiple project managers
        private static List<T> GroupByTimesheetAndProject<T>(
        IEnumerable<T> data,
        Func<T, int> timesheetIdSelector,
        Func<T, int> projectIdSelector)
        {
            return data
                .GroupBy(x => new
                {
                    TimesheetId = timesheetIdSelector(x),
                    ProjectId = projectIdSelector(x)
                })
                .Select(g => g.First())
                .ToList();
        }
    }
}
