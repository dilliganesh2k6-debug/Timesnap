﻿using LoginAppApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LoginAppApi.Controllers
{
    //[Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class AuditLogsController : ControllerBase
    {
        private readonly IAuditLogService _auditLogService;

        public AuditLogsController(IAuditLogService auditLogService)
        {
            _auditLogService = auditLogService;
        }

        // =========================================================
        // 🔹 GET ALL AUDIT LOGS (NO PARAMETERS)
        // =========================================================
        // GET: /api/auditlogs
        [HttpGet]
        public async Task<IActionResult> GetAllAuditLogs()
        {
            var logs = await _auditLogService.GetAllAuditLogsAsync();
            return Ok(logs);
        }

        // =========================================================
        // 🔹 GET AUDIT LOGS WITH PARAMETERS
        // =========================================================
        // GET: /api/auditlogs/search
        [HttpGet("search")]
        public async Task<IActionResult> SearchAuditLogs(
            int page = 1,
            int pageSize = 20,
            string? moduleName = null,
            string? actionType = null,
            int? actorEmpCode = null,
            int? targetEmpCode = null,
            DateTime? fromDate = null,
            DateTime? toDate = null)
        {
            var result = await _auditLogService.GetAuditLogsAsync(
                page,
                pageSize,
                moduleName,
                actionType,
                actorEmpCode,
                targetEmpCode,
                fromDate,
                toDate
            );

            return Ok(new
            {
                page,
                pageSize,
                totalRecords = result.TotalCount,
                data = result.Logs
            });
        }
    }
}
