﻿using LoginAppApi.Models;
using System.Threading.Tasks;
using TimeTrackerApplication.Models;

namespace LoginAppApi.Repositories.Interfaces

{ 
    public interface ITimesheetRepository 
    { 
        Task<int> InsertOrUpdateTimesheetHeader(TimesheetHeaderModel timesheet); 
        Task<bool> InsertOrUpdateTimesheetDetails(TimesheetDetailsModel details);  
        Task<bool> UpdateOverallHours(int timesheetId); 
    } 
}

