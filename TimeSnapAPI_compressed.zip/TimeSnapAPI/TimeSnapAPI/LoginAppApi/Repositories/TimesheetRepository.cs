﻿using Dapper;
using System.Data;
using System.Threading.Tasks;
using LoginAppApi.Models;
using LoginAppApi.Repositories.Interfaces;
using TimeTrackerApplication.Models;

namespace LoginAppApi.Repositories
{ 
    public class TimesheetRepository : ITimesheetRepository
    { 
        private readonly IDbConnection _dbConnection; 
        public TimesheetRepository(IDbConnection dbConnection) 
        { 
            _dbConnection = dbConnection; 
        }
        public async Task<int> InsertOrUpdateTimesheetHeader(TimesheetHeaderModel timesheet)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Emp_code", timesheet.Emp_code);
            parameters.Add("@Start_Date", timesheet.Start_Date);
            parameters.Add("@End_Date", timesheet.End_Date);
            parameters.Add("@Timesheet_Id", dbType: DbType.Int32, direction: ParameterDirection.Output);
            await _dbConnection.ExecuteAsync("InsertOrUpdateTimesheetHeader", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@Timesheet_Id"); // Return generated Timesheet_Id
        }

        public async Task<bool> InsertOrUpdateTimesheetDetails(TimesheetDetailsModel details)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Timesheet_Id", details.Timesheet_Id);
            parameters.Add("@Emp_code", details.Emp_code);
            parameters.Add("@Task_Id", details.Task_Id);
            parameters.Add("@Project_Id", details.Project_Id);
            parameters.Add("@Date", details.Date);
            parameters.Add("@Hours", details.Hours);
            int rowsAffected = await _dbConnection.ExecuteAsync("InsertOrUpdateTimesheetDetails", parameters, commandType: CommandType.StoredProcedure);
            return rowsAffected > 0;
        }

        public async Task<bool> UpdateOverallHours(int timesheetId)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Timesheet_Id", timesheetId);
            int rowsAffected = await _dbConnection.ExecuteAsync("UpdateOverallHours", parameters, commandType: CommandType.StoredProcedure);
            return rowsAffected > 0;
        }
    }
}

